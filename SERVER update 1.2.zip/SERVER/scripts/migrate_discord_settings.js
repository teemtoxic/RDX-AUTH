const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// THE CORRECT PATH as per .env and db.js
const dbPath = path.join(__dirname, '..', 'database', 'rdx_auth.db');
const db = new sqlite3.Database(dbPath);

console.log('Migrating database at:', dbPath);

db.serialize(() => {
    // Add columns to users table if they don't exist
    const columns = [
        { name: 'discord_server_id', type: 'TEXT' },
        { name: 'discord_log_channel_id', type: 'TEXT' },
        { name: 'discord_role_id', type: 'TEXT' }
    ];

    columns.forEach(col => {
        db.run(`ALTER TABLE users ADD COLUMN ${col.name} ${col.type}`, (err) => {
            if (err) {
                if (err.message.includes('duplicate column name')) {
                    console.log(`Column ${col.name} already exists.`);
                } else {
                    console.error(`Error adding column ${col.name}:`, err.message);
                }
            } else {
                console.log(`Column ${col.name} added successfully.`);
            }
        });
    });
});

db.close();
