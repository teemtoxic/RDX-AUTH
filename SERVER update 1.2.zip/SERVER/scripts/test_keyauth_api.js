const axios = require('axios');

async function testInit() {
    try {
        const response = await axios.post('http://localhost:5000/api/1.3/', {
            type: 'init',
            name: 'RDX_App', // Fake app name (handled gently if it doesn't exist)
            ownerid: 'your_ownerid',
            version: '1.0'
        }, {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' } // KeyAuth uses Form Urlencoded usually
        });

        console.log('API Response:', response.data);
    } catch (error) {
        console.error('API Error:', error.response ? error.response.data : error.message);
    }
}

testInit();
