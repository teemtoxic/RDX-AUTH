const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.join(__dirname, '..', 'database', 'rdx_auth.db');
const db = new sqlite3.Database(dbPath);

db.run("UPDATE users SET role = 'admin', plan = 'pro' WHERE email = 'noobgameryt12630@gmail.com'", function (err) {
    if (err) {
        console.error('Error:', err.message);
    } else {
        console.log(`Successfully updated user. Changes: ${this.changes}`);
    }
    db.close();
});
