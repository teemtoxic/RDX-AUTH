const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, '..', 'database', 'rdx_auth.db');
const db = new sqlite3.Database(dbPath);

console.log('Migrating database for Support Tickets at:', dbPath);

db.serialize(() => {
    // Create Tickets Table
    db.run(`
        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            subject TEXT NOT NULL,
            status TEXT DEFAULT 'pending', -- pending, open, resolved, closed
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    `, (err) => {
        if (err) console.error('Error creating tickets table:', err.message);
        else console.log('Tickets table ready.');
    });

    // Create Ticket Messages Table
    db.run(`
        CREATE TABLE IF NOT EXISTS ticket_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id INTEGER,
            sender_id INTEGER,
            message TEXT NOT NULL,
            attachment_url TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (ticket_id) REFERENCES tickets(id),
            FOREIGN KEY (sender_id) REFERENCES users(id)
        )
    `, (err) => {
        if (err) console.error('Error creating ticket_messages table:', err.message);
        else console.log('Ticket messages table ready.');
    });
});

db.close();
