const axios = require('axios');
const crypto = require('crypto');
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');
const path = require('path');

const BASE_URL = 'http://localhost:5000/rdx/api/licenses';
const MOCK_LICENSE = 'RDX-TEST-ADVANCED-HWID';
const APP_SECRET = 'test_secret_123';
const OWNER_ID = 999;
const APP_ID = 999;

async function setupMockData() {
    const dbPath = path.join(__dirname, '../database/rdx_auth.db');
    const db = await open({ filename: dbPath, driver: sqlite3.Database });

    // Insert Mock User
    await db.run('INSERT OR IGNORE INTO users (id, username, email) VALUES (?, ?, ?)', [OWNER_ID, 'test_owner', 'test@rdx.com']);

    // Insert Mock App with anti-cheat enabled
    await db.run(
        'INSERT OR IGNORE INTO apps (id, name, owner_id, owner_key, secret, anti_debug, anti_vm) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [APP_ID, 'TestApp_Advanced', OWNER_ID, OWNER_ID.toString(), APP_SECRET, 1, 1]
    );

    // Insert Mock Variable
    await db.run('DELETE FROM variables WHERE app_id = ?', [APP_ID]);
    await db.run('INSERT INTO variables (app_id, name, value) VALUES (?, ?, ?)', [APP_ID, 'ESP_Offset', '0x1337BEEF']);
    await db.run('INSERT INTO variables (app_id, name, value) VALUES (?, ?, ?)', [APP_ID, 'GodMode', 'true']);

    // Delete existing mock license to reset state
    await db.run('DELETE FROM licenses WHERE license_key = ?', [MOCK_LICENSE]);

    // Insert new fresh license
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + 30);
    await db.run(
        'INSERT INTO licenses (license_key, app_id, user_id, expiry_date, status) VALUES (?, ?, ?, ?, ?)',
        [MOCK_LICENSE, APP_ID, OWNER_ID, expiry.toISOString(), 'active']
    );

    console.log('[*] Mock Data Setup Complete\n');
}

async function testValidation(hardwareInfo) {
    const timestamp = Date.now().toString();
    const dataToSign = `${MOCK_LICENSE}${hardwareInfo.id}${OWNER_ID}${timestamp}`;
    const signature = crypto.createHmac('sha256', APP_SECRET).update(dataToSign).digest('hex');

    try {
        const response = await axios.post(`${BASE_URL}/validate`, {
            license_key: MOCK_LICENSE,
            owner_id: OWNER_ID.toString(),
            timestamp: timestamp,
            hardware_info: hardwareInfo
        }, {
            headers: { 'x-signature': signature }
        });

        let varStr = response.data.variables ? `| Variables Loaded: ${Object.keys(response.data.variables).length}` : '';
        console.log(`[SUCCESS] ${hardwareInfo.test_case}:`, response.data.message, varStr);
    } catch (error) {
        console.error(`[FAILED] ${hardwareInfo.test_case}:`, error.response ? error.response.data.message : error.message);
    }
}

async function runTests() {
    await setupMockData();

    const originalHWID = {
        test_case: 'Initial Binding (Fresh License)',
        id: 'LEGACY-123',
        baseboard: 'BASE-111',
        cpu: 'CPU-222',
        mac: 'MAC-333',
        is_debug: false,
        is_vm: false
    };

    const sameHWID = {
        test_case: 'Return Login (Same Device)',
        id: 'LEGACY-123',
        baseboard: 'BASE-111',
        cpu: 'CPU-222',
        mac: 'MAC-333',
        is_debug: false,
        is_vm: false
    };

    const spoofedMacHWID = {
        test_case: 'Tolerated Change (Spoofed MAC only)',
        id: 'LEGACY-123',
        baseboard: 'BASE-111',
        cpu: 'CPU-222',
        mac: 'MAC-HACKER-000', // Changed
        is_debug: false,
        is_vm: false
    };

    const totallySpoofedHWID = {
        test_case: 'Spoofed Device (Changed CPU & Baseboard)',
        id: 'LEGACY-999',
        baseboard: 'BASE-HACKER',
        cpu: 'CPU-HACKER',
        mac: 'MAC-HACKER-000',
        is_debug: false,
        is_vm: false
    };

    const debuggerAttached = {
        test_case: 'Anti-Debug Check (Debugger Attached)',
        id: 'LEGACY-123',
        baseboard: 'BASE-111',
        cpu: 'CPU-222',
        mac: 'MAC-333',
        is_debug: true, // Malicious
        is_vm: false
    };

    // Run tests sequentially
    await testValidation(originalHWID); // Should succeed and bind
    await new Promise(r => setTimeout(r, 500));

    await testValidation(sameHWID); // Should succeed
    await new Promise(r => setTimeout(r, 500));

    await testValidation(spoofedMacHWID); // Should succeed (Tolerance allowed)
    await new Promise(r => setTimeout(r, 500));

    await testValidation(totallySpoofedHWID); // Should FAIL
    await new Promise(r => setTimeout(r, 500));

    await testValidation(debuggerAttached); // Should FAIL (Security Alert)
}

runTests();
