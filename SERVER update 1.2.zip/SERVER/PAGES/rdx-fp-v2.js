/**
 * RDX Advanced Browser Fingerprinting Engine (v2)
 * Used to identify unique browser environments for non-HWID sessions.
 */
window.RDX_FP = (function() {
    const getCanvasFingerprint = () => {
        try {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) return 'no-canvas';
            
            ctx.textBaseline = "top";
            ctx.font = "14px 'Arial'";
            ctx.textBaseline = "alphabetic";
            ctx.fillStyle = "#f60";
            ctx.fillRect(125,1,62,20);
            ctx.fillStyle = "#069";
            ctx.fillText("RDX-Secure-FP", 2, 15);
            ctx.fillStyle = "rgba(102, 204, 0, 0.7)";
            ctx.fillText("RDX-Secure-FP", 4, 17);
            return canvas.toDataURL();
        } catch(e) { return 'canvas-blocked'; }
    };

    const getWebGLFingerprint = () => {
        try {
            const canvas = document.createElement('canvas');
            const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
            if (!gl) return 'no-webgl';
            
            const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
            if (!debugInfo) return 'no-debug-info';
            
            return gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) + '|' + gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
        } catch(e) { return 'webgl-blocked'; }
    };

    const getAudioFingerprint = () => {
        try {
            const context = new (window.AudioContext || window.webkitAudioContext)();
            return context.sampleRate;
        } catch (e) {
            return 'no-audio';
        }
    };

    const hashString = (str) => {
        let hash = 0;
        if (str.length === 0) return hash;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash |= 0; // Convert to 32bit integer
        }
        return Math.abs(hash).toString(16);
    };

    const generate = () => {
        const components = [
            navigator.userAgent,
            navigator.language,
            screen.colorDepth,
            screen.width + 'x' + screen.height,
            new Date().getTimezoneOffset(),
            !!window.sessionStorage,
            !!window.localStorage,
            !!window.indexedDB,
            getCanvasFingerprint(),
            getWebGLFingerprint(),
            getAudioFingerprint()
        ];
        
        const raw = components.join('###');
        return hashString(raw);
    };

    return {
        get: () => {
            let fp = localStorage.getItem('rdx_fp_v2');
            if (!fp) {
                fp = generate();
                localStorage.setItem('rdx_fp_v2', fp);
            }
            return fp;
        },
        refresh: () => {
            const fp = generate();
            localStorage.setItem('rdx_fp_v2', fp);
            return fp;
        }
    };
})();

// Auto-initialize
(function() {
    const fp = RDX_FP.get();
    localStorage.setItem('rdx_fp', fp); // Backwards compatibility
    console.log('[RDX] Advanced Fingerprint Generated:', fp);
})();
