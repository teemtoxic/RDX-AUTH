using System;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq; // Requires Newtonsoft.Json

namespace RDX_SDK
{
    public class RDX
    {
        private static string appName;
        private static string ownerId;
        private static string secret;
        private static string apiUrl;

        public static System.Collections.Generic.Dictionary<string, string> Variables { get; private set; } = new System.Collections.Generic.Dictionary<string, string>();

        public static void Initialize(string name, string oid, string sec, string baseUrl = "https://rdxcommunity.qzz.io/rdx/api")
        {
            appName = name;
            ownerId = oid;
            secret = sec;

            if (baseUrl.EndsWith("/"))
                baseUrl = baseUrl.Substring(0, baseUrl.Length - 1);

            apiUrl = baseUrl + "/license/validate";
        }

        public static void SetApiUrl(string url)
        {
            apiUrl = url;
        }

        public static Task<(bool success, string message)> Login(string licenseKey)
        {
            return PerformLogin("license", licenseKey);
        }

        public static Task<(bool success, string message)> Login(string username, string password)
        {
            return PerformLogin("member", username, password);
        }

        private static async Task<(bool success, string message)> PerformLogin(string type, string primary, string secondary = "")
        {
            try
            {
                if (string.IsNullOrEmpty(appName)) 
                    return (false, "RDX SDK not initialized.");

                long timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
                string hwid = GetHWID();

                string endpoint = apiUrl;
                var payload = new JObject();
                string dataToSign;

                if (type == "license")
                {
                    dataToSign = primary + hwid + ownerId + timestamp;
                    payload["license_key"] = primary;
                }
                else
                {
                    // Member Login endpoint change
                    endpoint = apiUrl.Replace("license/validate", "auth/login");
                    dataToSign = primary + secondary + hwid + ownerId + timestamp;
                    payload["username"] = primary;
                    payload["password"] = secondary;
                }

                // Generate Signature
                string signature = HmacSha256(dataToSign, secret);

                using (var client = new HttpClient())
                {
                    payload["hwid"] = hwid;
                    payload["app_name"] = appName;
                    payload["owner_id"] = ownerId;
                    payload["timestamp"] = timestamp;
                    payload["signature"] = signature;

                    var content = new StringContent(payload.ToString(), Encoding.UTF8, "application/json");
                    var response = await client.PostAsync(endpoint, content);
                    var responseStr = await response.Content.ReadAsStringAsync();
                    var json = JObject.Parse(responseStr);

                    bool success = (bool)json["success"];
                    string message = (string)json["message"];

                    if (success && json["variables"] != null)
                    {
                        Variables = json["variables"].ToObject<System.Collections.Generic.Dictionary<string, string>>();
                    }

                    return (success, message);
                }
            }
            catch (Exception ex)
            {
                return (false, "Error: " + ex.Message);
            }
        }

        public static string GetVariable(string key)
        {
            if (Variables != null && Variables.ContainsKey(key))
            {
                return Variables[key];
            }
            return null; // Variable not found
        }

        private static string GetHWID()
        {
            // Simple HWID for Windows (using SID or similar)
            // In a real app, use DeviceId or Hardware Identifier libraries
            return System.Security.Principal.WindowsIdentity.GetCurrent().User.Value;
        }

        private static string HmacSha256(string data, string key)
        {
            byte[] keyBytes = Encoding.UTF8.GetBytes(key);
            using (var hmac = new HMACSHA256(keyBytes))
            {
                byte[] hashBytes = hmac.ComputeHash(Encoding.UTF8.GetBytes(data));
                return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            }
        }
    }
}
