package com.chad;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * RDX Auth SDK for Android
 * Secure, Reusable, and Easy to Integrate.
 */
public class RDX {
    private static String appName;
    private static String ownerId;
    private static String secret;
    private static String apiUrl = "https://rdxcommunity.qzz.io/rdx/api/license/validate"; // Default
    private static Context context;
    private static JSONObject variables = new JSONObject();

    public interface AuthCallback {
        void onSuccess(String message, JSONObject info);

        void onError(String error);
    }

    /**
     * Initialize the SDK with your App Credentials
     */
    public static void initialize(Context ctx, String name, String oid, String sec) {
        context = ctx.getApplicationContext();
        appName = name;
        ownerId = oid;
        secret = sec;
    }

    /**
     * Set custom API URL if needed
     */
    public static void setApiUrl(String url) {
        apiUrl = url;
    }

    /**
     * Validate License Key
     */
    public static void login(final String licenseKey, final AuthCallback callback) {
        performLogin("license", licenseKey, null, callback);
    }

    /**
     * Login with Username and Password
     */
    public static void login(final String username, final String password, final AuthCallback callback) {
        performLogin("member", username, password, callback);
    }

    private static void performLogin(final String type, final String primary, final String secondary,
            final AuthCallback callback) {
        if (appName == null || ownerId == null || secret == null) {
            callback.onError("RDX SDK not initialized. Call RDX.initialize() first.");
            return;
        }

        final Handler mainHandler = new Handler(Looper.getMainLooper());

        new Thread(() -> {
            try {
                long timestamp = System.currentTimeMillis();
                String hwid = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);

                JSONObject payload = new JSONObject();
                String dataToSign;
                String endpoint;

                if (type.equals("license")) {
                    endpoint = apiUrl; // http://.../api/license/validate
                    payload.put("license_key", primary);
                    dataToSign = primary + hwid + ownerId + timestamp;
                } else {
                    // Change endpoint to login
                    endpoint = apiUrl.replace("license/validate", "auth/login");
                    payload.put("username", primary);
                    payload.put("password", secondary);
                    dataToSign = primary + secondary + hwid + ownerId + timestamp;
                }

                String signature = hmacSha256(dataToSign, secret);
                payload.put("hwid", hwid);
                payload.put("app_name", appName);
                payload.put("owner_id", ownerId);
                payload.put("timestamp", timestamp);
                payload.put("signature", signature);

                URL url = new URL(endpoint);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setDoOutput(true);
                conn.setConnectTimeout(15000);

                OutputStream os = conn.getOutputStream();
                os.write(payload.toString().getBytes("UTF-8"));
                os.close();

                int responseCode = conn.getResponseCode();
                BufferedReader reader;
                if (responseCode >= 200 && responseCode < 300) {
                    reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                } else {
                    reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                }

                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null)
                    sb.append(line);
                reader.close();

                final JSONObject response = new JSONObject(sb.toString());
                final boolean success = response.optBoolean("success");
                final String message = response.optString("message", "Unknown response");

                if (success && response.has("variables")) {
                    variables = response.optJSONObject("variables");
                }

                mainHandler.post(() -> {
                    if (success) {
                        callback.onSuccess(message, response.optJSONObject("info"));
                    } else {
                        callback.onError(message);
                    }
                });

            } catch (final Exception e) {
                mainHandler.post(() -> callback.onError("Network Error: " + e.getMessage()));
            }
        }).start();
    }

    /**
     * Get a remote variable after successful login
     */
    public static String getVariable(String key) {
        if (variables != null && variables.has(key)) {
            return variables.optString(key, null);
        }
        return null; // Local default if not found
    }

    private static String hmacSha256(String data, String key) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            SecretKeySpec secretKey = new SecretKeySpec(key.getBytes("UTF-8"), "HmacSHA256");
            mac.init(secretKey);
            byte[] bytes = mac.doFinal(data.getBytes("UTF-8"));
            StringBuilder hash = new StringBuilder();
            for (byte b : bytes) {
                String hex = Integer.toHexString(0xFF & b);
                if (hex.length() == 1)
                    hash.append('0');
                hash.append(hex);
            }
            return hash.toString();
        } catch (Exception e) {
            return "";
        }
    }
}
