#pragma once
#include <iostream>
#include <string>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <openssl/hmac.h> // Requires OpenSSL
#include <curl/curl.h>    // Requires libcurl

/**
 * RDX Auth C++ SDK
 * Note: Requires libcurl and OpenSSL
 */
class RDX {
private:
    static std::string appName;
    static std::string ownerId;
    static std::string secret;
    static std::string apiUrl;
    static std::string serverData;

    static std::string hmac_sha256(std::string data, std::string key) {
        unsigned char hash[32];
        unsigned int len = 32;
        HMAC(EVP_sha256(), key.c_str(), key.length(), (unsigned char*)data.c_str(), data.length(), hash, &len);
        
        std::stringstream ss;
        for(int i = 0; i < 32; i++)
            ss << std::hex << std::setw(2) << std::setfill('0') << (int)hash[i];
        return ss.str();
    }

    static size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
        ((std::string*)userp)->append((char*)contents, size * nmemb);
        return size * nmemb;
    }

public:
    static void Initialize(std::string name, std::string oid, std::string sec, std::string url = "https://rdxcommunity.qzz.io/rdx/api/license/validate") {
        appName = name;
        ownerId = oid;
        secret = sec;
        apiUrl = url;
    }

    struct Response {
        bool success;
        std::string message;
    };

    static Response Login(std::string licenseKey) {
        return PerformLogin("license", licenseKey);
    }

    static Response Login(std::string username, std::string password) {
        return PerformLogin("member", username, password);
    }

private:
    static Response PerformLogin(std::string type, std::string primary, std::string secondary = "") {
        if (appName.empty()) return { false, "SDK not initialized" };

        CURL* curl = curl_easy_init();
        if (!curl) return { false, "CURL Init Failed" };

        auto now = std::chrono::system_clock::now();
        auto timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count();
        
        std::string hwid = "HWID_PLACEHOLDER"; // Implement native HWID logic here
        
        std::string endpoint = apiUrl;
        std::string jsonPayload;
        std::string dataToSign;

        if (type == "license") {
            dataToSign = primary + hwid + ownerId + std::to_string(timestamp);
            jsonPayload = "{\"license_key\":\"" + primary + "\","
                          "\"hwid\":\"" + hwid + "\","
                          "\"app_name\":\"" + appName + "\","
                          "\"owner_id\":\"" + ownerId + "\","
                          "\"timestamp\":\"" + std::to_string(timestamp) + "\","
                          "\"signature\":\"" + hmac_sha256(dataToSign, secret) + "\"}";
        } else {
            // Member Login logic
            size_t pos = endpoint.find("license/validate");
            if (pos != std::string::npos) {
                endpoint.replace(pos, 16, "auth/login");
            }
            dataToSign = primary + secondary + hwid + ownerId + std::to_string(timestamp);
            jsonPayload = "{\"username\":\"" + primary + "\","
                          "\"password\":\"" + secondary + "\","
                          "\"hwid\":\"" + hwid + "\","
                          "\"app_name\":\"" + appName + "\","
                          "\"owner_id\":\"" + ownerId + "\","
                          "\"timestamp\":\"" + std::to_string(timestamp) + "\","
                          "\"signature\":\"" + hmac_sha256(dataToSign, secret) + "\"}";
        }

        std::string responseString;
        struct curl_slist* headers = NULL;
        headers = curl_slist_append(headers, "Content-Type: application/json");

        curl_easy_setopt(curl, CURLOPT_URL, endpoint.c_str());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonPayload.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseString);

        CURLcode res = curl_easy_perform(curl);
        curl_easy_cleanup(curl);

        if (res != CURLE_OK) return { false, "CURL Error" };

        bool success = (responseString.find("\"success\":true") != std::string::npos);
        if(success) {
            serverData = responseString; // Cache response for variable extraction
        }
        return { success, responseString };
    }

public:

    /**
     * Get a remote variable after successful login (Basic raw text search)
     * For production, parse the JSON properly using a library.
     */
    static std::string GetVariable(std::string key) {
        if(serverData.empty()) return "";
        std::string search = "\"" + key + "\":\"";
        size_t start = serverData.find(search);
        if (start == std::string::npos) return "";
        start += search.length();
        size_t end = serverData.find("\"", start);
        if (end == std::string::npos) return "";
        return serverData.substr(start, end - start);
    }
};

// Initialize static members
std::string RDX::appName = "";
std::string RDX::ownerId = "";
std::string RDX::secret = "";
std::string RDX::apiUrl = "";
std::string RDX::serverData = "";
