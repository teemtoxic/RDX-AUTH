#include <iostream>
#include <string>
#include <vector>
#include <windows.h>
#include <iphlpapi.h>
#pragma comment(lib, "iphlpapi.lib")

// Helper function to execute command and get output (for WMIC)
std::string execCommand(const char* cmd) {
    char buffer[128];
    std::string result = "";
    FILE* pipe = _popen(cmd, "r");
    if (!pipe) return "ERROR";
    while (fgets(buffer, sizeof(buffer), pipe) != NULL) {
        result += buffer;
    }
    _pclose(pipe);

    // Clean up newlines and extra spaces
    result.erase(result.find_last_not_of(" \n\r\t") + 1);
    return result;
}

std::string getCPUId() {
    // Get CPU ID using WMIC
    std::string cpuId = execCommand("wmic cpu get ProcessorId /format:list");
    size_t pos = cpuId.find("=");
    if (pos != std::string::npos) {
        return cpuId.substr(pos + 1);
    }
    return "UNKNOWN_CPU";
}

std::string getBaseboardId() {
    // Get Motherboard Serial Number using WMIC
    std::string baseboard = execCommand("wmic baseboard get serialnumber /format:list");
    size_t pos = baseboard.find("=");
    if (pos != std::string::npos) {
        return baseboard.substr(pos + 1);
    }
    return "UNKNOWN_BASEBOARD";
}

std::string getMACAddress() {
    IP_ADAPTER_INFO AdapterInfo[16];
    DWORD dwBufLen = sizeof(AdapterInfo);
    DWORD dwStatus = GetAdaptersInfo(AdapterInfo, &dwBufLen);
    if (dwStatus != ERROR_SUCCESS) return "UNKNOWN_MAC";

    PIP_ADAPTER_INFO pAdapterInfo = AdapterInfo;
    char macAddr[18];
    snprintf(macAddr, sizeof(macAddr), "%02X:%02X:%02X:%02X:%02X:%02X",
        pAdapterInfo->Address[0], pAdapterInfo->Address[1],
        pAdapterInfo->Address[2], pAdapterInfo->Address[3],
        pAdapterInfo->Address[4], pAdapterInfo->Address[5]);

    return std::string(macAddr);
}

// Anti-Debugger Check Example
bool checkDebugger() {
    return IsDebuggerPresent();
}

int main() {
    std::cout << "--- RDX Advanced Auth SDK Example ---" << std::endl;

    std::string cpu = getCPUId();
    std::string baseboard = getBaseboardId();
    std::string mac = getMACAddress();
    bool isDebug = checkDebugger();

    std::string legacyHwid = cpu + "-" + baseboard; // Fallback string

    std::cout << "[*] CPU ID: " << cpu << std::endl;
    std::cout << "[*] Baseboard ID: " << baseboard << std::endl;
    std::cout << "[*] MAC Address: " << mac << std::endl;
    std::cout << "[*] Debugger Attached: " << (isDebug ? "TRUE" : "FALSE") << std::endl;

    std::cout << "\n[HTTP JSON PAYLOAD TO SEND]" << std::endl;
    std::cout << "{\n";
    std::cout << "  \"license_key\": \"YOUR-LICENSE-KEY\",\n";
    std::cout << "  \"owner_id\": \"1\",\n";
    std::cout << "  \"timestamp\": \"" << std::time(nullptr) * 1000 << "\",\n";
    std::cout << "  \"hardware_info\": {\n";
    std::cout << "      \"id\": \"" << legacyHwid << "\",\n";
    std::cout << "      \"cpu\": \"" << cpu << "\",\n";
    std::cout << "      \"baseboard\": \"" << baseboard << "\",\n";
    std::cout << "      \"mac\": \"" << mac << "\",\n";
    std::cout << "      \"is_debug\": " << (isDebug ? "true" : "false") << ",\n";
    std::cout << "      \"is_vm\": false\n"; // Implement actual VM check based on CPUID/Registry
    std::cout << "  }\n";
    std::cout << "}\n";

    return 0;
}
