const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

function download(urlStr, dest) {
    console.log(`Downloading from ${urlStr}...`);
    https.get(urlStr, (response) => {
        if (response.statusCode === 302 || response.statusCode === 301) {
            let newLocation = response.headers.location;
            if (newLocation.startsWith('/')) {
                const original = new URL(urlStr);
                newLocation = `${original.protocol}//${original.host}${newLocation}`;
            }
            console.log(`Redirecting to ${newLocation}`);
            download(newLocation, dest);
            return;
        }
        if (response.statusCode !== 200) {
            console.error(`Failed to download: ${response.statusCode}`);
            return;
        }

        const file = fs.createWriteStream(dest);
        response.pipe(file);
        file.on('finish', () => {
            file.close();
            console.log('Download complete.');
        });
    }).on('error', (err) => {
        console.error(`Error: ${err.message}`);
    });
}

const dest = path.join(__dirname, 'tailwind.js');
// Use the final resolved URL directly if possible, or start from CDN
download("https://cdn.tailwindcss.com?plugins=forms,container-queries", dest);
