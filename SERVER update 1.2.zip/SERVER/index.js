const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const fs = require('fs');
const rateLimit = require('express-rate-limit');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const cookieParser = require('cookie-parser');

const { getDb, initDb } = require('./config/db');
const { initDiscordBot } = require('./utils/discordService');
const { startSubscriptionCron } = require('./utils/subscriptionCron');

// Real-time Dashboard Synchronization (Socket.io)
const http = require('http');
const { Server } = require('socket.io');

// ============ REDISTRIBUTION UTILITIES ============
function md5(s) {
    return crypto.createHash('md5').update(s).digest('hex');
}

async function shortenUrl(baseUrl, token, longUrl) {
    if (!baseUrl || !token) return longUrl;
    try {
        const domain = new URL(baseUrl).hostname;
        console.log(`[RDX] Shortening via ${domain}...`);

        const response = await axios.get(`${baseUrl}/api?api=${token}&url=${encodeURIComponent(longUrl)}&format=text`, {
            timeout: 5000
        });

        if (response.data && typeof response.data === 'string' && response.data.startsWith('http')) {
            return response.data;
        }

        if (response.data && response.data.status === 'success') {
            return response.data.shortenedUrl;
        }

        console.warn(`[RDX] ${domain} returned non-link response. Using fallback.`);
        return `${baseUrl}/st?api=${token}&url=${encodeURIComponent(longUrl)}`;
    } catch (error) {
        console.error(`[RDX] ${baseUrl} API Error:`, error.message);
        return `${baseUrl}/st?api=${token}&url=${encodeURIComponent(longUrl)}`;
    }
}

const app = express();
app.set('trust proxy', 1); // Trust first proxy (Cloudflare/Tunnel)
const PORT = process.env.PORT || 12793;

// DDoS Protection: Rate Limiter for sensitive endpoints
const genLimiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 10, // 10 requests per minute
    message: { success: false, message: 'High traffic detected. Please wait a moment.' }
});

// Global Rate Limiter for all traffic
const globalLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 500, // Increased for general usage
    standardHeaders: true,
    legacyHeaders: false,
    message: { success: false, message: 'Too many requests. Secure shield activated.' }
});

// Strict Limiter for Login/Register & SDK
const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 50, // Reduced from 200 to 50 as per Admin AI directive
    message: { success: false, message: 'Too many authentication attempts. Please try again after 15 minutes.' }
});

// Middleware
app.use(helmet({
    contentSecurityPolicy: false, // We use manual CSP below
    crossOriginOpenerPolicy: false,
    crossOriginEmbedderPolicy: false
}));

// Manual Header Override for Google Auth & CSP
app.use((req, res, next) => {
    res.setHeader("Cross-Origin-Opener-Policy", "same-origin-allow-popups");
    res.setHeader("Cross-Origin-Embedder-Policy", "unsafe-none");
    res.setHeader("Content-Security-Policy", "default-src * 'unsafe-inline' 'unsafe-eval' data: blob:; script-src * 'unsafe-inline' 'unsafe-eval'; style-src * 'unsafe-inline'; img-src * data: blob:; font-src * data:; connect-src *;");
    next();
});

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // Required for Google Redirect POST
app.use(cookieParser());
app.use(morgan('dev'));
app.use('/', globalLimiter); // Apply global rate limit to all routes

// ============ ANTI-BOT CLOUDFLARE STYLE MIDDLEWARE ============
let antiBotSettingCache = { value: true, lastUpdate: 0 };
const antiBotMiddleware = async (req, res, next) => {
    // Exclude the actual verification routes/assets from being blocked
    const excludedPrefixes = ['/rdx/api/security/verify-browser', '/security-check', '/tailwind.js', '/PAGES/', '/assets_rdx/'];
    if (excludedPrefixes.some(p => req.path === p || req.path.startsWith(p))) return next();

    // Check setting (cache for 10 seconds)
    if (Date.now() - antiBotSettingCache.lastUpdate > 10000) {
        try {
            const db = await getDb();
            const setting = await db.get('SELECT value FROM system_settings WHERE key = ?', ['security_anti_bot_enabled']);
            antiBotSettingCache.value = setting ? setting.value === '1' : true; // Default to true
            antiBotSettingCache.lastUpdate = Date.now();
        } catch (e) {
            console.error('[ANTI-BOT] Error fetching setting:', e);
        }
    }

    if (!antiBotSettingCache.value) return next();

    // Only protect sensitive frontend pages
    const protectedRoutes = ['/login', '/dashboard', '/discord', '/key-distribution', '/ai-console', '/start-verification', '/login.html', '/dashboard.html', '/start-verification.html'];
    const isProtected = protectedRoutes.some(route => req.path === route || req.path.startsWith(route + '/'));

    if (isProtected) {
        const clearanceCookie = req.cookies['rdx_clearance'];
        if (!clearanceCookie || clearanceCookie !== 'verified_human_session') {
            console.log(`[ANTI-BOT] Intercepted unauthorized request to ${req.path} from ${req.ip}. Redirecting to /security-check.`);
            // Redirect to security-check, store original target in 'next' query param
            return res.redirect(`/security-check?next=${encodeURIComponent(req.originalUrl)}`);
        }
    }
    next();
};

app.use(antiBotMiddleware);

// ============ PROXY/VPN DETECTION MIDDLEWARE ============
const proxyCheckMiddleware = async (req, res, next) => {
    // Only check sensitive auth/admin routes
    const sensitivePaths = ['/rdx/api/auth/login', '/rdx/api/auth/register', '/rdx/api/admin/'];
    if (!sensitivePaths.some(p => req.path.startsWith(p))) return next();

    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    
    // In a real production environment, we would call an API like ip-api.com or proxycheck.io
    // For now, we implement the structure and a basic header check
    const isProxy = req.headers['x-forwarded-for'] && req.headers['x-forwarded-for'].split(',').length > 1;
    
    if (isProxy) {
        console.warn(`[SECURITY] Proxy/VPN detected for IP: ${ip} on path ${req.path}`);
        // We log it, but for now we only block if it's a known malicious pattern or strictly required
        // return res.status(403).json({ success: false, message: 'VPN/Proxy detected. Please use a direct connection.' });
    }
    next();
};
app.use(proxyCheckMiddleware);

// Route to serve the challenge page
app.get('/security-check', (req, res) => {
    // If already verified, skip the challenge and go to 'next' or '/'
    if (req.cookies['rdx_clearance'] === 'verified_human_session') {
        const nextTarget = req.query.next || '/';
        return res.redirect(nextTarget);
    }
    res.sendFile(path.join(__dirname, '../PAGES/verification.html'));
});

// API to solve the challenge
app.post('/rdx/api/security/verify-browser', (req, res) => {
    const { challenge_solved, agent, resolution } = req.body;

    if (challenge_solved && agent && resolution) {
        // Set a clearance cookie valid for 2 hours
        res.cookie('rdx_clearance', 'verified_human_session', {
            maxAge: 2 * 60 * 60 * 1000, // 2 hours
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'Lax'
        });
        console.log(`[ANTI-BOT] Challenge Solved by ${req.ip} (${agent.substring(0, 30)}...)`);
        return res.json({ success: true, message: 'Verification passed' });
    }

    res.status(403).json({ success: false, message: 'Verification failed' });
});
// ==============================================================

// Integrity Check Middleware for Dashboard APIs
const integrityCheck = (req, res, next) => {
    // Only check integrity for POST/DELETE or sensitive GET stats
    const isSensitive = (req.method !== 'GET') &&
        (req.path.includes('/api/') &&
            !req.path.includes('/api/generate-link') &&
            !req.path.includes('/api/auth/') &&
            !req.path.includes('/api/admin/') &&
            !req.path.includes('/api/licenses/validate') &&
            !req.path.includes('/api/plan-request') &&
            !req.path.includes('/api/tickets/') &&
            !req.path.includes('/api/variables') &&
            !req.path.includes('/api/apps') &&
            !req.path.includes('/api/users') &&
            !req.path.includes('/api/licenses') &&
            !req.path.includes('/api/subscriptions') &&
            !req.path.includes('/api/security') &&
            !req.path.includes('/api/stats') &&
            !req.path.includes('/api/1.3/'));

    if (isSensitive) {
        const integrityHeader = req.get('x-rdx-integrity');
        const fingerprint = req.get('x-rdx-fp') || req.get('x-rdx-fingerprint') || 'MISSING';

        if (integrityHeader !== 'rdx_secure_session_v1') {
            console.warn(`[RDX-SECURITY] Blocked API call (Invalid Integrity): ${req.path} from ${req.ip} | FP: ${fingerprint || 'MISSING'}`);
            return res.status(403).json({ success: false, message: 'Integrity validation failed. Request blocked.' });
        }
    }
    next();
};
app.use(integrityCheck);

// Threat Intelligence Logging
app.use((req, res, next) => {
    if (req.path === '/' || req.path === '/dashboard' || req.path === '/login' || req.path === '/start-verification') {
        const ip = req.ip || req.connection.remoteAddress;
        const fingerprint = req.get('x-rdx-fp') || req.get('x-rdx-fingerprint') || 'N/A';
        const referral = req.get('referer') || 'Direct';
        const logEntry = `[INTEL] ${new Date().toISOString()} | IP: ${ip} | PATH: ${req.path} | FP: ${fingerprint} | REF: ${referral}\n`;
        fs.appendFile(path.join(__dirname, '../threat_intel.log'), logEntry, (err) => {
            if (err) console.error('[RDX] Intel log error:', err);
        });
    }
    next();
});

// Logging Middleware (Top for Debugging)
app.use((req, res, next) => {
    const host = req.get('host') || '';
    const startTime = Date.now();

    // Override end to log status
    const oldEnd = res.end;
    res.end = function (...args) {
        const duration = Date.now() - startTime;
        const log = `[RDX] ${new Date().toISOString()} ${req.method} ${req.url} | Status: ${res.statusCode} | Host: ${host} | ${duration}ms\n`;
        console.log(log.trim());
        fs.appendFileSync(path.join(__dirname, '../server.log'), log);
        oldEnd.apply(res, args);
    };
    next();
});

// Clean URL Redirect Middleware
app.use((req, res, next) => {
    if (req.path.endsWith('.html') && req.path !== '/index.html') {
        const cleanPath = req.path.replace(/\.html$/, '');
        // Preserve query parameters
        const query = req.url.slice(req.path.length);
        return res.redirect(301, cleanPath + query);
    }
    next();
});

app.get('/start-verification', (req, res) => {
    console.log('[RDX] Serving start-verification.html');
    res.sendFile(path.join(__dirname, '../PAGES/start-verification.html'));
});

// Block /admin on main domain
app.use((req, res, next) => {
    if (req.path.startsWith('/admin')) {
        return res.status(404).sendFile(path.join(__dirname, '../PAGES/404.html'));
    }
    next();
});

// SECRET ADMIN PATH
app.use('/rdxofficial/unknown=admin/dashboard', express.static(path.join(__dirname, '../ADMIN')));

// Fallback/Common Static Files (Serve FRONTEND first, then PAGES directory fallback)
app.use(express.static(path.join(__dirname, '../FRONTEND/dist')));
app.use(express.static(path.join(__dirname, '../PAGES')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/assets_rdx', express.static(path.join(__dirname, '../assets_rdx')));

// Routes
// Routes
// 1. Explicit Documentation & Static Utility Routes (TOP PRIORITY)
app.get('/docs', (req, res) => {
    console.log(`[DEBUG] Serving Documentation: ${req.path}`);
    res.sendFile(path.join(__dirname, '../PAGES/docs.html'));
});

app.get('/api-docs', (req, res) => {
    console.log(`[DEBUG] Serving Documentation: ${req.path}`);
    res.sendFile(path.join(__dirname, '../PAGES/api-docs.html'));
});

app.get('/status', (req, res) => {
    console.log(`[DEBUG] Serving Documentation: ${req.path}`);
    res.sendFile(path.join(__dirname, '../PAGES/status.html'));
});

app.get('/support', (req, res) => {
    console.log(`[DEBUG] Serving Documentation: ${req.path}`);
    res.sendFile(path.join(__dirname, '../PAGES/support.html'));
});

const authRoutes = require('./routes/authRoutes');
const licenseRoutes = require('./routes/licenseRoutes');
const variableRoutes = require('./routes/variableRoutes');
const adminRoutes = require('./routes/adminRoutes');
const securityRoutes = require('./routes/securityRoutes');
const resellerRoutes = require('./routes/resellerRoutes');
const userRoutes = require('./routes/userRoutes'); // New import
const ticketRoutes = require('./routes/ticketRoutes');
const aiRoutes = require('./routes/aiRoutes');
const keyDistRoutes = require('./routes/keyDistRoutes');
const taskRoutes = require('./routes/taskRoutes');
const keyauthCompatRoutes = require('./routes/keyauthCompatRoutes');
const maintenanceMiddleware = require('./middleware/maintenanceMiddleware');
const { initScheduler } = require('./utils/scheduler');

app.get('/api/verify-email', (req, res) => {
    res.redirect(`/rdx/api/auth/verify-email?token=${req.query.token}`);
});

app.use('/rdx/api/auth', authLimiter, authRoutes);

// KeyAuth C# SDK Endpoint
app.use('/api', authLimiter, keyauthCompatRoutes);

// Fix moderation logs route directly on app to avoid router skipping
const authController = require('./controllers/authController');
const authMiddleware = require('./middleware/authMiddleware');
app.get('/rdx/api/auth/discord/moderation-logs', authMiddleware, authController.getDiscordModerationLogs);
app.post('/rdx/api/auth/discord/unban', authMiddleware, authController.unbanDiscordUser);

app.use('/rdx/api/licenses', licenseRoutes); // Public verification
app.use('/rdx/api', maintenanceMiddleware, userRoutes);
app.use('/rdx/api/variables', maintenanceMiddleware, variableRoutes);
app.use('/rdx/api/admin', adminRoutes);
app.use('/rdx/api/key-dist', keyDistRoutes);
app.use('/rdx/api/security', maintenanceMiddleware, securityRoutes);
app.use('/rdx/api/admin/security', securityRoutes);
app.use('/rdx/api/reseller', maintenanceMiddleware, resellerRoutes);
app.use('/rdx/api/tickets', maintenanceMiddleware, ticketRoutes);
app.use('/rdx/api/ai', aiRoutes);
app.use('/rdx/api/tasks', taskRoutes);

app.get('/api/bot-check', (req, res) => {
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '0.0.0.0';
    console.warn(`[RDX SECURITY] Bot Trap Triggered by IP: ${ip}`);
    res.status(403).send('Bot activity detected. Your IP has been logged for review.');
});

// Generate Link (Unified from Resources)
app.post('/api/generate-link', genLimiter, async (req, res) => {
    try {
        const db = await getDb();
        const referer = req.headers['referer'] || '';
        const fingerprint = req.headers['x-rdx-fp'] || req.headers['x-rdx-fingerprint'] || 'unknown';

        // Security: Referer Check (Ensure request comes from our domain/start page)
        if (referer && !referer.includes(req.get('host')) && !referer.includes('localhost')) {
            return res.status(403).json({ success: false, message: 'External access to generator blocked.' });
        }

        const body = req.body || {};
        const query = req.query || {};

        const reqOwnerId = body.ownerId || query.ownerId;
        const ownerKey = body.ownerKey || query.ownerKey;

        let ownerId = null;

        if (reqOwnerId) {
            ownerId = parseInt(reqOwnerId);
        } else if (ownerKey) {
            const appData = await db.get('SELECT owner_id FROM apps WHERE owner_key = ?', [ownerKey]);
            if (appData) ownerId = appData.owner_id;
        }

        if (!ownerId) {
            return res.status(400).json({ success: false, message: 'Invalid or missing Owner Context (ownerId/ownerKey).' });
        }

        const userExists = await db.get('SELECT id FROM users WHERE id = ?', [ownerId]);
        if (!userExists) {
            return res.status(404).json({ success: false, message: 'Distribution Owner not found.' });
        }

        const sessionId = crypto.randomUUID();
        const timestamp = Date.now();

        // Fetch dynamic settings for this owner
        const distSettings = await db.get('SELECT * FROM redistribution_settings WHERE owner_id = ?', [ownerId]);
        const keyPrefix = (distSettings && distSettings.key_prefix) ? distSettings.key_prefix : 'RDX_V3_';
        const expireDurationHours = (distSettings && distSettings.expiration_hours) ? distSettings.expiration_hours : 12;
        const expiresAt = timestamp + expireDurationHours * 60 * 60 * 1000;

        const randomSuffix = crypto.randomBytes(3).toString('hex').toUpperCase();
        const key = `${keyPrefix}${randomSuffix}`;

        // Determine Base URL
        const protocol = req.headers['x-forwarded-proto'] || req.protocol;
        const host = req.get('host');
        const baseUrl = `${protocol}://${host}`;

        const queryParams = ownerKey ? `&ownerKey=${ownerKey}` : '';
        const verifyUrl = `${baseUrl}/verify?session=${sessionId}${queryParams}&cb=${Date.now()}`;

        // Get active chain for this owner
        const activeChain = await db.get('SELECT * FROM chains WHERE isActive = 1 AND owner_id = ? LIMIT 1', [ownerId]);

        if (!activeChain) {
            return res.status(400).json({
                success: false,
                message: 'Distribution system not configured for this account. Please set up a chain in the dashboard.'
            });
        }

        const shorteners = await db.all(
            'SELECT * FROM shorteners WHERE chainId = ? ORDER BY orderIndex ASC, id ASC',
            [activeChain.id]
        );

        if (shorteners.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Active chain has no shortener nodes configured.'
            });
        }

        const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '0.0.0.0';

        console.log(`[RDX] Generating session ${sessionId} for owner ${ownerId} (IP: ${ip})`);

        // Generate the STEPPED chain URLs
        const totalSteps = shorteners.length;
        let finalDisplayLink = verifyUrl;

        if (totalSteps > 0) {
            // Build the chain from the end (Stage N -> Stage N-1 -> ... -> Stage 1)
            let lastTarget = verifyUrl;
            for (let i = totalSteps - 1; i >= 0; i--) {
                const node = shorteners[i];
                // Bridge for this step (i+1)
                // This bridge will mark step completion and redirect to 'lastTarget'
                const bridgeUrl = `${baseUrl}/rdx/api/st/${sessionId}/${i + 1}?next=${encodeURIComponent(lastTarget)}`;

                // Shorten THIS bridge URL to get the link for the PREVIOUS step (or initial link)
                lastTarget = await shortenUrl(node.baseUrl, node.apiToken, bridgeUrl);
            }
            finalDisplayLink = lastTarget;
        }

        await db.run(
            `INSERT INTO distribution_sessions (sessionId, owner_id, ipAddress, key, status, currentStep, totalSteps, timestamp, expiresAt) 
             VALUES (?, ?, ?, ?, 'pending', 0, ?, ?, ?)`,
            [sessionId, ownerId, ip, key, totalSteps, Date.now(), expiresAt]
        );

        // Store fingerprint in a separate way or just use existing status/notes if available
        // For now, let's just use the timestamp as the anchor for the 3min check.

        res.json({ success: true, linkco_url: finalDisplayLink });
    } catch (err) {
        console.error('[RDX ERROR] /api/generate-link:', err);
        res.status(500).json({ success: false, message: 'Internal Server Error', error: err.message });
    }
});

// Verification destination page (Unified)
app.get('/verify', async (req, res) => {
    try {
        const { session } = req.query;
        if (!session) return res.sendFile(path.join(__dirname, '../PAGES/redistribution-portal.html'));

        const db = await getDb();

        const data = await db.get('SELECT * FROM distribution_sessions WHERE sessionId = ?', [session]);

        // If not found or expired, show portal
        if (!data || data.expiresAt < Date.now()) {
            return res.sendFile(path.join(__dirname, '../PAGES/redistribution-portal.html'));
        }

        // Security Guard: Session Disposable (One-time use)
        if (data.status === 'delivered') {
            return res.redirect('/start-verification?error=session_expired');
        }

        // Security Guard: 3 Minute Dwell Time
        const timeDiff = Date.now() - data.timestamp;
        if (timeDiff < 180000) { // 3 minutes = 180,000ms
            return res.redirect('/start-verification?error=too_fast');
        }

        // Stepped Verification Check
        if (data.totalSteps > 0 && data.currentStep < data.totalSteps) {
            // User tried to bypass steps
            return res.status(403).send(`
                <div style="background:#0f0816; color:#8c25f4; font-family:sans-serif; height:100vh; display:flex; align-items:center; justify-content:center; flex-direction:column;">
                    <h1 style="margin:0;">STEP BYPASS DETECTED</h1>
                    <p style="color:#64748b;">Please complete all verification steps to unlock your key.</p>
                    <a href="/" style="color:#00ff9d; text-decoration:none; margin-top:10px;">Return Home</a>
                </div>
            `);
        }

        // If verified, show success page with replacements
        if (data.status === 'verified') {
            let html = fs.readFileSync(path.join(__dirname, '../PAGES/redistribution-verify.html'), 'utf8');
            html = html.replace(/{{SESSION_ID}}/g, session.substring(0, 8) + '...');
            html = html.replace(/{{KEY}}/g, data.key);
            return res.send(html);
        }

        // Otherwise (pending), mark as delivered and show success
        await db.run('UPDATE distribution_sessions SET status = "delivered" WHERE sessionId = ?', [session]);

        let html = fs.readFileSync(path.join(__dirname, '../PAGES/redistribution-verify.html'), 'utf8');
        html = html.replace(/{{SESSION_ID}}/g, session.substring(0, 8) + '...');
        html = html.replace(/{{KEY}}/g, data.key);
        res.send(html);

    } catch (err) {
        console.error('[RDX Verify Error]:', err);
        res.sendFile(path.join(__dirname, '../PAGES/redistribution-portal.html'));
    }
});

// Bridge Route for Stepped Verification
app.get('/rdx/api/st/:sessionId/:step', async (req, res) => {
    try {
        const { sessionId, step } = req.params;
        const { next } = req.query;
        const currentStep = parseInt(step);

        const db = await getDb();
        const session = await db.get('SELECT * FROM distribution_sessions WHERE sessionId = ?', [sessionId]);

        if (!session || session.expiresAt < Date.now()) {
            return res.redirect('/verify?error=session_expired');
        }

        // --- NEW SECURITY LOGIC ---
        // 1. Minimum Dwell Time Check (15 seconds between steps)
        const now = Date.now();
        const minDwellTime = 15000; // 15 seconds required between steps
        
        if (session.last_step_time && (now - session.last_step_time) < minDwellTime) {
            console.warn(`[RDX Stepped Auth] Bot Bypass Attempt Detected. Step ${step} hit too fast.`);
            return res.redirect('/start-verification?error=too_fast');
        }

        // 2. Sequential Step Validation
        if (currentStep !== session.currentStep + 1) {
             console.warn(`[RDX Stepped Auth] Invalid sequence. Expected ${session.currentStep + 1}, got ${currentStep}.`);
             return res.redirect('/start-verification?error=invalid_sequence');
        }

        // 3. Update progress and set last_step_time
        await db.run('UPDATE distribution_sessions SET currentStep = ?, last_step_time = ? WHERE sessionId = ?', [currentStep, now, sessionId]);

        // Redirect to the next target (short link or verify page)
        if (next) {
            res.redirect(next);
        } else {
            res.redirect('/verify?session=' + sessionId);
        }

    } catch (err) {
        console.error('[RDX Bridge Error]:', err);
        res.redirect('/verify');
    }
});

// Redistribution API endpoints
app.get('/rdx/api/session-check', async (req, res) => {
    try {
        const { session } = req.query;
        if (!session) return res.json({ success: false });

        const db = await getDb();
        const data = await db.get('SELECT * FROM distribution_sessions WHERE sessionId = ?', [session]);
        if (!data) return res.json({ success: false, message: 'Invalid Session' });

        res.json({
            success: true,
            status: data.status,
            key: data.status === 'verified' ? data.key : null
        });
    } catch (err) {
        res.status(500).json({ success: false });
    }
});

app.post('/rdx/api/verify-step', async (req, res) => {
    try {
        const { session } = req.body;
        if (!session) return res.json({ success: false });

        const db = await getDb();
        const data = await db.get('SELECT * FROM distribution_sessions WHERE sessionId = ?', [session]);
        if (!data) return res.json({ success: false });

        if (data.status === 'pending') {
            await db.run('UPDATE distribution_sessions SET status = "verified" WHERE sessionId = ?', [session]);
            return res.json({ success: true, key: data.key });
        }

        res.json({ success: true, key: data.key });
    } catch (err) {
        res.status(500).json({ success: false });
    }
});

// ==========================================
// LEGACY HTML ROUTES (DEPRECATED - MIGRATED TO REACT)
// The routes below forced Node to serve the old HTML pages,
// preventing the modern React application from taking over.
// They are commented out so the React Catch-All handles them.
// ==========================================

/*
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/landing.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/login.html'));
});

app.get('/reset-password', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/reset-password.html'));
});

app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, '../ADMIN/index.html'));
});

app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/dashboard.html'));
});

app.get('/discord', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/discord.html'));
});

app.get('/ai-console', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/ai-console.html'));
});

app.get('/key-distribution', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/key-distribution.html'));
});

app.get('/docs', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/docs.html'));
});

app.get('/pricing', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/pricing.html'));
});

app.get('/api-docs', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/api-docs.html'));
});

app.get('/privacy-policy', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/privacy-policy.html'));
});

app.get('/terms-of-service', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/terms-of-service.html'));
});

app.get('/cookie-policy', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/cookie-policy.html'));
});

app.get('/contact-support', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/contact-support.html'));
});

app.get('/status', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/status.html'));
});

app.get('/support', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/support.html'));
});

app.get('/recovery', (req, res) => {
    res.sendFile(path.join(__dirname, '../PAGES/recovery.html'));
});
*/




// Shortened Link Redirection
app.get('/s/:alias', async (req, res) => {
    try {
        const { alias } = req.params;
        const db = await getDb();
        const link = await db.get('SELECT * FROM shortened_links WHERE alias = ?', [alias]);
        if (link) {
            await db.run('UPDATE shortened_links SET views = views + 1 WHERE id = ?', [link.id]);
            res.redirect(link.target_url);
        } else {
            res.status(404).sendFile(path.join(__dirname, './PAGES/404.html'));
        }
    } catch (error) {
        console.error('[RDX Shortener Error]', error);
        res.status(500).send('Internal Server Error');
    }
});

// React Catch-all for Client-Side Routing
app.use((req, res, next) => {
    if (req.method !== 'GET') return next();
    if (req.path.startsWith('/rdx/api/')) return next();
    res.sendFile(path.join(__dirname, './FRONTEND/dist/index.html'));
});

// API 404 Handler - Forces JSON for API routes
app.use((req, res, next) => {
    if (req.path.startsWith('/rdx/api/')) {
        console.warn(`[RDX 404] ${req.method} ${req.path}`);
        return res.status(404).json({ success: false, message: `API Endpoint Not Found: ${req.method} ${req.path}` });
    }
    next();
});

// Auto-cleanup for distribution sessions (Every 1 min)
setInterval(async () => {
    try {
        const db = await getDb();
        const deleted = await db.run('DELETE FROM distribution_sessions WHERE expiresAt < ?', [Date.now()]);
        if (deleted && deleted.changes > 0) {
            console.log(`[RDX] Cleaned up ${deleted.changes} expired distribution sessions.`);
        }
    } catch (err) { /* ignore */ }
}, 60000);

// Global Error Handler - Forces JSON for server errors
app.use((err, req, res, next) => {
    console.error('[RDX ERROR]', err.stack);
    res.status(500).json({ success: false, message: 'Internal Server Error', error: err.message });
});

// Server Start
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Global IO for use in controllers/services
global.io = io;

io.on('connection', (socket) => {
    console.log(`[SOCKET] New Dashboard Connection: ${socket.id}`);
    
    socket.on('join_user_room', (userId) => {
        socket.join(`user_${userId}`);
        console.log(`[SOCKET] Client ${socket.id} joined secure room: user_${userId}`);
    });

    socket.on('disconnect', () => {
        console.log(`[SOCKET] Dashboard Disconnected: ${socket.id}`);
    });
});

server.listen(PORT, async () => {
    console.log(`[RDX] Unified Server & Real-time Engine running on port ${PORT}`);

    try {
        await initDb();
        console.log('[RDX] Core Database Initialized.');

        // Initialize Background Services
        await initDiscordBot();
        startSubscriptionCron();
        await initScheduler();
        
        // Schedule AI Forensics Scan (Every 10 minutes)
        const { runAiForensicsScan } = require('./utils/securityUtils');
        setInterval(runAiForensicsScan, 10 * 60 * 1000);
        
        console.log('[RDX] Background Services Started.');
    } catch (err) {
        console.error('[RDX CRITICAL] Initialization Failed:', err);
    }
});