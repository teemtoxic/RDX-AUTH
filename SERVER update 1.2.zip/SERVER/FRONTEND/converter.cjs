const fs = require('fs');

const html = fs.readFileSync('c:/Users/Administrator/Desktop/SERVER/PAGES/landing.html', 'utf8');

let bodyMatch = html.match(/<body[^>]*>([\s\S]*?)<\/body>/);
let body = bodyMatch ? bodyMatch[1] : '';

// Remove script tags entirely to avoid errors
body = body.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');

// Escape raw curly braces for JSX safely
body = body.replace(/\{/g, '__OPEN_BRACE__').replace(/\}/g, '__CLOSE_BRACE__');

// Convert common HTML attributes to JSX
body = body.replace(/class="/g, 'className="');
body = body.replace(/for="/g, 'htmlFor="');
body = body.replace(/colspan="/g, 'colSpan="');
body = body.replace(/tabindex="/g, 'tabIndex="');
body = body.replace(/viewbox="/g, 'viewBox="');
body = body.replace(/fill-rule="/g, 'fillRule="');
body = body.replace(/clip-rule="/g, 'clipRule="');
body = body.replace(/stroke-width="/g, 'strokeWidth="');
body = body.replace(/stroke-linecap="/g, 'strokeLinecap="');
body = body.replace(/stroke-linejoin="/g, 'strokeLinejoin="');
body = body.replace(/onclick="([^"]*)"/gi, 'onClick={handleActionClick} data-onclick="$1"');

// Handle self-closing tags
body = body.replace(/<(img|br|hr|input)([^>]*?)>/g, (match, p1, p2) => {
    if (p2.trim().endsWith('/')) return match;
    return `<${p1}${p2} />`;
});

// Handle simple inline styles manually
body = body.replace(/style="([^"]*)"/g, (match, styleStr) => {
    let styles = styleStr.split(';').filter(s => s.trim() !== '');
    let styleObj = {};
    styles.forEach(s => {
        let [key, val] = s.split(':');
        if (!key || !val) return;
        key = key.trim().replace(/-([a-z])/g, (g) => g[1].toUpperCase());
        styleObj[key] = val.trim();
    });
    return `style={${JSON.stringify(styleObj)}}`;
});

// HTML comments to JSX
body = body.replace(/<!--([\s\S]*?)-->/g, '{/*$1*/}');

// Restore braces as JSX expressions
body = body.replace(/__OPEN_BRACE__/g, '{"{"}').replace(/__CLOSE_BRACE__/g, '{"}"}');

const reactCode = `import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Landing = () => {
    const navigate = useNavigate();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [userContextId, setUserContextId] = useState(null);
    const [genResult, setGenResult] = useState({ show: false, link: '' });
    const [isGenerating, setIsGenerating] = useState(false);

    useEffect(() => {
        const token = localStorage.getItem('rdx_token');
        if (token) {
            fetch('/rdx/api/auth/me', {
                headers: { 'Authorization': 'Bearer ' + token }
            })
            .then(res => res.json())
            .then(data => {
                if (data.success && data.user) {
                    setUserContextId(data.user.id);
                }
            })
            .catch(e => console.error('[RDX Hub] Auth sync failed', e));
        }

        const fp = btoa(navigator.userAgent + window.screen.width + window.screen.height + navigator.language);
        localStorage.setItem('rdx_fp', fp);
    }, []);

    const toggleMobileMenu = () => {
        setIsMobileMenuOpen(!isMobileMenuOpen);
        if (!isMobileMenuOpen) {
            document.body.classList.add('overflow-hidden');
            const menu = document.getElementById('mobile-menu');
            if (menu) {
                menu.classList.remove('hidden');
            }
        } else {
            document.body.classList.remove('overflow-hidden');
            const menu = document.getElementById('mobile-menu');
            if (menu) {
                menu.classList.add('hidden');
            }
        }
    };

    const handleActionClick = (e) => {
        let target = e.currentTarget;
        let originalOnClick = target.getAttribute('data-onclick') || '';
        
        if (originalOnClick.includes('toggleMobileMenu')) {
            toggleMobileMenu();
            return;
        }
        
        if (originalOnClick.includes('generateAccessLink')) {
            generateAccessLink();
            return;
        }

        if (originalOnClick.includes('copyGeneratedLink')) {
            copyGeneratedLink();
            return;
        }

        if (originalOnClick.includes('window.location.href')) {
            if (originalOnClick.includes('/security-check?next=/login') || originalOnClick.includes('/security-check?next=/dashboard')) {
                if (userContextId) {
                    window.location.href = '/security-check?next=/dashboard';
                } else {
                    window.location.href = '/security-check?next=/login';
                }
                return;
            }
            if (originalOnClick.includes('start-verification')) {
                const urlParams = new URLSearchParams(window.location.search);
                let ownerId = urlParams.get('ownerId');
                if (!ownerId && userContextId) {
                    ownerId = userContextId;
                }
                const dest = ownerId ? \`/start-verification?ownerId=\${ownerId}\` : '/start-verification';
                window.location.href = \`/security-check?next=\${encodeURIComponent(dest)}\`;
                return;
            }
        }
        
        // Handle generic href if any
        let href = target.getAttribute('href');
        if (!href && target.closest('a')) {
            href = target.closest('a').getAttribute('href');
        }
        if (href && href.startsWith('#')) {
            e.preventDefault();
            const el = document.querySelector(href);
            if (el) el.scrollIntoView({ behavior: 'smooth' });
            return;
        }
    };

    const generateAccessLink = async () => {
        setIsGenerating(true);
        try {
            const res = await fetch('/api/generate-link', { method: 'POST' });
            const data = await res.json();
            if (data.success && data.linkco_url) {
                setGenResult({ show: true, link: data.linkco_url });
            } else {
                alert('Error: ' + (data.message || 'Server busy.'));
            }
        } catch (err) {
            alert('Connection error.');
        } finally {
            setIsGenerating(false);
        }
    };

    const copyGeneratedLink = () => {
        navigator.clipboard.writeText(genResult.link);
        alert('Access Link copied to clipboard!');
    };

    return (
        <div className="bg-background-dark text-white font-display overflow-x-hidden selection:bg-primary selection:text-white min-h-screen">
            ${body}
        </div>
    );
};

export default Landing;
`;

// To ensure data-onclick captures original intent
// We will modify the HTML body replacement for onclick
const finalReactCode = reactCode;

fs.writeFileSync('c:/Users/Administrator/Desktop/SERVER/FRONTEND/src/pages/Landing.jsx', finalReactCode);
console.log('Conversion successful. Lines:', reactCode.split('\\n').length);
