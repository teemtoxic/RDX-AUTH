import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useSocket } from '../../contexts/SocketContext';
import { useGlow } from '../../contexts/GlowContext';
import { motion, AnimatePresence } from 'framer-motion';

// Module-level global to persist scroll across every render/navigation
let lastSidebarScroll = 0;

const Sidebar = ({ isMobileOpen, toggleSidebar, userContextData, onLogout }) => {
    const navigate = useNavigate();
    const location = useLocation();
    const { notifications, markAsRead } = useSocket();
    const { isGlassEnabled, toggleGlass, isGlowEnabled, toggleGlow } = useGlow();
    const [showNotifications, setShowNotifications] = useState(false);
    const scrollContainerRef = React.useRef(null);

    // Restore scroll position synchronously before browser paint
    React.useLayoutEffect(() => {
        if (scrollContainerRef.current) {
            scrollContainerRef.current.scrollTop = lastSidebarScroll;
        }
    }, [location.pathname]);

    // Save scroll position immediately on scroll
    const handleScroll = (e) => {
        lastSidebarScroll = e.target.scrollTop;
    };

    // Navigate and blur to prevent focus-driven scrolling
    const handleNavigate = (path, e) => {
        if (e && e.currentTarget) e.currentTarget.blur();
        navigate(path);
        if (window.innerWidth < 1024) toggleSidebar();
    };

    const handleLogoutPrompt = () => {
        if (onLogout) onLogout();
    };

    const generalItems = [
        { id: 'dashboard', label: 'Overview', icon: 'dashboard', path: '/dashboard' },
        { id: 'analytics', label: 'Analytics', icon: 'monitoring', path: '/analytics' },
        { id: 'apps', label: 'My Apps', icon: 'apps', path: '/apps' },
        { id: 'discord', label: 'Discord AI', icon: 'smart_toy', path: '/discord' },
        { id: 'key-distribution', label: 'Key Distribution', icon: 'key', path: '/key-distribution' },
        { id: 'ai-console', label: 'AI Console', icon: 'hub', path: '/ai-console' },
    ];

    const managementItems = [
        { id: 'users', label: 'Users', icon: 'group', path: '/users' },
        { id: 'licenses', label: 'Licenses', icon: 'vpn_key', path: '/licenses' },
        { id: 'subscriptions', label: 'Subscriptions', icon: 'loyalty', path: '/app-subscriptions' },
        { id: 'orders', label: 'Plan Requests', icon: 'shopping_cart', path: '/orders' },
        { id: 'variables', label: 'Variables', icon: 'data_object', path: '/variables' },
    ];

    const securityItems = [
        { id: 'security-overview', label: 'Security Panel', icon: 'shield', path: '/security-overview' },
        { id: 'security-monitoring', label: 'Live Shield', icon: 'visibility', path: '/security-monitoring' },
        { id: 'logs', label: 'System Logs', icon: 'analytics', path: '/logs' },
    ];

    // Only show Global Settings/Admin Panel to actual administrators
    if (userContextData?.role === 'admin') {
        securityItems.push({ id: 'admin-portal', label: 'Admin Panel', icon: 'admin_panel_settings', path: '/admin' });
    }

    const accountItems = [
        { id: 'billing', label: 'Billing & Plan', icon: 'payments', path: '/billing' },
        { id: 'profile', label: 'My Profile', icon: 'account_circle', path: '/profile' },
        { id: 'support', label: 'Support Desk', icon: 'support_agent', path: '/support' },
    ];

    const NavSection = ({ title, items }) => (
        <div className="mb-6">
            <p className="px-4 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-3">{title}</p>
            <div className="space-y-1">
                {items.map((item) => {
                    const isActive = location.pathname === item.path;
                    return (
                        <button
                            key={item.id}
                            onClick={(e) => handleNavigate(item.path, e)}
                            className={`nav-item group w-full text-left flex items-center ${isActive ? 'active text-white bg-primary/10 border-primary/20 shadow-[0_0_15px_rgba(140,37,244,0.1)]' : 'border-transparent'}`}
                        >
                            <span className={`material-symbols-outlined transition-colors mr-3 ${isActive ? 'text-primary' : 'group-hover:text-primary'}`}>
                                {item.icon}
                            </span>
                            {item.label}
                            {isActive && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_8px_rgba(140,37,244,0.8)] animate-pulse"></span>}
                        </button>
                    );
                })}
            </div>
        </div>
    );

    return (
        <>
            {/* Mobile Overlay */}
            <div
                className={`fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden transition-opacity duration-300 ${isMobileOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
                onClick={toggleSidebar}
            ></div>

            {/* Sidebar Container */}
            <aside className={`fixed inset-y-0 left-0 z-50 w-72 bg-slate-900/50 backdrop-blur-xl border-r border-white/5 transform transition-transform duration-300 ease-in-out ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}>
                <div className="flex flex-col h-full">
                    {/* Header */}
                    <div className="h-20 flex items-center px-8 border-b border-white/5 justify-between">
                        <span className="text-2xl font-black text-white tracking-tighter cursor-pointer" onClick={(e) => handleNavigate('/dashboard', e)}>
                            RDX<span className="text-primary">CORE</span>
                        </span>
                        
                        {/* Notification Bell */}
                        <div className="relative">
                            <button 
                                onClick={() => setShowNotifications(!showNotifications)}
                                className={`p-2 rounded-lg transition-all ${notifications.length > 0 ? 'text-primary animate-pulse-glow' : 'text-slate-500 hover:text-white'}`}
                            >
                                <span className="material-symbols-outlined">notifications</span>
                                {notifications.length > 0 && (
                                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-slate-900"></span>
                                )}
                            </button>

                            <AnimatePresence>
                                {showNotifications && (
                                    <motion.div 
                                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                                        animate={{ opacity: 1, y: 0, scale: 1 }}
                                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                                        className="absolute left-0 mt-2 w-80 glass-panel rounded-xl overflow-hidden z-[60] shadow-2xl"
                                    >
                                        <div className="p-4 border-b border-white/5 flex items-center justify-between bg-black/20">
                                            <span className="text-xs font-bold uppercase tracking-widest text-primary">Live Alerts</span>
                                            <span className="text-[10px] text-slate-500">{notifications.length} New</span>
                                        </div>
                                        <div className="max-h-96 overflow-y-auto custom-scrollbar">
                                            {notifications.length === 0 ? (
                                                <div className="p-8 text-center text-slate-500 text-xs">No active alerts</div>
                                            ) : (
                                                notifications.map(n => (
                                                    <div key={n.id} className="p-4 border-b border-white/5 hover:bg-white/5 transition-colors relative group">
                                                        <div className="flex items-start gap-3">
                                                            <div className={`mt-1 w-2 h-2 rounded-full ${n.type === 'error' ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]' : 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]'}`}></div>
                                                            <div className="flex-1">
                                                                 <p className="text-xs font-bold text-white uppercase tracking-tight">{n.title}</p>
                                                                 <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">{n.message}</p>
                                                                 <p className="text-[9px] text-slate-600 mt-2 font-mono">{new Date(n.timestamp).toLocaleTimeString()}</p>
                                                            </div>
                                                            <button onClick={() => markAsRead(n.id)} className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-600 hover:text-white">
                                                                <span className="material-symbols-outlined text-sm">close</span>
                                                            </button>
                                                        </div>
                                                        {n.type === 'error' && <div className="absolute inset-0 bg-red-500/5 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity"></div>}
                                                    </div>
                                                ))
                                            )}
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                    </div>

                    <div 
                        ref={scrollContainerRef}
                        onScroll={handleScroll}
                        className="flex-1 py-6 px-3 overflow-y-auto custom-scrollbar"
                    >
                        <NavSection title="Main Console" items={generalItems} />
                        <NavSection title="User Management" items={managementItems} />
                        <NavSection title="Account & Security" items={[...securityItems, ...accountItems]} />
                    </div>

                    {/* Sidebar Footer */}
                    <div className="p-4 border-t border-white/5 bg-black/20">
                        {/* Theme Toggles */}
                        <div className="flex items-center gap-2 mb-4">
                            <button 
                                onClick={toggleGlass}
                                className={`flex-1 flex items-center justify-center gap-2 p-2 rounded-lg border transition-all text-[10px] font-bold uppercase tracking-widest ${isGlassEnabled ? 'bg-primary/20 border-primary/40 text-white shadow-neon-sm' : 'bg-white/5 border-white/10 text-slate-500 hover:text-white'}`}
                            >
                                <span className="material-symbols-outlined text-sm">blur_on</span>
                                Glass
                            </button>
                            <button 
                                onClick={toggleGlow}
                                className={`flex-1 flex items-center justify-center gap-2 p-2 rounded-lg border transition-all text-[10px] font-bold uppercase tracking-widest ${isGlowEnabled ? 'bg-primary/20 border-primary/40 text-white shadow-neon-sm' : 'bg-white/5 border-white/10 text-slate-500 hover:text-white'}`}
                            >
                                <span className="material-symbols-outlined text-sm">flare</span>
                                Glow
                            </button>
                        </div>

                        {/* User Profile */}
                        <div className="p-4 border-t border-white/5 bg-white/[0.02]">
                            <div className="flex items-center gap-3 w-full group text-left">
                                <div className="relative">
                                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center border border-primary/20 group-hover:border-primary/40 transition-all overflow-hidden shadow-inner">
                                        <span className="font-black text-xs text-primary">
                                            {userContextData ? userContextData.username?.substring(0, 2).toUpperCase() : '--'}
                                        </span>
                                    </div>
                                    <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 border-2 border-background-dark rounded-full shadow-lg"></div>
                                </div>
                                
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-1.5 mb-0.5">
                                        <p className="text-sm font-bold text-white truncate tracking-tight">
                                            {userContextData ? userContextData.username : 'Guest User'}
                                        </p>
                                        {userContextData?.role === 'admin' && (
                                            <span className="flex-shrink-0 w-3.5 h-3.5 bg-primary/20 text-primary border border-primary/30 rounded flex items-center justify-center pointer-events-none">
                                                <span className="material-symbols-outlined text-[10px] font-bold">verified</span>
                                            </span>
                                        )}
                                    </div>
                                    <p className="text-[10px] text-slate-500 truncate lowercase mb-1.5 opacity-80">
                                        {userContextData?.email || 'no-email-synced'}
                                    </p>
                                    <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-primary/10 border border-primary/20">
                                        <div className="w-1 h-1 rounded-full bg-primary animate-pulse"></div>
                                        <span className="text-[8px] font-black text-primary uppercase tracking-widest">
                                            {userContextData ? userContextData.plan : 'PROBING...'}
                                        </span>
                                    </div>
                                </div>

                                <button 
                                    onClick={onLogout} 
                                    className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-all border border-transparent hover:border-red-500/20"
                                    title="Logout"
                                >
                                    <span className="material-symbols-outlined text-[20px]">logout</span>
                                </button>
                            </div>
                        </div>

                        {/* Status Widget */}
                        <div className="glass-panel p-4 rounded-xl border border-primary/20 bg-primary/5 flex items-center justify-between mt-2">
                            <div className="flex items-center gap-3">
                                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
                                <span className="text-[10px] font-bold text-white uppercase tracking-wider">System Live</span>
                            </div>
                            <span className="text-[9px] text-slate-500 font-mono">v4.0.2</span>
                        </div>
                    </div>
                </div>
            </aside>
        </>
    );
};

export default Sidebar;
