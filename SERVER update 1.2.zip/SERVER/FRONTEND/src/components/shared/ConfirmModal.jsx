import React from 'react';

const ConfirmModal = ({ isOpen, title, message, onConfirm, onCancel, confirmText = 'Confirm', type = 'danger' }) => {
    if (!isOpen) return null;
    
    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center animate-in fade-in duration-200">
            <div className="bg-slate-900 border border-white/10 p-6 rounded-xl shadow-2xl w-full max-w-md animate-in zoom-in-95 duration-200 relative overflow-hidden">
                <div className={`absolute top-0 left-0 w-full h-1 bg-${type === 'danger' ? 'red' : 'primary'}-500`}></div>
                <div className="flex items-center gap-3 mb-4 mt-2">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center bg-${type === 'danger' ? 'red' : 'primary'}-500/20`}>
                        <span className={`material-symbols-outlined text-${type === 'danger' ? 'red-500' : 'primary'} text-xl`}>
                            {type === 'danger' ? 'warning' : 'help'}
                        </span>
                    </div>
                    <h2 className="text-xl font-bold text-white uppercase tracking-tighter">{title}</h2>
                </div>
                <p className="text-slate-300 mb-6">{message}</p>
                <div className="flex justify-end gap-3 mt-8">
                    <button 
                        onClick={onCancel}
                        className="px-4 py-2 text-sm font-bold text-slate-400 hover:text-white transition-colors"
                    >
                        Cancel
                    </button>
                    <button 
                        onClick={() => {
                            onConfirm();
                            onCancel(); // Close modal immediately after confirm is triggered
                        }}
                        className={`px-4 py-2 text-sm font-bold text-white rounded-lg transition-colors flex items-center gap-2 ${
                            type === 'danger' ? 'bg-red-500 hover:bg-red-600 shadow-[0_0_15px_rgba(239,68,68,0.3)]' : 'bg-primary hover:bg-primary/90 shadow-neon-sm'
                        }`}
                    >
                        {confirmText}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ConfirmModal;
