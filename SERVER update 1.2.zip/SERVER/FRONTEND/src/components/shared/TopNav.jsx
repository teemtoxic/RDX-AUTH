import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useGlow } from '../../contexts/GlowContext';

const TopNav = ({ toggleSidebar }) => {
    const navigate = useNavigate();
    const { isGlowEnabled, toggleGlow } = useGlow();

    return (
        <>
            {/* Mobile Header */}
            <div className="lg:hidden h-16 border-b border-white/5 flex items-center justify-between px-6 bg-slate-900/50 backdrop-blur-md">
                <button
                    className="text-white p-2 hover:bg-white/5 rounded-lg active:scale-95 transition-all"
                    onClick={toggleSidebar}
                >
                    <span className="material-symbols-outlined">menu</span>
                </button>
                <span className="text-lg font-bold text-white tracking-tight cursor-pointer" onClick={() => navigate('/dashboard')}>
                    RDX<span className="text-primary">CORE</span>
                </span>
                <div className="w-9"></div> {/* Spacer for centering */}
            </div>

            {/* Desktop Header */}
            <header className="h-20 border-b border-white/5 flex items-center justify-between px-8 bg-slate-900/50 backdrop-blur-md hidden lg:flex">
                <button className="lg:hidden p-2 text-slate-400 hover:text-white" onClick={toggleSidebar}>
                    <span className="material-symbols-outlined">menu</span>
                </button>

                <div className="flex-1"></div>

                <div className="flex items-center gap-4">
                    <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-green-500/10 border border-green-500/20 rounded-full">
                        <span className="relative flex h-2 w-2">
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-green-400 animate-pulse"></span>
                        </span>
                        <span className="text-xs font-medium text-green-400 tracking-wide uppercase">Server Online</span>
                    </div>
                    {/* Integrity Status Widget */}
                    <div
                        className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-primary/10 border border-primary/20 rounded-full group cursor-help transition-all hover:bg-primary/20"
                        title="Integrity Check: ACTIVE. Browser Fingerprint: VALID. Encryption: AES-256-GCM."
                    >
                        <span className="material-symbols-outlined text-[16px] text-primary">verified_user</span>
                        <span className="text-xs font-bold text-primary tracking-wide uppercase">Secured</span>
                    </div>

                    <div className="h-6 w-px bg-white/10 mx-2"></div>

                    <button onClick={toggleGlow} className="relative p-2 text-slate-400 hover:text-white transition-colors" title="Toggle Neon Effects">
                        <span className="material-symbols-outlined">{isGlowEnabled ? 'light_mode' : 'dark_mode'}</span>
                    </button>

                    <button className="relative p-2 text-slate-400 hover:text-white transition-colors tooltip" title="System Messages">
                        <span className="material-symbols-outlined">notifications</span>
                    </button>

                    <button
                        className="bg-accent hover:bg-accent/90 text-white text-sm font-medium px-4 py-2 rounded-lg shadow-[0_0_15px_rgba(251,146,60,0.3)] transition-all flex items-center gap-2"
                        onClick={() => navigate('/pricing')}
                    >
                        <span className="material-symbols-outlined text-[18px]">payments</span>
                        Subscription
                    </button>
                </div>
            </header>
        </>
    );
};

export default TopNav;
