import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from './Sidebar';
import TopNav from './TopNav';
import { useLocation } from 'react-router-dom';

const DashboardLayout = ({ children }) => {
    const navigate = useNavigate();
    const location = useLocation();
    const contentRef = React.useRef(null);
    const [isMobileOpen, setIsMobileOpen] = useState(false);
    const [userContextData, setUserContextData] = useState(window.__RDX_AUTH_CACHE?.user || null);
    // Instant load if cached, unless it's the stale debug user
    const [isLoading, setIsLoading] = useState(
        !window.__RDX_AUTH_CACHE || window.__RDX_AUTH_CACHE.user?.username === 'DEBUG_USER'
    );

    useEffect(() => {
        // Clear stale debug cache if present
        if (window.__RDX_AUTH_CACHE?.user?.username === 'DEBUG_USER') {
            window.__RDX_AUTH_CACHE = null;
            setUserContextData(null);
            setIsLoading(true);
        }

        // Disable automatic scroll restoration to prevent jumps
        if ('scrollRestoration' in window.history) {
            window.history.scrollRestoration = 'manual';
        }

        const urlParams = new URLSearchParams(window.location.search);
        let token = urlParams.get('auth_token') || localStorage.getItem('rdx_token');

        // Cleanup malformed or literal string "null"/"undefined" tokens
        if (token === 'undefined' || token === 'null' || token === '[object Object]') {
            token = null;
            localStorage.removeItem('rdx_token');
        }

        if (urlParams.has('auth_token') && token) {
            localStorage.setItem('rdx_token', token);
            window.history.replaceState({}, document.title, window.location.pathname);
        }

        if (!token) {
            navigate('/login');
            return;
        }

        // Background sync
        fetch('/rdx/api/auth/me', {
            headers: { 'Authorization': 'Bearer ' + token }
        })
            .then(res => {
                if (res.status === 401 || res.status === 403) {
                    localStorage.removeItem('rdx_token');
                    window.__RDX_AUTH_CACHE = null;
                    navigate('/login');
                    return null;
                }
                if (!res.ok) throw new Error('Sync failed');
                return res.json();
            })
            .then(resJson => {
                if (resJson && resJson.success) {
                    // Profile.jsx uses the root response object (resJson) because it's flattened
                    // by responseHelper. This ensures all keys like username, email, stats, etc.
                    // are available directly on the userContextData object.
                    setUserContextData(resJson);
                    window.__RDX_AUTH_CACHE = { user: resJson, timestamp: Date.now() };
                } else if (resJson) {
                    // Logic to handle success: false but status 200
                    if (resJson.message?.toLowerCase().includes('not found')) {
                        localStorage.removeItem('rdx_token');
                        navigate('/login');
                    }
                }
            })
            .catch(e => {
                console.error('[RDX Hub] Auth sync failed:', e);
                // If persistent failure and no cache, force logout to avoid getting stuck
                setTimeout(() => {
                    const currentCache = window.__RDX_AUTH_CACHE;
                    if (!currentCache || currentCache.user?.username === 'DEBUG_USER') {
                        localStorage.removeItem('rdx_token');
                        navigate('/login');
                    }
                }, 5000); 
            })
            .finally(() => setIsLoading(false));
    }, [navigate]);

    // Scroll main content to top on route change
    useEffect(() => {
        if (contentRef.current) {
            contentRef.current.scrollTop = 0;
        }
    }, [location.pathname]);

    const toggleSidebar = () => {
        setIsMobileOpen((prev) => !prev);
    };

    const handleLogout = () => {
        if (window.confirm("Are you sure you want to log out?")) {
            localStorage.removeItem('rdx_token');
            window.__RDX_AUTH_CACHE = null;
            navigate('/login');
        }
    };

    // If completely new session and no cache, show a minimal flicker-free loader
    if (isLoading && !window.__RDX_AUTH_CACHE) {
        return (
            <div className="min-h-screen bg-background-dark flex items-center justify-center">
                <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
            </div>
        );
    }

    return (
        <div className="font-display bg-background-dark text-slate-200 h-screen w-full flex overflow-hidden lg:ml-0 selection:bg-primary selection:text-white">
            {/* Background effects - fixed and behind everything */}
            <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
                <div className="absolute inset-0 bg-cyber-grid bg-[length:50px_50px] opacity-10"></div>
                <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-primary/10 rounded-full mix-blend-screen filter blur-[100px] animate-blob"></div>
                <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-blue-600/5 rounded-full mix-blend-screen filter blur-[100px] animate-blob" style={{ animationDelay: '2s' }}></div>
            </div>

            <div className="relative z-10 flex h-full w-full overflow-hidden">
                <Sidebar
                    isMobileOpen={isMobileOpen}
                    toggleSidebar={toggleSidebar}
                    userContextData={userContextData}
                    onLogout={handleLogout}
                />

                <main className="flex-1 flex flex-col min-w-0 transition-all duration-300 lg:pl-72 relative z-10">
                    <TopNav toggleSidebar={toggleSidebar} />

                    {/* Main Content Area */}
                    <div 
                        ref={contentRef}
                        className="flex-1 overflow-y-auto p-4 lg:p-8 scroll-smooth custom-scrollbar relative z-10"
                    >
                        {children}
                    </div>
                </main>
            </div>
        </div>
    );
};

export default DashboardLayout;
