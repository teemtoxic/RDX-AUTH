import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Navbar = ({ userContextId }) => {
    const navigate = useNavigate();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    const spaRoutes = ['/pricing', '/dashboard', '/login', '/signup', '/'];

    const toggleMobileMenu = () => {
        setIsMobileMenuOpen(!isMobileMenuOpen);
        if (!isMobileMenuOpen) {
            document.body.classList.add('overflow-hidden');
        } else {
            document.body.classList.remove('overflow-hidden');
        }
    };

    const handleLinkClick = (e, dest) => {
        // If it's a relative anchor on the home page, let it handle naturally or scroll
        if (dest.startsWith('#')) {
            const el = document.querySelector(dest);
            if (el) {
                e.preventDefault();
                el.scrollIntoView({ behavior: 'smooth' });
                return;
            }
        }

        // Special handling for security-check
        if (dest.includes('/security-check')) {
            e.preventDefault();
            const next = userContextId ? '/dashboard' : '/login';
            window.location.href = `/security-check?next=${next}`;
            return;
        }

        // Check if it's an SPA route
        if (spaRoutes.includes(dest)) {
            e.preventDefault();
            navigate(dest);
        } else {
            // Let the default link behavior (browser navigation) handle it for non-SPA routes
            // Or use window.location.href if specifically needed
        }
    };

    return (
        <div className="fixed top-0 left-0 right-0 z-50 flex justify-center px-4 pt-6">
            <nav className="glass rounded-full px-6 py-3 flex items-center justify-between gap-8 max-w-5xl w-full shadow-lg border border-white/10 transition-all duration-300 hover:border-primary/30 hover:shadow-neon-sm">
                <div className="flex items-center gap-3 cursor-pointer" onClick={(e) => handleLinkClick(e, '/')}>
                    <div className="text-primary relative">
                        <span className="absolute inset-0 blur-sm text-secondary opacity-50 material-symbols-outlined text-[28px]">shield_lock</span>
                        <span className="material-symbols-outlined text-[28px] relative z-10">shield_lock</span>
                    </div>
                    <span className="text-lg font-bold tracking-tight text-white">RDX Authentication</span>
                </div>
                <div className="hidden md:flex items-center gap-8">
                    <a className="text-sm font-medium text-gray-300 hover:text-white transition-colors cursor-pointer"
                        href="/#features" onClick={(e) => handleLinkClick(e, '#features')}>Features</a>
                    <a className="text-sm font-medium text-gray-300 hover:text-white transition-colors cursor-pointer" 
                        href="/api-docs" onClick={(e) => handleLinkClick(e, '/api-docs')}>API</a>
                    <a className="text-sm font-medium text-gray-300 hover:text-white transition-colors cursor-pointer"
                        href="/pricing" onClick={(e) => handleLinkClick(e, '/pricing')}>Pricing</a>
                    <a className="text-sm font-medium text-gray-300 hover:text-white transition-colors cursor-pointer"
                        href="/status" onClick={(e) => handleLinkClick(e, '/status')}>Status</a>
                    <a className="text-sm font-medium text-gray-300 hover:text-white transition-colors cursor-pointer"
                        href="/support" onClick={(e) => handleLinkClick(e, '/support')}>Support</a>
                    <a className="text-sm font-medium text-gray-300 hover:text-white transition-colors cursor-pointer"
                        href="/docs" onClick={(e) => handleLinkClick(e, '/docs')}>Documentation</a>
                </div>
                <button id="navActionBtn" onClick={(e) => handleLinkClick(e, '/security-check')}
                    className="bg-primary hover:bg-primary-hover text-white text-sm font-bold py-2 px-5 rounded-full transition-all duration-300 shadow-neon-sm hover:shadow-neon hover:scale-105 active:scale-95">
                    {userContextId ? 'Dashboard' : 'Get Started'}
                </button>

                <button id="mobile-menu-btn" onClick={toggleMobileMenu}
                    className="md:hidden text-white p-2 hover:bg-white/10 rounded-full transition-colors">
                    <span className="material-symbols-outlined">menu</span>
                </button>
            </nav>

            {/* Mobile Menu Overlay */}
            <div id="mobile-menu" className={`fixed inset-0 z-40 md:hidden ${isMobileMenuOpen ? '' : 'hidden'}`}>
                <div className="absolute inset-0 bg-background-dark/90 backdrop-blur-xl" onClick={toggleMobileMenu}></div>
                <div className="absolute right-0 top-0 bottom-0 w-64 bg-[#0B0B12] border-l border-white/10 p-6 flex flex-col gap-6 shadow-2xl animate-slide-in">
                    <div className="flex justify-end">
                        <button onClick={toggleMobileMenu} className="text-gray-400 hover:text-white transition-colors">
                            <span className="material-symbols-outlined">close</span>
                        </button>
                    </div>
                    <div className="flex flex-col gap-4">
                        <a className="text-lg font-medium text-gray-300 hover:text-white transition-colors py-2 border-b border-white/5 cursor-pointer"
                            href="/#features" onClick={(e) => { handleLinkClick(e, '#features'); toggleMobileMenu(); }}>Features</a>
                        <a className="text-lg font-medium text-gray-300 hover:text-white transition-colors py-2 border-b border-white/5 cursor-pointer"
                            href="/api-docs" onClick={(e) => { handleLinkClick(e, '/api-docs'); toggleMobileMenu(); }}>API</a>
                        <a className="text-lg font-medium text-gray-300 hover:text-white transition-colors py-2 border-b border-white/5 cursor-pointer"
                            href="/status" onClick={(e) => { handleLinkClick(e, '/status'); toggleMobileMenu(); }}>Status</a>
                        <a className="text-lg font-medium text-gray-300 hover:text-white transition-colors py-2 border-b border-white/5 cursor-pointer"
                            href="/support" onClick={(e) => { handleLinkClick(e, '/support'); toggleMobileMenu(); }}>Support</a>
                        <a className="text-lg font-medium text-gray-300 hover:text-white transition-colors py-2 border-b border-white/5 cursor-pointer"
                            href="/pricing" onClick={(e) => { handleLinkClick(e, '/pricing'); toggleMobileMenu(); }}>Pricing</a>
                        <a className="text-lg font-medium text-gray-300 hover:text-white transition-colors py-2 border-b border-white/5 cursor-pointer"
                            href="/docs" onClick={(e) => { handleLinkClick(e, '/docs'); toggleMobileMenu(); }}>Documentation</a>
                    </div>
                    <div className="mt-auto">
                        <button onClick={(e) => { handleLinkClick(e, '/security-check'); toggleMobileMenu(); }}
                            className="w-full bg-primary hover:bg-primary-hover text-white font-bold py-3 rounded-xl transition-all shadow-neon-sm">
                            {userContextId ? 'Access Dashboard' : 'Get Started'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};


export default Navbar;
