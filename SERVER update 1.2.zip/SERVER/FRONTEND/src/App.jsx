import { Routes, Route, Navigate, Outlet } from 'react-router-dom';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import DiscordGuardian from './pages/DiscordGuardian';
import KeyDistribution from './pages/KeyDistribution';
import AiConsole from './pages/AiConsole';
import AppSubscriptions from './pages/AppSubscriptions';
import Users from './pages/Users';
import Licenses from './pages/Licenses';
import SecurityOverview from './pages/SecurityOverview';
import SecurityMonitoring from './pages/SecurityMonitoring';
import SecurityActions from './pages/SecurityActions';
import Variables from './pages/Variables';
import Apps from './pages/Apps';
import Analytics from './pages/Analytics';
import Profile from './pages/Profile';
import Billing from './pages/Billing';
import Pricing from './pages/Pricing';
import Support from './pages/Support';
import Recovery from './pages/Recovery';
import DashboardLayout from './components/shared/DashboardLayout';
import Orders from './pages/Orders';
import SystemLogs from './pages/SystemLogs';
import SystemSettings from './pages/SystemSettings';
import Admin from './pages/Admin';


// Persistent Layout Wrapper using Outlet
const ProtectedLayout = () => {
    return (
        <DashboardLayout>
            <Outlet />
        </DashboardLayout>
    );
};

function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/recovery" element={<Recovery />} />
      <Route path="/pricing" element={<Pricing />} />
      
      {/* Protected Routes Wrapper - Single instance, nested children */}
      <Route element={<ProtectedLayout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/apps" element={<Apps />} />
          <Route path="/app-subscriptions" element={<AppSubscriptions />} />
          <Route path="/users" element={<Users />} />
          <Route path="/licenses" element={<Licenses />} />
          <Route path="/variables" element={<Variables />} />
          <Route path="/security-overview" element={<SecurityOverview />} />
          <Route path="/security-monitoring" element={<SecurityMonitoring />} />
          <Route path="/security-actions" element={<SecurityActions />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/billing" element={<Billing />} />
          <Route path="/support" element={<Support />} />
          <Route path="/discord" element={<DiscordGuardian />} />
          <Route path="/key-distribution" element={<KeyDistribution />} />
          <Route path="/ai-console" element={<AiConsole />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/logs" element={<SystemLogs />} />
          <Route path="/admin" element={<Admin />} />
      </Route>
      
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;
