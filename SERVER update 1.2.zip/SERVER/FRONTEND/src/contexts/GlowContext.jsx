import React, { createContext, useContext, useState, useEffect } from 'react';

const GlowContext = createContext();

export const useGlow = () => {
    return useContext(GlowContext);
};

export const GlowProvider = ({ children }) => {
    const [isGlowEnabled, setIsGlowEnabled] = useState(() => {
        const saved = localStorage.getItem('rdx_glow_enabled');
        return saved !== null ? JSON.parse(saved) : true;
    });

    const [isGlassEnabled, setIsGlassEnabled] = useState(() => {
        const saved = localStorage.getItem('rdx_glass_enabled');
        return saved !== null ? JSON.parse(saved) : false;
    });

    useEffect(() => {
        localStorage.setItem('rdx_glow_enabled', JSON.stringify(isGlowEnabled));
        if (isGlowEnabled) {
            document.body.classList.add('glow-enabled');
        } else {
            document.body.classList.remove('glow-enabled');
        }
    }, [isGlowEnabled]);

    useEffect(() => {
        localStorage.setItem('rdx_glass_enabled', JSON.stringify(isGlassEnabled));
        if (isGlassEnabled) {
            document.body.classList.add('glass-enabled');
        } else {
            document.body.classList.remove('glass-enabled');
        }
    }, [isGlassEnabled]);

    const toggleGlow = () => setIsGlowEnabled(prev => !prev);
    const toggleGlass = () => setIsGlassEnabled(prev => !prev);

    return (
        <GlowContext.Provider value={{ isGlowEnabled, toggleGlow, isGlassEnabled, toggleGlass }}>
            {children}
        </GlowContext.Provider>
    );
};
