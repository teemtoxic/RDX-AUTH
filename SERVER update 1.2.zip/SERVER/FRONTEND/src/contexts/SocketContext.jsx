import React, { createContext, useContext, useState, useEffect } from 'react';
import { io } from 'socket.io-client';

const SocketContext = createContext();

export const useSocket = () => {
    return useContext(SocketContext);
};

export const SocketProvider = ({ children }) => {
    const [socket, setSocket] = useState(null);
    const [notifications, setNotifications] = useState([]);
    const [isConnected, setIsConnected] = useState(false);

    useEffect(() => {
        const token = localStorage.getItem('rdx_token');
        if (!token) return;

        // Parse token to get user ID
        let userId = null;
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            userId = payload.id;
        } catch (e) {
            console.error('[Socket] Failed to parse token', e);
        }

        const newSocket = io(window.location.origin, {
            auth: { token }
        });

        newSocket.on('connect', () => {
            console.log('[Socket] Connected to RDX Nexus');
            setIsConnected(true);
            if (userId) {
                newSocket.emit('join_user_room', userId);
            }
        });

        newSocket.on('disconnect', () => {
            setIsConnected(false);
            console.log('[Socket] Disconnected');
        });

        newSocket.on('notification', (notif) => {
            // notif: { id, title, message, type, timestamp }
            setNotifications(prev => [
                { id: Date.now(), timestamp: new Date(), ...notif },
                ...prev
            ].slice(0, 20)); // Keep last 20
        });

        setSocket(newSocket);

        return () => newSocket.close();
    }, []);

    const clearNotifications = () => setNotifications([]);
    const markAsRead = (id) => {
        setNotifications(prev => prev.filter(n => n.id !== id));
    };

    return (
        <SocketContext.Provider value={{ socket, notifications, isConnected, clearNotifications, markAsRead }}>
            {children}
        </SocketContext.Provider>
    );
};
