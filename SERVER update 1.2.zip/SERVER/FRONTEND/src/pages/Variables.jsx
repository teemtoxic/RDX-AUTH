import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const Variables = () => {
    const [apps, setApps] = useState([]);
    const [selectedAppId, setSelectedAppId] = useState('');
    const [variables, setVariables] = useState([]);
    const [quickConfig, setQuickConfig] = useState({ title: '', discord: '', instagram: '', youtube: '', message: '' });
    const [sdkType, setSdkType] = useState('cpp');
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [newVar, setNewVar] = useState({ name: '', value: '' });
    const token = localStorage.getItem('rdx_token');

    useEffect(() => {
        fetchApps();
    }, []);

    useEffect(() => {
        if (selectedAppId) {
            loadVariables(selectedAppId);
        }
    }, [selectedAppId]);

    const fetchApps = async () => {
        try {
            const res = await fetch('/rdx/api/apps', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                setApps(data.apps);
                if (data.apps.length > 0) setSelectedAppId(data.apps[0].id);
            }
        } catch (e) { console.error('Error fetching apps:', e); }
    };

    const loadVariables = async (appId) => {
        try {
            const res = await fetch(`/rdx/api/variables?app_id=${appId}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                const vars = Object.entries(data.variables).map(([name, value]) => ({ name, value }));
                setVariables(vars);

                // Set quick config if exists
                setQuickConfig({
                    title: data.variables['title'] || '',
                    discord: data.variables['discord'] || '',
                    instagram: data.variables['instagram'] || '',
                    youtube: data.variables['youtube'] || '',
                    message: data.variables['message'] || ''
                });
            }
        } catch (e) { console.error('Error loading variables:', e); }
    };

    const handleUpdateVar = async (name, value) => {
        try {
            const res = await fetch('/rdx/api/variables/update', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ app_id: selectedAppId, name, value })
            });
            const data = await res.json();
            if (data.success) {
                loadVariables(selectedAppId);
            }
        } catch (e) { console.error('Error updating variable:', e); }
    };

    const handleDeleteVar = async (name) => {
        if (!window.confirm(`Delete variable ${name}?`)) return;
        try {
            const res = await fetch('/rdx/api/variables/delete', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ app_id: selectedAppId, name })
            });
            const data = await res.json();
            if (data.success) {
                loadVariables(selectedAppId);
            }
        } catch (e) { console.error('Error deleting variable:', e); }
    };

    const saveQuickConfig = async () => {
        for (const [name, value] of Object.entries(quickConfig)) {
            await handleUpdateVar(name, value);
        }
        alert('Quick config updated!');
    };

    const handleCreateVar = async (e) => {
        e.preventDefault();
        await handleUpdateVar(newVar.name, newVar.value);
        setIsAddModalOpen(false);
        setNewVar({ name: '', value: '' });
    };

    const sdkSnippets = {
        cpp: `// Fetch variable using KeyAuth Compatibility\nstring myVar = KeyAuthApp.var("VARIABLE_NAME");\nConsole.WriteLine("Value: " + myVar);`,
        py: `# Python Example\nvariable = keyauthapp.var("VARIABLE_NAME")\nprint(f"Server says: {variable}")`,
        js: `// Node.js API\nconst res = await fetch('https://rdxcommunity.qzz.io/rdx/api/variables?app_id=YOUR_APP_ID');\nconst data = await res.json();\nconsole.log(data.variables['VARIABLE_NAME']);`
    };

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-3xl font-bold text-white mb-2 tracking-tighter text-shadow-glow flex items-center gap-3">
                        <span className="material-symbols-outlined text-4xl text-primary">data_object</span>
                        Remote Configuration
                    </h2>
                    <p className="text-slate-400">Manage global app variables and feature toggles.</p>
                </div>
                <div className="flex gap-3">
                    <div className="relative">
                        <select
                            value={selectedAppId}
                            onChange={(e) => setSelectedAppId(e.target.value)}
                            className="bg-slate-900 border border-white/5 rounded-lg pl-4 pr-10 py-2.5 text-sm text-white hover:border-primary/50 transition-all uppercase tracking-wider font-bold focus:outline-none focus:ring-1 focus:ring-primary/50 appearance-none h-full"
                        >
                            <option value="">Select Application</option>
                            {apps.map(app => (
                                <option key={app.id} value={app.id}>{app.name}</option>
                            ))}
                        </select>
                        <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-[18px] opacity-50 pointer-events-none">expand_more</span>
                    </div>
                    <button
                        onClick={() => setIsAddModalOpen(true)}
                        className="bg-primary hover:bg-primary-glow text-white text-sm font-bold px-6 py-2.5 rounded-lg shadow-neon transition-all flex items-center gap-2 "
                    >
                        <span className="material-symbols-outlined text-[20px]">add_circle</span>
                        New Variable
                    </button>
                </div>
            </div>

            {/* Quick Config Card (Original Style) */}
            <div className="glass-panel p-6 rounded-xl border border-primary/20 bg-slate-900/40 relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity pointer-events-none">
                    <span className="material-symbols-outlined text-9xl text-primary">settings_suggest</span>
                </div>

                <div className="flex items-center gap-3 mb-6 relative z-10">
                    <div className="p-2 bg-primary/10 rounded-lg text-primary shadow-neon-sm">
                        <span className="material-symbols-outlined">settings_suggest</span>
                    </div>
                    <div>
                        <h3 className="text-lg font-bold text-white">Quick Remote Config</h3>
                        <p className="text-xs text-slate-400">Easy-to-use templates for common settings.</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10">
                    <div className="space-y-2">
                        <label className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">App Display Title</label>
                        <input
                            type="text" value={quickConfig.title} onChange={e => setQuickConfig({ ...quickConfig, title: e.target.value })}
                            placeholder="e.g. RDX COMMUNITY"
                            className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-sm text-white focus:border-primary/50 outline-none transition-all shadow-inner"
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Discord Link</label>
                        <input
                            type="text" value={quickConfig.discord} onChange={e => setQuickConfig({ ...quickConfig, discord: e.target.value })}
                            placeholder="https://discord.gg/..."
                            className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-sm text-white focus:border-primary/50 outline-none transition-all shadow-inner"
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Instagram Link</label>
                        <input
                            type="text" value={quickConfig.instagram} onChange={e => setQuickConfig({ ...quickConfig, instagram: e.target.value })}
                            placeholder="https://instagram.com/..."
                            className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-sm text-white focus:border-primary/50 outline-none transition-all shadow-inner"
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">YouTube Link</label>
                        <input
                            type="text" value={quickConfig.youtube} onChange={e => setQuickConfig({ ...quickConfig, youtube: e.target.value })}
                            placeholder="https://youtube.com/..."
                            className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-sm text-white focus:border-primary/50 outline-none transition-all shadow-inner"
                        />
                    </div>
                    <div className="space-y-2 lg:col-span-2">
                        <label className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Alert/News Message</label>
                        <input
                            type="text" value={quickConfig.message} onChange={e => setQuickConfig({ ...quickConfig, message: e.target.value })}
                            placeholder="e.g. New Update v1.2 is here!"
                            className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-sm text-white focus:border-primary/50 outline-none transition-all shadow-inner"
                        />
                    </div>
                </div>

                <div className="mt-6 pt-6 border-t border-white/5 flex justify-end relative z-10">
                    <button
                        onClick={saveQuickConfig}
                        className="bg-primary hover:bg-primary-glow text-white text-xs font-bold px-6 py-2.5 rounded-lg transition-all flex items-center gap-2 shadow-neon-sm"
                    >
                        <span className="material-symbols-outlined text-[18px]">save</span>
                        Update Remote UI
                    </button>
                </div>
            </div>

            {/* Main Variables Grid */}
            {!selectedAppId || variables.length === 0 ? (
                <div className="glass-panel p-12 rounded-xl text-center border-dashed border-2 border-white/5 space-y-4">
                    <div className="w-16 h-16 rounded-full bg-slate-800/50 flex items-center justify-center mx-auto text-slate-600 shadow-inner">
                        <span className="material-symbols-outlined text-3xl">data_object</span>
                    </div>
                    <h3 className="text-xl font-bold text-white">No Variables Found</h3>
                    <p className="text-slate-500 max-w-sm mx-auto">Select an application to manage its remote configuration or create your first variable.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {variables.filter(v => !['title', 'discord', 'instagram', 'youtube', 'message'].includes(v.name)).map((v, idx) => (
                        <div key={idx} className="glass-panel p-5 rounded-xl border border-white/5 bg-slate-900/50 hover:border-primary/30 transition-all group relative overflow-hidden flex flex-col justify-between min-h-[120px]">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-full blur-2xl group-hover:bg-primary/10 transition-colors pointer-events-none"></div>
                            <div className="z-10 relative">
                                <div className="flex justify-between items-start mb-2">
                                    <h4 className="text-sm font-bold text-white tracking-wide">{v.name}</h4>
                                    <button onClick={() => handleDeleteVar(v.name)} className="text-slate-600 hover:text-red-400 transition-colors bg-white/5 p-1 rounded-md">
                                        <span className="material-symbols-outlined text-[16px]">delete</span>
                                    </button>
                                </div>
                                <p className="text-xs text-primary font-mono bg-black/40 px-3 py-2 rounded border border-white/5 truncate break-all">{v.value}</p>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {/* Create Variable Modal */}
            {isAddModalOpen && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
                    <div className="glass-panel p-8 rounded-3xl max-w-md w-full border border-primary/20 shadow-neon bg-[#0f0f13] relative overflow-hidden">
                        <div className="absolute top-[-20%] right-[-10%] w-64 h-64 bg-primary/20 rounded-full blur-[80px] pointer-events-none"></div>

                        <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3 relative z-10">
                            <span className="material-symbols-outlined text-primary text-3xl">add_circle</span>
                            New Variable
                        </h3>
                        <form onSubmit={handleCreateVar} className="space-y-5 relative z-10">
                            <div>
                                <label className="block text-xs font-bold uppercase text-slate-500 mb-2 tracking-wider">Variable Name</label>
                                <input type="text" required value={newVar.name} onChange={e => setNewVar({ ...newVar, name: e.target.value })} className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-primary/50 outline-none transition-all shadow-inner" placeholder="e.g. MAINTENANCE_MODE" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold uppercase text-slate-500 mb-2 tracking-wider">Value</label>
                                <textarea required value={newVar.value} onChange={e => setNewVar({ ...newVar, value: e.target.value })} className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white h-28 focus:border-primary/50 outline-none transition-all shadow-inner resize-none" placeholder="Enter variable content" />
                            </div>
                            <div className="flex gap-4 pt-4">
                                <button type="button" onClick={() => setIsAddModalOpen(false)} className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-white text-sm font-bold rounded-xl transition-all">Cancel</button>
                                <button type="submit" className="flex-1 py-3 bg-primary hover:bg-primary-glow text-white text-sm font-bold rounded-xl transition-all shadow-neon-sm flex items-center justify-center gap-2">
                                    <span className="material-symbols-outlined text-[18px]">add</span>
                                    Create
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Variables;
