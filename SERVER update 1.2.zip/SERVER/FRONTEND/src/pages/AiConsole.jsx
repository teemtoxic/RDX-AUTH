import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { motion, AnimatePresence } from 'framer-motion';

const AiConsole = () => {
    const navigate = useNavigate();
    
    // Auth States
    const [isLoading, setIsLoading] = useState(!window.__RDX_AUTH_CACHE);
    const [userPlan, setUserPlan] = useState(window.__RDX_AUTH_CACHE?.user?.plan || '');
    const [isPro, setIsPro] = useState(window.__RDX_AUTH_CACHE?.user?.plan?.toLowerCase().includes('pro') || false);

    // Chat States
    const [messages, setMessages] = useState([
        { sender: 'ai', text: 'Hello Sir! Main aapka AI Assistant hu. Aap mujhe app create, delete, user manage, ya maintenance on/off karne ke liye command de sakte hain. Bataiye main aapki kya madad karu?' }
    ]);
    const [input, setInput] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const [activeTasks, setActiveTasks] = useState([]);
    const [actionCounter, setActionCounter] = useState({});

    // Mainframe Status (Restored from backup)
    const [mainframeServices] = useState([
        { name: 'AUTH_SYSTEM', status: 'ACTIVE', load: '12.4%', uptime: '99.9%' },
        { name: 'DATABASE_NODE', status: 'ACTIVE', load: '45.2%', uptime: '100%' },
        { name: 'AI_ORBITER', status: 'SYNCING', load: '8.1%', uptime: '98.5%' },
        { name: 'SECURITY_VAULT', status: 'LOCKED', load: '0.0%', uptime: '100.0%' }
    ]);

    const messagesEndRef = useRef(null);
    const token = localStorage.getItem('rdx_token') || localStorage.getItem('token');
    const userPayload = token ? JSON.parse(atob(token.split('.')[1])) : null;

    useEffect(() => {
        if (!token) {
            navigate('/login');
            return;
        }
        
        // Background verify
        fetch(`/rdx/api/ai/verify/${userPayload.id}`, {
            headers: { 'Authorization': `Bearer ${token}` }
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                setUserPlan(data.plan);
                setIsPro(data.isPro);
                if (!data.isPro && messages.length === 1) {
                    setMessages([{ sender: 'ai', text: 'Warning: AI features requires a Pro/Professional plan. Your access might be restricted.' }]);
                }
            }
        })
        .catch(err => console.error('AI Verify Error:', err))
        .finally(() => setIsLoading(false));

        const fetchTasks = async () => {
            try {
                const res = await axios.get('/rdx/api/tasks', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (res.data.success) setActiveTasks(res.data.tasks);
            } catch (err) { console.error('Task fetch failed', err); }
        };
        fetchTasks();
    }, [navigate, token]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const determineAction = (text) => {
        const lower = text.toLowerCase();
        let action = 'UNKNOWN';
        let params = {};

        if (lower.includes('expiry') || lower.includes('plan khatam')) {
            action = 'GET_EXPIRY';
        } else if (lower.includes('stats') || lower.includes('status bolo')) {
            action = 'GET_STATS';
        } else if (lower.includes('apps') || lower.includes('mere apps')) {
            action = 'GET_APPS';
        } else if (lower.includes('payment') || lower.includes('history')) {
            action = 'FETCH_PAYMENTS';
        } else if (lower.includes('create user') || lower.includes('add user')) {
            action = 'CREATE_USER';
            const words = text.split(' ');
            if (words.length >= 4) {
               params.username = words[2];
               params.password = words[3];
               params.duration = 30;
            }
        } else if (lower.includes('delete user') || lower.includes('remove user')) {
             action = 'DELETE_USER';
             const words = text.split(' ');
             if (words.length >= 3) params.username = words[2];
        } else if (lower.includes('ban user')) {
             action = 'BAN_USER';
             const words = text.split(' ');
             if (words.length >= 3) params.username = words[2];
        } else if (lower.includes('unban user')) {
             action = 'UNBAN_USER';
             const words = text.split(' ');
             if (words.length >= 3) params.username = words[2];
        } else if (lower.includes('create app') || lower.includes('new app')) {
             action = 'CREATE_APP';
             const words = text.split(' ');
             if (words.length >= 3) params.name = words[2];
        } else if (lower.includes('delete app') || lower.includes('remove app')) {
             action = 'DELETE_APP';
             const words = text.split(' ');
             if (words.length >= 3) params.app_id = words[2];
        } else if (lower.includes('maintenance')) {
             action = 'MAINTENANCE_MODE';
             params.status = lower.includes('on') ? 'true' : 'false';
        } else if (lower.includes('generate key') || lower.includes('new key')) {
             action = 'GENERATE_KEY';
             const words = text.split(' ');
             if (words.length >= 3) params.duration = words[2];
        } else if (lower.includes('post') && lower.includes('discord')) {
             action = 'SEND_DISCORD_MESSAGE';
             const words = text.split(' ');
             if (words.length >= 5) {
                params.channel_id = words[3];
                params.message = words.slice(4).join(' ');
             }
        } else if (lower.includes('schedule') || lower.includes('automation')) {
             action = 'SCHEDULE_TASK';
             params.action = lower.includes('key') ? 'CREATE_FREE_KEY' : 'DISCORD_POST';
             params.cron_expression = '0 18 * * *';
             params.payload = { 
                channel_id: 'GLOBAL',
                custom_message: '🎁 Automated Key Drop'
             };
        } else if (lower.includes('ticket')) {
             action = 'CREATE_TICKET';
             params.subject = "AI Generated Ticket";
             params.message = text;
        }

        return { action, params };
    };

    const handleSendMessage = async (e) => {
        if (e) e.preventDefault();
        if (!input.trim() || !isPro || isTyping) return;

        const userText = input.trim();
        setMessages(prev => [...prev, { sender: 'user', text: userText }]);
        setInput('');
        setIsTyping(true);

        const lower = userText.toLowerCase();
        let currentPattern = null;
        if (lower.includes('create') || lower.includes('generate')) currentPattern = 'CREATION';
        
        if (currentPattern) {
            const count = (actionCounter[currentPattern] || 0) + 1;
            setActionCounter(prev => ({ ...prev, [currentPattern]: count }));
            if (count === 3) {
                setTimeout(() => {
                    setMessages(prev => [...prev, {
                        sender: 'ai',
                        text: "Sir, maine notice kiya aap ye kaam roz (kaafi baar) kar rahe hain. Kya main iska ek 'Daily Schedule' bana lu? Aapka time bach jayega! 👑"
                    }]);
                }, 1000);
            }
        }

        const { action, params } = determineAction(userText);

        if (action === 'UNKNOWN') {
            setTimeout(() => {
                setMessages(prev => [...prev, { sender: 'ai', text: 'Sir, mujhe ye command samajh nahi aayi. Main mostly apps, users, keys manage karne aur stats check karne me madad kar sakta hu. Please thoda specific batayein.' }]);
                setIsTyping(false);
            }, 1000);
            return;
        }

        try {
            const res = await fetch('/rdx/api/ai/execute', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    accountId: userPayload.id,
                    action,
                    params
                })
            });

            const data = await res.json();
            
            setMessages(prev => [...prev, { 
                sender: 'ai', 
                text: data.message || (data.success ? 'Command executed successfully.' : 'Action failed.'),
                data: data.data
            }]);

        } catch (error) {
            console.error('AI Execute Error:', error);
            setMessages(prev => [...prev, { sender: 'ai', text: 'Connection error. Main abhi API se connect nahi kar paa raha hu.' }]);
        } finally {
            setIsTyping(false);
        }
    };

    return (
        <div className="relative z-10 flex flex-col gap-6 w-full max-w-7xl mx-auto animate-in fade-in duration-500">
            {/* Top Bar for status */}
            {isLoading && (
                <div className="absolute top-0 right-0 p-2 flex items-center gap-2 text-[10px] text-primary font-bold uppercase tracking-widest bg-primary/10 rounded-bl-xl border-l border-b border-primary/20 z-50">
                    <span className="material-symbols-outlined text-[12px] animate-spin">sync</span>
                    Refreshing Core Data...
                </div>
            )}

            <div className="flex flex-col lg:flex-row gap-6 h-full min-h-[600px]">
                {/* Chat Section */}
                <div className="glass-panel flex-1 rounded-2xl border border-primary/20 bg-slate-900/80 backdrop-blur-xl shadow-2xl flex flex-col overflow-hidden min-h-[500px]">
                    {/* Header */}
                    <div className="p-6 border-b border-white/5 flex items-center justify-between bg-black/20">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center border border-primary/30 relative text-primary">
                                <span className="material-symbols-outlined text-2xl text-shadow-glow">smart_toy</span>
                                <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-pulse border-2 border-slate-900"></div>
                            </div>
                            <div>
                                <h2 className="text-xl font-black text-white uppercase tracking-widest text-shadow-glow">Nexus AI Assistant</h2>
                                <p className="text-xs text-slate-400 font-mono tracking-wider">Secure Administrative Terminal</p>
                            </div>
                        </div>
                        <div className="hidden sm:block text-right">
                            <div className="text-xs text-slate-500 font-bold uppercase tracking-widest">Plan Level</div>
                            <div className={`text-sm font-black ${isPro ? 'text-green-400' : 'text-red-400'} uppercase tracking-widest`}>
                                {userPlan || 'BASIC'}
                            </div>
                        </div>
                    </div>

                    {/* Chat Area */}
                    <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
                        <AnimatePresence initial={false}>
                            {messages.map((msg, i) => (
                                <motion.div 
                                    key={i} 
                                    initial={{ opacity: 0, x: msg.sender === 'user' ? 20 : -20, y: 10 }}
                                    animate={{ opacity: 1, x: 0, y: 0 }}
                                    className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                                >
                                    <div className={`max-w-[80%] rounded-2xl p-4 shadow-lg ${
                                        msg.sender === 'user' 
                                        ? 'bg-primary text-white ml-auto rounded-br-sm shadow-[0_0_20px_rgba(140,37,244,0.3)]' 
                                        : 'bg-white/5 border border-white/10 text-slate-300 rounded-bl-sm'
                                    }`}>
                                        {msg.sender === 'ai' && (
                                            <div className="flex items-center gap-2 mb-2 text-primary font-bold text-[10px] uppercase tracking-widest">
                                                <span className="material-symbols-outlined text-[14px]">smart_toy</span>
                                                Nexus AI Output
                                            </div>
                                        )}
                                        <p className="text-sm leading-relaxed font-medium">{msg.text}</p>
                                        {msg.data && (
                                            <pre className="mt-3 bg-black/40 p-3 rounded-lg text-xs font-mono text-green-400 overflow-x-auto border border-green-500/20">
                                                {JSON.stringify(msg.data, null, 2)}
                                            </pre>
                                        )}
                                    </div>
                                </motion.div>
                            ))}
                        </AnimatePresence>
                        {isTyping && (
                            <div className="flex justify-start">
                                <div className="bg-white/5 border border-white/10 rounded-2xl rounded-bl-sm p-4">
                                    <div className="flex gap-1 items-center justify-center">
                                        <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce"></div>
                                        <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }}></div>
                                        <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }}></div>
                                    </div>
                                </div>
                            </div>
                        )}
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Input Area */}
                    <div className="p-4 bg-black/30 border-t border-white/5 relative">
                        {isPro ? (
                            <form onSubmit={handleSendMessage} className="relative flex items-center">
                                <span className="material-symbols-outlined absolute left-4 text-primary">terminal</span>
                                <input 
                                    type="text" 
                                    value={input}
                                    onChange={(e) => setInput(e.target.value)}
                                    placeholder="Execute AI command (e.g. 'stats', 'create app', 'ban user')..."
                                    className="w-full bg-slate-900/80 border border-white/10 rounded-xl py-4 pl-12 pr-16 text-sm text-white focus:outline-none focus:border-primary/50 shadow-inner font-mono transition-all"
                                    disabled={isTyping}
                                />
                                <button 
                                    type="submit" 
                                    disabled={!input.trim() || isTyping}
                                    className="absolute right-2 bg-primary hover:bg-primary-glow text-white p-2 rounded-lg transition-all flex items-center justify-center h-10 w-10 disabled:opacity-50"
                                >
                                    <span className="material-symbols-outlined">rocket_launch</span>
                                </button>
                            </form>
                        ) : (
                            <div className="text-center py-4 text-red-400/80 text-sm font-bold bg-red-500/10 rounded-lg border border-red-500/20 flex flex-col items-center justify-center gap-2">
                                <span className="material-symbols-outlined text-3xl">lock</span>
                                AI Console is restricted to Pro tier plans.
                            </div>
                        )}
                    </div>
                </div>

                {/* Right Sidebar: Mainframe & Tasks */}
                <div className="w-full lg:w-80 flex flex-col gap-6">
                    {/* Mainframe Status Section (Restored from backup) */}
                    <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-slate-900/40">
                        <div className="flex items-center justify-between mb-6">
                            <h3 className="text-xs font-black text-white uppercase tracking-widest flex items-center gap-2">
                                <span className="material-symbols-outlined text-primary text-sm">terminal</span>
                                Mainframe Status
                            </h3>
                            <div className="flex items-center gap-1.5">
                                <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
                                <span className="text-[9px] text-slate-500 font-mono">LIVE</span>
                            </div>
                        </div>
                        
                        <div className="space-y-3">
                            {mainframeServices.map(service => (
                                <div key={service.name} className="p-3 bg-white/5 border border-white/5 rounded-xl hover:bg-white/10 transition-colors group">
                                    <div className="flex justify-between items-start mb-2">
                                        <span className="text-[10px] font-mono text-primary font-bold">{service.name}</span>
                                        <span className={`px-1.5 py-0.5 rounded text-[8px] font-black ${service.status === 'ACTIVE' ? 'bg-green-500/10 text-green-500' : 'bg-yellow-500/10 text-yellow-500'}`}>
                                            {service.status}
                                        </span>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <div className="flex flex-col">
                                            <span className="text-[8px] text-slate-500 uppercase tracking-tighter">Load</span>
                                            <span className="text-xs text-white font-bold">{service.load}</span>
                                        </div>
                                        <div className="flex flex-col text-right">
                                            <span className="text-[8px] text-slate-500 uppercase tracking-tighter">Uptime</span>
                                            <span className="text-xs text-slate-400 font-mono">{service.uptime}</span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Active Automation Section */}
                    <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-slate-900/40 flex-1 overflow-hidden flex flex-col">
                        <h3 className="text-xs font-black text-primary uppercase tracking-widest flex items-center gap-2 mb-6">
                            <span className="material-symbols-outlined text-sm">robot_2</span> 
                            Active Automation
                        </h3>
                        <div className="flex-1 overflow-y-auto space-y-4 custom-scrollbar">
                            {activeTasks.length === 0 ? (
                                <div className="flex flex-col items-center justify-center h-full opacity-30 text-center py-10">
                                    <span className="material-symbols-outlined text-4xl mb-2">event_busy</span>
                                    <p className="text-[10px] font-bold uppercase tracking-widest">No Active Schedules</p>
                                </div>
                            ) : (
                                activeTasks.map(task => (
                                    <div key={task.id} className="p-4 bg-white/5 border border-white/5 rounded-xl hover:border-primary/30 transition-colors relative overflow-hidden group">
                                        <div className="absolute top-0 right-0 p-1 opacity-10 group-hover:opacity-100 transition-opacity">
                                            <span className="material-symbols-outlined text-xs text-primary">schedule</span>
                                        </div>
                                        <div className="font-bold text-white text-xs mb-1 uppercase tracking-tight">{task.action}</div>
                                        <div className="text-slate-500 text-[9px] font-mono mb-2">CRON: {task.cron_expression}</div>
                                        <div className="flex items-center gap-2 mt-2 pt-2 border-t border-white/5">
                                            <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                                            <span className="text-[9px] text-slate-400 font-bold">LAST RUN: {task.last_run ? new Date(task.last_run).toLocaleTimeString() : 'PENDING'}</span>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AiConsole;
