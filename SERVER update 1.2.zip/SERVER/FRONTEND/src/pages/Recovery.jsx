import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Recovery = () => {
    const navigate = useNavigate();
    const [step, setStep] = useState(1);
    const [identifier, setIdentifier] = useState('');
    const [otpCode, setOtpCode] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [loading, setLoading] = useState(false);
    
    const [toast, setToast] = useState({ show: false, message: '', type: 'info' });

    const showToast = (message, type = 'info') => {
        setToast({ show: true, message, type });
        setTimeout(() => setToast(prev => ({ ...prev, show: false })), 4000);
    };

    useEffect(() => {
        const style = document.createElement('style');
        style.textContent = `
            .glass-morphism {
                background: rgba(255, 255, 255, 0.05);
                backdrop-filter: blur(24px) saturate(180%);
                border: 1px solid rgba(255, 255, 255, 0.1);
            }
            .neo-gradient-text {
                background: linear-gradient(to right, #6366f1, #ffffff, #00f5d4);
                -webkit-background-clip: text;
                color: transparent;
            }
            .celestial-orbit {
                position: absolute;
                border-radius: 50%;
                border: 1px solid rgba(255, 255, 255, 0.05);
            }
            .step-node.active {
                background-color: #6366f1;
                color: white;
                transform: scale(1.1);
                box-shadow: 0 0 20px rgba(99,102,241,0.5);
            }
            .step-node.completed {
                background-color: #00f5d4;
                color: #030208;
            }
            .animate-float {
                animation: float 6s ease-in-out infinite;
            }
            @keyframes float {
                0%, 100% { transform: translateY(0px); }
                50% { transform: translateY(-20px); }
            }
        `;
        document.head.appendChild(style);
        return () => document.head.removeChild(style);
    }, []);

    const handleSendOTP = async () => {
        if (!identifier) return showToast('Identifier payload required', 'error');
        setLoading(true);
        try {
            const res = await fetch('/rdx/api/auth/recovery/send-otp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ identifier })
            });
            const data = await res.json();
            if (data.success) {
                showToast(data.message, 'success');
                setStep(2);
            } else {
                showToast(data.message, 'error');
            }
        } catch (e) {
            showToast('Infrastructure connection failed', 'error');
        } finally {
            setLoading(false);
        }
    };

    const handleVerifyOTP = async () => {
        if (!otpCode || otpCode.length < 6) return showToast('Security code incomplete', 'error');
        setLoading(true);
        try {
            const res = await fetch('/rdx/api/auth/recovery/verify-otp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ identifier, otp: otpCode })
            });
            const data = await res.json();
            if (data.success) {
                showToast(data.message, 'success');
                setStep(3);
            } else {
                showToast(data.message, 'error');
            }
        } catch (e) {
            showToast('Authentication node link failed', 'error');
        } finally {
            setLoading(false);
        }
    };

    const handleResetPassword = async () => {
        if (newPassword !== confirmPassword) return showToast('Password mismatch', 'error');
        if (newPassword.length < 8) return showToast('Password entropy too low (min 8 chars)', 'error');
        setLoading(true);
        try {
            const res = await fetch('/rdx/api/auth/recovery/reset-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ identifier, otp: otpCode, newPassword })
            });
            const data = await res.json();
            if (data.success) {
                showToast(data.message, 'success');
                setTimeout(() => navigate('/login'), 2000);
            } else {
                showToast(data.message, 'error');
            }
        } catch (e) {
            showToast('Update transmission failed', 'error');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="dark bg-[#030208] text-slate-100 font-sans min-h-screen overflow-x-hidden selection:bg-indigo-500/30">
            {/* Celestial Background */}
            <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
                <div className="absolute top-[-10%] right-[-10%] w-[60%] h-[60%] bg-indigo-500/10 rounded-full blur-[120px] animate-pulse" style={{ animationDuration: '4s' }}></div>
                <div className="absolute bottom-[-10%] left-[-10%] w-[50%] h-[50%] bg-[#00f5d4]/5 rounded-full blur-[100px]"></div>
                <div className="celestial-orbit w-[800px] h-[800px] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"></div>
                <div className="celestial-orbit w-[1200px] h-[1200px] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rotate-45"></div>
            </div>

            {/* Navigation Header */}
            <header className="fixed top-6 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-4xl">
                <nav className="glass-morphism px-8 py-4 rounded-full flex items-center justify-between shadow-2xl">
                    <div className="flex items-center gap-3 group cursor-pointer" onClick={() => navigate('/')}>
                        <div className="p-2 rounded-xl bg-indigo-500/20 group-hover:bg-indigo-500/30 transition-all">
                            <span className="material-symbols-outlined text-indigo-500 group-hover:rotate-180 transition-transform duration-500">shield_lock</span>
                        </div>
                        <span className="text-sm font-bold tracking-[0.2em] uppercase hidden sm:block">RDX <span className="text-indigo-500">Aether</span></span>
                    </div>

                    <div className="flex items-center gap-10 text-[10px] font-bold tracking-[0.2em] text-slate-400">
                        <button onClick={() => navigate('/')} className="hover:text-white transition-colors">HOME</button>
                        <button onClick={() => navigate('/login')} className="hover:text-white transition-colors">AUTH</button>
                        <button className="hover:text-white transition-colors">STATUS</button>
                        <button className="hover:text-white transition-colors">SUPPORT</button>
                    </div>

                    <div className="hidden md:block">
                        <button onClick={() => navigate('/login')} className="px-6 py-2 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-[10px] font-bold tracking-[0.2em] uppercase">Auth Sync</button>
                    </div>
                </nav>
            </header>

            {/* Main Recovery Portal */}
            <main className="relative z-10 pt-32 pb-20 px-4 min-h-screen flex items-center justify-center">
                <div className="w-full max-w-5xl grid lg:grid-cols-2 gap-12 items-center">
                    
                    {/* Information Panel */}
                    <div className="space-y-8 animate-float">
                        <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full glass-morphism text-[10px] font-bold tracking-widest text-indigo-500 uppercase">
                            <span className="relative flex h-2 w-2">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-500 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                            </span>
                            Identity Recovery Protocol
                        </div>

                        <h1 className="text-5xl lg:text-7xl font-extrabold leading-[1.1] tracking-tight">
                            Recover your <br />
                            <span className="neo-gradient-text">Elite Status.</span>
                        </h1>

                        <p className="text-slate-400 text-lg leading-relaxed max-w-md font-light">
                            Follow the secure multi-stage verification process to regain access to your infrastructure and security assets.
                        </p>

                        <div className="grid grid-cols-2 gap-6 pt-4">
                            <div className="glass-morphism p-6 rounded-3xl space-y-3">
                                <span className="material-symbols-outlined text-indigo-500 text-3xl">verified_user</span>
                                <h3 className="text-sm font-bold">Encrypted</h3>
                                <p className="text-xs text-slate-500">Atomic end-to-end sync</p>
                            </div>
                            <div className="glass-morphism p-6 rounded-3xl space-y-3">
                                <span className="material-symbols-outlined text-[#00f5d4] text-3xl">bolt</span>
                                <h3 className="text-sm font-bold">Instant</h3>
                                <p className="text-xs text-slate-500">Real-time OTP dispatch</p>
                            </div>
                        </div>
                    </div>

                    {/* Interaction Panel */}
                    <div className="glass-morphism p-8 md:p-12 rounded-[2.5rem] shadow-[0_0_30px_rgba(99,102,241,0.1)] relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-8 opacity-5">
                            <span className="material-symbols-outlined text-[120px]">security</span>
                        </div>

                        {/* Progress Tracker */}
                        <div className="flex items-center justify-between mb-12 relative">
                            <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white/5 -translate-y-1/2 z-0"></div>
                            <div className="absolute top-1/2 left-0 h-0.5 bg-gradient-to-r from-indigo-500 to-[#00f5d4] -translate-y-1/2 z-0 transition-all duration-500" style={{ width: step === 1 ? '0%' : step === 2 ? '50%' : '100%' }}></div>

                            <div className={`step-node relative z-10 size-10 rounded-full glass-morphism flex items-center justify-center text-xs font-bold transition-all duration-500 ${step === 1 ? 'active' : 'completed'}`}>01</div>
                            <div className={`step-node relative z-10 size-10 rounded-full glass-morphism flex items-center justify-center text-xs font-bold transition-all duration-500 ${step === 2 ? 'active' : step > 2 ? 'completed' : ''}`}>02</div>
                            <div className={`step-node relative z-10 size-10 rounded-full glass-morphism flex items-center justify-center text-xs font-bold transition-all duration-500 ${step === 3 ? 'active' : ''}`}>03</div>
                        </div>

                        <div className="relative min-h-[300px]">
                            {/* Step 1: Identification */}
                            <div className={`absolute w-full space-y-6 transition-all duration-500 ${step === 1 ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10 pointer-events-none'}`}>
                                <div>
                                    <h2 className="text-2xl font-bold mb-2 text-white">Identify Payload</h2>
                                    <p className="text-slate-500 text-sm">Enter the credentials associated with your account.</p>
                                </div>
                                <div className="space-y-4">
                                    <div className="relative group">
                                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-500 transition-colors">alternate_email</span>
                                        <input value={identifier} onChange={(e) => setIdentifier(e.target.value)} type="text" placeholder="Email or Username" className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-indigo-500/50 focus:ring-4 focus:ring-indigo-500/10 transition-all placeholder:text-slate-600 outline-none text-white" />
                                    </div>
                                </div>
                                <button disabled={loading} onClick={handleSendOTP} className="w-full py-4 rounded-2xl bg-gradient-to-r from-indigo-500 to-indigo-600 hover:shadow-[0_0_30px_rgba(99,102,241,0.4)] transition-all flex items-center justify-center gap-3 group font-bold text-white disabled:opacity-50 mt-4">
                                    <span>{loading ? 'PROCESSING...' : 'DISPATCH CODE'}</span>
                                    {loading ? <span className="animate-spin material-symbols-outlined">sync</span> : <span className="material-symbols-outlined group-hover:translate-x-1 transition-transform">send</span>}
                                </button>
                            </div>

                            {/* Step 2: Verification */}
                            <div className={`absolute w-full space-y-6 transition-all duration-500 ${step === 2 ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10 pointer-events-none'}`}>
                                <div>
                                    <h2 className="text-2xl font-bold mb-2 text-white">Security Verification</h2>
                                    <p className="text-slate-500 text-sm">Input the 6-digit synchronization code sent to your inbox.</p>
                                </div>
                                <div className="flex justify-between gap-3">
                                    <input value={otpCode} onChange={(e) => setOtpCode(e.target.value)} maxLength="6" type="text" placeholder="0 0 0 0 0 0" className="w-full bg-white/5 border border-white/10 rounded-2xl py-6 text-center text-4xl font-black tracking-[0.5em] focus:outline-none focus:border-[#00f5d4]/50 focus:ring-4 focus:ring-[#00f5d4]/10 transition-all placeholder:text-slate-700 outline-none text-white" />
                                </div>
                                <button disabled={loading} onClick={handleVerifyOTP} className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#00f5d4] to-teal-400 text-background-dark hover:shadow-[0_0_30px_rgba(0,245,212,0.4)] transition-all flex items-center justify-center gap-3 group font-bold text-[#030208] disabled:opacity-50 mt-4">
                                    <span>{loading ? 'VERIFYING...' : 'VERIFY IDENTITY'}</span>
                                    <span className="material-symbols-outlined">security</span>
                                </button>
                                <div className="text-center pt-2">
                                    <button onClick={handleSendOTP} className="text-xs text-slate-500 hover:text-white transition-colors flex items-center justify-center gap-2 mx-auto">
                                        <span className="material-symbols-outlined text-sm">refresh</span> RESEND PAYLOAD
                                    </button>
                                </div>
                            </div>

                            {/* Step 3: Reset */}
                            <div className={`absolute w-full space-y-6 transition-all duration-500 ${step === 3 ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10 pointer-events-none'}`}>
                                <div>
                                    <h2 className="text-2xl font-bold mb-2 text-white">Update Credentials</h2>
                                    <p className="text-slate-500 text-sm">Construct a powerful new master password.</p>
                                </div>
                                <div className="space-y-4">
                                    <div className="relative group">
                                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-500 transition-colors">lock</span>
                                        <input value={newPassword} onChange={(e) => setNewPassword(e.target.value)} type="password" placeholder="New Master Password" className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-indigo-500/50 focus:ring-4 focus:ring-indigo-500/10 transition-all text-white outline-none" />
                                    </div>
                                    <div className="relative group">
                                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-500 transition-colors">verified</span>
                                        <input value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} type="password" placeholder="Confirm Master Password" className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-indigo-500/50 focus:ring-4 focus:ring-indigo-500/10 transition-all text-white outline-none" />
                                    </div>
                                </div>
                                <button disabled={loading} onClick={handleResetPassword} className="w-full py-4 rounded-2xl bg-gradient-to-r from-indigo-500 to-[#00f5d4] hover:shadow-[0_0_30px_rgba(99,102,241,0.4)] transition-all flex items-center justify-center gap-3 group font-bold text-[#030208] disabled:opacity-50 mt-4">
                                    <span>{loading ? 'SYNCING...' : 'SYNC NEW PASSWORD'}</span>
                                    <span className="material-symbols-outlined group-hover:rotate-45 transition-transform">published_with_changes</span>
                                </button>
                            </div>
                        </div>

                        <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between text-xs text-slate-600">
                            <button onClick={() => navigate('/login')} className="hover:text-indigo-500 transition-colors flex items-center gap-2">
                                <span className="material-symbols-outlined text-sm">arrow_back</span> Return to Auth
                            </button>
                            <span className="font-bold tracking-tighter">SECURE NODE v3.1</span>
                        </div>
                    </div>
                </div>
            </main>

            {/* Global Toast */}
            <div className={`fixed bottom-10 right-10 z-[100] transition-all duration-500 ${toast.show ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0 pointer-events-none'}`}>
                <div className="glass-morphism px-8 py-4 rounded-2xl shadow-2xl flex items-center gap-4">
                    <span className="material-symbols-outlined" style={{ color: toast.type === 'success' ? '#00f5d4' : '#ef4444' }}>
                        {toast.type === 'success' ? 'check_circle' : 'error'}
                    </span>
                    <span className="text-sm font-medium">{toast.message}</span>
                </div>
            </div>
        </div>
    );
};

export default Recovery;
