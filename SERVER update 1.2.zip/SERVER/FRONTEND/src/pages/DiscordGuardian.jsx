import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const tabHeaders = {
    'overview': { title: 'Overview', sub: 'Monitoring server telemetry and AI actions.' },
    'setup': { title: 'Server Setup', sub: 'Establish secure connection to Discord API.' },
    'rules': { title: 'Rules & Behavior', sub: 'Define behavioral boundaries for the AI.' },
    'aimode': { title: 'AI Mode', sub: 'Control AI intelligence, strictness, and learning.' },
    'security': { title: 'Security Center', sub: 'Anti-raid logic and strict threat mitigation.' },
    'logs': { title: 'Logs & Actions', sub: 'Radical transparency into the AI thought process.' },
    'advanced': { title: 'Integrations', sub: 'Webhooks, backups, and developer tools.' }
};

const DiscordGuardian = () => {
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState('overview');

    // Auth & Config States
    const [user, setUser] = useState(window.__RDX_AUTH_CACHE?.user || null);
    const [config, setConfig] = useState(null);
    const [isLoading, setIsLoading] = useState(!window.__RDX_AUTH_CACHE);

    // Form States
    const [guildId, setGuildId] = useState('');
    const [ownerId, setOwnerId] = useState('');

    useEffect(() => {
        const token = localStorage.getItem('rdx_token') || localStorage.getItem('token');
        if (!token) {
            navigate('/login');
            return;
        }

        const loadData = async () => {
            try {
                // Fetch User Info
                const userRes = await fetch('/rdx/api/auth/me', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                const userData = await userRes.json();
                
                if (userData.success && userData.user) {
                    setUser(userData.user);
                    if (userData.user.discord_server_id) setGuildId(userData.user.discord_server_id);
                    if (userData.user.discord_id) setOwnerId(userData.user.discord_id);
                }

                // Fetch Discord Config
                const configRes = await fetch('/rdx/api/auth/config/discord', {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                const configData = await configRes.json();
                if (configData.success) {
                    setConfig(configData);
                }
            } catch (error) {
                console.error("Error loading Discord config:", error);
            } finally {
                setIsLoading(false);
            }
        };

        loadData();
    }, [navigate]);

    const handleVerifyConnect = async () => {
        const token = localStorage.getItem('rdx_token') || localStorage.getItem('token');
        try {
            const res = await fetch('/rdx/api/auth/update-profile', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    discord_server_id: guildId,
                    discord_id: ownerId
                })
            });
            const data = await res.json();
            if (data.success) {
                alert('Discord Guardian Configuration Saved!');
                // Auto invite check
                if (config?.clientId) {
                    if (window.confirm("Configuration saved! Would you like to invite the bot now?")) {
                         window.open(`https://discord.com/oauth2/authorize?client_id=${config.clientId}&permissions=8&integration_type=0&scope=bot`, '_blank');
                    }
                }
            } else {
                alert(data.message || 'Failed to save config.');
            }
        } catch (error) {
            console.error(error);
            alert('Failed to save config.');
        }
    };

    return (
        <div className="relative z-10 flex flex-1 w-full flex-col lg:flex-row gap-6 animate-in fade-in duration-500">
            {/* Sidebar Navigation */}
            <aside className="w-full lg:w-64 glass-panel rounded-2xl border border-white/5 bg-slate-900/40 p-6 flex flex-col h-fit lg:h-full shrink-0">
                <div className="glass-panel p-4 rounded-xl border border-primary/20 flex flex-col items-center justify-center mb-6 text-center group relative overflow-hidden">
                    <span className="material-symbols-outlined text-4xl text-primary mb-2">robot_2</span>
                    <h3 className="text-white font-bold text-sm tracking-wide">AI Guardian</h3>
                    <p className="text-[10px] text-slate-400 uppercase tracking-widest mt-1">Status: Active</p>
                </div>

                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 px-2">Modules</p>
                <nav className="space-y-1">
                    {Object.keys(tabHeaders).map(id => (
                        <button 
                            key={id}
                            onClick={() => setActiveTab(id)} 
                            className={`w-full flex items-center px-4 py-2.5 rounded-xl text-xs font-bold transition-all border ${activeTab === id ? 'text-white bg-primary/10 border-primary/20 shadow-neon-sm' : 'text-slate-400 border-transparent hover:bg-white/5 hover:text-white'}`}
                        >
                            <span className="material-symbols-outlined text-[18px] mr-3">
                                {id === 'overview' ? 'monitoring' : id === 'setup' ? 'cable' : id === 'rules' ? 'rule' : id === 'aimode' ? 'psychology' : id === 'security' ? 'shield_locked' : id === 'logs' ? 'receipt_long' : 'code'}
                            </span>
                            {tabHeaders[id].title}
                        </button>
                    ))}
                </nav>
            </aside>

            {/* Main Content Area */}
            <main className="flex-1 glass-panel rounded-2xl border border-white/5 bg-slate-900/40 flex flex-col overflow-hidden relative">
                {isLoading && (
                    <div className="absolute top-4 right-4 z-50 flex items-center gap-2 text-[10px] font-black text-primary uppercase animate-pulse">
                        <span className="material-symbols-outlined text-[14px] animate-spin">sync</span>
                        Syncing Matrix...
                    </div>
                )}

                <div className="p-6 border-b border-white/5 bg-black/20 flex items-center justify-between">
                    <div>
                        <h1 className="text-xl font-black text-white uppercase tracking-tighter text-shadow-glow">{tabHeaders[activeTab].title}</h1>
                        <p className="text-xs text-slate-400 mt-1 font-medium italic">{tabHeaders[activeTab].sub}</p>
                    </div>
                </div>

                <div className="p-8 overflow-y-auto custom-scrollbar flex-1">
                    {/* TAB: OVERVIEW */}
                    {activeTab === 'overview' && (
                        <div className="space-y-8 animate-in slide-in-from-bottom-2 duration-300">
                             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                <div className="glass-panel p-6 rounded-xl border border-white/5 bg-white/[0.02] flex flex-col">
                                    <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-2 font-bold">Guardian Engine</p>
                                    <h3 className="text-2xl font-black text-green-400 flex items-center gap-3">
                                        <span className="w-3 h-3 rounded-full bg-green-400 animate-pulse"></span> ONLINE
                                    </h3>
                                    <div className="mt-4 pt-4 border-t border-white/5 flex gap-2">
                                         <span className="px-2 py-0.5 bg-green-500/10 text-green-500 text-[8px] font-bold rounded">LATENCY: 42ms</span>
                                         <span className="px-2 py-0.5 bg-blue-500/10 text-blue-500 text-[8px] font-bold rounded">UPTIME: 100%</span>
                                    </div>
                                </div>
                                <div className="glass-panel p-6 rounded-xl border border-white/5 bg-white/[0.02]">
                                    <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-2 font-bold">Interventions Today</p>
                                    <h3 className="text-3xl font-black text-white tracking-tighter">12 <span className="text-xs font-medium text-slate-500 ml-1">ACTIONS</span></h3>
                                    <p className="text-[10px] text-primary mt- hover:underline cursor-pointer" onClick={() => setActiveTab('logs')}>View detailed log feed →</p>
                                </div>
                                <div className="glass-panel p-6 rounded-xl border border-white/5 bg-white/[0.02]">
                                    <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-2 font-bold">Risk Level</p>
                                    <h3 className="text-2xl font-black text-blue-400 uppercase tracking-widest">Minimal</h3>
                                    <div className="w-full h-1 bg-slate-800 rounded-full mt-4">
                                        <div className="h-full bg-blue-400 rounded-full w-[15%]"></div>
                                    </div>
                                </div>
                            </div>

                            <div className="p-12 bg-black/40 rounded-3xl border border-white/5 flex flex-col items-center justify-center text-center group">
                                <div className="size-20 bg-primary/10 rounded-full flex items-center justify-center mb-6 border border-primary/20 group-hover:scale-110 transition-transform duration-500">
                                    <span className="material-symbols-outlined text-5xl text-primary animate-pulse">shield_with_heart</span>
                                </div>
                                <h3 className="text-2xl font-bold text-white tracking-tight">Telemetry Synchronized</h3>
                                <p className="text-sm text-slate-400 mt-4 max-w-lg leading-relaxed font-medium">
                                    Sir, the AI Guardian is vigilantly monitoring your linked Discord environment. No malicious payloads or raid behaviors detected in the last 24 cycles.
                                </p>
                                <button onClick={() => setActiveTab('setup')} className="mt-8 px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-bold text-white transition-all">
                                    Configure Server ID
                                </button>
                            </div>
                        </div>
                    )}

                    {/* TAB: SERVER SETUP */}
                    {activeTab === 'setup' && (
                        <div className="glass-panel p-8 rounded-3xl border border-white/10 max-w-3xl bg-white/[0.02] shadow-2xl animate-in slide-in-from-bottom-2">
                            <h2 className="text-2xl font-black text-white mb-2 uppercase tracking-tighter">Connection Parameters</h2>
                            <p className="text-sm text-slate-400 mb-8 font-medium italic">Establish a secure conduit between NEXUS and your Discord guild.</p>
                            
                            <div className="space-y-6">
                                <div className="p-4 bg-indigo-500/5 border border-indigo-500/20 rounded-xl flex gap-4 items-start">
                                    <span className="material-symbols-outlined text-indigo-400">info</span>
                                    <p className="text-xs text-indigo-300 leading-relaxed font-medium">Please ensure the bot has 'Administrator' permissions on your server for the Guardian protocol to operate autonomously.</p>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Server Guild ID</label>
                                        <input 
                                            type="text" 
                                            value={guildId} 
                                            onChange={e => setGuildId(e.target.value)} 
                                            placeholder="876543210987654321"
                                            className="w-full bg-slate-950/80 border border-white/10 rounded-2xl px-5 py-4 text-sm font-mono text-white focus:outline-none focus:border-primary shadow-inner" 
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Master Discord ID</label>
                                        <input 
                                            type="text" 
                                            value={ownerId} 
                                            onChange={e => setOwnerId(e.target.value)} 
                                            placeholder="123456789012345678"
                                            className="w-full bg-slate-950/80 border border-white/10 rounded-2xl px-5 py-4 text-sm font-mono text-white focus:outline-none focus:border-primary shadow-inner" 
                                        />
                                    </div>
                                </div>

                                <div className="pt-6 flex flex-wrap gap-4 items-center justify-between border-t border-white/5">
                                    <div className="flex items-center gap-3">
                                        <div className={`w-2 h-2 rounded-full ${config?.clientId ? 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]' : 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]'}`}></div>
                                        <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{config?.clientId ? 'Bot Authorized' : 'Bot Offline'}</span>
                                    </div>
                                    <div className="flex gap-4">
                                        {config?.clientId && (
                                            <button onClick={() => window.open(`https://discord.com/oauth2/authorize?client_id=${config.clientId}&permissions=8&integration_type=0&scope=bot`, '_blank')} className="px-6 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-2xl transition-all uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-indigo-600/20">
                                                <span className="material-symbols-outlined text-[18px]">person_add</span> Invite Bot
                                            </button>
                                        )}
                                        <button onClick={handleVerifyConnect} className="px-8 py-3.5 bg-primary hover:bg-primary-glow text-white font-black text-xs rounded-2xl transition-all uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-primary/30">
                                            <span className="material-symbols-outlined text-[18px]">sync</span> Verify & Connect
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* TAB: RULES & BEHAVIOR */}
                    {activeTab === 'rules' && (
                        <div className="space-y-8 animate-in slide-in-from-bottom-2">
                             <div className="flex items-center justify-between">
                                <div>
                                    <h2 className="text-xl font-bold text-white tracking-tight uppercase">Behavioral Matrix</h2>
                                    <p className="text-xs text-slate-400 mt-1 italic font-medium">Fine-tune AI detection thresholds and enforcement actions.</p>
                                </div>
                                <button className="px-4 py-2 bg-accent/10 hover:bg-accent/20 border border-accent/30 text-accent text-[10px] font-black uppercase rounded-lg">AI Alignment Tool</button>
                            </div>

                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {[
                                    { title: 'Spam Mitigation', icon: 'chat_error', desc: 'Flood & Repetition Control', color: 'red' },
                                    { title: 'Toxicity & Abuse', icon: 'gavel', desc: 'Slurs, Harassment, Toxicity', color: 'orange' },
                                    { title: 'Links & Invites', icon: 'link_off', desc: 'Phishing & Discord Invites', color: 'blue' },
                                    { title: 'Threat Detection', icon: 'bug_report', desc: 'Malware & Executables', color: 'purple' }
                                ].map(rule => (
                                    <div key={rule.title} className="glass-panel p-6 rounded-2xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.04] transition-colors relative overflow-hidden group">
                                         <span className={`material-symbols-outlined absolute top-4 right-4 text-4xl text-${rule.color}-500/10 group-hover:scale-125 transition-transform`}>{rule.icon}</span>
                                         <div className="flex items-center gap-4 mb-4 relative z-10">
                                            <div className={`p-3 bg-${rule.color}-500/10 border border-${rule.color}-500/20 rounded-xl text-${rule.color}-400`}>
                                                <span className="material-symbols-outlined text-[20px]">{rule.icon}</span>
                                            </div>
                                            <div>
                                                <h4 className="text-sm font-bold text-white tracking-tight">{rule.title}</h4>
                                                <p className="text-[10px] text-slate-500 uppercase font-black">{rule.desc}</p>
                                            </div>
                                            <div className="ml-auto">
                                                <div className="w-10 h-5 bg-primary/20 rounded-full flex items-center px-1">
                                                    <div className="size-3.5 bg-primary rounded-full translate-x-4"></div>
                                                </div>
                                            </div>
                                         </div>
                                         <div className="pt-4 border-t border-white/5 flex gap-4">
                                             <select className="flex-1 bg-black/40 border border-white/5 rounded-lg px-2 py-1.5 text-[10px] font-bold text-slate-400">
                                                 <option>Medium Strictness</option>
                                                 <option>High Strictness</option>
                                                 <option>Absolute Zero Tolerance</option>
                                             </select>
                                             <button className="px-3 bg-white/5 border border-white/5 rounded-lg text-[10px] font-bold">CONFIG</button>
                                         </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Placeholder for other tabs */}
                    {['aimode', 'security', 'logs', 'advanced'].includes(activeTab) && (
                        <div className="flex flex-col items-center justify-center p-20 text-center animate-in zoom-in-95 duration-500">
                            <div className="size-24 bg-white/5 rounded-full flex items-center justify-center mb-8 border border-white/10 group">
                                <span className="material-symbols-outlined text-6xl text-slate-600 animate-pulse">settings_suggest</span>
                            </div>
                            <h3 className="text-2xl font-black text-white uppercase tracking-widest">Protocol Fragmented</h3>
                            <p className="text-sm text-slate-400 mt-4 max-w-sm font-medium italic">
                                Sir, this module is currently in 'Standby' mode. Linking to secondary AI nodes will resume full interface capability soon.
                            </p>
                            <button onClick={() => setActiveTab('overview')} className="mt-8 px-6 py-2.5 bg-primary/20 hover:bg-primary/30 border border-primary/30 rounded-xl text-xs font-bold text-primary transition-all">
                                Return to Telemetry
                            </button>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
};

export default DiscordGuardian;
