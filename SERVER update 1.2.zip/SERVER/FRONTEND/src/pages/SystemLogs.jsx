import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const SystemLogs = () => {
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [pagination, setPagination] = useState({ total: 0, page: 1, limit: 50, pages: 1 });
    const [filters, setFilters] = useState({ app_id: '', user_id: '', search: '' });

    useEffect(() => {
        fetchLogs();
    }, [pagination.page, filters.app_id, filters.user_id]);

    const fetchLogs = async () => {
        try {
            setLoading(true);
            const token = localStorage.getItem('rdx_token');
            let url = `/rdx/api/admin/logs?page=${pagination.page}&limit=${pagination.limit}`;
            if (filters.app_id) url += `&app_id=${filters.app_id}`;
            if (filters.user_id) url += `&user_id=${filters.user_id}`;

            const res = await fetch(url, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                setLogs(data.data.logs);
                setPagination(data.data.pagination);
            }
        } catch (error) {
            console.error('Failed to fetch logs', error);
        } finally {
            setLoading(false);
        }
    };

    const getActionColor = (action) => {
        if (!action) return 'text-slate-400';
        const a = action.toUpperCase();
        if (a.includes('ERROR') || a.includes('FAIL') || a.includes('BANNED') || a.includes('TAMPER')) return 'text-red-400';
        if (a.includes('SUCCESS') || a.includes('CREATED') || a.includes('APPROVED')) return 'text-green-400';
        if (a.includes('LOGIN') || a.includes('AUTH')) return 'text-primary';
        if (a.includes('KEY') || a.includes('LICENSE')) return 'text-amber-400';
        return 'text-blue-400';
    };

    const filteredLogs = logs.filter(log => 
        log.action.toLowerCase().includes(filters.search.toLowerCase()) ||
        (log.username && log.username.toLowerCase().includes(filters.search.toLowerCase())) ||
        (log.app_name && log.app_name.toLowerCase().includes(filters.search.toLowerCase()))
    );

    return (
        <div className="max-w-[1600px] mx-auto space-y-6 animate-in fade-in duration-500">
            {/* Header Area */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-3xl font-black text-white uppercase tracking-tighter flex items-center gap-3">
                        <span className="material-symbols-outlined text-4xl text-primary animate-pulse">terminal</span>
                        System Audit Trail
                    </h2>
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-[0.2em] mt-1">Real-time infrastructure monitoring & security logs</p>
                </div>
                
                <div className="flex flex-wrap gap-3">
                    <div className="relative group">
                        <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm group-hover:text-primary transition-colors">search</span>
                        <input 
                            type="text"
                            placeholder="SEARCH LOGS..."
                            value={filters.search}
                            onChange={(e) => setFilters({...filters, search: e.target.value})}
                            className="bg-black/40 border border-white/5 rounded-lg pl-9 pr-4 py-2 text-[11px] font-bold text-white uppercase tracking-widest focus:outline-none focus:border-primary/50 transition-all w-64"
                        />
                    </div>
                    <button 
                        onClick={() => { setPagination({...pagination, page: 1}); fetchLogs(); }}
                        className="bg-primary/10 hover:bg-primary/20 border border-primary/20 text-primary p-2 rounded-lg transition-all"
                    >
                        <span className="material-symbols-outlined">refresh</span>
                    </button>
                </div>
            </div>

            {/* Terminal View */}
            <div className="glass-panel rounded-2xl border border-white/5 bg-slate-950/80 shadow-2xl overflow-hidden flex flex-col min-h-[700px]">
                {/* Terminal Header */}
                <div className="bg-black/40 px-6 py-3 border-b border-white/5 flex items-center justify-between">
                    <div className="flex gap-1.5">
                        <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
                        <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
                        <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
                    </div>
                    <div className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">
                        RDX_SECURE_AUDIT_V4.0.2
                    </div>
                    <div className="flex items-center gap-4 text-[10px] font-bold text-slate-500">
                        <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span> LIVE</span>
                        <span>{pagination.total} ENTRIES</span>
                    </div>
                </div>

                {/* Log List */}
                <div className="flex-1 overflow-y-auto custom-scrollbar font-mono text-[11px] p-4 space-y-1 bg-[#050508]">
                    {loading && logs.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-slate-600 gap-4 opacity-50">
                            <span className="material-symbols-outlined animate-spin text-4xl">sync</span>
                            <span className="uppercase tracking-[0.3em]">Initializing Stream...</span>
                        </div>
                    ) : filteredLogs.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-slate-700 uppercase tracking-widest gap-2">
                             <span className="material-symbols-outlined text-4xl mb-2">find_in_page</span>
                             No logs detected for current filters
                        </div>
                    ) : (
                        filteredLogs.map((log, idx) => (
                            <motion.div 
                                initial={{ opacity: 0, x: -5 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: idx * 0.01 }}
                                key={log.id} 
                                className="group flex gap-4 p-2 hover:bg-white/[0.02] rounded transition-colors border-l-2 border-transparent hover:border-primary/30"
                            >
                                <span className="text-slate-600 whitespace-nowrap">[{new Date(log.timestamp).toLocaleString()}]</span>
                                <span className="text-indigo-400 font-bold min-w-[120px] uppercase truncate">
                                    {log.username || 'SYSTEM'}
                                </span>
                                <span className={`flex-1 ${getActionColor(log.action)} font-medium`}>
                                    {log.action}
                                    {log.app_name && <span className="text-slate-600 text-[9px] ml-2">@ {log.app_name}</span>}
                                </span>
                                <span className="text-slate-500 group-hover:text-slate-300 transition-colors uppercase tracking-tighter">
                                    {log.ip_address}
                                </span>
                            </motion.div>
                        ))
                    )}
                </div>

                {/* Terminal Footer / Stats */}
                <div className="bg-black/60 px-6 py-4 border-t border-white/5 flex items-center justify-between">
                    <div className="flex gap-6">
                        <div className="text-center">
                            <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.1em] mb-0.5">Total Pages</p>
                            <p className="text-xs font-bold text-white font-mono">{pagination.pages}</p>
                        </div>
                        <div className="text-center">
                            <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.1em] mb-0.5">Current Page</p>
                            <p className="text-xs font-bold text-primary font-mono">{pagination.page}</p>
                        </div>
                    </div>

                    <div className="flex items-center gap-2">
                        <button 
                            disabled={pagination.page <= 1}
                            onClick={() => setPagination({...pagination, page: pagination.page - 1})}
                            className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 text-slate-400 hover:text-white disabled:opacity-30 transition-all"
                        >
                            <span className="material-symbols-outlined text-sm">chevron_left</span>
                        </button>
                        <div className="flex gap-1">
                            {[...Array(Math.min(5, pagination.pages))].map((_, i) => {
                                const p = pagination.page > 3 ? pagination.page - 2 + i : i + 1;
                                if (p > pagination.pages) return null;
                                return (
                                    <button 
                                        key={p}
                                        onClick={() => setPagination({...pagination, page: p})}
                                        className={`w-8 h-8 flex items-center justify-center rounded-lg text-[10px] font-bold transition-all ${pagination.page === p ? 'bg-primary text-white' : 'bg-white/5 border border-white/5 text-slate-500 hover:text-white'}`}
                                    >
                                        {p}
                                    </button>
                                );
                            })}
                        </div>
                        <button 
                            disabled={pagination.page >= pagination.pages}
                            onClick={() => setPagination({...pagination, page: pagination.page + 1})}
                            className="w-8 h-8 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 text-slate-400 hover:text-white disabled:opacity-30 transition-all"
                        >
                            <span className="material-symbols-outlined text-sm">chevron_right</span>
                        </button>
                    </div>

                    <div className="hidden lg:flex items-center gap-3">
                        <div className="text-right">
                            <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.1em] mb-0.5">Memory Usage</p>
                            <p className="text-[10px] font-bold text-green-400 font-mono">14.2 MB / 512 MB</p>
                        </div>
                        <div className="w-24 h-1 bg-white/5 rounded-full overflow-hidden">
                            <div className="w-1/4 h-full bg-green-500"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            {/* Quick Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-slate-900/40 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
                         <span className="material-symbols-outlined text-6xl">security</span>
                    </div>
                    <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-2">Auth Success Rate</h3>
                    <div className="flex items-baseline gap-2">
                        <p className="text-3xl font-black text-white italic">94.8%</p>
                        <p className="text-xs font-bold text-green-400">↑ 2.1%</p>
                    </div>
                </div>
                <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-slate-900/40 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
                         <span className="material-symbols-outlined text-6xl">dangerous</span>
                    </div>
                    <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-2">Tamper Attempts</h3>
                    <div className="flex items-baseline gap-2">
                        <p className="text-3xl font-black text-white italic">0</p>
                        <p className="text-xs font-bold text-slate-500">--</p>
                    </div>
                </div>
                <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-slate-900/40 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
                         <span className="material-symbols-outlined text-6xl">speed</span>
                    </div>
                    <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-2">Avg Auth Time</h3>
                    <div className="flex items-baseline gap-2">
                        <p className="text-3xl font-black text-white italic">14ms</p>
                        <p className="text-xs font-bold text-primary">OPTIMAL</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SystemLogs;
