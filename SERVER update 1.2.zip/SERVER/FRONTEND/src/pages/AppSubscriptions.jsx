import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ConfirmModal from '../components/shared/ConfirmModal';

const AppSubscriptions = () => {
    const [subscriptions, setSubscriptions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [apps, setApps] = useState([]);
    const [selectedAppFilter, setSelectedAppFilter] = useState('');
    const [newSub, setNewSub] = useState({ name: '', level: 1, appId: '' });
    const [confirmModal, setConfirmModal] = useState({ isOpen: false, title: '', message: '', type: 'danger', onConfirm: () => {} });

    useEffect(() => {
        fetchData();
    }, [selectedAppFilter]);

    const fetchData = async () => {
        try {
            const token = localStorage.getItem('rdx_token');
            if (!token) return;

            setLoading(true);

            // Fetch Apps for dropdowns
            const appsRes = await fetch('/rdx/api/apps', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const appsData = await appsRes.json();
            if (appsData.success) {
                setApps(appsData.apps);
                if (appsData.apps.length > 0 && !newSub.appId) {
                    setNewSub(prev => ({ ...prev, appId: appsData.apps[0].id }));
                }
            }

            // Fetch Subscriptions
            let url = '/rdx/api/subscriptions';
            if (selectedAppFilter) {
                url += `?app_id=${selectedAppFilter}`;
            }
            
            const subsRes = await fetch(url, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const subsData = await subsRes.json();
            if (subsData.success) {
                setSubscriptions(subsData.subscriptions || []);
            }
        } catch (error) {
            console.error('Failed to fetch data', error);
        } finally {
            setLoading(false);
        }
    };

    const handleCreateSub = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('rdx_token');
            const res = await fetch('/rdx/api/subscriptions', {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    app_id: newSub.appId,
                    name: newSub.name,
                    level: newSub.level
                })
            });
            
            const data = await res.json();
            if (data.success) {
                window.showToast && window.showToast('Plan created successfully', 'success');
                setIsAddModalOpen(false);
                setNewSub({ name: '', level: 1, appId: apps.length > 0 ? apps[0].id : '' });
                fetchData();
            } else {
                window.showToast && window.showToast(data.message || 'Error creating plan', 'error');
            }
        } catch (err) {
            console.error(err);
        }
    };

    const handleDeleteSub = (id) => {
        setConfirmModal({
            isOpen: true,
            title: 'Delete Subscription Plan',
            message: 'Are you sure you want to delete this subscription plan? Users using this plan will lose access until reassigned. This action cannot be undone.',
            type: 'danger',
            onConfirm: async () => {
                try {
                    const token = localStorage.getItem('rdx_token');
                    const res = await fetch(`/rdx/api/subscriptions/${id}`, {
                        method: 'DELETE',
                        headers: { 'Authorization': `Bearer ${token}` }
                    });
                    
                    const data = await res.json();
                    if (data.success) {
                        window.showToast && window.showToast('Plan deleted successfully', 'success');
                        fetchData();
                    } else {
                        window.showToast && window.showToast(data.message || 'Error deleting plan', 'error');
                    }
                } catch (err) {
                    console.error(err);
                }
            }
        });
    };

    const filteredSubs = subscriptions.filter(sub => 
        sub.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        String(sub.id).includes(searchQuery)
    );

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-3xl font-bold text-white mb-2 uppercase tracking-tighter">
                        App Subscriptions
                    </h2>
                    <p className="text-slate-400">Define access tiers and restrict end-users based on level.</p>
                </div>
                <div className="flex flex-wrap gap-3 w-full md:w-auto">
                    {/* Search Bar */}
                    <div className="relative group">
                        <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-[18px] group-focus-within:text-accent transition-colors">search</span>
                        <input 
                            type="text" 
                            placeholder="Search plans..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="bg-slate-900 border border-white/10 rounded-lg pl-10 pr-4 py-2 text-sm text-white focus:border-accent/50 outline-none w-64 transition-all placeholder:text-slate-600 focus:ring-1 focus:ring-accent/50"
                        />
                    </div>

                    <div className="relative">
                        <select value={selectedAppFilter} onChange={e => setSelectedAppFilter(e.target.value)} className="bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-sm text-white hover:border-accent/50 transition-all min-w-[180px] uppercase tracking-wider font-bold appearance-none focus:outline-none focus:ring-1 focus:ring-accent/50 h-full">
                            <option value="">ALL APPLICATIONS</option>
                            {apps.map(app => <option key={app.id} value={app.id}>{app.name}</option>)}
                        </select>
                        <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-[18px] opacity-50 pointer-events-none">expand_more</span>
                    </div>

                    <button onClick={fetchData} className="glass-panel px-4 py-2 text-white text-sm rounded-lg hover:bg-white/5 transition-colors flex items-center gap-2 border border-white/10">
                        <span className="material-symbols-outlined text-[20px]">refresh</span>
                        Refresh
                    </button>
                    
                    <button
                        onClick={() => setIsAddModalOpen(true)}
                        className="bg-accent hover:bg-accent/90 text-white text-sm font-medium px-6 py-2.5 rounded-lg shadow-neon-sm transition-all flex items-center gap-2"
                    >
                        <span className="material-symbols-outlined text-[20px]">style</span>
                        New Plan
                    </button>
                </div>
            </div>

            <div className="glass-panel overflow-hidden rounded-xl border border-white/5 shadow-2xl">
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-slate-900/50 border-b border-white/10">
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Plan Details</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Target App</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Access Level</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-center">Active Users</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5 font-mono text-xs">
                            {loading ? (
                                <tr>
                                    <td colSpan="5" className="px-6 py-12 text-center text-slate-500 animate-pulse font-mono tracking-widest text-xs uppercase text-accent">
                                        Synchronizing access levels...
                                    </td>
                                </tr>
                            ) : filteredSubs.length === 0 ? (
                                <tr>
                                    <td colSpan="5" className="px-6 py-12 text-center text-slate-500 font-mono tracking-widest text-xs uppercase">
                                        No subscription plans found
                                    </td>
                                </tr>
                            ) : (
                                filteredSubs.map(sub => (
                                    <tr key={sub.id} className="hover:bg-white/5 transition-colors group">
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 rounded-lg bg-accent/20 flex items-center justify-center text-accent group-hover:scale-110 transition-transform shadow-neon-sm">
                                                    <span className="material-symbols-outlined text-sm">workspace_premium</span>
                                                </div>
                                                <div>
                                                    <div className="text-sm font-bold text-white flex gap-2 items-center">
                                                        {sub.name}
                                                    </div>
                                                    <div className="text-[10px] text-slate-500 uppercase tracking-widest">
                                                        UID: {sub.id}
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-primary/10 border border-primary/20 text-primary font-bold tracking-tight uppercase text-[10px]">
                                                <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
                                                {sub.app_name || 'Global'}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-white font-black uppercase text-[10px] group-hover:border-accent/40 transition-all">
                                                <span className="material-symbols-outlined text-[14px] text-accent">shield</span>
                                                Level {sub.level}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-center">
                                            <div className="inline-flex items-center gap-2">
                                                <span className="material-symbols-outlined text-[16px] text-slate-500">group</span>
                                                <span className="text-slate-200 font-bold">{sub.usersCnt || 0}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right">
                                            <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button onClick={() => handleDeleteSub(sub.id)} className="text-slate-500 hover:text-red-500 transition-colors tooltip" title="Delete Plan">
                                                    <span className="material-symbols-outlined text-[18px]">delete_forever</span>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Add Plan Modal */}
            <AnimatePresence>
                {isAddModalOpen && (
                    <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-background-dark/80 backdrop-blur-sm"
                    >
                        <motion.div 
                            initial={{ scale: 0.9, y: 20 }}
                            animate={{ scale: 1, y: 0 }}
                            exit={{ scale: 0.9, y: 20 }}
                            className="glass-panel p-8 rounded-3xl max-w-md w-full border border-white/10 shadow-[0_0_50px_rgba(235,54,75,0.1)] relative overflow-hidden bg-slate-950/95"
                        >
                            <div className="absolute top-0 right-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
                            
                            <div className="flex justify-between items-center mb-8 relative z-10">
                                <div>
                                    <h3 className="text-2xl font-black text-white uppercase tracking-tighter">New Subscription</h3>
                                    <p className="text-slate-500 text-[10px] font-bold tracking-widest uppercase mt-1">Access tier provisioning protocol</p>
                                </div>
                                <button onClick={() => setIsAddModalOpen(false)} className="text-slate-500 hover:text-white transition-colors p-2">
                                    <span className="material-symbols-outlined">close</span>
                                </button>
                            </div>

                            <form onSubmit={handleCreateSub} className="space-y-4 relative z-10">
                                <div>
                                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Target Application</label>
                                    <select required value={newSub.appId} onChange={e => setNewSub({ ...newSub, appId: e.target.value })} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-accent/50 transition-all font-mono text-sm">
                                        <option value="" disabled>--- Select Application ---</option>
                                        {apps.map(app => <option key={app.id} value={app.id}>{app.name}</option>)}
                                    </select>
                                </div>

                                <div>
                                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Plan Name</label>
                                    <input type="text" required value={newSub.name} onChange={e => setNewSub({ ...newSub, name: e.target.value })} placeholder="e.g. VIP Access" className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-accent/50 transition-all font-mono text-sm" />
                                </div>

                                <div>
                                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Access Level (Integer)</label>
                                    <input type="number" required min="1" value={newSub.level} onChange={e => setNewSub({ ...newSub, level: parseInt(e.target.value) || 1 })} className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-accent/50 transition-all font-mono text-sm" />
                                    <p className="text-[10px] text-slate-500 mt-2 font-mono">Used for mathematical access restriction.</p>
                                </div>

                                <div className="pt-6">
                                    <button type="submit" className="w-full bg-accent hover:bg-accent/90 text-white font-black py-4 rounded-xl transition-all shadow-neon-accent-sm flex items-center justify-center gap-2 group uppercase tracking-widest text-xs border border-accent/30">
                                        <span>Create Subscription Tier</span>
                                        <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">add_circle</span>
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>

            <ConfirmModal 
                isOpen={confirmModal.isOpen} 
                title={confirmModal.title} 
                message={confirmModal.message} 
                type={confirmModal.type} 
                onConfirm={confirmModal.onConfirm} 
                onCancel={() => setConfirmModal({ ...confirmModal, isOpen: false })} 
            />
        </div>
    );
};

export default AppSubscriptions;
