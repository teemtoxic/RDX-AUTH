import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ConfirmModal from '../components/shared/ConfirmModal';

const Licenses = () => {
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [newLicense, setNewLicense] = useState({ quantity: 1, durationDays: 30, appId: '', subscriptionId: '', hwid_lock: true });
    
    // Edit License state
    const [editLicense, setEditLicense] = useState({ id: '', license_key: '', expiry_date: '' });

    const [licenses, setLicenses] = useState([]);
    const [loading, setLoading] = useState(true);
    const [apps, setApps] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedAppFilter, setSelectedAppFilter] = useState('');
    const [confirmModal, setConfirmModal] = useState({ isOpen: false, title: '', message: '', type: 'danger', onConfirm: () => {} });

    const [subscriptions, setSubscriptions] = useState([]);

    useEffect(() => {
        fetchData();
    }, [selectedAppFilter]);

    const fetchData = async () => {
        try {
            const token = localStorage.getItem('rdx_token');
            if (!token) return;

            setLoading(true);

            // Fetch Apps for the dropdown
            const appsRes = await fetch('/rdx/api/apps', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const appsData = await appsRes.json();
            if (appsData.success) {
                setApps(appsData.apps);
            }

            // Fetch Subscriptions for Select
            const subsRes = await fetch('/rdx/api/subscriptions', {
                 headers: { 'Authorization': `Bearer ${token}` }
            });
            const subsData = await subsRes.json();
            if (subsData.success) {
                setSubscriptions(subsData.subscriptions || []);
            }

            // Fetch Licenses with optional app filter
            let url = '/rdx/api/licenses';
            if (selectedAppFilter) url += `?app_id=${selectedAppFilter}`;

            const licsRes = await fetch(url, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const licsData = await licsRes.json();
            if (licsData.success) {
                setLicenses(licsData.licenses);
            }
        } catch (error) {
            console.error('Failed to fetch data', error);
        } finally {
            setLoading(false);
        }
    };

    const handleGenerateLicense = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('rdx_token');
            const payload = {
                app_id: newLicense.appId,
                duration_days: newLicense.durationDays,
                expiry_date: newLicense.expiry_date,
                hwid_lock: newLicense.hwid_lock
            };
            if (newLicense.subscriptionId) payload.subscription_id = newLicense.subscriptionId;

            const res = await fetch('/rdx/api/licenses/create', {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });
            const data = await res.json();
            if (data.success) {
                setIsAddModalOpen(false);
                setNewLicense({ quantity: 1, durationDays: 30, expiry_date: '', appId: '', subscriptionId: '', hwid_lock: true });
                fetchData();
                if (window.showToast) window.showToast('License generated successfully', 'success');
            } else {
                alert(data.message || 'Failed to generate license');
            }
        } catch (error) {
            console.error(error);
            alert('An error occurred');
        }
    };

    const handleEditLicenseSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('rdx_token');
            const res = await fetch(`/rdx/api/licenses/create`, {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    is_update: true,
                    license_id: editLicense.id,
                    expiry_date: editLicense.expiry_date
                })
            });
            const data = await res.json();
            if (data.success) {
                setIsEditModalOpen(false);
                fetchData();
            } else {
                alert(data.message || 'Failed to update license');
            }
        } catch (error) {
            console.error(error);
            alert('An error occurred');
        }
    };

    const openEditModal = (license) => {
        let defaultExpiry = license.expiry_date ? new Date(new Date(license.expiry_date).getTime() - (new Date().getTimezoneOffset() * 60000)).toISOString().slice(0, 16) : '';
        setEditLicense({
            id: license.id,
            license_key: license.license_key,
            expiry_date: defaultExpiry
        });
        setIsEditModalOpen(true);
    };

    const handleDeleteLicense = (id) => {
        setConfirmModal({
            isOpen: true,
            title: 'Delete License',
            message: 'Are you sure you want to delete this license? This action cannot be undone.',
            type: 'danger',
            onConfirm: async () => {
                try {
                    const token = localStorage.getItem('rdx_token');
                    const res = await fetch(`/rdx/api/licenses/${id}`, {
                        method: 'DELETE',
                        headers: { 'Authorization': `Bearer ${token}` }
                    });
                    const data = await res.json();
                    if (data.success) {
                        fetchData();
                    } else {
                        alert(data.message || 'Failed to delete license');
                    }
                } catch (err) { console.error(err); }
            }
        });
    };

    const handleResetHwid = (id) => {
        setConfirmModal({
            isOpen: true,
            title: 'Reset License HWID',
            message: 'Are you sure you want to reset HWID for this license? This allows it to bind to a new device.',
            type: 'danger',
            onConfirm: async () => {
                try {
                    const token = localStorage.getItem('rdx_token');
                    const res = await fetch(`/rdx/api/licenses/${id}/reset`, {
                        method: 'POST',
                        headers: { 'Authorization': `Bearer ${token}` }
                    });
                    const data = await res.json();
                    if (data.success) fetchData();
                    else alert(data.message || 'Failed to reset HWID');
                } catch (err) { console.error(err); }
            }
        });
    };

    const toggleLicenseStatus = (id, currentStatus, type) => {
        let newStatus = 'active';
        let confirmMsg = '';

        if (type === 'pause') {
            newStatus = currentStatus === 'paused' ? 'active' : 'paused';
            confirmMsg = `Are you sure you want to ${newStatus === 'paused' ? 'pause' : 'resume'} this license?`;
        } else if (type === 'ban') {
            newStatus = currentStatus === 'banned' ? 'active' : 'banned';
            confirmMsg = `Are you sure you want to ${newStatus === 'banned' ? 'ban' : 'unban'} this license?`;
        }

        setConfirmModal({
            isOpen: true,
            title: 'Change License Status',
            message: confirmMsg,
            type: 'warning',
            onConfirm: async () => {
                try {
                    const token = localStorage.getItem('rdx_token');
                    const res = await fetch(`/rdx/api/licenses/${id}/status`, {
                        method: 'POST',
                        headers: { 
                            'Authorization': `Bearer ${token}`,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ status: newStatus })
                    });
                    const data = await res.json();
                    if (data.success) fetchData();
                    else alert(data.message || 'Failed to update license status');
                } catch (err) { console.error(err); }
            }
        });
    };

    const filteredLicenses = licenses.filter(l => 
        l.license_key.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (l.created_by_username && l.created_by_username.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (l.app_name && l.app_name.toLowerCase().includes(searchQuery.toLowerCase()))
    );

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {/* Header section */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-3xl font-bold text-white mb-2 uppercase tracking-tighter">
                        License Management
                    </h2>
                    <p className="text-slate-400">Create and manage license keys for your clients.</p>
                </div>
                <div className="flex flex-wrap gap-3 w-full md:w-auto">
                    {/* Search Bar */}
                    <div className="relative group">
                        <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-[18px] group-focus-within:text-primary transition-colors">search</span>
                        <input 
                            type="text" 
                            placeholder="Search keys..." 
                            value={searchQuery}
                            onChange={e => setSearchQuery(e.target.value)}
                            className="bg-slate-900 border border-white/10 rounded-lg pl-10 pr-4 py-2 text-sm text-white focus:border-primary/50 outline-none w-64 transition-all placeholder:text-slate-600 focus:ring-1 focus:ring-primary/50"
                        />
                    </div>

                    <div className="relative">
                        <select 
                            value={selectedAppFilter} 
                            onChange={e => setSelectedAppFilter(e.target.value)} 
                            className="bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-sm text-white hover:border-primary/50 transition-all min-w-[180px] uppercase tracking-wider font-bold appearance-none focus:outline-none focus:ring-1 focus:ring-primary/50 h-full"
                        >
                            <option value="">ALL APPLICATIONS</option>
                            {apps.map(app => <option key={app.id} value={app.id}>{app.name}</option>)}
                        </select>
                        <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-[18px] opacity-50 pointer-events-none">expand_more</span>
                    </div>

                    <button id="btn-refresh-licenses" onClick={fetchData} className="glass-panel px-4 py-2 text-white text-sm rounded-lg hover:bg-white/5 transition-colors flex items-center gap-2 border border-white/10">
                        <span className="material-symbols-outlined text-[20px]">refresh</span>
                        Refresh
                    </button>
                    
                    <button 
                        id="btn-open-create-license-modal"
                        onClick={() => setIsAddModalOpen(true)}
                        className="bg-primary hover:bg-primary/90 text-white text-sm font-medium px-6 py-2.5 rounded-lg shadow-neon-sm transition-all flex items-center gap-2"
                    >
                        <span className="material-symbols-outlined text-[20px]">add_card</span>
                        Generate Key
                    </button>
                </div>
            </div>

            {/* Table */}
            <div className="glass-panel rounded-2xl border border-white/5 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-slate-900/50 border-b border-white/10">
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">License Key</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Application</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Subscription</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Owner (User)</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Expiry / Duration</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Hardware</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Status</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5 font-mono text-xs">
                            {loading ? (
                                <tr>
                                    <td colSpan="7" className="px-6 py-12 text-center">
                                        <div className="inline-block animate-spin size-6 border-2 border-primary border-t-transparent rounded-full mb-2"></div>
                                        <p className="text-slate-500 text-[10px] font-bold tracking-widest uppercase">Fetching encrypted data...</p>
                                    </td>
                                </tr>
                            ) : filteredLicenses.length === 0 ? (
                                <tr>
                                    <td colSpan="7" className="px-6 py-12 text-center text-slate-500">
                                        <span className="material-symbols-outlined text-4xl mb-2 opacity-20">key_off</span>
                                        <p className="text-[10px] font-bold tracking-widest uppercase">No license nodes matching your query</p>
                                    </td>
                                </tr>
                            ) : (
                                filteredLicenses.map(license => (
                                    <tr key={license.id} className="hover:bg-white/5 transition-colors group">
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center gap-2 group/copy">
                                                <code className="text-[11px] font-mono text-white bg-primary/10 px-2 py-1 rounded border border-primary/20">
                                                    {license.license_key}
                                                </code>
                                                <button onClick={() => { navigator.clipboard.writeText(license.license_key); }} className="text-slate-600 hover:text-white transition-colors opacity-0 group-hover/copy:opacity-100">
                                                    <span className="material-symbols-outlined text-[14px]">content_copy</span>
                                                </button>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-xs text-slate-400 font-bold uppercase tracking-wider">
                                            {license.app_name || 'N/A'}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-xs text-slate-400 font-bold uppercase tracking-wider">
                                            {license.subscription_name || 'Free Tier'}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-xs text-slate-400">
                                            {license.created_by_username || 'System'}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-[10px] text-slate-400 font-bold">
                                            {license.expiry_date ? new Date(license.expiry_date).toLocaleDateString() : 'LIFETIME'}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center gap-2 group/copy">
                                                <code className="text-[10px] text-slate-400 font-mono px-2 py-1 bg-white/5 rounded border border-white/10" title={license.hwid}>
                                                    {Number(license.hwid_lock) === 0 ? 'Public User' : (license.hwid ? license.hwid.substring(0,15)+'...' : 'Unbound')}
                                                </code>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            {license.status === 'active' && <span className="px-2 py-1 inline-flex text-[9px] leading-4 font-black rounded bg-success/10 text-success border border-success/20 uppercase tracking-widest">Active</span>}
                                            {license.status === 'paused' && <span className="px-2 py-1 inline-flex text-[9px] leading-4 font-black rounded bg-amber-500/10 text-amber-500 border border-amber-500/20 uppercase tracking-widest">Paused</span>}
                                            {license.status === 'banned' && <span className="px-2 py-1 inline-flex text-[9px] leading-4 font-black rounded bg-red-500/10 text-red-400 border border-red-500/20 uppercase tracking-widest">Banned</span>}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button onClick={() => openEditModal(license)} className="text-slate-500 hover:text-blue-400 transition-colors tooltip" title="Edit License">
                                                    <span className="material-symbols-outlined text-[18px]">edit</span>
                                                </button>
                                                <button onClick={() => handleResetHwid(license.id)} className="text-slate-500 hover:text-yellow-400 transition-colors tooltip" title="Reset HWID">
                                                    <span className="material-symbols-outlined text-[18px]">restart_alt</span>
                                                </button>
                                                <button onClick={() => toggleLicenseStatus(license.id, license.status, 'pause')} className="text-slate-500 hover:text-orange-400 transition-colors tooltip" title={license.status === 'paused' ? 'Resume License' : 'Pause License'}>
                                                    <span className="material-symbols-outlined text-[18px]">{license.status === 'paused' ? 'play_circle' : 'pause_circle'}</span>
                                                </button>
                                                <button onClick={() => toggleLicenseStatus(license.id, license.status, 'ban')} className="text-slate-500 hover:text-red-500 transition-colors tooltip" title={license.status === 'banned' ? 'Unban License' : 'Ban License'}>
                                                    <span className="material-symbols-outlined text-[18px]">{license.status === 'banned' ? 'gavel' : 'block'}</span>
                                                </button>
                                                <button onClick={() => handleDeleteLicense(license.id)} className="text-slate-500 hover:text-red-400 transition-colors tooltip" title="Delete License">
                                                    <span className="material-symbols-outlined text-[18px]">delete</span>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Create License Modal - Premium Redesign */}
            <AnimatePresence>
                {isAddModalOpen && (
                    <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-background-dark/80 backdrop-blur-md"
                    >
                        <motion.div 
                            initial={{ scale: 0.95, opacity: 0, y: 20 }}
                            animate={{ scale: 1, opacity: 1, y: 0 }}
                            exit={{ scale: 0.95, opacity: 0, y: 20 }}
                            className="glass-panel w-full max-w-md rounded-2xl p-8 border border-primary/20 relative overflow-hidden bg-slate-950/95 shadow-[0_0_50px_rgba(140,37,244,0.15)]"
                        >
                            {/* Visual Accents */}
                            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
                            
                            <div className="flex justify-between items-center mb-8 relative z-10">
                                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                                    <span className="material-symbols-outlined text-primary">add_card</span>
                                    Provision License Node
                                </h3>
                                <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white transition-colors">
                                    <span className="material-symbols-outlined">close</span>
                                </button>
                            </div>

                            <form onSubmit={handleGenerateLicense} className="space-y-5 relative z-10">
                                <div>
                                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Target Application</label>
                                    <select 
                                        required 
                                        value={newLicense.appId} 
                                        onChange={e => setNewLicense({ ...newLicense, appId: e.target.value })}
                                        className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary transition-all font-mono appearance-none cursor-pointer"
                                    >
                                        <option value="" disabled>--- Select Application ---</option>
                                        {apps.map(app => <option key={app.id} value={app.id}>{app.name}</option>)}
                                    </select>
                                </div>

                                <div>
                                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Subscription Plan</label>
                                    <select 
                                        value={newLicense.subscriptionId} 
                                        onChange={e => setNewLicense({ ...newLicense, subscriptionId: e.target.value })}
                                        className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary transition-all font-mono appearance-none cursor-pointer"
                                    >
                                        <option value="">--- Default Access ---</option>
                                        {subscriptions
                                            .filter(s => newLicense.appId ? s.app_id === parseInt(newLicense.appId) : true)
                                            .map(sub => (
                                                <option key={sub.id} value={sub.id}>
                                                    {sub.name} (LVL {sub.level})
                                                </option>
                                            ))
                                        }
                                    </select>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Duration (Days)</label>
                                        <div className="flex gap-2">
                                            <input
                                                type="number"
                                                min="0"
                                                value={newLicense.durationDays}
                                                onChange={e => setNewLicense({ ...newLicense, durationDays: parseInt(e.target.value) })}
                                                className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary transition-all font-mono"
                                            />
                                            <select 
                                                className="bg-slate-900 border border-white/10 rounded-xl px-2 text-[10px] text-slate-400 focus:outline-none"
                                                onChange={(e) => {
                                                    if (e.target.value !== "") {
                                                        setNewLicense({ ...newLicense, durationDays: parseInt(e.target.value) });
                                                    }
                                                }}
                                            >
                                                <option value="">Preset</option>
                                                <option value="1">1D</option>
                                                <option value="7">7D</option>
                                                <option value="30">30D</option>
                                                <option value="365">1Y</option>
                                                <option value="0">Life</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">OR Expiry Date</label>
                                        <input
                                            type="datetime-local"
                                            value={newLicense.expiry_date}
                                            onChange={e => setNewLicense({ ...newLicense, expiry_date: e.target.value })}
                                            className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary transition-all font-mono"
                                        />
                                    </div>
                                </div>

                                <div className="p-4 bg-slate-900/50 rounded-2xl border border-white/5 space-y-4">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="text-[10px] font-bold text-white uppercase tracking-wider">Hardware Identification</p>
                                            <p className="text-[9px] text-slate-500 uppercase tracking-widest">Bind license to unique HWID</p>
                                        </div>
                                        <label className="relative inline-flex items-center cursor-pointer">
                                            <input 
                                                type="checkbox" 
                                                className="sr-only peer"
                                                checked={newLicense.hwid_lock}
                                                onChange={e => setNewLicense({ ...newLicense, hwid_lock: e.target.checked })}
                                            />
                                            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary shadow-inner"></div>
                                        </label>
                                    </div>
                                </div>

                                <div className="pt-2">
                                    <button
                                        type="submit"
                                        className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-xl shadow-neon transition-all flex items-center justify-center gap-2 group"
                                    >
                                        <span className="material-symbols-outlined group-hover:rotate-12 transition-transform">bolt</span>
                                        ESTABLISH LICENSE NODE
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Edit License Modal */}
            <AnimatePresence>
                {isEditModalOpen && (
                    <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-background-dark/80 backdrop-blur-sm"
                    >
                        <motion.div 
                            initial={{ scale: 0.9, y: 20 }}
                            animate={{ scale: 1, y: 0 }}
                            exit={{ scale: 0.9, y: 20 }}
                            className="glass-panel p-8 rounded-3xl max-w-md w-full border border-white/10 shadow-[0_0_50px_rgba(34,197,94,0.1)] relative overflow-hidden bg-slate-950/95"
                        >
                            <div className="flex justify-between items-center mb-8">
                                <div>
                                    <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Modify Node Expiry</h3>
                                    <p className="text-slate-500 text-[10px] font-bold tracking-widest uppercase mt-1">Temporal override protocol</p>
                                </div>
                                <button onClick={() => setIsEditModalOpen(false)} className="text-slate-500 hover:text-white transition-colors p-2">
                                    <span className="material-symbols-outlined">close</span>
                                </button>
                            </div>

                            <form onSubmit={handleEditLicenseSubmit} className="space-y-4">
                                <div>
                                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">License Key</label>
                                    <input className="w-full bg-slate-800/50 border border-white/5 rounded-lg px-4 py-3 text-slate-500 cursor-not-allowed font-mono text-sm" disabled type="text" value={editLicense.license_key} />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">New Expiry Date</label>
                                    <input className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary/50 transition-all font-mono text-sm" type="datetime-local" value={editLicense.expiry_date} onChange={e => setEditLicense({...editLicense, expiry_date: e.target.value})} />
                                </div>
                                <div className="pt-6">
                                    <button type="submit" className="w-full bg-success hover:bg-success/90 text-white font-black py-4 rounded-xl transition-all shadow-neon-sm flex items-center justify-center gap-2 group uppercase tracking-widest text-xs border border-success/30">
                                        <span>Update Temporal Sync</span>
                                        <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">auto_mode</span>
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>

            <ConfirmModal 
                isOpen={confirmModal.isOpen} 
                title={confirmModal.title} 
                message={confirmModal.message} 
                type={confirmModal.type} 
                onConfirm={confirmModal.onConfirm} 
                onCancel={() => setConfirmModal({ ...confirmModal, isOpen: false })} 
            />
        </div>
    );
};

export default Licenses;
