import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import SystemSettings from './SystemSettings'; // Import existing component logic

const Admin = () => {
    const [activeTab, setActiveTab] = useState('settings');

    const tabs = [
        { id: 'settings', label: 'Global Settings', icon: 'settings' },
        { id: 'hwid', label: 'HWID Requests', icon: 'admin_panel_settings' },
        { id: 'users', label: 'User Overrides', icon: 'manage_accounts' },
    ];

    return (
        <div className="flex-1 overflow-y-auto p-6 lg:p-8 scroll-smooth section-container">
            <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-6xl mx-auto space-y-8"
            >
                {/* Admin Header */}
                <div className="glass-panel p-6 rounded-2xl border border-primary/20 bg-primary/5 flex flex-col md:flex-row items-center justify-between gap-4">
                    <div>
                        <h2 className="text-3xl font-black text-white uppercase tracking-tighter text-shadow-glow flex items-center gap-3">
                            <span className="material-symbols-outlined text-4xl text-primary">security</span>
                            Ultra-Admin Portal
                        </h2>
                        <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em] mt-1">High-level administrative synchronization and override console</p>
                    </div>
                </div>

                {/* Tab Navigation */}
                <div className="flex gap-2 p-1 bg-black/40 rounded-xl border border-white/5 w-fit">
                    {tabs.map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`px-6 py-2.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${activeTab === tab.id ? 'bg-primary text-white shadow-neon-sm' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}
                        >
                            <span className="material-symbols-outlined text-sm">{tab.icon}</span>
                            {tab.label}
                        </button>
                    ))}
                </div>

                {/* Tab Content */}
                <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.2 }}
                >
                    {activeTab === 'settings' && <SystemSettings />}
                    {activeTab === 'hwid' && (
                        <div className="glass-panel p-20 text-center rounded-2xl border border-white/5 opacity-50">
                            <span className="material-symbols-outlined text-6xl mb-4">history_edu</span>
                            <p className="font-black uppercase tracking-widest text-xs">HWID Request Manager - Coming Soon</p>
                        </div>
                    )}
                    {activeTab === 'users' && (
                        <div className="glass-panel p-20 text-center rounded-2xl border border-white/5 opacity-50">
                            <span className="material-symbols-outlined text-6xl mb-4">person_search</span>
                            <p className="font-black uppercase tracking-widest text-xs">User Override Console - Coming Soon</p>
                        </div>
                    )}
                </motion.div>
            </motion.div>
        </div>
    );
};

export default Admin;
