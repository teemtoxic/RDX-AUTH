import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const SystemSettings = () => {
    const [settings, setSettings] = useState({
        auto_delete_expired_licenses: '0',
        discord_bot_token: '',
        maintenance_mode: '0'
    });
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        fetchSettings();
    }, []);

    const fetchSettings = async () => {
        try {
            const token = localStorage.getItem('rdx_token');
            const res = await fetch('/rdx/api/settings', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                setSettings(data.data);
            }
        } catch (error) {
            console.error('Failed to fetch settings', error);
        } finally {
            setLoading(false);
        }
    };

    const handleUpdateSetting = async (key, value) => {
        try {
            setSaving(true);
            const token = localStorage.getItem('rdx_token');
            const res = await fetch('/rdx/api/settings', {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ key, value })
            });
            const data = await res.json();
            if (data.success) {
                setSettings(prev => ({ ...prev, [key]: value }));
                if (window.showToast) window.showToast('Setting updated successfully', 'success');
            } else {
                if (window.showToast) window.showToast(data.message || 'Failed to update', 'error');
            }
        } catch (error) {
            console.error(error);
            if (window.showToast) window.showToast('An error occurred', 'error');
        } finally {
            setSaving(false);
        }
    };

    const SettingCard = ({ title, description, icon, children }) => (
        <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-slate-900/40 hover:border-primary/20 transition-all group">
            <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                    <span className="material-symbols-outlined text-2xl">{icon}</span>
                </div>
                <div className="flex-1">
                    <h3 className="text-lg font-bold text-white uppercase tracking-tight">{title}</h3>
                    <p className="text-sm text-slate-500 mt-1 leading-relaxed">{description}</p>
                    <div className="mt-6">
                        {children}
                    </div>
                </div>
            </div>
        </div>
    );

    return (
        <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500">
            <div>
                <h2 className="text-3xl font-black text-white uppercase tracking-tighter text-shadow-glow flex items-center gap-3">
                    <span className="material-symbols-outlined text-4xl text-primary animate-pulse-glow">settings</span>
                    Global Core configuration
                </h2>
                <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em] mt-1">Authorized administrative override for neural network parameters</p>
            </div>

            {loading ? (
                <div className="py-20 text-center">
                    <div className="inline-block animate-spin size-8 border-4 border-primary border-t-transparent rounded-full mb-4"></div>
                    <p className="text-slate-500 font-mono text-xs uppercase tracking-widest">Decrypting system config...</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <SettingCard 
                        title="Neural Expiry Purge" 
                        description="Automatically delete license nodes from the mainframe once they reach the temporal expiration threshold."
                        icon="auto_delete"
                    >
                        <div className="flex items-center gap-3 bg-black/40 p-3 rounded-xl border border-white/5">
                            <span className="flex-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Auto-Delete Logic</span>
                            <div 
                                onClick={() => handleUpdateSetting('auto_delete_expired_licenses', settings.auto_delete_expired_licenses === '1' ? '0' : '1')}
                                className={`w-12 h-6 rounded-full p-1 cursor-pointer transition-all duration-300 ${settings.auto_delete_expired_licenses === '1' ? 'bg-primary' : 'bg-slate-700'}`}
                            >
                                <div className={`w-4 h-4 rounded-full bg-white transition-all duration-300 transform ${settings.auto_delete_expired_licenses === '1' ? 'translate-x-6' : 'translate-x-0'}`}></div>
                            </div>
                        </div>
                    </SettingCard>

                    <SettingCard 
                        title="Maintenance Protocol" 
                        description="Lock down the neural network for unauthorized entities. Only administrative nodes will maintain access."
                        icon="construction"
                    >
                        <div className="flex items-center gap-3 bg-black/40 p-3 rounded-xl border border-white/5">
                            <span className="flex-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">Maintenance Status</span>
                            <div 
                                onClick={() => handleUpdateSetting('maintenance_mode', settings.maintenance_mode === '1' ? '0' : '1')}
                                className={`w-12 h-6 rounded-full p-1 cursor-pointer transition-all duration-300 ${settings.maintenance_mode === '1' ? 'bg-amber-500' : 'bg-slate-700'}`}
                            >
                                <div className={`w-4 h-4 rounded-full bg-white transition-all duration-300 transform ${settings.maintenance_mode === '1' ? 'translate-x-6' : 'translate-x-0'}`}></div>
                            </div>
                        </div>
                    </SettingCard>

                    <SettingCard 
                        title="Discord Integration" 
                        description="Bridge the neural network with the Discord subspace for remote synchronization and log broadcast."
                        icon="robot_2"
                    >
                        <div className="space-y-3">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Bot Access Token</label>
                            <div className="flex gap-2">
                                <input 
                                    type="password"
                                    value={settings.discord_bot_token || ''}
                                    onChange={(e) => setSettings({ ...settings, discord_bot_token: e.target.value })}
                                    className="flex-1 bg-black/60 border border-white/10 rounded-lg px-4 py-2 text-xs text-white focus:outline-none focus:border-primary/50 transition-all font-mono"
                                    placeholder="Enter Token..."
                                />
                                <button 
                                    onClick={() => handleUpdateSetting('discord_bot_token', settings.discord_bot_token)}
                                    className="bg-primary/20 hover:bg-primary/30 border border-primary/30 text-primary px-3 py-2 rounded-lg transition-all"
                                >
                                    <span className="material-symbols-outlined text-sm">sync</span>
                                </button>
                            </div>
                        </div>
                    </SettingCard>

                    <SettingCard 
                        title="Neural Security Level" 
                        description="Configure the sensitivity of the AI Threat Mitigation system and intrusion detection algorithms."
                        icon="security"
                    >
                        <div className="flex gap-2">
                            {['LOW', 'MED', 'HIGH'].map(lvl => (
                                <button
                                    key={lvl}
                                    onClick={() => handleUpdateSetting('security_sensitivity', lvl)}
                                    className={`flex-1 py-2 rounded-lg text-[10px] font-black tracking-widest uppercase border transition-all ${settings.security_sensitivity === lvl ? 'bg-primary border-primary text-white' : 'bg-white/5 border-white/10 text-slate-500 hover:text-white'}`}
                                >
                                    {lvl}
                                </button>
                            ))}
                        </div>
                    </SettingCard>
                </div>
            )}
            
            <div className="glass-panel p-6 rounded-2xl border border-red-500/20 bg-red-500/5 mt-12">
                <div className="flex items-center gap-3 mb-4">
                    <span className="material-symbols-outlined text-red-500 animate-pulse">warning</span>
                    <h3 className="text-lg font-bold text-white uppercase tracking-tighter">Emergency Purge Protocols</h3>
                </div>
                <p className="text-sm text-slate-400 mb-6 font-medium">Critical actions that involve massive data erasure. These protocols cannot be reversed once initialized.</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <button className="bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all">Clear All Licenses</button>
                    <button className="bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all">Reset All Stats</button>
                    <button className="bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all">Wipe Global Logs</button>
                </div>
            </div>
        </div>
    );
};

export default SystemSettings;
