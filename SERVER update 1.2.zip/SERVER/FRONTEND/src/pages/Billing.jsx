import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const Billing = () => {
    const navigate = useNavigate();
    const [user, setUser] = useState(null);
    const [history, setHistory] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const token = localStorage.getItem('rdx_token');

    useEffect(() => {
        if (token) {
            fetchBillingData();
        } else {
            navigate('/login');
        }
    }, [token]);

    const fetchBillingData = async () => {
        setLoading(true);
        setError(null);
        try {
            // Use the flattened response from Profile fix if possible, 
            // but standardizing on user object if that's what other pages expect.
            // Actually, my Profile fix used `setUser(data)` because of flattening.
            const profileRes = await fetch('/rdx/api/auth/me', { 
                headers: { 'Authorization': `Bearer ${token}` } 
            });
            const profileData = await profileRes.json();
            if (profileData.success) {
                // The backend flattens the user object into the root response via responseHelper
                setUser(profileData);
            }

            const historyRes = await fetch('/rdx/api/auth/billing-history', { 
                headers: { 'Authorization': `Bearer ${token}` } 
            });
            const historyData = await historyRes.json();
            if (historyData.success) {
                setHistory(historyData.history || []);
            } else if (historyRes.status === 429) {
                setError('Too many requests. Please wait a moment.');
            } else {
                setError(historyData.message || 'Failed to load history');
            }
        } catch (e) {
            console.error(e);
            setError('Connection failed.');
        } finally {
            setLoading(false);
        }
    };

    const getStatusColor = (status) => {
        switch (status?.toLowerCase()) {
            case 'approved': return 'bg-green-500/10 text-green-400 border-green-500/20';
            case 'pending': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20';
            default: return 'bg-red-500/10 text-red-400 border-red-500/20';
        }
    };

    if (loading && !user) {
        return (
            <div className="p-8 text-white font-black uppercase tracking-widest animate-pulse flex items-center justify-center h-full gap-3">
                <span className="material-symbols-outlined animate-spin text-primary">sync</span> 
                Synchronizing Ledger...
            </div>
        );
    }

    return (
        <div className="flex-1 overflow-y-auto p-6 lg:p-8 scroll-smooth section-container">
            <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-7xl mx-auto space-y-8"
            >
                {/* Header */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
                    <div>
                        <h2 className="text-3xl font-black text-white mb-2 uppercase tracking-tighter flex items-center gap-3">
                            <span className="material-symbols-outlined text-4xl text-primary">account_balance_wallet</span>
                            Billing & Subscription
                        </h2>
                        <p className="text-slate-400 uppercase tracking-widest text-[10px] font-bold opacity-70">Manage your active tier and check transaction telemetry.</p>
                    </div>
                    <button 
                        onClick={() => navigate('/pricing')}
                        className="bg-primary hover:bg-primary-dark text-white text-[11px] font-black px-8 py-4 rounded-xl shadow-neon transition-all flex items-center justify-center gap-3 uppercase tracking-[0.2em]"
                    >
                        <span className="material-symbols-outlined text-[20px]">upgrade</span>
                        Upgrade Plan
                    </button>
                </div>

                {/* Details Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="glass-panel p-8 rounded-2xl border border-white/5 bg-gradient-to-br from-primary/10 to-transparent flex flex-col justify-between relative overflow-hidden group">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 blur-[80px] -z-10 group-hover:bg-primary/30 transition-colors"></div>
                        <div>
                            <p className="text-[10px] text-slate-500 uppercase tracking-[0.3em] font-black mb-1">Active Infrastructure</p>
                            <h3 className="text-4xl font-black text-white uppercase tracking-tighter">
                                {user?.plan ? `RDX ${user.plan.toUpperCase()}` : 'RDX STARTER'}
                            </h3>
                        </div>
                        <div className="mt-8 pt-6 border-t border-white/5">
                            <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">
                                Infrastructure valid until: <span className="text-white font-mono ml-2">
                                    {user?.subscription?.expiry ? new Date(user.subscription.expiry).toLocaleDateString() : 'NEVER (LIFETIME)'}
                                </span>
                            </p>
                        </div>
                    </div>

                    <div className="glass-panel p-8 rounded-2xl border border-white/5 bg-slate-900/50 relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-6 opacity-5">
                            <span className="material-symbols-outlined text-7xl">loyalty</span>
                        </div>
                        <p className="text-[10px] text-slate-500 uppercase tracking-[0.3em] font-black mb-6">Subscription Status</p>
                        <div className="space-y-4">
                            <div className="flex items-center justify-between text-[11px]">
                                <span className="text-slate-500 uppercase font-black tracking-widest">Daily API Limit</span>
                                <span className="text-white font-mono font-bold">UNLIMITED</span>
                            </div>
                            <div className="flex items-center justify-between text-[11px]">
                                <span className="text-slate-500 uppercase font-black tracking-widest">Support Level</span>
                                <span className="text-primary uppercase font-black">{user?.role === 'admin' ? 'SYSTEM OVERSEER' : 'PRIORITY ELITE'}</span>
                            </div>
                            <div className="flex items-center justify-between text-[11px]">
                                <span className="text-slate-500 uppercase font-black tracking-widest">Global Status</span>
                                <span className="text-green-400 uppercase font-black flex items-center gap-1">
                                    <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span>
                                    Synchronized
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Transaction History */}
                <div className="glass-panel rounded-2xl border border-white/5 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-700">
                    <div className="p-6 border-b border-white/5 bg-white/[0.03] flex items-center justify-between">
                        <h3 className="text-[10px] font-black text-white uppercase tracking-[0.2em] flex items-center gap-2">
                            <span className="material-symbols-outlined text-sm text-primary">history</span>
                            Transaction History Logs
                        </h3>
                        <button 
                            onClick={fetchBillingData}
                            className={`p-2 hover:bg-white/5 rounded-lg transition-all ${loading ? 'animate-spin text-primary' : 'text-slate-500'}`}
                        >
                            <span className="material-symbols-outlined text-[18px]">refresh</span>
                        </button>
                    </div>
                    <div className="overflow-x-auto min-h-[300px] custom-scrollbar">
                        <table className="w-full text-left">
                            <thead className="bg-slate-950/50 text-[10px] text-slate-500 font-black uppercase tracking-widest border-b border-white/5">
                                <tr>
                                    <th className="px-8 py-5">Transaction ID</th>
                                    <th className="px-8 py-5">Infrastructure Tier</th>
                                    <th className="px-8 py-5">Value / Cost</th>
                                    <th className="px-8 py-5">Timestamp</th>
                                    <th className="px-8 py-5">Protocol Status</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-white/5 text-xs font-mono">
                                {loading && history.length === 0 ? (
                                    <tr>
                                        <td colSpan="5" className="px-8 py-16 text-center text-slate-500 uppercase font-black tracking-[0.2em] animate-pulse">
                                            Connecting to mainframe ledger...
                                        </td>
                                    </tr>
                                ) : history.length > 0 ? (
                                    history.map((item, idx) => (
                                        <tr key={idx} className="hover:bg-white/[0.02] transition-colors group">
                                            <td className="px-8 py-5 text-slate-400 group-hover:text-white transition-colors">
                                                {(item.transaction_id || 'SYSTEM_INTERNAL').slice(0, 16)}
                                            </td>
                                            <td className="px-8 py-5">
                                                <span className="text-white font-black uppercase text-[11px] tracking-tight">{item.plan}</span>
                                            </td>
                                            <td className="px-8 py-5 text-slate-300">
                                                {item.plan?.toLowerCase() === 'pro' ? '₹80.00' : item.plan?.toLowerCase() === 'basic' ? '₹50.00' : '₹0.00'}
                                            </td>
                                            <td className="px-8 py-5 text-slate-500 text-[10px] font-bold uppercase">
                                                {new Date(item.created_at).toLocaleString()}
                                            </td>
                                            <td className="px-8 py-5">
                                                <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase border tracking-widest ${getStatusColor(item.status)}`}>
                                                    {item.status}
                                                </span>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="5" className="px-8 py-16 text-center text-slate-600 uppercase font-black tracking-[0.2em] opacity-40">
                                            No structural transactions found in history.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Info Box */}
                <div className="p-6 bg-primary/5 border border-primary/20 rounded-2xl flex items-start gap-4">
                    <span className="material-symbols-outlined text-primary">info</span>
                    <div>
                        <h4 className="text-xs font-bold text-white uppercase tracking-widest mb-1">Infrastructure Synchronization</h4>
                        <p className="text-[10px] text-slate-500 uppercase tracking-wider leading-relaxed">
                            All transactions are verified against the decentralized ledger. 
                            Approved plans are activated within seconds of transaction confirmation.
                            For support regarding specific transaction IDs, please contact the Support Desk.
                        </p>
                    </div>
                </div>
            </motion.div>
        </div>
    );
};

export default Billing;
