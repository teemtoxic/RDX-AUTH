import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const SecurityMonitoring = () => {
    const [apps, setApps] = useState([]);
    const [selectedAppId, setSelectedAppId] = useState('');
    const [stats, setStats] = useState({ totalRequests: 0, blockedIps: 0, threats: 0 });
    const [logs, setLogs] = useState([]);
    const [blacklist, setBlacklist] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    const token = localStorage.getItem('rdx_token');

    useEffect(() => {
        const init = async () => {
            setIsLoading(true);
            await fetchApps();
            await loadGlobalSecurityData();
            setIsLoading(false);
        };
        init();
    }, []);

    const fetchApps = async () => {
        try {
            const res = await fetch('/rdx/api/apps', { headers: { 'Authorization': `Bearer ${token}` } });
            const data = await res.json();
            if (data.success && Array.isArray(data.apps)) {
                setApps(data.apps);
                if (data.apps.length > 0) setSelectedAppId(data.apps[0].id);
            }
        } catch (e) { console.error('App Fetch Failed:', e); }
    };

    const loadGlobalSecurityData = async () => {
        try {
            const [statsRes, blRes, logsRes] = await Promise.all([
                fetch('/rdx/api/stats', { headers: { 'Authorization': `Bearer ${token}` } }).then(r => r.json()).catch(() => ({})),
                fetch('/rdx/api/security/blacklist', { headers: { 'Authorization': `Bearer ${token}` } }).then(r => r.json()).catch(() => ({})),
                fetch('/rdx/api/logs?limit=100', { headers: { 'Authorization': `Bearer ${token}` } }).then(r => r.json()).catch(() => ({}))
            ]);

            if (blRes.success) setBlacklist(blRes.blacklist || []);
            
            let securityEvents = [];
            if (logsRes.success && Array.isArray(logsRes.logs)) {
                securityEvents = logsRes.logs.filter(log =>
                    log.action && (
                        log.action.includes('LOGIN') || log.action.includes('AUTH') ||
                        log.action.includes('FAILED') || log.action.includes('INVALID') ||
                        log.action.includes('BANNED') || log.action.includes('BLACKLIST')
                    )
                );
                // In a dedicated view we can show more logs
                setLogs(securityEvents.slice(0, 20)); 
            }

            setStats({
                totalRequests: statsRes.stats?.totalHits || 0,
                blockedIps: (blRes.blacklist || []).length,
                threats: securityEvents.length || 0
            });

        } catch (e) { console.error('Global Security Load Failed:', e); }
    };

    const handleBlacklistAdd = async (type, value) => {
        const reason = prompt(`Reason for blacklisting this ${type}?`, 'Suspicious Activity');
        if (reason === null) return;
        
        try {
            const res = await fetch('/rdx/api/security/blacklist/add', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ type, value, reason, app_id: selectedAppId || null })
            });
            const data = await res.json();
            if (data.success) {
                window.showToast && window.showToast(`${type.toUpperCase()} added to Blacklist.`, 'success');
                loadGlobalSecurityData();
            } else {
                window.showToast && window.showToast(`Error: ${data.message}`, 'error');
            }
        } catch (e) { console.error('Blacklist Add Failed:', e); }
    };

    if (isLoading) {
        return (
            <div className="p-8 text-white font-black uppercase tracking-widest animate-pulse flex items-center gap-3">
                <span className="material-symbols-outlined animate-spin text-primary">monitoring</span>
                Loading Monitoring Data...
            </div>
        );
    }

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* Header */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                    <div className="space-y-1">
                        <h2 className="text-3xl font-black text-white uppercase tracking-tighter flex items-center gap-3 text-shadow-glow">
                            <span className="material-symbols-outlined text-4xl text-primary drop-shadow-[0_0_10px_rgba(140,37,244,0.5)]">monitoring</span>
                            Security Monitoring
                        </h2>
                        <p className="text-slate-400 font-medium tracking-tight">Real-time analysis and threat intelligence streams.</p>
                    </div>
                    <div className="flex items-center gap-4">
                        <div className="relative group">
                            <select 
                                value={selectedAppId} 
                                onChange={(e) => setSelectedAppId(e.target.value)}
                                className="bg-slate-900 border border-white/10 rounded-xl px-5 py-3 text-xs text-white font-black uppercase tracking-widest hover:border-primary transition-all focus:outline-none focus:ring-2 focus:ring-primary/20 appearance-none pr-10 min-w-[200px]"
                            >
                                <option value="">Select Target App</option>
                                {apps.map(app => (
                                    <option key={app.id} value={app.id}>{app.name}</option>
                                ))}
                            </select>
                            <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none text-[18px]">expand_more</span>
                        </div>
                        <button 
                            onClick={loadGlobalSecurityData}
                            className="p-3 bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all group shadow-inner hover:shadow-white/5"
                        >
                            <span className={`material-symbols-outlined ${isLoading ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-500'}`}>refresh</span>
                        </button>
                    </div>
                </div>

                {/* Stats Matrix */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[
                        { label: 'Network Requests', val: stats.totalRequests, icon: 'analytics', color: 'primary' },
                        { label: 'Blocked Threats', val: stats.blockedIps, icon: 'gpp_bad', color: 'red-500' },
                        { label: 'Security Events', val: stats.threats, icon: 'security_update_warning', color: 'amber-500' }
                    ].map((stat, i) => (
                        <div key={i} className={`glass-panel p-8 rounded-3xl border border-white/5 relative group overflow-hidden bg-slate-900/40 hover:border-${stat.color}/50 transition-all duration-500`}>
                            <div className={`absolute top-0 right-0 p-12 bg-${stat.color}/5 blur-[80px] rounded-full group-hover:bg-${stat.color}/20 transition-all duration-700`}></div>
                            <div className="relative z-10 flex items-center justify-between mb-6">
                                <div className={`size-12 rounded-2xl bg-${stat.color}/10 border border-${stat.color}/20 flex items-center justify-center text-${stat.color} shadow-neon-sm`}>
                                    <span className="material-symbols-outlined text-3xl">{stat.icon}</span>
                                </div>
                                <span className={`text-[9px] font-black uppercase tracking-[0.2em] px-3 py-1 bg-${stat.color}/5 border border-${stat.color}/10 rounded-lg text-${stat.color}`}>Real-time</span>
                            </div>
                            <h3 className="text-4xl font-black text-white mb-1 font-mono tracking-tighter text-shadow-glow">{(stat.val || 0).toLocaleString()}</h3>
                            <p className="text-[10px] text-slate-500 uppercase font-black tracking-[0.25em]">{stat.label}</p>
                        </div>
                    ))}
                </div>

                {/* Intelligent Threat Matrix */}
                <div className="glass-panel w-full rounded-3xl border border-white/5 overflow-hidden bg-slate-900/40 shadow-neon-sm transition-all duration-500">
                    <div className="p-6 border-b border-white/5 bg-white/5 flex items-center justify-between backdrop-blur-md">
                        <div className="flex items-center gap-4">
                            <div className="size-2 rounded-full bg-amber-500 animate-ping"></div>
                            <h3 className="text-xs font-black text-white uppercase tracking-[0.3em]">Threat Intelligence Stream</h3>
                        </div>
                        <span className="px-3 py-1 bg-amber-500/10 text-amber-500 text-[9px] font-black rounded-lg uppercase tracking-widest border border-amber-500/20">Active Analysis</span>
                    </div>
                    <div className="divide-y divide-white/5 max-h-[600px] overflow-y-auto custom-scrollbar bg-black/20">
                        {logs.length === 0 ? (
                            <div className="p-16 text-center opacity-30 flex flex-col items-center gap-4">
                                <span className="material-symbols-outlined text-6xl">radar</span>
                                <p className="text-[10px] font-black uppercase tracking-[0.3em]">System clean. No recent anomalies detected.</p>
                            </div>
                        ) : (
                            logs.map((log, idx) => (
                                <div key={idx} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between hover:bg-white/[0.05] transition-colors group gap-4 sm:gap-0">
                                    <div className="flex items-start sm:items-center gap-5">
                                        <div className="size-10 shrink-0 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-500 shadow-neon-sm">
                                            <span className="material-symbols-outlined text-[20px]">warning</span>
                                        </div>
                                        <div className="flex-1">
                                            <div className="flex flex-wrap items-center gap-2 mb-1.5">
                                                <p className="text-[11px] font-black text-white uppercase tracking-widest">{log.action}</p>
                                                <span className="px-2 py-0.5 rounded bg-white/5 text-[9px] text-slate-400 font-mono tracking-tighter border border-white/10 uppercase">
                                                    {log.app_name || 'Global'}
                                                </span>
                                            </div>
                                            <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                                                <span className="text-[9px] text-slate-500 font-mono flex items-center gap-1 bg-black/40 px-2 py-0.5 rounded border border-white/5">
                                                    <span className="material-symbols-outlined text-[10px]">public</span>
                                                    {log.ip || 'UNKNOWN'}
                                                </span>
                                                <span className="text-[9px] text-slate-500 font-mono flex items-center gap-1 bg-black/40 px-2 py-0.5 rounded border border-white/5 truncate max-w-[200px]" title={log.hwid}>
                                                    <span className="material-symbols-outlined text-[10px]">devices</span>
                                                    {log.hwid || 'No HWID'}
                                                </span>
                                                <span className="text-[9px] text-primary font-black uppercase tracking-widest flex items-center gap-1 bg-primary/10 border border-primary/20 px-2 py-0.5 rounded text-shadow-glow">
                                                    <span className="material-symbols-outlined text-[10px]">person</span>
                                                    {log.username || 'ANONYMOUS'}
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-between sm:justify-end gap-6 sm:w-auto w-full border-t border-white/5 sm:border-t-0 pt-3 sm:pt-0">
                                        <div className="flex items-center gap-2 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                                            {log.ip && (
                                                <button 
                                                    onClick={(e) => { e.stopPropagation(); handleBlacklistAdd('ip', log.ip); }}
                                                    className="text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 rounded-lg bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500 hover:text-white transition-all flex items-center gap-1.5 shadow-[0_0_10px_rgba(239,68,68,0.2)] hover:shadow-neon-sm"
                                                >
                                                    <span className="material-symbols-outlined text-[12px]">block</span>
                                                    Block IP
                                                </button>
                                            )}
                                            {log.hwid && (
                                                <button 
                                                    onClick={(e) => { e.stopPropagation(); handleBlacklistAdd('hwid', log.hwid); }}
                                                    className="text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 rounded-lg bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500 hover:text-white transition-all flex items-center gap-1.5 shadow-[0_0_10px_rgba(239,68,68,0.2)] hover:shadow-neon-sm"
                                                >
                                                    <span className="material-symbols-outlined text-[12px]">fingerprint</span>
                                                    Block HWID
                                                </button>
                                            )}
                                        </div>
                                        <div className="text-right shrink-0">
                                            <p className="text-[10px] text-slate-400 font-mono italic">{new Date(log.timestamp).toLocaleTimeString()}</p>
                                            <p className="text-[8px] text-slate-600 font-mono uppercase mt-0.5">{new Date(log.timestamp).toLocaleDateString()}</p>
                                        </div>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
        </div>
    );
};

export default SecurityMonitoring;
