import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const navigate = useNavigate();
    const [isLogin, setIsLogin] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [show2FA, setShow2FA] = useState(false);

    // Form States
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: '',
        confirmPassword: ''
    });
    const [twoFactorCode, setTwoFactorCode] = useState('');
    const [tempToken, setTempToken] = useState(null);

    useEffect(() => {
        // Auto Login if token exists
        const existingToken = localStorage.getItem('rdx_token');
        if (existingToken) {
            navigate('/dashboard');
        }

        // Add dynamic CSS needed for Login
        const style = document.createElement('style');
        style.textContent = `
            .glass-panel-login {
                background: rgba(255, 255, 255, 0.03);
                backdrop-filter: blur(24px) saturate(180%);
                border: 1px solid rgba(255, 255, 255, 0.08);
                box-shadow: 0 0 50px rgba(99, 102, 241, 0.4), inset 0 0 20px rgba(99, 102, 241, 0.1);
            }
            .celestial-bg {
                background: radial-gradient(circle at 50% -20%, #1e1b4b 0%, #030208 60%);
            }
            .arc-glow {
                position: absolute;
                width: 140%;
                height: 1000px;
                border-top: 1px solid rgba(99, 102, 241, 0.3);
                border-radius: 50%;
                top: 45%;
                left: 50%;
                transform: translateX(-50%);
                box-shadow: 0 -20px 120px -20px rgba(99, 102, 241, 0.4);
                pointer-events: none;
            }
            .glow-sphere {
                position: absolute;
                width: 400px;
                height: 400px;
                background: radial-gradient(circle, rgba(99, 102, 241, 0.15) 0%, transparent 70%);
                filter: blur(60px);
                pointer-events: none;
            }
            .input-glass {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.1);
                transition: all 0.3s ease;
            }
            .input-glass:focus {
                background: rgba(255, 255, 255, 0.08);
                border-color: rgba(99, 102, 241, 0.5);
                box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
            }
            .gsi-container > div {
                width: 100% !important;
                border-radius: 0.75rem !important;
                overflow: hidden !important;
            }
        `;
        document.head.appendChild(style);

        const handleGoogleResponse = async (response) => {
            setSubmitting(true);
            try {
                const res = await fetch('/rdx/api/auth/google', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ idToken: response.credential })
                });
                const resJson = await res.json();
                const payload = resJson.data || resJson;
                if (resJson.success) {
                    localStorage.setItem('rdx_token', payload.token);
                    if (payload.user && payload.user.role === 'admin') {
                        window.location.href = `/rdxofficial/unknown=admin/dashboard?auth_token=${payload.token}`;
                    } else {
                        navigate('/dashboard');
                    }
                } else {
                    alert(resJson.message || 'Google Auth Failed');
                }
            } catch (err) {
                console.error(err);
                alert('Google Auth Failed');
            } finally {
                setSubmitting(false);
            }
        };

        // Initialize Google Login
        const initGoogleLogin = () => {
            if (window.google && document.getElementById("g_id_signin")) {
                window.google.accounts.id.initialize({
                    client_id: "889846934482-odfm3l9gdqs7hanvoh46t5s8ubcp5i9a.apps.googleusercontent.com",
                    callback: handleGoogleResponse,
                    auto_select: false,
                    cancel_on_tap_outside: false
                });

                window.google.accounts.id.renderButton(
                    document.getElementById("g_id_signin"),
                    { theme: "outline", size: "large", type: "standard", shape: "pill", text: "continue_with", logo_alignment: "left" }
                );
            }
        };

        const googleTimer = setInterval(() => {
            if (window.google) {
                clearInterval(googleTimer);
                initGoogleLogin();
            }
        }, 100);

        return () => {
            clearInterval(googleTimer);
            document.head.removeChild(style);
        };
    }, [navigate]);

    const handleInputChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleAuthSubmit = async (e) => {
        e.preventDefault();
        const { username, email, password, confirmPassword } = formData;

        if (!username || !password) return alert('Fill in required fields');
        if (!isLogin && !email) return alert('Enter your email');
        if (!isLogin && password !== confirmPassword) return alert('Passwords mismatch');

        setSubmitting(true);
        const endpoint = isLogin ? '/rdx/api/auth/login' : '/rdx/api/auth/register';
        const body = { username, password, source: 'dashboard' };
        if (!isLogin) body.email = email;

        try {
            const res = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            const resJson = await res.json();
            const payload = resJson.data || resJson;

            if (resJson.success) {
                if (payload.two_factor_required) {
                    setTempToken(payload.temp_token);
                    setShow2FA(true);
                    return;
                }
                if (isLogin) {
                    localStorage.setItem('rdx_token', payload.token);
                    if (payload.user && payload.user.role === 'admin') {
                        window.location.href = `/rdxofficial/unknown=admin/dashboard?auth_token=${payload.token}`;
                    } else {
                        navigate('/dashboard');
                    }
                } else {
                    alert('Identity Created! Please sign in.');
                    setIsLogin(true);
                }
            } else {
                alert(resJson.message || 'Verification Error');
            }
        } catch (error) {
            alert('Connection failure');
        } finally {
            setSubmitting(false);
        }
    };

    const handle2FASubmit = async () => {
        if (twoFactorCode.length < 6) return alert('Enter valid code');
        setSubmitting(true);

        try {
            const res = await fetch('/rdx/api/auth/2fa/verify-login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${tempToken}` },
                body: JSON.stringify({ code: twoFactorCode })
            });
            const resJson = await res.json();
            const payload = resJson.data || resJson;
            if (resJson.success) {
                localStorage.setItem('rdx_token', payload.token);
                if (payload.user && payload.user.role === 'admin') {
                    window.location.href = `/rdxofficial/unknown=admin/dashboard?auth_token=${payload.token}`;
                } else {
                    navigate('/dashboard');
                }
            } else {
                alert(resJson.message);
            }
        } catch (e) {
            alert('Authorization failure');
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="dark min-h-screen celestial-bg flex flex-col font-sans">
            <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
                <div className="arc-glow animate-pulse"></div>
                <div className="glow-sphere top-[-10%] left-[-10%] animate-pulse" style={{ animationDuration: '4s' }}></div>
                <div className="glow-sphere bottom-[-10%] right-[-10%] opacity-50 animate-pulse" style={{ animationDuration: '6s' }}></div>
            </div>

            <nav className="relative z-50 px-12 py-8 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-indigo-400 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
                        <span className="material-symbols-outlined text-white text-2xl">auto_awesome</span>
                    </div>
                </div>
                <div className="hidden lg:flex items-center gap-10 text-[11px] font-bold tracking-[0.2em] text-slate-400">
                    <a className="hover:text-white transition-colors" href="/">HOME</a>
                    <a className="hover:text-white transition-colors" href="/docs">HELP</a>
                    <a className="hover:text-white transition-colors" href="/status">STATUS</a>
                    <a className="hover:text-white transition-colors" href="/support">SUPPORT</a>
                </div>
                <div>
                    <button onClick={() => navigate('/dashboard')} className="px-8 py-2.5 rounded-full border border-white/10 bg-white/5 hover:bg-white/10 transition-all text-[10px] font-bold tracking-[0.2em] uppercase text-white">
                        DASHBOARD ACCESS
                    </button>
                </div>
            </nav>

            <main className="flex-grow flex items-center justify-center px-6 relative z-10 py-12">
                <div className="w-full max-w-6xl glass-panel-login rounded-[2.5rem] overflow-hidden flex flex-col lg:flex-row min-h-[640px]">

                    {/* Left Form Side */}
                    <div className="w-full lg:w-1/2 p-12 lg:p-20 flex flex-col justify-center border-b lg:border-b-0 lg:border-r border-white/5">
                        <div className="max-w-md mx-auto w-full">
                            <div className="mb-12">
                                <h2 className="text-xs font-bold tracking-[0.3em] text-indigo-400 uppercase mb-4">
                                    {isLogin ? 'Authentication' : 'Initialization'}
                                </h2>
                                <h3 className="text-3xl font-semibold mb-2 text-white">
                                    {isLogin ? 'Secure Portal' : 'Create Identity'}
                                </h3>
                                <p className="text-slate-400 text-sm">Please verify your credentials to proceed.</p>
                            </div>

                            {/* Tab Switcher */}
                            <div className="mb-8 flex gap-2">
                                <button onClick={() => setIsLogin(true)} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${isLogin ? 'text-white bg-indigo-500/20 border-indigo-500/30 border shadow-lg shadow-indigo-500/10' : 'text-slate-500 border border-transparent hover:text-white'}`}>Login</button>
                                <button onClick={() => setIsLogin(false)} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${!isLogin ? 'text-white bg-indigo-500/20 border-indigo-500/30 border shadow-lg shadow-indigo-500/10' : 'text-slate-500 border border-transparent hover:text-white'}`}>Register</button>
                            </div>

                            <form className="space-y-6" onSubmit={handleAuthSubmit}>
                                <div className="space-y-2">
                                    <label className="text-[10px] font-bold tracking-widest text-slate-500 uppercase ml-1">Identity</label>
                                    <div className="relative group">
                                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-xl group-focus-within:text-indigo-400 transition-colors">person</span>
                                        <input name="username" value={formData.username} onChange={handleInputChange} className="w-full input-glass rounded-2xl py-4 pl-12 pr-6 text-sm outline-none placeholder:text-slate-600 text-white" placeholder="Username" type="text" />
                                    </div>
                                </div>

                                {!isLogin && (
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-bold tracking-widest text-slate-500 uppercase ml-1">Security Email</label>
                                        <div className="relative group">
                                            <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-xl group-focus-within:text-indigo-400 transition-colors">mail</span>
                                            <input name="email" value={formData.email} onChange={handleInputChange} className="w-full input-glass rounded-2xl py-4 pl-12 pr-6 text-sm outline-none placeholder:text-slate-600 text-white" placeholder="security@rdx.network" type="email" />
                                        </div>
                                    </div>
                                )}

                                <div className="space-y-2">
                                    <div className="flex justify-between items-center px-1">
                                        <label className="text-[10px] font-bold tracking-widest text-slate-500 uppercase">Keyphrase</label>
                                        <button type="button" onClick={() => window.location.href='/recovery'} className="text-[9px] font-bold text-indigo-400 hover:text-white uppercase tracking-wider transition-colors">Recovery</button>
                                    </div>
                                    <div className="relative group">
                                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-xl group-focus-within:text-indigo-400 transition-colors">lock</span>
                                        <input name="password" value={formData.password} onChange={handleInputChange} className="w-full input-glass rounded-2xl py-4 pl-12 pr-6 text-sm outline-none placeholder:text-slate-600 text-white" placeholder="••••••••" type="password" />
                                    </div>
                                </div>

                                {!isLogin && (
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-bold tracking-widest text-slate-500 uppercase ml-1">Verify Keyphrase</label>
                                        <div className="relative group">
                                            <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-xl group-focus-within:text-indigo-400 transition-colors">verified_user</span>
                                            <input name="confirmPassword" value={formData.confirmPassword} onChange={handleInputChange} className="w-full input-glass rounded-2xl py-4 pl-12 pr-6 text-sm outline-none placeholder:text-slate-600 text-white" placeholder="••••••••" type="password" />
                                        </div>
                                    </div>
                                )}

                                <div className="flex items-center justify-between pt-2">
                                    <label className="flex items-center gap-2 cursor-pointer group">
                                        <div className="relative flex items-center justify-center">
                                            <input className="peer h-5 w-5 bg-white/5 border-white/10 rounded-md checked:bg-indigo-500 checked:border-transparent focus:ring-0 transition-all" type="checkbox" id="rememberMe" />
                                            <span className="material-symbols-outlined absolute text-white text-sm opacity-0 peer-checked:opacity-100 pointer-events-none">check</span>
                                        </div>
                                        <span className="text-xs text-slate-400 group-hover:text-slate-300 transition-colors">Persistent session</span>
                                    </label>
                                </div>

                                <button disabled={submitting} type="submit" className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-4 rounded-2xl shadow-xl shadow-indigo-500/20 transition-all tracking-[0.15em] text-xs mt-4 flex items-center justify-center gap-2 group disabled:opacity-50">
                                    <span>{submitting ? 'PROCESSING...' : (isLogin ? 'INITIALIZE LOGIN' : 'CREATE ACCOUNT')}</span>
                                    <span className="material-symbols-outlined text-lg group-hover:translate-x-1 transition-transform">{isLogin ? 'arrow_forward' : 'person_add'}</span>
                                </button>
                            </form>

                            {/* Social Auth Graphic Placeholder */}
                            <div className="mt-8 space-y-4">
                                <div className="relative flex items-center py-2">
                                    <div className="flex-grow border-t border-white/5"></div>
                                    <span className="flex-shrink-0 mx-4 text-[9px] font-bold text-slate-600 uppercase tracking-[0.3em]">OR SYNC VIA</span>
                                    <div className="flex-grow border-t border-white/5"></div>
                                </div>
                                <div className="flex gap-4 items-center">
                                    <div id="g_id_signin" className="flex-1 w-full overflow-hidden rounded-xl h-[40px] flex items-center justify-center gsi-container"></div>
                                    <button type="button" className="flex-1 h-[40px] bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl px-4 transition-all flex items-center justify-center gap-3">
                                        <span className="text-[10px] font-bold uppercase tracking-widest text-white/70">GitHub</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Right Graphic Side */}
                    <div className="w-full lg:w-1/2 p-12 lg:p-20 flex flex-col justify-center relative overflow-hidden bg-white/[0.01]">
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-gradient-to-br from-indigo-500/10 to-transparent pointer-events-none"></div>
                        <div className="max-w-md mx-auto lg:mx-0 relative z-10">
                            <h1 className="text-7xl lg:text-8xl font-extrabold mb-8 tracking-tighter leading-none text-white text-shadow-glow">
                                Welcome<span className="text-indigo-500">.</span>
                            </h1>
                            <div className="space-y-6">
                                <p className="text-lg text-slate-300 font-light leading-relaxed">
                                    Ascend to the next tier of digital orchestration. Our glass-native interface bridges the gap between complex infrastructure and intuitive control.
                                </p>
                                <div className="flex items-center gap-6 pt-4 text-white">
                                    <div className="flex flex-col">
                                        <span className="text-2xl font-bold text-shadow-glow">99.9%</span>
                                        <span className="text-[10px] tracking-widest text-slate-500 uppercase font-bold">Uptime</span>
                                    </div>
                                    <div className="w-px h-10 bg-white/10"></div>
                                    <div className="flex flex-col">
                                        <span className="text-2xl font-bold text-shadow-glow">24/7</span>
                                        <span className="text-[10px] tracking-widest text-slate-500 uppercase font-bold">Relay</span>
                                    </div>
                                    <div className="w-px h-10 bg-white/10"></div>
                                    <div className="flex flex-col">
                                        <span className="text-2xl font-bold text-shadow-glow">4.8k</span>
                                        <span className="text-[10px] tracking-widest text-slate-500 uppercase font-bold">Nodes</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <footer className="relative z-50 py-10 px-12 flex flex-col md:flex-row items-center justify-between text-[10px] font-bold tracking-[0.2em] text-slate-500 uppercase mt-auto">
                <div className="mb-4 md:mb-0">© 2024 Celestial Technologies. All rights reserved.</div>
                <div className="flex items-center gap-8">
                    <a className="hover:text-white transition-colors" href="#">Privacy</a>
                    <a className="hover:text-white transition-colors" href="#">Terminal Terms</a>
                    <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-accent animate-pulse"></span>
                        <span className="text-accent text-shadow-glow-secondary">System Online</span>
                    </div>
                </div>
            </footer>

            {/* 2FA Modal */}
            {show2FA && (
                <div className="fixed inset-0 z-[100] bg-background-dark/95 backdrop-blur-3xl flex items-center justify-center p-6">
                    <div className="w-full max-w-sm text-center">
                        <div className="size-20 bg-indigo-500/20 rounded-full flex items-center justify-center mx-auto mb-8 animate-pulse shadow-lg shadow-indigo-500/20">
                            <span className="material-symbols-outlined text-4xl text-indigo-400">shield_person</span>
                        </div>
                        <h3 className="text-2xl font-black text-white uppercase tracking-tighter mb-2">Multifactor Required</h3>
                        <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-[0.2em] mb-10 opacity-60">Enter the orbital authorization code</p>

                        <div className="space-y-8 mb-10">
                            <input value={twoFactorCode} onChange={(e) => setTwoFactorCode(e.target.value)} type="text" placeholder="000000" maxLength="6" className="w-full bg-transparent border-b-2 border-white/10 text-center text-5xl font-mono tracking-[0.5em] text-white focus:outline-none focus:border-indigo-500 transition-all py-4" />
                        </div>

                        <div className="flex flex-col gap-4">
                            <button disabled={submitting} onClick={handle2FASubmit} className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-5 rounded-2xl transition-all shadow-xl shadow-indigo-500/20 text-xs uppercase tracking-widest disabled:opacity-50">
                                <span>{submitting ? 'AUTHORIZING...' : 'Verify Identity'}</span>
                            </button>
                            <button onClick={() => { setShow2FA(false); setTempToken(null); }} className="text-[10px] font-bold text-gray-500 hover:text-white uppercase tracking-widest transition-colors py-2">
                                Abort Request
                            </button>
                        </div>
                    </div>
                </div>
            )}

        </div>
    );
};

export default Login;
