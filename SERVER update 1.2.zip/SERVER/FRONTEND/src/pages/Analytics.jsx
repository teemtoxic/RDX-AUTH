import React, { useState, useEffect } from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, Title, Filler } from 'chart.js';
import { Doughnut, Line } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, Title, Filler);

const Analytics = () => {
    const [stats, setStats] = useState({ 
        totalHits: 0, 
        avgHitRate: 0, 
        licenseRequests: 0,
        totalUsers: 0,
        totalLicenses: 0,
        keyStatus: { used: 0, unused: 0, banned: 0, paused: 0 },
        userStatus: { active: 0, unused: 0, paused: 0, banned: 0 },
        trafficLabels: Array.from({length: 24}, (_, i) => `${i}:00`),
        authTrafficData: Array(24).fill(0)
    });
    const token = localStorage.getItem('rdx_token');

    useEffect(() => {
        fetchAnalytics();
    }, []);

    const fetchAnalytics = async () => {
        try {
            const res = await fetch('/rdx/api/stats', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success && data.stats) {
                setStats({
                    totalHits: data.stats.totalHits || 0,
                    avgHitRate: data.stats.hitRate || 0,
                    licenseRequests: data.stats.licenseRequests || 0,
                    totalUsers: data.stats.users || 0,
                    totalLicenses: data.stats.licenses || 0,
                    keyStatus: data.stats.keys || { used: 0, unused: 0, banned: 0, paused: 0 },
                    userStatus: data.stats.users_status || { active: 0, unused: 0, paused: 0, banned: 0 },
                    trafficLabels: data.stats.trafficLabels || Array.from({length: 24}, (_, i) => `${i}:00`),
                    authTrafficData: data.stats.authTrafficData || Array(24).fill(0)
                });
            }
        } catch (e) { console.error('Error fetching analytics:', e); }
    };

    const keyChartData = {
        labels: ['Used', 'Unused', 'Banned', 'Paused'],
        datasets: [{
            data: [stats.keyStatus.used, stats.keyStatus.unused, stats.keyStatus.banned, stats.keyStatus.paused],
            backgroundColor: ['#4ade80', '#60a5fa', '#f87171', '#fb923c'],
            borderWidth: 0,
            hoverOffset: 4
        }]
    };

    const userChartData = {
        labels: ['Active', 'Unused', 'Banned', 'Paused'],
        datasets: [{
            data: [stats.userStatus.active, stats.userStatus.unused, stats.userStatus.banned, stats.userStatus.paused],
            backgroundColor: ['#4ade80', '#60a5fa', '#f87171', '#fb923c'],
            borderWidth: 0,
            hoverOffset: 4
        }]
    };

    const doughnutOptions = {
        responsive: true,
        cutout: '75%',
        plugins: {
            legend: { display: false },
            tooltip: {
                backgroundColor: 'rgba(15, 23, 42, 0.9)',
                titleColor: '#fff',
                bodyColor: '#cbd5e1',
                borderColor: 'rgba(255,255,255,0.1)',
                borderWidth: 1,
                padding: 12,
                displayColors: true,
                boxPadding: 4
            }
        }
    };

    const trafficChartData = {
        labels: stats.trafficLabels,
        datasets: [{
            label: 'Authentication Requests',
            data: stats.authTrafficData,
            fill: true,
            backgroundColor: 'rgba(140, 37, 244, 0.1)',
            borderColor: '#8c25f4',
            borderWidth: 2,
            tension: 0.4,
            pointBackgroundColor: '#8c25f4',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 0,
            pointHoverRadius: 6
        }]
    };

    const trafficOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false },
            tooltip: {
                mode: 'index',
                intersect: false,
                backgroundColor: 'rgba(15, 23, 42, 0.9)',
                titleColor: '#fff',
                bodyColor: '#cbd5e1',
                borderColor: 'rgba(140, 37, 244, 0.3)',
                borderWidth: 1,
                padding: 12
            }
        },
        scales: {
            x: { displa:false, grid: { display: false, drawBorder: false }, ticks: { display: false } },
            y: { display: true, grid: { color: 'rgba(255, 255, 255, 0.05)', drawBorder: false }, ticks: { color: '#64748b', font: { family: 'monospace', size: 10 }, maxTicksLimit: 5 } }
        },
        interaction: { mode: 'nearest', axis: 'x', intersect: false }
    };

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h2 className="text-3xl font-bold text-white mb-2 uppercase tracking-tighter text-shadow-glow">System Analytics</h2>
                        <p className="text-slate-400">Deep dive into application performance and license usage.</p>
                    </div>
                    <div className="bg-slate-900 border border-white/10 rounded-lg p-1 flex items-center">
                        <button className="px-3 py-1.5 text-xs font-medium bg-primary text-white rounded shadow-sm">Real-time</button>
                        <button className="px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-white transition-colors">Historical</button>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="glass-panel p-5 rounded-xl border border-white/5 relative overflow-hidden group shadow-neon-sm">
                        <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                            <span className="material-symbols-outlined text-4xl text-blue-400">group</span>
                        </div>
                        <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">Total Users</p>
                        <h3 className="text-2xl font-bold text-white text-shadow-glow">{stats.totalUsers}</h3>
                        <div className="mt-2 text-[10px] text-green-400 flex items-center gap-1">
                            <span className="material-symbols-outlined text-[12px]">person_check</span>
                            <span>Active Accounts</span>
                        </div>
                    </div>
                    <div className="glass-panel p-5 rounded-xl border border-white/5 relative overflow-hidden group shadow-neon-sm">
                        <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                            <span className="material-symbols-outlined text-4xl text-primary">vpn_key</span>
                        </div>
                        <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">Total Licenses</p>
                        <h3 className="text-2xl font-bold text-white text-shadow-glow">{stats.totalLicenses}</h3>
                        <div className="mt-2 text-[10px] text-primary flex items-center gap-1">
                            <span className="material-symbols-outlined text-[12px]">database</span>
                            <span>Generated Keys</span>
                        </div>
                    </div>
                    <div className="glass-panel p-5 rounded-xl border border-white/5 relative overflow-hidden group shadow-neon-sm">
                        <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                            <span className="material-symbols-outlined text-4xl text-green-400">verified_user</span>
                        </div>
                        <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">License Key Requests</p>
                        <h3 className="text-2xl font-bold text-white text-shadow-glow">{stats.licenseRequests}</h3>
                        <div className="mt-2 text-[10px] text-slate-400 flex items-center gap-1">
                            <span className="material-symbols-outlined text-[12px]">history</span>
                            <span>Total Auth Requests</span>
                        </div>
                    </div>
                    <div className="glass-panel p-5 rounded-xl border border-white/5 relative overflow-hidden group shadow-neon-sm">
                        <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                            <span className="material-symbols-outlined text-4xl text-red-400">login</span>
                        </div>
                        <p className="text-xs text-slate-400 uppercase tracking-wider mb-1">User Requests</p>
                        <h3 className="text-2xl font-bold text-white text-shadow-glow">{stats.totalHits}</h3>
                        <div className="mt-2 text-[10px] text-red-400 flex items-center gap-1">
                            <span className="material-symbols-outlined text-[12px]">sensors</span>
                            <span>Auth Hit Rate: <span>{stats.avgHitRate}%</span></span>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                    {/* License Key Distribution */}
                    <div className="lg:col-span-1 glass-panel rounded-xl p-6 border border-white/5 flex flex-col">
                        <h3 className="text-sm font-bold text-white mb-6 flex items-center gap-2 uppercase tracking-tighter">
                            <span className="material-symbols-outlined text-blue-400">key</span>
                            License Distribution
                        </h3>
                        <div className="relative flex-1 flex items-center justify-center min-h-[200px]">
                            <Doughnut data={keyChartData} options={doughnutOptions} />
                        </div>
                        <div className="mt-6">
                            <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-3 px-1 text-center font-black">Key Breakdown</p>
                            <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                                <div className="bg-slate-900/50 p-2 rounded flex justify-between items-center border border-white/5">
                                    <span className="text-green-400 flex items-center gap-1.5"><span className="size-1.5 rounded-full bg-green-400"></span> Used</span>
                                    <span className="text-white font-bold">{stats.keyStatus.used}</span>
                                </div>
                                <div className="bg-slate-900/50 p-2 rounded flex justify-between items-center border border-white/5">
                                    <span className="text-blue-400 flex items-center gap-1.5"><span className="size-1.5 rounded-full bg-blue-400"></span> Unused</span>
                                    <span className="text-white font-bold">{stats.keyStatus.unused}</span>
                                </div>
                                <div className="bg-slate-900/50 p-2 rounded flex justify-between items-center border border-white/5">
                                    <span className="text-red-400 flex items-center gap-1.5"><span className="size-1.5 rounded-full bg-red-400"></span> Banned</span>
                                    <span className="text-white font-bold">{stats.keyStatus.banned}</span>
                                </div>
                                <div className="bg-slate-900/50 p-2 rounded flex justify-between items-center border border-white/5">
                                    <span className="text-orange-400 flex items-center gap-1.5"><span className="size-1.5 rounded-full bg-orange-400"></span> Paused</span>
                                    <span className="text-white font-bold">{stats.keyStatus.paused}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* User Account Distribution */}
                    <div className="lg:col-span-1 glass-panel rounded-xl p-6 border border-white/5 flex flex-col">
                        <h3 className="text-sm font-bold text-white mb-6 flex items-center gap-2 uppercase tracking-tighter">
                            <span className="material-symbols-outlined text-green-400">account_circle</span>
                            User Distribution
                        </h3>
                        <div className="relative flex-1 flex items-center justify-center min-h-[200px]">
                            <Doughnut data={userChartData} options={doughnutOptions} />
                        </div>
                        <div className="mt-6">
                            <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-3 px-1 text-center font-black">User Breakdown</p>
                            <div className="grid grid-cols-1 gap-2 text-[10px] font-mono">
                                <div className="flex gap-2">
                                    <div className="flex-1 bg-slate-900/50 p-2 rounded flex justify-between items-center border border-white/5">
                                        <span className="text-green-400 flex items-center gap-1.5"><span className="size-1.5 rounded-full bg-green-400"></span> Active</span>
                                        <span className="text-white font-bold">{stats.userStatus.active}</span>
                                    </div>
                                    <div className="flex-1 bg-slate-900/50 p-2 rounded flex justify-between items-center border border-white/5">
                                        <span className="text-blue-400 flex items-center gap-1.5"><span className="size-1.5 rounded-full bg-blue-400"></span> Unused</span>
                                        <span className="text-white font-bold">{stats.userStatus.unused}</span>
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                    <div className="flex-1 bg-slate-900/50 p-2 rounded flex justify-between items-center border border-white/5">
                                        <span className="text-orange-400 flex items-center gap-1.5"><span className="size-1.5 rounded-full bg-orange-400"></span> Paused</span>
                                        <span className="text-white font-bold">{stats.userStatus.paused}</span>
                                    </div>
                                    <div className="flex-1 bg-slate-900/50 p-2 rounded flex justify-between items-center border border-white/5">
                                        <span className="text-red-400 flex items-center gap-1.5"><span className="size-1.5 rounded-full bg-red-400"></span> Banned</span>
                                        <span className="text-white font-bold">{stats.userStatus.banned}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Traffic Chart */}
                    <div className="lg:col-span-2 glass-panel rounded-xl p-6 border border-white/5 flex flex-col">
                        <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2 uppercase tracking-tighter">
                            <span className="material-symbols-outlined text-purple-400">ssid_chart</span>
                            Authentication Traffic
                        </h3>
                        <div className="relative flex-1 w-full min-h-[300px]">
                            <Line data={trafficChartData} options={trafficOptions} />
                        </div>
                    </div>
                </div>
        </div>
    );
};

export default Analytics;
