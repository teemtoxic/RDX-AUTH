import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/shared/Navbar';

const Pricing = () => {
    const navigate = useNavigate();
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedPlan, setSelectedPlan] = useState('');
    const [transactionId, setTransactionId] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showPaymentModal, setShowPaymentModal] = useState(false);
    
    const token = localStorage.getItem('rdx_token');

    useEffect(() => {
        if (token) {
            fetchBillingData();
        } else {
            setLoading(false);
        }
    }, [token]);

    const fetchBillingData = async () => {
        setLoading(true);
        setError(null);
        try {
            const profileRes = await fetch('/rdx/api/auth/me', { 
                headers: { 'Authorization': `Bearer ${token}` } 
            });
            const profileData = await profileRes.json();
            if (profileData.success) setUser(profileData.user);

            if (profileData.success) setUser(profileData.user);
        } catch (e) {
            console.error(e);
            setError('Connection failed.');
        } finally {
            setLoading(false);
        }
    };

    const handleRequestPlan = (planName) => {
        if (!token) {
            navigate('/login');
            return;
        }

        if (planName === 'starter') {
            navigate('/dashboard');
            return;
        }

        setSelectedPlan(planName);
        setShowPaymentModal(true);
    };

    const submitPayment = async () => {
        if (!transactionId) {
            alert('Please enter Transaction ID');
            return;
        }

        setIsSubmitting(true);
        try {
            const res = await fetch('/rdx/api/plan-request', {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${token}`, 
                    'Content-Type': 'application/json' 
                },
                body: JSON.stringify({ plan: selectedPlan, transaction_id: transactionId })
            });
            const data = await res.json();
            if (data.success) {
                alert(data.message);
                setShowPaymentModal(false);
                setTransactionId('');
                fetchBillingData(); // Refresh to show pending status
            } else {
                alert('Error: ' + data.message);
            }
        } catch (e) {
            alert('Connection error.');
        } finally {
            setIsSubmitting(false);
        }
    };



    return (
        <div className="min-h-screen bg-[#020617] text-white selection:bg-primary/30 relative overflow-hidden flex flex-col pb-20">
            <Navbar userContextId={user?.id} />
            {/* Background Gradients */}
            <div className="fixed inset-0 pointer-events-none z-0">
                <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/20 rounded-full blur-[120px]"></div>
                <div className="absolute bottom-[-10%] right-[-10%] w-[30%] h-[30%] bg-accent/10 rounded-full blur-[100px]"></div>
            </div>

            <div className="relative z-10 max-w-7xl mx-auto px-6 w-full space-y-20 animate-in fade-in slide-in-from-bottom-4 duration-500">
                {/* Header */}
                <header className="text-center">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 mb-6 backdrop-blur-sm">
                        <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                        <span className="text-xs font-bold text-primary uppercase tracking-widest">Pricing & Tiers</span>
                    </div>
                    <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">
                        Unleash the <span className="text-primary">Power</span>
                    </h1>
                    <p className="text-slate-400 max-w-2xl mx-auto text-lg md:text-xl leading-relaxed">
                        Enterprise-grade authentication infrastructure for every scale. <br />Select a plan that fuels your growth.
                    </p>
                </header>

                {/* Pricing Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
                    {/* Starter Plan */}
                    <div className="glass-panel p-8 rounded-[2.5rem] border border-white/5 hover:border-white/10 transition-all group relative flex flex-col bg-slate-900/40">
                        <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                            <span className="material-symbols-outlined text-7xl">auto_mode</span>
                        </div>
                        <div className="mb-8">
                            <h3 className="text-2xl font-bold text-white mb-2">Starter</h3>
                            <div className="flex items-baseline gap-1">
                                <span className="text-5xl font-bold text-white tracking-tighter">Free</span>
                                <span className="text-slate-500 font-medium">/ forever</span>
                            </div>
                        </div>
                        <p className="text-slate-400 mb-8 leading-relaxed">Essential foundation for developers and small prototypes.</p>
                        <div className="space-y-4 mb-10 flex-grow">
                            <div className="flex items-center gap-3 text-sm text-slate-300">
                                <span className="material-symbols-outlined text-green-400 text-[18px]">check_circle</span>
                                <span><b>5</b> Applications Managed</span>
                            </div>
                            <div className="flex items-center gap-3 text-sm text-slate-300">
                                <span className="material-symbols-outlined text-green-400 text-[18px]">check_circle</span>
                                <span><b>Unlimited</b> Users & Keys</span>
                            </div>
                            <div className="flex items-center gap-3 text-sm text-slate-300">
                                <span className="material-symbols-outlined text-green-400 text-[18px]">check_circle</span>
                                <span><b>100%</b> Secure Server-Auth</span>
                            </div>
                            <div className="flex items-center gap-3 text-sm text-slate-500 line-through">
                                <span className="material-symbols-outlined text-[18px]">block</span>
                                <span>Discord Command Manager</span>
                            </div>
                        </div>
                        <button 
                            onClick={() => handleRequestPlan('starter')}
                            className="w-full py-4 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 text-white font-bold transition-all transform hover:scale-[1.02]"
                        >
                            Get Started Free
                        </button>
                    </div>

                    {/* Basic Plan */}
                    <div className="lg:-mt-4 lg:mb-4 relative group transform transition-all duration-300">
                        <div className="absolute inset-0 bg-blue-500/20 rounded-[2.5rem] blur-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        <div className="glass-panel p-1 rounded-[2.5rem] bg-gradient-to-b from-blue-500/30 via-blue-500/5 to-transparent relative h-full shadow-2xl">
                            <div className="bg-[#0b1121]/90 rounded-[2.4rem] p-8 h-full relative overflow-hidden flex flex-col border border-white/5">
                                <div className="absolute top-0 right-0 px-6 py-2 bg-blue-600 text-white text-[10px] font-bold uppercase rounded-bl-2xl tracking-widest z-10">
                                    Most Popular
                                </div>
                                <div className="mb-8">
                                    <h3 className="text-2xl font-bold text-white mb-2">Basic</h3>
                                    <div className="flex items-baseline gap-1">
                                        <span className="text-5xl font-bold text-white tracking-tighter">₹50</span>
                                        <span className="text-slate-500 font-medium">/ month</span>
                                    </div>
                                </div>
                                <p className="text-slate-400 mb-8 leading-relaxed">Advanced tools for growing communities.</p>
                                <div className="space-y-4 mb-10 flex-grow">
                                    <div className="flex items-center gap-3 text-sm text-slate-200">
                                        <span className="material-symbols-outlined text-blue-400 text-[18px]">check_circle</span>
                                        <span><b>20</b> Applications Managed</span>
                                    </div>
                                    <div className="flex items-center gap-3 text-sm text-slate-200">
                                        <span className="material-symbols-outlined text-blue-400 text-[18px]">check_circle</span>
                                        <span><b>Discord Command Manager</b></span>
                                    </div>
                                    <div className="flex items-center gap-3 text-sm text-slate-200">
                                        <span className="material-symbols-outlined text-blue-400 text-[18px]">check_circle</span>
                                        <span>Live HWID Reset Logs</span>
                                    </div>
                                </div>
                                <button 
                                    onClick={() => handleRequestPlan('basic')}
                                    className="w-full py-4 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold transition-all transform hover:scale-[1.02] shadow-[0_0_20px_rgba(59,130,246,0.3)]"
                                >
                                    Upgrade to Basic
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Pro Plan */}
                    <div className="glass-panel p-8 rounded-[2.5rem] border border-primary/20 hover:border-primary/40 transition-all group relative flex flex-col bg-primary/5 shadow-neon-sm">
                        <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                            <span className="material-symbols-outlined text-7xl text-primary">auto_awesome</span>
                        </div>
                        <div className="mb-8">
                            <h3 className="text-2xl font-bold text-white mb-2">Pro</h3>
                            <div className="flex items-baseline gap-1">
                                <span className="text-5xl font-bold text-primary tracking-tighter">₹80</span>
                                <span className="text-slate-500 font-medium">/ month</span>
                            </div>
                        </div>
                        <p className="text-slate-400 mb-8 leading-relaxed">Full AI integration and infinite scalability.</p>
                        <div className="space-y-4 mb-10 flex-grow">
                            <div className="flex items-center gap-3 text-sm text-slate-100">
                                <span className="material-symbols-outlined text-primary text-[18px]">check_circle</span>
                                <span><b>Unlimited</b> Applications</span>
                            </div>
                            <div className="flex items-center gap-3 text-sm text-primary font-bold">
                                <span className="material-symbols-outlined text-[18px]">auto_awesome</span>
                                <span>AI Mainframe Console</span>
                            </div>
                            <div className="flex items-center gap-3 text-sm text-slate-100">
                                <span className="material-symbols-outlined text-primary text-[18px]">check_circle</span>
                                <span>Enterprise Support Tier</span>
                            </div>
                        </div>
                        <button 
                            onClick={() => handleRequestPlan('pro')}
                            className="w-full py-4 rounded-2xl bg-primary hover:bg-primary-hover text-white font-bold shadow-neon transition-all transform hover:scale-[1.02]"
                        >
                            Unlock Pro Access
                        </button>
                    </div>
                </div>

            </div>

            {/* Payment Modal */}
            {showPaymentModal && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowPaymentModal(false)}></div>
                    <div className="relative w-full max-w-md bg-[#0f172a] rounded-3xl border border-white/10 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
                        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary via-accent to-primary"></div>
                        <div className="p-8 space-y-6">
                            <div className="flex items-center gap-4">
                                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                                    <span className="material-symbols-outlined text-primary">payments</span>
                                </div>
                                <div>
                                    <h3 className="text-lg font-bold text-white">Confirm Subscription</h3>
                                    <p className="text-sm text-slate-400">Upgrade to <span className="text-white font-black uppercase text-glow">{selectedPlan}</span> Plan</p>
                                </div>
                            </div>

                            <div className="p-6 rounded-2xl bg-slate-900/50 border border-white/5 text-center space-y-4">
                                <p className="text-[10px] text-slate-500 uppercase tracking-[0.2em] font-black">Scan to pay via UPI</p>
                                <div className="flex items-center justify-center gap-2 bg-black/40 p-3 rounded-xl border border-white/5">
                                    <span className="text-base font-mono text-accent font-bold">anuj12630@fam</span>
                                    <button 
                                        onClick={() => {
                                            navigator.clipboard.writeText('anuj12630@fam');
                                            alert('UPI ID Copied');
                                        }}
                                        className="text-slate-500 hover:text-white transition-colors"
                                    >
                                        <span className="material-symbols-outlined text-base">content_copy</span>
                                    </button>
                                </div>
                                <div className="w-40 h-40 bg-white p-2 mx-auto rounded-2xl overflow-hidden border border-white/10">
                                    <img src="/assets_rdx/qr.png" alt="Payment QR Code" className="w-full h-full object-contain" />
                                </div>
                                <p className="text-[10px] text-slate-500 italic">Verify amount: ₹{selectedPlan === 'pro' ? '80' : '50'}</p>
                            </div>

                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Transaction ID / UTR</label>
                                <input 
                                    type="text" 
                                    placeholder="Enter 12-digit Ref ID"
                                    value={transactionId}
                                    onChange={(e) => setTransactionId(e.target.value)}
                                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm font-mono text-white focus:outline-none focus:border-primary transition-colors"
                                />
                            </div>

                            <div className="flex gap-3 pt-2">
                                <button 
                                    onClick={submitPayment}
                                    disabled={isSubmitting}
                                    className="flex-1 py-4 bg-primary hover:bg-primary-hover text-white text-[11px] font-black rounded-xl transition-all shadow-neon uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-50"
                                >
                                    <span className="material-symbols-outlined text-[20px]">{isSubmitting ? 'sync' : 'check_circle'}</span>
                                    {isSubmitting ? 'Verifying...' : 'Verify & Activate'}
                                </button>
                                <button 
                                    onClick={() => setShowPaymentModal(false)}
                                    className="px-6 py-4 bg-white/5 hover:bg-white/10 text-white text-[11px] font-black rounded-xl transition-all uppercase tracking-widest border border-white/5"
                                >
                                    Cancel
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Pricing;
