import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

const container = {
    hidden: { opacity: 0 },
    show: {
        opacity: 1,
        transition: {
            staggerChildren: 0.1
        }
    }
};

const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
};

const Dashboard = () => {
    const navigate = useNavigate();
    const [serverTime, setServerTime] = useState('SYNCING...');
    const [apps, setApps] = useState([]);
    const [activities, setActivities] = useState([]);
    const [loadingApps, setLoadingApps] = useState(true);
    const [loadingActivities, setLoadingActivities] = useState(true);

    useEffect(() => {
        // Server time mock
        const interval = setInterval(() => {
            const now = new Date();
            setServerTime(now.toLocaleTimeString('en-US', { hour12: false }) + '.' + now.getMilliseconds().toString().padStart(3, '0'));
        }, 87);

        fetchDashboardData();

        return () => clearInterval(interval);
    }, []);

    const fetchDashboardData = async () => {
        try {
            const token = localStorage.getItem('rdx_token');
            if (!token) return;

            // Fetch Apps
            fetch('/rdx/api/apps', {
                headers: { 'Authorization': `Bearer ${token}` }
            })
            .then(res => res.json())
            .then(resJson => {
                const data = resJson.data || resJson;
                if (resJson.success && data.apps) {
                    setApps(data.apps.slice(0, 4)); // Get up to 4 apps for the matrix
                }
                setLoadingApps(false);
            })
            .catch(() => setLoadingApps(false));

            // Fetch Logs
            fetch('/rdx/api/logs', {
                headers: { 'Authorization': `Bearer ${token}` }
            })
            .then(res => res.json())
            .then(resJson => {
                const data = resJson.data || resJson;
                if (resJson.success && data.logs) {
                    setActivities(data.logs.slice(0, 5)); // Get top 5 recent logs
                }
                setLoadingActivities(false);
            })
            .catch(() => setLoadingActivities(false));

        } catch (error) {
            console.error('Failed to fetch dashboard data', error);
            setLoadingApps(false);
            setLoadingActivities(false);
        }
    };

    return (
        <div className="max-w-7xl mx-auto space-y-10 py-4">
            <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in zoom-in-95 duration-300">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                    <div>
                        <h2 className="text-3xl font-bold text-white mb-2 uppercase tracking-tighter text-shadow-glow">Welcome back, Agent.</h2>
                        <p className="text-slate-400">Here's what's happening with your secure applications today.</p>
                    </div>
                    <div className="flex gap-2 text-[10px] text-slate-500 font-black uppercase tracking-widest">
                        <span>SERVER TIME:</span>
                        <span className="text-primary font-mono text-shadow-glow">{serverTime}</span>
                    </div>
                </div>

                <motion.section 
                    variants={container}
                    initial="hidden"
                    animate="show"
                    className="grid grid-cols-1 md:grid-cols-3 gap-6"
                >
                    {/* Subscription Plan Card */}
                    <motion.div variants={item} onClick={() => navigate('/pricing')} className="glass-panel p-6 rounded-xl relative group cursor-pointer overflow-hidden transition-all hover:border-primary/30 bg-slate-900/40 border border-white/10 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.5)] shadow-neon-sm">
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                            <span className="material-symbols-outlined text-6xl text-primary">rocket_launch</span>
                        </div>
                        <div className="relative z-10">
                            <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 border border-primary/20 shadow-neon-sm">
                                <span className="material-symbols-outlined text-primary text-shadow-glow">payments</span>
                            </div>
                            <h3 className="text-lg font-bold text-white mb-2 underline decoration-primary/30 underline-offset-4 text-shadow-glow-secondary">Subscription Plan</h3>
                            <p className="text-sm text-slate-400 mb-4">View and upgrade your current infrastructure plan.</p>
                            <div className="flex items-center text-primary text-[10px] font-black uppercase tracking-widest text-shadow-glow">
                                Manage Plan <span className="material-symbols-outlined text-sm ml-1 group-hover:translate-x-1 transition-transform" >arrow_forward</span>
                            </div>
                        </div>
                        <div className="absolute bottom-0 left-0 h-0.5 w-0 bg-primary group-hover:w-full transition-all duration-500"></div>
                    </motion.div>

                    {/* App Subscriptions Card */}
                    <motion.div variants={item} onClick={() => navigate('/app-subscriptions')} className="glass-panel p-6 rounded-xl relative group cursor-pointer overflow-hidden transition-all hover:border-accent/30 bg-slate-900/40 border border-white/10 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.5)] shadow-neon-sm">
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                            <span className="material-symbols-outlined text-6xl text-accent">loyalty</span>
                        </div>
                        <div className="relative z-10">
                            <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 border border-accent/20 shadow-neon-sm">
                                <span className="material-symbols-outlined text-accent text-shadow-glow">style</span>
                            </div>
                            <h3 className="text-lg font-bold text-white mb-2 underline decoration-accent/30 underline-offset-4 text-shadow-glow-secondary">App Subscriptions</h3>
                            <p className="text-sm text-slate-400 mb-4">Create custom plans (Free, VIP) for your end-users.</p>
                            <div className="flex items-center text-accent text-[10px] font-black uppercase tracking-widest text-shadow-glow">
                                Manage Plans <span className="material-symbols-outlined text-sm ml-1 group-hover:translate-x-1 transition-transform">arrow_forward</span>
                            </div>
                        </div>
                        <div className="absolute bottom-0 left-0 h-0.5 w-0 bg-accent group-hover:w-full transition-all duration-500"></div>
                    </motion.div>

                    {/* Generate Access Link Card */}
                    <motion.div variants={item} onClick={() => navigate('/support')} className="glass-panel p-6 rounded-xl relative group cursor-pointer overflow-hidden transition-all hover:border-purple-400/30 bg-slate-900/40 border border-white/10 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.5)]">
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                            <span className="material-symbols-outlined text-6xl text-purple-400">link</span>
                        </div>
                        <div className="relative z-10">
                            <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 border border-purple-500/20">
                                <span className="material-symbols-outlined text-purple-400">add_link</span>
                            </div>
                            <h3 className="text-lg font-bold text-white mb-2 underline decoration-purple-400/30 underline-offset-4">Generate Access Link</h3>
                            <p className="text-sm text-slate-400 mb-4">Create a secure distribution link for your apps.</p>
                            <div className="flex items-center text-purple-400 text-[10px] font-black uppercase tracking-widest">
                                Generate Now <span className="material-symbols-outlined text-sm ml-1 group-hover:translate-x-1 transition-transform">arrow_forward</span>
                            </div>
                        </div>
                        <div className="absolute bottom-0 left-0 h-0.5 w-0 bg-purple-400 group-hover:w-full transition-all duration-500"></div>
                    </motion.div>

                    {/* Discord Guardian Card */}
                    <motion.div variants={item} onClick={() => navigate('/discord')} className="glass-panel p-6 rounded-xl relative group cursor-pointer overflow-hidden transition-all hover:border-green-400/30 bg-slate-900/40 border border-white/10 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.5)]">
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                            <span className="material-symbols-outlined text-6xl text-green-400">gavel</span>
                        </div>
                        <div className="relative z-10">
                            <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 border border-green-500/20">
                                <span className="material-symbols-outlined text-green-400">smart_toy</span>
                            </div>
                            <h3 className="text-lg font-bold text-white mb-2 underline decoration-green-400/30 underline-offset-4">Discord Guardian</h3>
                            <p className="text-sm text-slate-400 mb-4">Configure AI-powered autonomous server protection.</p>
                            <div className="flex items-center text-green-400 text-[10px] font-black uppercase tracking-widest">
                                Manage Guardian <span className="material-symbols-outlined text-sm ml-1 group-hover:translate-x-1 transition-transform">arrow_forward</span>
                            </div>
                        </div>
                        <div className="absolute bottom-0 left-0 h-0.5 w-0 bg-green-400 group-hover:w-full transition-all duration-500"></div>
                    </motion.div>

                    {/* Key Distribution Card */}
                    <motion.div variants={item} onClick={() => navigate('/key-distribution')} className="glass-panel p-6 rounded-xl relative group cursor-pointer overflow-hidden transition-all hover:border-orange-400/30 bg-slate-900/40 border border-white/10 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.5)]">
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                            <span className="material-symbols-outlined text-6xl text-orange-400">share</span>
                        </div>
                        <div className="relative z-10">
                            <div className="w-12 h-12 rounded-lg bg-orange-500/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 border border-orange-500/20">
                                <span className="material-symbols-outlined text-orange-400">vpn_key</span>
                            </div>
                            <h3 className="text-lg font-bold text-white mb-2 underline decoration-orange-400/30 underline-offset-4">Key Distribution</h3>
                            <p className="text-sm text-slate-400 mb-4">Manage and distribute access keys securely.</p>
                            <div className="flex items-center text-orange-400 text-[10px] font-black uppercase tracking-widest">
                                Distribute Keys <span className="material-symbols-outlined text-sm ml-1 group-hover:translate-x-1 transition-transform">arrow_forward</span>
                            </div>
                        </div>
                        <div className="absolute bottom-0 left-0 h-0.5 w-0 bg-orange-400 group-hover:w-full transition-all duration-500"></div>
                    </motion.div>

                    {/* AI Console Card */}
                    <motion.div variants={item} onClick={() => navigate('/ai-console')} className="glass-panel p-6 rounded-xl relative group cursor-pointer overflow-hidden transition-all hover:border-blue-400/30 bg-slate-900/40 border border-white/10 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.5)]">
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                            <span className="material-symbols-outlined text-6xl text-blue-400">terminal</span>
                        </div>
                        <div className="relative z-10">
                            <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 border border-blue-500/20">
                                <span className="material-symbols-outlined text-blue-400">hub</span>
                            </div>
                            <h3 className="text-lg font-bold text-white mb-2 underline decoration-blue-400/30 underline-offset-4">AI Console</h3>
                            <p className="text-sm text-slate-400 mb-4">Configure conversational AI automation and tasks.</p>
                            <div className="flex items-center text-blue-400 text-[10px] font-black uppercase tracking-widest">
                                Enter Console <span className="material-symbols-outlined text-sm ml-1 group-hover:translate-x-1 transition-transform">arrow_forward</span>
                            </div>
                        </div>
                        <div className="absolute bottom-0 left-0 h-0.5 w-0 bg-blue-400 group-hover:w-full transition-all duration-500"></div>
                    </motion.div>
                </motion.section>

                {/* Lower Section: Service Status Matrix & Latest Activity */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-8">
                    {/* Service Status Matrix */}
                    <div className="lg:col-span-2 glass-panel rounded-xl p-6 relative overflow-hidden flex flex-col border border-white/5 bg-slate-900/40 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.5)]">
                        <div className="flex items-center justify-between mb-6 relative z-10">
                            <div>
                                <h3 className="text-lg font-bold text-white flex items-center gap-2 uppercase tracking-tighter text-shadow-glow">
                                    <span className="material-symbols-outlined text-primary">apps</span>
                                    Service Status Matrix
                                </h3>
                                <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">Live overview of your protected applications.</p>
                            </div>
                            <button onClick={() => navigate('/apps')} className="text-[10px] font-black text-primary hover:text-white transition-colors uppercase tracking-widest hover:underline decoration-primary/30 underline-offset-4">Manage All</button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 flex-1 content-start font-mono">
                            {loadingApps ? (
                                <div className="py-10 text-center text-slate-500 animate-pulse col-span-full italic text-xs">Syncing with secure vault...</div>
                            ) : apps.length === 0 ? (
                                <div className="py-10 text-center text-slate-500 col-span-full italic text-xs">No active services detected.</div>
                            ) : (
                                apps.map(app => (
                                    <div key={app.id} className="p-4 rounded-lg bg-slate-950/50 border border-white/5 flex items-center justify-between group hover:border-primary/30 transition-colors">
                                        <div className="flex items-center gap-3">
                                            <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.8)]"></div>
                                            <div>
                                                <p className="text-sm font-bold text-white group-hover:text-primary transition-colors">{app.name}</p>
                                                <p className="text-[10px] text-slate-500 uppercase tracking-widest">v{app.version}</p>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <p className="text-xs text-green-400 font-bold uppercase tracking-widest">ONLINE</p>
                                            <p className="text-[10px] text-slate-500">Latency: {Math.floor(Math.random() * 30 + 10)}ms</p>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>

                    {/* Latest Activity */}
                    <div className="glass-panel rounded-xl p-6 flex flex-col border border-white/5 bg-slate-900/40 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.5)]">
                        <h3 className="text-lg font-bold text-white mb-6 flex items-center justify-between uppercase tracking-tighter">
                            <span className="text-shadow-glow">Latest Activity</span>
                            <button onClick={() => navigate('/logs')} className="text-[10px] font-black text-primary hover:text-white transition-colors uppercase tracking-widest hover:underline decoration-primary/30 underline-offset-4">View All</button>
                        </h3>
                        <div className="space-y-6 relative flex-1 overflow-y-auto max-h-[400px] scrollbar-thin pr-2 font-mono">
                            <div className="absolute top-2 bottom-2 left-[19px] w-px bg-gradient-to-b from-primary/20 via-primary/10 to-transparent"></div>
                            
                            {loadingActivities ? (
                                <div className="text-center text-slate-500 italic text-xs mt-10 animate-pulse">Waiting for activity events...</div>
                            ) : activities.length === 0 ? (
                                <div className="text-center text-slate-500 italic text-xs mt-10">No recent activity detected.</div>
                            ) : (
                                activities.map(log => (
                                    <div key={log.id} className="relative pl-12">
                                        <div className={`absolute left-0 top-1 w-10 h-10 rounded-full border-4 border-[#0f0f13] flex items-center justify-center z-10 ${log.action.includes('FAILED') || log.action.includes('REJECTED') ? 'bg-red-500/20 text-red-500' : 'bg-primary/20 text-primary'}`}>
                                            <span className="material-symbols-outlined text-[18px]">
                                                {log.action.includes('LOGIN') ? 'login' : log.action.includes('CREATED') ? 'add' : log.action.includes('FAILED') ? 'error' : 'analytics'}
                                            </span>
                                        </div>
                                        <div className="bg-slate-950/50 p-4 rounded-xl border border-white/5 hover:border-white/10 transition-colors">
                                            <p className="text-sm text-white mb-1"><span className="text-primary font-bold">{log.action}</span> - {log.details}</p>
                                            <p className="text-[10px] text-slate-500 uppercase tracking-widest flex items-center justify-between">
                                                <span>IP: {log.ip_address}</span>
                                                <span className="flex items-center gap-1"><span className="material-symbols-outlined text-[12px]">schedule</span> {new Date(log.timestamp).toLocaleString()}</span>
                                            </p>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
