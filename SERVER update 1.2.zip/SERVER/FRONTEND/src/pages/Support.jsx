import React, { useState, useEffect, useRef } from 'react';

const Support = () => {
    const [tickets, setTickets] = useState([]);
    const [currentTicket, setCurrentTicket] = useState(null);
    const [messages, setMessages] = useState([]);
    const [replyMsg, setReplyMsg] = useState('');
    const [isNewTicketModalOpen, setIsNewTicketModalOpen] = useState(false);
    const [newTicket, setNewTicket] = useState({ subject: '', message: '', category: 'general' });
    const [user, setUser] = useState(null);
    const messagesEndRef = useRef(null);
    const token = localStorage.getItem('rdx_token');

    useEffect(() => {
        fetchTickets();
        fetchUser();
        const interval = setInterval(() => {
            if (currentTicket) fetchMessages(currentTicket.id);
        }, 15000);
        return () => clearInterval(interval);
    }, [currentTicket]);

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    const fetchUser = async () => {
        try {
            const res = await fetch('/rdx/api/auth/me', { headers: { 'Authorization': `Bearer ${token}` } });
            const data = await res.json();
            if (data.success) setUser(data.user);
        } catch (e) { console.error(e); }
    };

    const fetchTickets = async () => {
        try {
            const res = await fetch('/rdx/api/tickets/my-tickets', { headers: { 'Authorization': `Bearer ${token}` } });
            const data = await res.json();
            if (data.success) setTickets(data.tickets);
        } catch (e) { console.error(e); }
    };

    const fetchMessages = async (id) => {
        try {
            const res = await fetch(`/rdx/api/tickets/${id}/messages`, { headers: { 'Authorization': `Bearer ${token}` } });
            const data = await res.json();
            if (data.success) {
                setMessages(data.messages);
                setCurrentTicket(data.ticket);
            }
        } catch (e) { console.error(e); }
    };

    const openTicket = (id) => {
        fetchMessages(id);
    };

    const handleSendReply = async (e) => {
        e.preventDefault();
        if (!replyMsg || !currentTicket) return;
        try {
            const res = await fetch(`/rdx/api/tickets/${currentTicket.id}/reply`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ message: replyMsg })
            });
            const data = await res.json();
            if (data.success) {
                setReplyMsg('');
                fetchMessages(currentTicket.id);
            }
        } catch (e) { console.error(e); }
    };

    const handleSubmitTicket = async (e) => {
        e.preventDefault();
        try {
            const res = await fetch('/rdx/api/tickets/create', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(newTicket)
            });
            const data = await res.json();
            if (data.success) {
                setIsNewTicketModalOpen(false);
                setNewTicket({ subject: '', message: '', category: 'general' });
                fetchTickets();
            }
        } catch (e) { console.error(e); }
    };

    const getStatusStyle = (status) => {
        switch (status?.toLowerCase()) {
            case 'pending': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
            case 'open': return 'bg-green-500/10 text-green-500 border-green-500/20';
            case 'resolved': return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
            default: return 'bg-slate-500/10 text-slate-500 border-slate-500/20';
        }
    };

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 h-[calc(100vh-140px)] flex flex-col">
                <div className="flex justify-between items-end flex-shrink-0">
                    <div className="space-y-1">
                        <h2 className="text-3xl font-bold text-white tracking-tight flex items-center gap-3">
                            <span className="material-symbols-outlined text-4xl text-primary">support_agent</span>
                            Support Center
                        </h2>
                        <p className="text-slate-400">Manage your tickets and get assistance from our team.</p>
                    </div>
                    <button 
                        onClick={() => setIsNewTicketModalOpen(true)}
                        className="px-6 py-3 bg-primary hover:bg-primary/90 text-white font-black rounded-xl transition-all shadow-neon-sm flex items-center gap-2 uppercase tracking-widest text-xs"
                    >
                        <span className="material-symbols-outlined text-[20px]">add_circle</span>
                        New Ticket
                    </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 flex-1 overflow-hidden min-h-0">
                    {/* Ticket List Sidebar */}
                    <div className="lg:col-span-1 glass-panel rounded-3xl border border-white/5 flex flex-col overflow-hidden bg-slate-900/40">
                        <div className="p-6 border-b border-white/5 bg-white/5">
                            <h3 className="text-[10px] font-black text-white uppercase tracking-widest">My Active Tickets</h3>
                        </div>
                        <div className="flex-1 overflow-y-auto divide-y divide-white/5 custom-scrollbar">
                            {tickets.length > 0 ? tickets.map(t => (
                                <div 
                                    key={t.id} 
                                    onClick={() => openTicket(t.id)}
                                    className={`p-5 cursor-pointer hover:bg-white/5 transition-all border-l-4 ${currentTicket?.id === t.id ? 'bg-primary/5 border-primary' : 'border-transparent'}`}
                                >
                                    <div className="flex justify-between items-start mb-1">
                                        <h4 className="text-sm font-bold text-white truncate max-w-[150px]">{t.subject}</h4>
                                        <span className="text-[9px] text-slate-500 font-mono italic">{new Date(t.updated_at).toLocaleDateString()}</span>
                                    </div>
                                    <div className="flex items-center justify-between mt-2">
                                        <span className="text-[10px] text-slate-500 font-mono uppercase font-black tracking-widest">#{t.id}</span>
                                        <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase border ${getStatusStyle(t.status)}`}>{t.status}</span>
                                    </div>
                                </div>
                            )) : (
                                <div className="p-12 text-center text-slate-600 opacity-50 flex flex-col items-center">
                                    <span className="material-symbols-outlined text-5xl mb-4">forum</span>
                                    <p className="text-[10px] font-black uppercase tracking-widest">No tickets in vault</p>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Chat Interface */}
                    <div className="lg:col-span-2 glass-panel rounded-3xl border border-white/5 flex flex-col overflow-hidden bg-slate-900/40 relative">
                        {!currentTicket ? (
                            <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 z-10 bg-slate-950/20 backdrop-blur-sm">
                                <div className="size-24 rounded-full bg-slate-900/80 flex items-center justify-center mb-6 border border-white/5 shadow-[0_0_40px_rgba(0,0,0,0.5)]">
                                    <span className="material-symbols-outlined text-4xl text-primary animate-pulse">chat_bubble</span>
                                </div>
                                <h4 className="text-lg font-black text-white uppercase tracking-tighter mb-1">Secure Uplink Established</h4>
                                <p className="text-[10px] uppercase font-black tracking-widest text-slate-600">Select a ticket to begin transmission.</p>
                            </div>
                        ) : (
                            <div className="flex flex-col h-full">
                                {/* Header */}
                                <div className="p-6 border-b border-white/5 bg-white/5 flex items-center justify-between">
                                    <div className="flex items-center gap-4">
                                        <div className={`size-10 rounded-xl flex items-center justify-center border ${getStatusStyle(currentTicket.status)}`}>
                                            <span className="material-symbols-outlined">{currentTicket.status === 'resolved' ? 'verified' : 'pending'}</span>
                                        </div>
                                        <div>
                                            <h3 className="font-bold text-white uppercase tracking-tight">{currentTicket.subject}</h3>
                                            <div className="flex items-center gap-3 mt-0.5">
                                                <span className="text-[10px] text-slate-500 font-mono">ID: #{currentTicket.id}</span>
                                                <span className="size-1 rounded-full bg-slate-700"></span>
                                                <span className={`text-[9px] font-black uppercase ${getStatusStyle(currentTicket.status).split(' ')[1]}`}>{currentTicket.status}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <button onClick={() => fetchMessages(currentTicket.id)} className="p-2.5 bg-white/5 hover:bg-white/10 rounded-xl text-slate-500 hover:text-white transition-all border border-white/5">
                                        <span className="material-symbols-outlined text-[20px]">refresh</span>
                                    </button>
                                </div>

                                {/* Messages Area */}
                                <div className="flex-1 overflow-y-auto p-8 space-y-6 custom-scrollbar bg-black/10">
                                    {messages.map((m, idx) => (
                                        <div key={idx} className={`flex ${m.sender_role === 'admin' ? 'justify-start' : 'justify-end'} animate-in slide-in-from-bottom-2 duration-300`}>
                                            <div className={`max-w-[80%] rounded-2xl p-5 shadow-lg border ${m.sender_role === 'admin' ? 'bg-slate-800/80 border-white/5 rounded-tl-none' : 'bg-primary/20 border-primary/20 rounded-tr-none'}`}>
                                                <div className="flex items-center justify-between gap-6 mb-2">
                                                    <span className={`text-[10px] font-black uppercase tracking-widest ${m.sender_role === 'admin' ? 'text-primary' : 'text-accent'}`}>{m.sender_name}</span>
                                                    <span className="text-[9px] text-slate-500 font-mono uppercase">{new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                                </div>
                                                <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap">{m.message}</p>
                                            </div>
                                        </div>
                                    ))}
                                    <div ref={messagesEndRef} />
                                </div>

                                {/* Reply Input */}
                                <div className="p-6 bg-slate-900/40 border-t border-white/5">
                                    <form onSubmit={handleSendReply} className="relative group">
                                        <textarea 
                                            value={replyMsg}
                                            onChange={e => setReplyMsg(e.target.value)}
                                            placeholder="Transmit message to support..." 
                                            className="w-full bg-black/40 border border-white/10 rounded-2xl px-6 py-4 text-sm text-white focus:outline-none focus:border-primary/50 transition-all resize-none shadow-inner"
                                            rows="3"
                                            onKeyDown={e => {
                                                if(e.key === 'Enter' && !e.shiftKey) {
                                                    e.preventDefault();
                                                    handleSendReply(e);
                                                }
                                            }}
                                        ></textarea>
                                        <button 
                                            type="submit"
                                            className="absolute right-4 bottom-4 size-10 bg-primary hover:bg-primary-glow text-white rounded-xl shadow-neon-sm transition-all flex items-center justify-center group-focus-within:scale-110 active:scale-95"
                                        >
                                            <span className="material-symbols-outlined text-[20px]">send</span>
                                        </button>
                                    </form>
                                    <p className="mt-3 text-[9px] text-center text-slate-500 uppercase font-black tracking-widest opacity-50">Secure multi-layer encrypted channel</p>
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                {/* New Ticket Modal */}
                {isNewTicketModalOpen && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300">
                        <div className="glass-panel w-full max-w-lg rounded-3xl p-8 border border-white/10 bg-[#0f0f13] shadow-2xl scale-in-95 animate-in duration-300">
                            <div className="flex justify-between items-center mb-8">
                                <div className="flex items-center gap-3">
                                    <div className="size-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                                        <span className="material-symbols-outlined font-bold">add_task</span>
                                    </div>
                                    <h3 className="text-xl font-black text-white uppercase tracking-tighter">Initialize Support Ticket</h3>
                                </div>
                                <button onClick={() => setIsNewTicketModalOpen(false)} className="text-slate-500 hover:text-white transition-colors">
                                    <span className="material-symbols-outlined">close</span>
                                </button>
                            </div>

                            <form onSubmit={handleSubmitTicket} className="space-y-6">
                                <div className="grid grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Subject Matter</label>
                                        <input 
                                            type="text" 
                                            required 
                                            value={newTicket.subject} 
                                            onChange={e => setNewTicket({...newTicket, subject: e.target.value})}
                                            className="w-full bg-black/40 border border-white/10 rounded-xl px-5 py-3 text-sm text-white focus:border-primary/50 outline-none transition-all font-mono" 
                                            placeholder="e.g. License Sync Error" 
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Department</label>
                                        <select 
                                            value={newTicket.category}
                                            onChange={e => setNewTicket({...newTicket, category: e.target.value})}
                                            className="w-full bg-black/40 border border-white/10 rounded-xl px-5 py-3 text-sm text-white focus:border-primary/50 outline-none transition-all font-mono appearance-none"
                                        >
                                            <option value="general">General Support</option>
                                            <option value="billing">Billing / Account</option>
                                            <option value="technical">Technical Dept</option>
                                            <option value="report">Integrity Report</option>
                                        </select>
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Detailed Logs/Information</label>
                                    <textarea 
                                        required 
                                        value={newTicket.message}
                                        onChange={e => setNewTicket({...newTicket, message: e.target.value})}
                                        className="w-full bg-black/40 border border-white/10 rounded-xl px-5 py-4 text-sm text-white focus:border-primary/50 outline-none transition-all resize-none font-mono" 
                                        rows="6" 
                                        placeholder="Detailed description of your inquiry..."
                                    ></textarea>
                                </div>

                                <div className="p-4 rounded-xl bg-primary/5 border border-primary/10 flex gap-4">
                                    <span className="material-symbols-outlined text-primary text-[20px]">info</span>
                                    <p className="text-[9px] text-slate-400 font-black uppercase leading-relaxed tracking-widest">A dedicated agent will be assigned to your case shortly after submission.</p>
                                </div>

                                <div className="flex gap-4 pt-4">
                                    <button type="button" onClick={() => setIsNewTicketModalOpen(false)} className="flex-1 py-4 bg-white/5 text-white text-[10px] font-black rounded-xl uppercase tracking-widest hover:bg-white/10 transition-all border border-white/5">Cancel</button>
                                    <button type="submit" className="flex-[2] py-4 bg-primary text-white text-[10px] font-black rounded-xl uppercase tracking-widest shadow-neon-sm hover:bg-primary/90 transition-all flex items-center justify-center gap-2">
                                        <span className="material-symbols-outlined text-[18px]">rocket_launch</span>
                                        Dispatch Ticket
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}
        </div>
    );
};

export default Support;
