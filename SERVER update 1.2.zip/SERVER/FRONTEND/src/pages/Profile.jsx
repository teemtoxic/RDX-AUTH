import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const Profile = () => {
    const [user, setUser] = useState(null);
    const [hwidApp, setHwidApp] = useState('');
    const [hwidReason, setHwidReason] = useState('');
    const [hwidHistory, setHwidHistory] = useState([]);
    const [apps, setApps] = useState([]);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editForm, setEditForm] = useState({ username: '', email: '' });
    const [isProcessing, setIsProcessing] = useState(false);
    
    const token = localStorage.getItem('rdx_token');

    useEffect(() => {
        fetchProfile();
        fetchApps();
        fetchHwidHistory();
    }, []);

    const fetchProfile = async () => {
        try {
            const res = await fetch('/rdx/api/auth/me', { headers: { 'Authorization': `Bearer ${token}` } });
            const data = await res.json();
            if (data.success) {
                // Backend flattens user data into root payload via responseHelper
                setUser(data);
                setEditForm({
                    username: data.username || '',
                    email: data.email || ''
                });
            }
        } catch (e) { console.error(e); }
    };

    const fetchApps = async () => {
        try {
            const res = await fetch('/rdx/api/apps', { headers: { 'Authorization': `Bearer ${token}` } });
            const data = await res.json();
            if (data.success) setApps(data.apps || []);
        } catch (e) { console.error(e); }
    };

    const fetchHwidHistory = async () => {
        try {
            const res = await fetch('/rdx/api/hwid-reset/my-requests', { headers: { 'Authorization': `Bearer ${token}` } });
            const data = await res.json();
            if (data.success) setHwidHistory(data.requests || []);
        } catch (e) { console.error(e); }
    };

    const handleHwidReset = async (e) => {
        e.preventDefault();
        if (!hwidApp || !hwidReason) return;
        setIsProcessing(true);
        try {
            const res = await fetch('/rdx/api/hwid-reset/request', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ app_id: hwidApp, reason: hwidReason })
            });
            const data = await res.json();
            if (data.success) {
                setHwidReason('');
                setHwidApp('');
                fetchHwidHistory();
                alert('Reset request submitted successfully!');
            } else {
                alert(data.message || 'Failed to submit request');
            }
        } catch (e) { console.error(e); }
        finally { setIsProcessing(false); }
    };

    const handleUpdateProfile = async (e) => {
        e.preventDefault();
        setIsProcessing(true);
        try {
            const res = await fetch('/rdx/api/auth/update-profile', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(editForm)
            });
            const data = await res.json();
            if (data.success) {
                await fetchProfile();
                setIsEditModalOpen(false);
                alert('Profile updated successfully!');
            } else {
                alert(data.message || 'Update failed');
            }
        } catch (e) { console.error(e); }
        finally { setIsProcessing(false); }
    };

    const handleDeleteAccount = async () => {
        if (!window.confirm('WARNING: This operation is irreversible. All associated data will be purged. Proceed?')) return;
        
        try {
            const res = await fetch('/rdx/api/auth/delete-account', {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                localStorage.removeItem('rdx_token');
                window.location.href = '/login';
            } else {
                alert(data.message || 'Deletion failed');
            }
        } catch (e) { console.error(e); }
    };

    if (!user) return (
        <div className="p-8 text-white font-black uppercase tracking-widest animate-pulse flex items-center justify-center h-full gap-3">
            <span className="material-symbols-outlined animate-spin text-primary">sync</span> 
            Synchronizing Mainframe...
        </div>
    );

    return (
        <div className="flex-1 overflow-y-auto p-6 lg:p-8 scroll-smooth section-container">
            <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-5xl mx-auto space-y-8"
            >
                {/* Header */}
                <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-primary/5 flex flex-col md:flex-row items-center justify-between gap-4 mb-8">
                    <div>
                        <h2 className="text-3xl font-bold text-white uppercase tracking-tighter">User Profile</h2>
                        <p className="text-slate-400">Manage your account settings and view usage statistics.</p>
                    </div>
                    <button 
                        onClick={() => setIsEditModalOpen(true)}
                        className="px-6 py-3 bg-primary hover:bg-primary-dark text-white text-xs font-bold rounded-xl border border-primary/20 transition-all shadow-neon flex items-center gap-2 uppercase tracking-wider"
                    >
                        <span className="material-symbols-outlined text-[18px]">edit_note</span>
                        Update Profile
                    </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* User Details Card */}
                    <div className="md:col-span-2 glass-panel p-8 rounded-xl border border-white/5 relative overflow-hidden group">
                        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-6 relative z-10">
                            <div className="flex items-center gap-6">
                                <div className="size-24 bg-gradient-to-br from-primary to-blue-600 rounded-2xl flex items-center justify-center text-4xl font-bold text-white shadow-lg border-4 border-slate-900 overflow-hidden">
                                    {user.username?.substring(0, 2).toUpperCase() || '--'}
                                </div>
                                <div>
                                    <h3 className="text-3xl font-bold text-white uppercase tracking-tight">{user.username}</h3>
                                    <div className="flex items-center gap-3 mt-1">
                                        <p className="text-slate-400 font-mono text-sm">{user.email || 'No email set'}</p>
                                        <span className="size-1 bg-slate-700 rounded-full"></span>
                                        <p className="text-primary font-bold text-xs uppercase tracking-widest">{user.role || 'User'}</p>
                                    </div>
                                </div>
                            </div>
                            <span className="px-3 py-1 bg-green-500/10 text-green-400 border border-green-500/20 rounded-full text-[10px] font-black uppercase tracking-widest">Active Status</span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 relative z-10">
                            <div className="p-4 bg-slate-950/40 rounded-xl border border-white/5 flex flex-col justify-center">
                                <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-1">Account ID</p>
                                <p className="text-white font-mono text-sm">#{user.id}</p>
                            </div>
                            <div className="p-4 bg-slate-950/40 rounded-xl border border-white/5 flex flex-col justify-center">
                                <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-1">Member Since</p>
                                <p className="text-white font-mono text-sm">{user.created_at ? new Date(user.created_at).toLocaleDateString() : '---'}</p>
                            </div>
                        </div>
                    </div>

                    {/* Subscription Status */}
                    <div className="glass-panel p-6 rounded-xl border border-white/5 flex flex-col justify-between relative overflow-hidden group">
                        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                        <div className="relative z-10 flex flex-col h-full">
                            <div className="size-12 bg-accent/20 rounded-lg flex items-center justify-center mb-4 text-accent border border-accent/20">
                                <span className="material-symbols-outlined text-2xl">diamond</span>
                            </div>
                            <h4 className="text-lg font-bold text-white mb-1 uppercase tracking-tighter">Subscription</h4>
                            <p className="text-xs text-slate-500 mb-6 uppercase tracking-widest">Current Plan Status</p>

                            <div className="space-y-4 flex-1">
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-slate-500 font-bold uppercase text-[10px] tracking-widest">Active Plan</span>
                                    <span className="text-white font-bold px-3 py-1 bg-accent/10 border border-accent/20 rounded text-[10px] uppercase">
                                        {user.subscription?.type || user.plan || 'Starter'}
                                    </span>
                                </div>
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-slate-500 font-bold uppercase text-[10px] tracking-widest">Expiration</span>
                                    <span className="text-white font-mono text-[10px] uppercase">
                                        {user.subscription?.expiry ? new Date(user.subscription.expiry).toLocaleDateString() : 'Never/Lifetime'}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Usage Statistics */}
                <div className="space-y-4">
                    <h3 className="text-xl font-bold text-white flex items-center gap-3 uppercase tracking-tighter">
                        <span className="material-symbols-outlined text-primary text-2xl">analytics</span>
                        Infrastructure Metrics
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                        <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-white/[0.02] relative group overflow-hidden">
                            <div className="absolute -right-4 -bottom-4 opacity-5 group-hover:opacity-10 transition-opacity">
                                <span className="material-symbols-outlined text-7xl text-primary font-black">apps</span>
                            </div>
                            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 relative z-10">Managed Apps</p>
                            <div className="flex items-end justify-between relative z-10">
                                <h4 className="text-4xl font-black text-white">{user.stats?.apps || 0}</h4>
                                <span className="text-primary material-symbols-outlined text-3xl">apps</span>
                            </div>
                        </div>
                        <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-white/[0.02] relative group overflow-hidden">
                            <div className="absolute -right-4 -bottom-4 opacity-5 group-hover:opacity-10 transition-opacity">
                                <span className="material-symbols-outlined text-7xl text-accent font-black">key</span>
                            </div>
                            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 relative z-10">Active Licenses</p>
                            <div className="flex items-end justify-between relative z-10">
                                <h4 className="text-4xl font-black text-white">{user.stats?.keys || 0}</h4>
                                <span className="text-accent material-symbols-outlined text-3xl">key</span>
                            </div>
                        </div>
                        <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-white/[0.02] relative group overflow-hidden">
                            <div className="absolute -right-4 -bottom-4 opacity-5 group-hover:opacity-10 transition-opacity">
                                <span className="material-symbols-outlined text-7xl text-green-400 font-black">bolt</span>
                            </div>
                            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 relative z-10">Total API Hits</p>
                            <div className="flex items-end justify-between relative z-10">
                                <h4 className="text-4xl font-black text-white">{user.stats?.hits || 0}</h4>
                                <span className="text-green-400 material-symbols-outlined text-3xl">bolt</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Security & Activity */}
                <div className="space-y-4">
                    <h3 className="text-xl font-bold text-white flex items-center gap-3 uppercase tracking-tighter">
                        <span className="material-symbols-outlined text-primary text-2xl">security</span>
                        Security Protocols
                    </h3>
                    <div className="glass-panel rounded-2xl border border-white/5 overflow-hidden bg-white/[0.01]">
                        <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-white/5">
                            <div className="p-6 flex items-center gap-6 hover:bg-white/[0.02] transition-colors">
                                <div className="size-14 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-400 border border-blue-500/10">
                                    <span className="material-symbols-outlined text-2xl">login</span>
                                </div>
                                <div className="space-y-1">
                                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Last Access Sequence</p>
                                    <p className="text-white font-mono text-xs">{user.security?.last_login ? new Date(user.security.last_login).toLocaleString() : 'UNDEFINED'}</p>
                                </div>
                            </div>
                            <div className="p-6 flex items-center gap-6 hover:bg-white/[0.02] transition-colors">
                                <div className="size-14 rounded-2xl bg-purple-500/10 flex items-center justify-center text-purple-400 border border-purple-500/10">
                                    <span className="material-symbols-outlined text-2xl">public</span>
                                </div>
                                <div className="space-y-1">
                                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Authorized Source IP</p>
                                    <p className="text-white font-mono text-sm tracking-tight">{user.security?.last_ip || '0.0.0.0'}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Hardware Reset Section */}
                <div className="glass-panel p-8 rounded-xl border border-white/5 relative overflow-hidden group">
                    <div className="flex items-center gap-4 mb-6">
                        <div className="size-12 rounded-xl bg-primary/20 border border-primary/20 flex items-center justify-center text-primary shadow-neon-sm">
                            <span className="material-symbols-outlined">restart_alt</span>
                        </div>
                        <div>
                            <h3 className="text-xl font-bold text-white uppercase tracking-tighter">Hardware Reset Request</h3>
                            <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest opacity-80 mt-1">Submit a request to clear your hardware lock for specific applications.</p>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <form onSubmit={handleHwidReset} className="space-y-5">
                            <div>
                                <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-2 block">Application Infrastructure</label>
                                <select
                                    value={hwidApp}
                                    onChange={e => setHwidApp(e.target.value)}
                                    required
                                    className="w-full bg-slate-900/50 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-primary transition-all outline-none"
                                >
                                    <option value="">Select Target App</option>
                                    {apps.map(app => (
                                        <option key={app.id} value={app.id}>{app.name}</option>
                                    ))}
                                </select>
                            </div>
                            <div>
                                <label className="text-[10px] text-slate-500 font-black uppercase tracking-widest mb-2 block">Reason for Reset</label>
                                <textarea
                                    value={hwidReason}
                                    onChange={e => setHwidReason(e.target.value)}
                                    required
                                    rows="3"
                                    className="w-full bg-slate-900/50 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-primary transition-all outline-none resize-none"
                                    placeholder="Device change, OS reinstallation, security update..."
                                ></textarea>
                            </div>
                            <button 
                                type="submit" 
                                disabled={isProcessing}
                                className="w-full py-4 bg-primary hover:bg-primary-dark text-white text-[10px] font-black rounded-xl transition-all shadow-neon uppercase tracking-[0.2em] flex items-center justify-center gap-2 disabled:opacity-50"
                            >
                                <span className={`material-symbols-outlined text-[18px] ${isProcessing ? 'animate-spin' : ''}`}>
                                    {isProcessing ? 'sync' : 'send'}
                                </span>
                                {isProcessing ? 'Processing...' : 'Submit Reset Request'}
                            </button>
                        </form>

                        <div className="bg-black/20 rounded-2xl border border-white/5 p-6 flex flex-col">
                            <div className="flex items-center justify-between mb-4">
                                <h4 className="text-[10px] text-slate-500 font-black uppercase tracking-widest">Protocol Reset History</h4>
                                <span className="px-2 py-0.5 bg-white/5 rounded text-[8px] text-slate-600 font-mono font-black uppercase tracking-tighter">LATEST ENTRIES</span>
                            </div>
                            <div className="flex-1 space-y-3 overflow-y-auto max-h-[220px] pr-2 custom-scrollbar">
                                {hwidHistory.length > 0 ? (
                                    hwidHistory.map(req => (
                                        <div key={req.id} className="p-3 bg-white/[0.02] border border-white/5 rounded-xl text-xs flex flex-col gap-1 hover:border-white/10 transition-colors">
                                            <div className="flex justify-between items-center">
                                                <span className="font-black text-white uppercase tracking-tight">{req.app_name}</span>
                                                <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase border ${
                                                    req.status === 'approved' ? 'bg-green-500/10 text-green-500 border-green-500/20' : 
                                                    req.status === 'rejected' ? 'bg-red-500/10 text-red-500 border-red-500/20' : 
                                                    'bg-yellow-500/10 text-yellow-500 border-yellow-500/20'
                                                }`}>
                                                    {req.status}
                                                </span>
                                            </div>
                                            <span className="text-[10px] text-slate-500 italic opacity-70 break-words">"{req.reason}"</span>
                                            <p className="text-[8px] text-slate-600 font-mono mt-1">{new Date(req.created_at).toLocaleString()}</p>
                                        </div>
                                    ))
                                ) : (
                                    <div className="flex flex-col items-center justify-center h-full text-slate-600 opacity-30 space-y-2 py-12">
                                        <span className="material-symbols-outlined text-4xl">history</span>
                                        <p className="text-[9px] font-black uppercase tracking-widest text-center">No structural history found</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Danger Zone */}
                <div className="space-y-4">
                    <h3 className="text-xl font-bold text-red-500 flex items-center gap-3 uppercase tracking-tighter">
                        <span className="material-symbols-outlined text-2xl">warning</span>
                        Termination Zone
                    </h3>
                    <div className="glass-panel p-6 rounded-2xl border border-red-500/20 bg-red-500/5">
                        <div className="flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
                            <div>
                                <h4 className="text-white font-bold mb-1 uppercase tracking-tight">Delete Account Protocol</h4>
                                <p className="text-xs text-slate-400 max-w-md uppercase tracking-widest opacity-70 text-[10px] leading-relaxed">
                                    Once you delete your account, there is no going back. All your data, including application settings and license keys, will be permanently removed.
                                </p>
                            </div>
                            <button 
                                onClick={handleDeleteAccount}
                                className="px-8 py-4 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white border border-red-500/20 font-black rounded-xl transition-all shadow-[0_0_20px_rgba(239,68,68,0.1)] text-[10px] uppercase tracking-[0.2em]"
                            >
                                Purge Identity
                            </button>
                        </div>
                    </div>
                </div>
            </motion.div>

            {/* Edit Profile Modal */}
            <AnimatePresence>
                {isEditModalOpen && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                        <motion.div 
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            onClick={() => setIsEditModalOpen(false)}
                            className="absolute inset-0 bg-background-dark/80 backdrop-blur-sm"
                        ></motion.div>
                        <motion.div 
                            initial={{ scale: 0.95, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.95, opacity: 0 }}
                            className="glass-panel w-full max-w-md rounded-2xl p-8 border-primary/20 relative z-10 bg-[#0d1117]/95"
                            style={{ border: '1px solid rgba(140, 37, 244, 0.2)' }}
                        >
                            <div className="flex justify-between items-center mb-6">
                                <h3 className="text-xl font-bold text-white flex items-center gap-2 uppercase tracking-tighter">
                                    <span className="material-symbols-outlined text-primary">manage_accounts</span>
                                    Edit Profile
                                </h3>
                                <button 
                                    onClick={() => setIsEditModalOpen(false)}
                                    className="text-slate-500 hover:text-white transition-colors"
                                >
                                    <span className="material-symbols-outlined">close</span>
                                </button>
                            </div>

                            <form onSubmit={handleUpdateProfile} className="space-y-4">
                                <div>
                                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Username Identity</label>
                                    <input 
                                        type="text" 
                                        value={editForm.username}
                                        onChange={e => setEditForm({...editForm, username: e.target.value})}
                                        required
                                        className="w-full bg-slate-900 border border-white/5 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 transition-colors text-sm"
                                    />
                                </div>
                                <div>
                                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Email Address</label>
                                    <input 
                                        type="email" 
                                        value={editForm.email}
                                        onChange={e => setEditForm({...editForm, email: e.target.value})}
                                        required
                                        className="w-full bg-slate-900 border border-white/5 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 transition-colors text-sm"
                                    />
                                </div>
                                <button 
                                    type="submit"
                                    disabled={isProcessing}
                                    className="w-full py-4 bg-primary hover:bg-primary/90 text-white font-black rounded-xl transition-all shadow-neon mt-4 flex items-center justify-center gap-2 uppercase tracking-widest text-[10px] disabled:opacity-50"
                                >
                                    <span className={`material-symbols-outlined text-[20px] ${isProcessing ? 'animate-spin' : ''}`}>
                                        {isProcessing ? 'sync' : 'check_circle'}
                                    </span>
                                    {isProcessing ? 'Confirming...' : 'Save Profile Changes'}
                                </button>
                                <p className="text-[9px] text-center text-slate-500 mt-4 leading-relaxed uppercase tracking-wider opacity-60">
                                    Note: Changing your username may affect some SDK integrations if you use username-based auth.
                                </p>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default Profile;
