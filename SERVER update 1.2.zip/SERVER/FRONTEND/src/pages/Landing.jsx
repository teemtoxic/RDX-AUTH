import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/shared/Navbar';
const Landing = () => {
    const navigate = useNavigate();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [userContextId, setUserContextId] = useState(null);
    const [genResult, setGenResult] = useState({ show: false, link: '' });
    const [isGenerating, setIsGenerating] = useState(false);

    useEffect(() => {
        const token = localStorage.getItem('rdx_token');
        if (token) {
            fetch('/rdx/api/auth/me', {
                headers: { 'Authorization': 'Bearer ' + token }
            })
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.user) {
                        setUserContextId(data.user.id);
                    }
                })
                .catch(e => console.error('[RDX Hub] Auth sync failed', e));
        }

        const fp = btoa(navigator.userAgent + window.screen.width + window.screen.height + navigator.language);
        localStorage.setItem('rdx_fp', fp);
    }, []);

    const handleActionClick = (e, customDest = null) => {
        if (customDest) {
            navigate(customDest);
            return;
        }
        
        let target = e.currentTarget;
        let originalOnClick = target.getAttribute('data-onclick') || '';

        if (originalOnClick.includes('window.location.href')) {
            const match = originalOnClick.match(/window\.location\.href\s*=\s*['"](.*?)['"]/);
            if (match && match[1]) {
                const dest = match[1];
                if (dest.includes('/security-check')) {
                    window.location.href = dest;
                } else if (dest.startsWith('/')) {
                    navigate(dest);
                } else {
                    window.location.href = dest;
                }
            }
        }
    };

    const generateAccessLink = async () => {
        setIsGenerating(true);
        try {
            const res = await fetch('/api/generate-link', { method: 'POST' });
            const data = await res.json();
            if (data.success && data.linkco_url) {
                setGenResult({ show: true, link: data.linkco_url });
            } else {
                alert('Error: ' + (data.message || 'Server busy.'));
            }
        } catch (err) {
            alert('Connection error.');
        } finally {
            setIsGenerating(false);
        }
    };

    const copyGeneratedLink = () => {
        navigator.clipboard.writeText(genResult.link);
        alert('Access Link copied to clipboard!');
    };

    return (
        <div className="bg-background-dark text-white font-display overflow-x-hidden selection:bg-primary selection:text-white min-h-screen">

            <div className="fixed inset-0 z-0 pointer-events-none">
                <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-primary/10 rounded-full blur-[120px]"></div>
                <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-secondary/10 rounded-full blur-[120px]">
                </div>
                <div className="absolute inset-0 bg-grid-pattern bg-grid opacity-[0.05]"></div>
            </div>
            <Navbar userContextId={userContextId} />
            <main className="relative z-10 flex flex-col items-center w-full">
                <section
                    className="min-h-screen flex flex-col items-center justify-center w-full max-w-7xl px-6 pt-32 pb-20 relative">
                    <div className="grid lg:grid-cols-2 gap-16 items-center w-full">
                        <div className="flex flex-col gap-8 text-left max-w-2xl z-10">
                            <div
                                className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary/10 border border-secondary/20 w-fit backdrop-blur-sm">
                                <span className="w-2 h-2 rounded-full bg-secondary animate-pulse"></span>
                                <span className="text-xs font-medium text-secondary uppercase tracking-wider">RDX v3.0 Enterprise
                                    Ready</span>
                            </div>
                            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.1] tracking-tight">
                                Secure Your Future <br />
                                with <span className="text-gradient text-shadow-glow">RDX Auth</span>
                            </h1>
                            <p className="text-lg text-gray-400 leading-relaxed max-w-xl">
                                The definitive authentication standard for high-performance software. Enterprise-grade
                                protection, real-time analytics, and seamless integration for modern applications.
                            </p>
                            <ul className="space-y-4 text-gray-300 font-light">
                                <li className="flex items-center gap-3">
                                    <span className="material-symbols-outlined text-secondary">check_circle</span>
                                    <span>Advanced HWID Fingerprinting Technology</span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <span className="material-symbols-outlined text-secondary">check_circle</span>
                                    <span>Encrypted TCP/IP Socket Connection</span>
                                </li>
                                <li className="flex items-center gap-3">
                                    <span className="material-symbols-outlined text-secondary">check_circle</span>
                                    <span>99.9% Uptime SLA Guarantee</span>
                                </li>
                            </ul>
                            <div className="flex flex-wrap gap-4 pt-6">
                                <button onClick={handleActionClick} data-onclick="window.location.href='/security-check?next=/login'"
                                    className="bg-primary text-white text-base font-bold h-12 px-8 rounded-lg transition-all duration-300 shadow-neon hover:shadow-neon hover:-translate-y-0.5 flex items-center gap-2">
                                    <span>Initialize RDX</span>
                                    <span className="material-symbols-outlined text-sm">terminal</span>
                                </button>
                                <button id="gen-btn" onClick={() => navigate('/pricing')}
                                    className="bg-secondary/10 hover:bg-secondary/20 text-secondary text-base font-bold h-12 px-8 rounded-lg border border-secondary/30 transition-all duration-300 flex items-center gap-2 group shadow-neon-blue/20 hover:shadow-neon-blue">
                                    <span
                                        className="material-symbols-outlined group-hover:rotate-12 transition-transform">bolt</span>
                                    <span>GET ACCESS KEY</span>
                                </button>
                            </div>

                            {/* Generate Result */}
                            <div id="gen-result" className="hidden mt-6 animate-in fade-in slide-in-from-top-4 duration-500">
                                <div
                                    className="glass p-4 rounded-xl border border-secondary/30 flex items-center justify-between gap-4">
                                    <div className="flex-grow min-w-0">
                                        <div className="text-[10px] text-secondary font-bold uppercase tracking-wider mb-1">Session
                                            Link Ready</div>
                                        <input id="link-display" readonly type="text"
                                            className="w-full bg-black/40 border border-white/5 rounded-lg px-3 py-2 text-xs font-mono text-gray-300 focus:outline-none"
                                            value="" />
                                    </div>
                                    <div className="flex gap-2">
                                        <button onClick={handleActionClick} data-onclick="copyGeneratedLink()"
                                            className="p-2 hover:bg-white/5 rounded-lg text-gray-400 hover:text-white transition-colors">
                                            <span className="material-symbols-outlined text-sm">content_copy</span>
                                        </button>
                                        <a id="link-anchor" href="#" target="_blank"
                                            className="p-2 bg-secondary/20 hover:bg-secondary/30 rounded-lg text-secondary border border-secondary/30 transition-all">
                                            <span className="material-symbols-outlined text-sm">open_in_new</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="relative w-full flex items-center justify-center">
                            <div
                                className="absolute inset-0 bg-gradient-to-r from-primary/30 to-secondary/30 rounded-full blur-[100px] transform opacity-40">
                            </div>
                            <div
                                className="relative w-full rounded-xl border border-white/10 bg-[#0B0B12]/90 backdrop-blur-xl shadow-2xl overflow-hidden group hover:border-primary/50 transition-colors duration-500 animate-float">
                                <div
                                    className="flex items-center justify-between px-6 py-4 border-b border-white/5 bg-white/[0.02]">
                                    <div className="flex gap-2">
                                        <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
                                        <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
                                        <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
                                    </div>
                                    <div className="text-xs text-gray-500 font-mono flex items-center gap-2">
                                        <span className="material-symbols-outlined text-sm">lock</span>
                                        secure_login.cpp
                                    </div>
                                </div>
                                <div className="p-6 md:p-8 overflow-x-auto font-mono text-sm md:text-base leading-relaxed">
                                    <div className="flex mb-4 text-gray-500 text-xs select-none border-b border-white/5 pb-2">
                                        <span className="mr-4">Ln 1, Col 1</span>
                                        <span className="mr-4">UTF-8</span>
                                        <span className="text-secondary">RDX SDK Loaded</span>
                                    </div>
                                    <pre dangerouslySetInnerHTML={{
                                        __html: `<code class="language-cpp"><span class="text-neon-purple">#include</span> <span class="text-green-400">&lt;RDX_Auth.h&gt;</span>
<span class="text-gray-500">// Initialize Secure Session</span>
<span class="text-blue-400">auto</span> session = <span class="text-neon-blue">RDX::Initialize</span>({
    .app_id = <span class="text-orange-300">"8821-AFX-22"</span>,
    .secret = <span class="text-orange-300">"****************"</span>,
    .version = <span class="text-orange-300">"3.0.1"</span>
});
<span class="text-blue-400">if</span> (!session.<span class="text-yellow-300">ValidateIntegrity</span>()) {
    <span class="text-neon-purple">RDX::Panic</span>(<span class="text-orange-300">"Tamper Detected!"</span>);
    <span class="text-blue-400">return</span> -1;
}
<span class="text-gray-500">// Authenticate User Hardware</span>
<span class="text-blue-400">bool</span> auth = session.<span class="text-yellow-300">Login</span>(username, password);
<span class="text-blue-400">if</span> (auth) {
    <span class="text-green-400">std::cout</span> &lt;&lt; <span class="text-orange-300">"RDX Access Granted."</span>;
    <span class="text-neon-blue">LaunchApplication();</span>
}</code>`}}></pre>
                                </div>
                                <div
                                    className="bg-primary/5 px-6 py-2 border-t border-white/5 flex justify-between items-center text-xs font-mono">
                                    <span className="text-gray-400">Status: <span
                                        className="text-green-400 animate-pulse">Connected</span></span>
                                    <span className="text-gray-500">Latency: 14ms</span>
                                </div>
                            </div>
                            <div className="absolute -right-4 -bottom-4 bg-background-card border border-white/10 p-4 rounded-xl shadow-neon-blue hidden md:block animate-float"
                                style={{ "animationDelay": "1s" }}>
                                <div className="flex items-center gap-3">
                                    <div
                                        className="w-10 h-10 rounded-full bg-secondary/20 flex items-center justify-center text-secondary">
                                        <span className="material-symbols-outlined">shield</span>
                                    </div>
                                    <div>
                                        <div className="text-sm font-bold text-white">Protection Active</div>
                                        <div className="text-xs text-gray-400">AES-256 Encryption</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="w-full border-y border-white/5 bg-white/[0.02] backdrop-blur-sm relative overflow-hidden">
                    <div
                        className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-secondary/50 to-transparent">
                    </div>
                    <div className="max-w-7xl mx-auto px-6 py-12">
                        <div
                            className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center divide-y md:divide-y-0 md:divide-x divide-white/10">
                            <div className="flex flex-col items-center gap-2 px-4">
                                <span
                                    className="text-4xl lg:text-5xl font-bold text-white tracking-tighter tabular-nums text-shadow-glow">5M+</span>
                                <span className="text-sm font-medium text-gray-400 uppercase tracking-widest">Secured
                                    Sessions</span>
                            </div>
                            <div className="flex flex-col items-center gap-2 px-4 pt-8 md:pt-0">
                                <span
                                    className="text-4xl lg:text-5xl font-bold text-white tracking-tighter tabular-nums text-shadow-glow">25k+</span>
                                <span className="text-sm font-medium text-gray-400 uppercase tracking-widest">Active
                                    Applications</span>
                            </div>
                            <div className="flex flex-col items-center gap-2 px-4 pt-8 md:pt-0">
                                <span
                                    className="text-4xl lg:text-5xl font-bold text-secondary tracking-tighter tabular-nums text-shadow-glow-secondary">99.99%</span>
                                <span className="text-sm font-medium text-gray-400 uppercase tracking-widest">RDX Server
                                    Uptime</span>
                            </div>
                        </div>
                    </div>
                    <div
                        className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-primary/50 to-transparent">
                    </div>
                </section>
                <section id="features" className="w-full max-w-7xl px-6 py-24 relative">
                    <div className="text-center mb-16 space-y-4">
                        <h2 className="text-3xl md:text-5xl font-bold">Uncompromising <span className="text-gradient">Power &
                            Security</span></h2>
                        <p className="text-gray-400 max-w-2xl mx-auto text-lg">Experience the ultimate Authentication platform. We
                            provide Top-Tier Security, AI Automation, and Unlimited flexibility—even on the Free plan.</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {/* Feature 1: Server-Side Auth */}
                        <div
                            className="group relative p-1 rounded-xl bg-gradient-to-b from-white/10 to-transparent hover:from-primary hover:to-primary/20 transition-all duration-300">
                            <div
                                className="absolute inset-0 bg-primary/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-xl">
                            </div>
                            <div
                                className="relative h-full bg-background-card rounded-lg p-8 border border-white/5 flex flex-col gap-4 overflow-hidden">
                                <div
                                    className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-2 group-hover:scale-110 transition-transform duration-300">
                                    <span className="material-symbols-outlined text-3xl">lock</span>
                                </div>
                                <h3 className="text-xl font-bold text-white">100% Secure Server-Auth</h3>
                                <p className="text-gray-400 leading-relaxed">Mathematically uncrackable. Features HMAC SHA-256
                                    signatures, timestamp anti-replay validation, and advanced 4-tier deep HWID locking (CPU,
                                    Baseboard, MAC). No compromises for Free or Pro tiers.</p>
                                <div
                                    className="mt-auto pt-6 flex justify-center opacity-50 group-hover:opacity-100 transition-opacity">
                                    <div className="w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent"></div>
                                </div>
                            </div>
                        </div>

                        {/* Feature 2: Generous Free Tier */}
                        <div
                            className="group relative p-1 rounded-xl bg-gradient-to-b from-white/10 to-transparent hover:from-secondary hover:to-secondary/20 transition-all duration-300">
                            <div
                                className="absolute inset-0 bg-secondary/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-xl">
                            </div>
                            <div
                                className="relative h-full bg-background-card rounded-lg p-8 border border-white/5 flex flex-col gap-4 overflow-hidden">
                                <div
                                    className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center text-secondary mb-2 group-hover:scale-110 transition-transform duration-300">
                                    <span className="material-symbols-outlined text-3xl">volunteer_activism</span>
                                </div>
                                <h3 className="text-xl font-bold text-white">Unbeatable Free Tier</h3>
                                <p className="text-gray-400 leading-relaxed">Tired of KeyAuth limits? Why pay for basic features?
                                    RDX offers up to <strong>5
                                        Apps</strong>, <strong>Unlimited Keys</strong>, <strong>Unlimited Users</strong>, and
                                    full access to our remote variable system entirely for free. We never put your security
                                    behind a
                                    paywall.</p>
                                <div
                                    className="mt-auto pt-6 flex justify-center opacity-50 group-hover:opacity-100 transition-opacity">
                                    <div className="w-full h-1 bg-gradient-to-r from-transparent via-secondary to-transparent">
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Feature 3: AI Console */}
                        <div
                            className="group relative p-1 rounded-xl bg-gradient-to-b from-white/10 to-transparent hover:from-primary hover:to-primary/20 transition-all duration-300">
                            <div
                                className="absolute inset-0 bg-primary/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-xl">
                            </div>
                            <div
                                className="relative h-full bg-background-card rounded-lg p-8 border border-white/5 flex flex-col gap-4 overflow-hidden">
                                <div
                                    className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-2 group-hover:scale-110 transition-transform duration-300">
                                    <span className="material-symbols-outlined text-3xl">smart_toy</span>
                                </div>
                                <h3 className="text-xl font-bold text-white">AI Mainframe (Jarvis Mode)</h3>
                                <p className="text-gray-400 leading-relaxed">Built-in AI configuration that supports <strong>Voice
                                    Commands</strong> for complete PC automation. Control your dashboard, generate keys, and
                                    manage applications using natural language like Jarvis.</p>
                                <div
                                    className="mt-auto pt-6 flex justify-center opacity-50 group-hover:opacity-100 transition-opacity">
                                    <div className="w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent"></div>
                                </div>
                            </div>
                        </div>

                        {/* Feature 4: Remote Variables */}
                        <div
                            className="group relative p-1 rounded-xl bg-gradient-to-b from-white/10 to-transparent hover:from-secondary hover:to-secondary/20 transition-all duration-300">
                            <div
                                className="absolute inset-0 bg-secondary/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-xl">
                            </div>
                            <div
                                className="relative h-full bg-background-card rounded-lg p-8 border border-white/5 flex flex-col gap-4 overflow-hidden">
                                <div
                                    className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center text-secondary mb-2 group-hover:scale-110 transition-transform duration-300">
                                    <span className="material-symbols-outlined text-3xl">memory</span>
                                </div>
                                <h3 className="text-xl font-bold text-white">Free Remote Variables</h3>
                                <p className="text-gray-400 leading-relaxed">Dynamically stream memory offsets, feature flags, or
                                    strings straight from the dashboard to your C++ application without hardcoding them.
                                    Available to everyone.</p>
                                <div
                                    className="mt-auto pt-6 flex justify-center opacity-50 group-hover:opacity-100 transition-opacity">
                                    <div className="w-full h-1 bg-gradient-to-r from-transparent via-secondary to-transparent">
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Feature 5: Discord Bot */}
                        <div
                            className="group relative p-1 rounded-xl bg-gradient-to-b from-white/10 to-transparent hover:from-primary hover:to-primary/20 transition-all duration-300">
                            <div
                                className="absolute inset-0 bg-primary/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-xl">
                            </div>
                            <div
                                className="relative h-full bg-background-card rounded-lg p-8 border border-white/5 flex flex-col gap-4 overflow-hidden">
                                <div
                                    className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-2 group-hover:scale-110 transition-transform duration-300">
                                    <span className="material-symbols-outlined text-3xl">forum</span>
                                </div>
                                <h3 className="text-xl font-bold text-white">Full Discord Management</h3>
                                <p className="text-gray-400 leading-relaxed">Complete Discord integration. Sync logs, manage user
                                    roles, and fully automate your Discord server directly from your RDX dashboard. A truly
                                    seamless connection.</p>
                                <div
                                    className="mt-auto pt-6 flex justify-center opacity-50 group-hover:opacity-100 transition-opacity">
                                    <div className="w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent"></div>
                                </div>
                            </div>
                        </div>

                        {/* Feature 6: Security Hub */}
                        <div
                            className="group relative p-1 rounded-xl bg-gradient-to-b from-white/10 to-transparent hover:from-secondary hover:to-secondary/20 transition-all duration-300">
                            <div
                                className="absolute inset-0 bg-secondary/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-xl">
                            </div>
                            <div
                                className="relative h-full bg-background-card rounded-lg p-8 border border-white/5 flex flex-col gap-4 overflow-hidden">
                                <div
                                    className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center text-secondary mb-2 group-hover:scale-110 transition-transform duration-300">
                                    <span className="material-symbols-outlined text-3xl">security</span>
                                </div>
                                <h3 className="text-xl font-bold text-white">Security Hub & Monitoring</h3>
                                <p className="text-gray-400 leading-relaxed">Built-in DDoS protection, automated VPN/Proxy
                                    shielding, and real-time live traffic monitoring. Watch authentications and block threats as
                                    they happen.</p>
                                <div
                                    className="mt-auto pt-6 flex justify-center opacity-50 group-hover:opacity-100 transition-opacity">
                                    <div className="w-full h-1 bg-gradient-to-r from-transparent via-secondary to-transparent">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="w-full max-w-7xl px-6 py-10 relative">
                    <div className="relative group max-w-4xl mx-auto">
                        <div
                            className="absolute inset-0 bg-primary/20 blur-[80px] opacity-50 group-hover:opacity-100 transition-opacity">
                        </div>
                        <div className="glass p-8 rounded-3xl border-white/10 relative z-10 overflow-hidden shadow-2xl">
                            <h3 className="text-3xl font-bold mb-8 flex items-center justify-center gap-3 text-center">
                                <span className="material-symbols-outlined text-primary text-4xl">analytics</span>
                                Modern Security Comparison
                            </h3>
                            <div className="overflow-x-auto">
                                <table className="w-full text-left text-base">
                                    <thead className="text-gray-500 uppercase text-xs tracking-wider">
                                        <tr className="border-b border-white/10">
                                            <th className="pb-4 px-4 font-bold">Feature</th>
                                            <th className="pb-4 px-4 font-bold">KeyAuth &amp; Others</th>
                                            <th className="pb-4 px-4 text-primary font-bold">RDX Auth</th>
                                        </tr>
                                    </thead>
                                    <tbody className="text-gray-300 divide-y divide-white/5">
                                        <tr className="hover:bg-white/5 transition-colors">
                                            <td className="py-5 px-4 font-medium flex items-center gap-2"><span
                                                className="material-symbols-outlined text-sm text-gray-500">smart_toy</span> AI
                                                Command Control</td>
                                            <td className="py-5 px-4 text-gray-500">❌ None</td>
                                            <td className="py-5 px-4 text-primary font-bold">✅ Included (Mainframe)</td>
                                        </tr>
                                        <tr className="hover:bg-white/5 transition-colors">
                                            <td className="py-5 px-4 font-medium flex items-center gap-2"><span
                                                className="material-symbols-outlined text-sm text-gray-500">forum</span> Discord
                                                Management</td>
                                            <td className="py-5 px-4 text-gray-500">❌ Manual Only</td>
                                            <td className="py-5 px-4 text-primary font-bold">✅ Full Server Automation</td>
                                        </tr>
                                        <tr className="hover:bg-white/5 transition-colors">
                                            <td className="py-5 px-4 font-medium flex items-center gap-2"><span
                                                className="material-symbols-outlined text-sm text-gray-500">memory</span>
                                                Anti-Dump Protection</td>
                                            <td className="py-5 px-4 text-gray-500">Basic / Vulnerable</td>
                                            <td className="py-5 px-4 text-secondary font-bold">Encrypted Memory Stream</td>
                                        </tr>
                                        <tr className="hover:bg-white/5 transition-colors">
                                            <td className="py-5 px-4 font-medium flex items-center gap-2"><span
                                                className="material-symbols-outlined text-sm text-gray-500">volunteer_activism</span>
                                                Free Tier Limits</td>
                                            <td className="py-5 px-4 text-red-400">Restricted Users &amp; Keys</td>
                                            <td className="py-5 px-4 text-green-400 font-bold">Unlimited Users &amp; Keys</td>
                                        </tr>
                                        <tr className="hover:bg-white/5 transition-colors">
                                            <td className="py-5 px-4 font-medium flex items-center gap-2"><span
                                                className="material-symbols-outlined text-sm text-gray-500">cloud_sync</span>
                                                Server Variables</td>
                                            <td className="py-5 px-4 text-gray-500">Basic Text Only</td>
                                            <td className="py-5 px-4 text-primary font-bold">Unlimited Live Streaming</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="w-full max-w-7xl px-6 py-20 relative" id="pricing">
                    <div className="text-center mb-16 space-y-4">
                        <h2 className="text-3xl md:text-5xl font-bold">Flexible <span className="text-gradient-blue">Pricing
                            Plans</span></h2>
                        <p className="text-gray-400 max-w-2xl mx-auto text-lg">Choose the RDX package that fits your scaling needs.
                        </p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {/* Free Tier */}
                        <div className="relative group">
                            <div
                                className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent rounded-2xl blur-sm -z-10">
                            </div>
                            <div
                                className="glass h-full p-8 rounded-2xl border border-white/10 hover:border-white/30 transition-all duration-300 flex flex-col relative overflow-hidden">
                                <div
                                    className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-[50px] translate-x-10 -translate-y-10">
                                </div>
                                <h3 className="text-xl font-bold text-white mb-2">Starter</h3>
                                <div className="flex items-baseline gap-1 mb-6">
                                    <span className="text-4xl font-bold">Free</span>
                                    <span className="text-gray-500">/ forever</span>
                                </div>
                                <p className="text-gray-400 text-sm mb-8">Perfect for hobbyists and prototypes.</p>
                                <ul className="space-y-4 mb-8 text-sm text-gray-300 flex-grow">
                                    <li className="flex items-center gap-3"><span
                                        className="material-symbols-outlined text-green-400 text-base">check</span> 5
                                        Applications</li>
                                    <li className="flex items-center gap-3"><span
                                        className="material-symbols-outlined text-green-400 text-base">check</span> Unlimited
                                        Users & Keys</li>
                                    <li className="flex items-center gap-3"><span
                                        className="material-symbols-outlined text-green-400 text-base">check</span> Remote
                                        Variables</li>
                                </ul>
                                <button onClick={() => navigate('/pricing')}
                                    className="w-full py-3 rounded-lg border border-white/20 hover:bg-white/5 transition-colors font-medium">Get
                                    Started</button>
                            </div>
                        </div>

                        {/* Basic Tier */}
                        <div className="relative group transform md:-translate-y-4">
                            <div
                                className="absolute inset-0 bg-blue-500/20 rounded-2xl blur-md -z-10 group-hover:bg-blue-500/30 transition-colors duration-500">
                            </div>
                            <div
                                className="bg-[#12121a] h-full p-8 rounded-2xl border border-blue-500/50 shadow-neon-sm hover:shadow-neon-blue transition-all duration-300 flex flex-col relative overflow-hidden">
                                <div
                                    className="absolute top-0 right-0 w-40 h-40 bg-blue-500/20 rounded-full blur-[60px] translate-x-10 -translate-y-10">
                                </div>
                                <div className="flex justify-between items-start mb-2">
                                    <h3 className="text-xl font-bold text-white">Basic</h3>
                                    <span
                                        className="px-2 py-1 rounded bg-blue-500/20 text-blue-400 text-xs font-bold uppercase">Popular</span>
                                </div>
                                <div className="flex items-baseline gap-1 mb-6">
                                    <span className="text-4xl font-bold text-blue-400">₹50</span>
                                    <span className="text-gray-500">/month</span>
                                </div>
                                <p className="text-gray-400 text-sm mb-8">Essential tools for growing communities.</p>
                                <ul className="space-y-4 mb-8 text-sm text-gray-300 flex-grow">
                                    <li className="flex items-center gap-3"><span
                                        className="material-symbols-outlined text-blue-400 text-base">check</span> 10
                                        Applications</li>
                                    <li className="flex items-center gap-3"><span
                                        className="material-symbols-outlined text-slate-500 text-base">add</span> Everything in
                                        Starter</li>
                                    <li className="flex items-center gap-3"><span
                                        className="material-symbols-outlined text-blue-400 text-base">discord</span> Discord
                                        Manager (Soon)</li>
                                </ul>
                                <button 
                                    onClick={() => navigate('/pricing')}
                                    className="w-full py-3 rounded-lg bg-blue-600 hover:bg-blue-500 shadow-lg transition-all font-bold text-white">Subscribe
                                    Now</button>
                            </div>
                        </div>

                        {/* Pro Tier */}
                        <div className="relative group">
                            <div
                                className="absolute inset-0 bg-primary/10 rounded-2xl blur-sm -z-10 group-hover:bg-primary/20 transition-colors duration-500">
                            </div>
                            <div
                                className="glass h-full p-8 rounded-2xl border border-primary/30 hover:shadow-neon transition-all duration-300 flex flex-col relative overflow-hidden">
                                <div
                                    className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-[50px] translate-x-10 -translate-y-10">
                                </div>
                                <h3 className="text-xl font-bold text-white mb-2">Pro</h3>
                                <div className="flex items-baseline gap-1 mb-6">
                                    <span className="text-4xl font-bold text-primary">₹80</span>
                                    <span className="text-gray-500">/month</span>
                                </div>
                                <p className="text-gray-400 text-sm mb-8">Power user features and unlimited access.</p>
                                <ul className="space-y-4 mb-8 text-sm text-gray-300 flex-grow">
                                    <li className="flex items-center gap-3"><span
                                        className="material-symbols-outlined text-primary text-base">check</span> Unlimited
                                        Applications</li>
                                    <li className="flex items-center gap-3"><span
                                        className="material-symbols-outlined text-slate-500 text-base">add</span> Everything in
                                        Basic</li>
                                    <li className="flex items-center gap-3"><span
                                        className="material-symbols-outlined text-primary text-base">terminal</span> AI CMD
                                        Control (Soon)</li>
                                </ul>
                                <button onClick={() => navigate('/pricing')}
                                    className="w-full py-3 rounded-lg border border-primary/50 text-primary hover:bg-primary/10 transition-colors font-medium">Go
                                    Pro</button>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="w-full max-w-7xl px-6 py-20">
                    <div
                        className="glass rounded-3xl p-8 md:p-12 border border-white/10 bg-gradient-to-b from-white/5 to-transparent relative overflow-hidden">
                        <div
                            className="absolute top-0 right-0 w-64 h-64 bg-primary/20 blur-[100px] rounded-full -translate-y-1/2 translate-x-1/2">
                        </div>
                        <div className="grid lg:grid-cols-2 gap-12 items-center">
                            <div className="space-y-6">
                                <h2 className="text-3xl md:text-4xl font-bold">Integrate in <span
                                    className="text-primary">seconds</span></h2>
                                <p className="text-gray-400 text-lg">Our SDKs are designed to be plug-and-play. Don't waste time
                                    reinventing the wheel.</p>
                                <div className="flex flex-col gap-3">
                                    <div className="flex items-center gap-3 text-gray-300">
                                        <span className="material-symbols-outlined text-primary">check_circle</span>
                                        <span>Support for C++, C#, Python, Rust</span>
                                    </div>
                                    <div className="flex items-center gap-3 text-gray-300">
                                        <span className="material-symbols-outlined text-primary">check_circle</span>
                                        <span>Secure communication channels</span>
                                    </div>
                                    <div className="flex items-center gap-3 text-gray-300">
                                        <span className="material-symbols-outlined text-primary">check_circle</span>
                                        <span>Anti-debug &amp; Anti-tamper protection</span>
                                    </div>
                                </div>
                                <button
                                    className="mt-4 text-white font-medium border-b border-primary pb-1 hover:text-primary transition-colors flex items-center gap-2 w-fit group">
                                    View Full Documentation
                                    <span
                                        className="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                                </button>
                            </div>
                            <div
                                className="bg-[#0f0f13] rounded-xl border border-white/10 shadow-2xl overflow-hidden font-mono text-sm relative group">
                                <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5 bg-white/5">
                                    <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
                                    <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
                                    <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
                                    <div className="ml-auto text-xs text-gray-500">Program.cs</div>
                                </div>
                                <div className="p-6 text-gray-300 overflow-x-auto">
                                    <pre dangerouslySetInnerHTML={{
                                        __html: `<code class="language-csharp"><span class="text-purple-400">using</span> KeyAuth;

<span class="text-blue-400">namespace</span> MyApp {
    <span class="text-blue-400">class</span> <span class="text-yellow-300">Program</span> {
        <span class="text-gray-500">// Initialize RDX API</span>
        <span class="text-blue-400">public static</span> api KeyAuthApp = <span class="text-blue-400">new</span> <span class="text-yellow-300">api</span>(
            <span class="text-orange-300">"RDX_App"</span>,
            <span class="text-orange-300">"your_ownerid"</span>,
            <span class="text-orange-300">"1.0"</span>
        );

        <span class="text-blue-400">static void</span> <span class="text-yellow-300">Main</span>() {
            KeyAuthApp.<span class="text-yellow-300">init</span>(); <span class="text-gray-500">// Connect to Secure Edge</span>
            KeyAuthApp.<span class="text-yellow-300">login</span>(<span class="text-orange-300">"username"</span>, <span class="text-orange-300">"password"</span>);
            
            <span class="text-blue-400">if</span> (KeyAuthApp.response.success) {
                Console.<span class="text-yellow-300">WriteLine</span>(<span class="text-orange-300">"Access Granted via RDX!"</span>);
            }
        }
    }
}</code>`}}></pre>
                                </div>
                                <button
                                    className="absolute top-12 right-4 p-2 rounded bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors">
                                    <span className="material-symbols-outlined text-sm">content_copy</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="w-full relative py-24 overflow-hidden">
                    <div className="absolute inset-0 bg-secondary/5 skew-y-3 transform origin-top-left scale-110 -z-10"></div>
                    <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
                        <div
                            className="inline-flex items-center justify-center p-3 bg-white/5 rounded-full mb-8 border border-white/10">
                            <span className="material-symbols-outlined text-secondary text-3xl">verified_user</span>
                        </div>
                        <h2 className="text-4xl md:text-5xl font-bold mb-8">About <span className="text-secondary">RDX
                            Authentication</span></h2>
                        <p className="text-xl text-gray-300 leading-relaxed mb-10">
                            Our mission is to provide the world's most secure, high-speed authentication infrastructure for
                            software developers.
                            We believe that security shouldn't come at the cost of performance. RDX combines cutting-edge
                            encryption with a
                            global edge network to deliver millisecond response times and unbreakable protection.
                        </p>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 border-t border-white/10 pt-10">
                            <div>
                                <h4 className="text-2xl font-bold text-white mb-1">Global</h4>
                                <span className="text-sm text-gray-500">Server Network</span>
                            </div>
                            <div>
                                <h4 className="text-2xl font-bold text-white mb-1">24/7</h4>
                                <span className="text-sm text-gray-500">Security Monitoring</span>
                            </div>
                            <div>
                                <h4 className="text-2xl font-bold text-white mb-1">Zero</h4>
                                <span className="text-sm text-gray-500">Data Breaches</span>
                            </div>
                            <div>
                                <h4 className="text-2xl font-bold text-white mb-1">&lt;15ms</h4>
                                <span className="text-sm text-gray-500">Avg Latency</span>
                            </div>
                        </div>
                    </div>
                </section>
                <footer className="w-full border-t border-white/5 bg-[#08080c] mt-auto">
                    <div className="max-w-7xl mx-auto px-6 py-12">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 md:gap-8 mb-12">
                            <div className="col-span-1 md:col-span-2">
                                <div className="flex items-center gap-2 mb-6">
                                    <span className="material-symbols-outlined text-primary text-2xl">shield_lock</span>
                                    <span className="text-xl font-bold">RDX Authentication</span>
                                </div>
                                <p className="text-gray-400 max-w-sm mb-6">
                                    The most advanced authentication system for software developers. Secure, scalable, and
                                    simple.
                                </p>
                                <div className="flex gap-4">
                                    <a className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-primary hover:text-white transition-colors text-gray-400"
                                        href="#">
                                        <span className="material-symbols-outlined text-xl">rocket_launch</span>
                                    </a>
                                    <a className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-primary hover:text-white transition-colors text-gray-400"
                                        href="#">
                                        <span className="material-symbols-outlined text-xl">alternate_email</span>
                                    </a>
                                    <a className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-primary hover:text-white transition-colors text-gray-400"
                                        href="#">
                                        <span className="material-symbols-outlined text-xl">code</span>
                                    </a>
                                </div>
                            </div>
                            <div>
                                <h4 className="text-white font-bold mb-6">Product</h4>
                                <ul className="space-y-4 text-sm text-gray-400">
                                    <li><a className="hover:text-primary transition-colors" href="#features">Features</a></li>
                                    <li><a className="hover:text-primary transition-colors" href="/api-docs">API Integration</a>
                                    </li>
                                    <li><a className="hover:text-primary transition-colors" href="/docs">Documentation</a></li>
                                    <li><a className="hover:text-primary transition-colors cursor-pointer" data-onclick="window.location.href='/pricing'" onClick={handleActionClick}>Pricing</a></li>
                                </ul>
                            </div>
                            <div>
                                <h4 className="text-white font-bold mb-6">Legal</h4>
                                <ul className="space-y-4 text-sm text-gray-400">
                                    <li><a className="hover:text-primary transition-colors" href="/privacy-policy.html">Privacy
                                        Policy</a></li>
                                    <li><a className="hover:text-primary transition-colors" href="/terms-of-service.html">Terms of
                                        Service</a></li>
                                    <li><a className="hover:text-primary transition-colors" href="/cookie-policy.html">Cookie
                                        Policy</a></li>
                                    <li><a className="hover:text-primary transition-colors" href="/contact-support.html">Contact
                                        Support</a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
                            <p className="text-gray-500 text-sm">© 2023 RDX Authentication. All rights reserved.</p>
                            <div className="flex gap-6 text-sm text-gray-500">
                                <span>System Status: <span className="text-green-500">Operational</span></span>
                            </div>
                        </div>
                    </div>
                </footer>
            </main>



        </div>
    );
};

export default Landing;
