import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ConfirmModal from '../components/shared/ConfirmModal';

const Apps = () => {
    const [apps, setApps] = useState([]);
    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
    const [newApp, setNewApp] = useState({ name: '' });
    const [selectedApp, setSelectedApp] = useState(null);
    const [showSecret, setShowSecret] = useState(false);
    const [confirmModal, setConfirmModal] = useState({ isOpen: false, title: '', message: '', type: 'danger', onConfirm: () => {} });
    const token = localStorage.getItem('rdx_token');

    useEffect(() => {
        fetchApps();
    }, []);

    const fetchApps = async () => {
        try {
            const res = await fetch('/rdx/api/apps', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) setApps(data.apps);
        } catch (e) { console.error('Error fetching apps:', e); }
    };

    const handleCreateApp = async (e) => {
        e.preventDefault();
        try {
            const res = await fetch('/rdx/api/apps', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(newApp)
            });
            const data = await res.json();
            if (data.success) {
                fetchApps();
                setIsCreateModalOpen(false);
                setNewApp({ name: '' });
            }
        } catch (e) { console.error('Error creating app:', e); }
    };

    const handleDeleteApp = (id) => {
        setConfirmModal({
            isOpen: true,
            title: 'Delete Application',
            message: 'Are you sure? This will delete all associated data including users and licenses. This action cannot be undone.',
            type: 'danger',
            onConfirm: async () => {
                try {
                    const res = await fetch(`/rdx/api/apps/${id}`, {
                        method: 'DELETE',
                        headers: { 'Authorization': `Bearer ${token}` }
                    });
                    const data = await res.json();
                    if (data.success) fetchApps();
                } catch (e) { console.error('Error deleting app:', e); }
            }
        });
    };

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-3xl font-bold text-white mb-2 uppercase tracking-tighter text-shadow-glow">My Applications</h2>
                    <p className="text-slate-400">Manage and monitor your secure software instances.</p>
                </div>
                <button 
                    onClick={() => setIsCreateModalOpen(true)}
                    className="bg-primary hover:bg-primary/90 text-white text-sm font-medium px-6 py-2.5 rounded-lg shadow-neon-sm transition-all flex items-center gap-2"
                >
                    <span className="material-symbols-outlined text-[20px]">add</span>
                    Create New App
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {apps.map(app => (
                    <div key={app.id} 
                         className="glass-panel p-6 rounded-xl hover:border-primary/50 transition-all group cursor-pointer relative shadow-neon-sm"
                         onClick={() => setSelectedApp(app)}>
                        <div className="flex justify-between items-start mb-4">
                            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                                <span className="material-symbols-outlined">terminal</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <button 
                                    onClick={(e) => { e.stopPropagation(); handleDeleteApp(app.id); }}
                                    className="p-1.5 rounded-lg bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition-all tooltip relative z-10" 
                                    title="Delete Application"
                                >
                                    <span className="material-symbols-outlined text-sm">delete</span>
                                </button>
                                <span className="px-2 py-0.5 rounded bg-green-500/10 text-green-400 text-[10px] font-bold">STABLE</span>
                            </div>
                        </div>
                        <h3 className="text-white font-bold mb-1 text-shadow-glow">{app.name}</h3>
                        <p className="text-xs text-slate-500 mb-4">KEY: {app.owner_key}</p>
                        <div className="space-y-2">
                            <div className="flex justify-between text-[10px]">
                                <span className="text-slate-500">VERSION</span>
                                <span className="text-white">v{app.version || '1.0.0'}</span>
                            </div>
                            <div className="flex justify-between text-[10px]">
                                <span className="text-slate-500">STATUS</span>
                                <span className="text-accent">ENCRYPTED</span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {apps.length === 0 && (
                 <div className="col-span-full py-10 text-center text-slate-500">No applications found. Create one to get started!</div>
            )}

            {isCreateModalOpen && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-background-dark/80 backdrop-blur-sm" onClick={() => setIsCreateModalOpen(false)}></div>
                    <div className="glass-panel w-full max-w-md rounded-2xl p-8 relative z-10 animate-in zoom-in-95 duration-200" style={{ background: 'rgba(13, 17, 23, 0.95)', border: '1px solid rgba(140, 37, 244, 0.2)' }}>
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="text-xl font-bold text-white flex items-center gap-2">
                                <span className="material-symbols-outlined text-primary">add_box</span>
                                Create Application
                            </h3>
                            <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 hover:text-white transition-colors">
                                <span className="material-symbols-outlined">close</span>
                            </button>
                        </div>
                        <form onSubmit={handleCreateApp} className="space-y-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Application Name</label>
                                <input 
                                    type="text" 
                                    required 
                                    value={newApp.name} 
                                    onChange={e => setNewApp({ ...newApp, name: e.target.value })} 
                                    className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary transition-all" 
                                    placeholder="e.g. My Secure App" 
                                />
                            </div>
                            <div className="pt-4">
                                <button type="submit" className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-lg transition-all flex items-center justify-center gap-2 group shadow-neon-sm">
                                    <span>Deploy Application</span>
                                    <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">rocket_launch</span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {selectedApp && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-background-dark/80 backdrop-blur-sm" onClick={() => setSelectedApp(null)}></div>
                    <div className="glass-panel w-full max-w-lg rounded-2xl p-8 relative z-10 animate-in zoom-in-95 duration-200" style={{ background: 'rgba(13, 17, 23, 0.95)', border: '1px solid rgba(140, 37, 244, 0.2)' }}>
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="text-xl font-bold text-white flex items-center gap-2">
                                <span className="material-symbols-outlined text-primary">info</span>
                                Application Details
                            </h3>
                            <button onClick={() => setSelectedApp(null)} className="text-slate-400 hover:text-white transition-colors">
                                <span className="material-symbols-outlined">close</span>
                            </button>
                        </div>
                        <div className="space-y-6">
                            <div className="flex items-center gap-4 p-4 bg-white/5 rounded-xl border border-white/10">
                                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center text-primary">
                                    <span className="material-symbols-outlined font-bold">terminal</span>
                                </div>
                                <div>
                                    <h4 className="text-lg font-bold text-white">{selectedApp.name}</h4>
                                    <p className="text-xs text-slate-500">Version {selectedApp.version}</p>
                                </div>
                                <div className="ml-auto">
                                    <span className="px-2 py-1 rounded bg-green-500/10 text-green-400 text-[10px] font-bold uppercase">Active</span>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 gap-4">
                                <div className="p-4 bg-slate-900/50 rounded-xl border border-white/5">
                                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Owner Identifier</label>
                                    <div className="flex items-center justify-between">
                                        <code className="text-sm text-primary font-mono">{selectedApp.owner_key}</code>
                                        <button onClick={() => { navigator.clipboard.writeText(selectedApp.owner_key); window.showToast && window.showToast('Owner key copied', 'success'); }} className="text-slate-500 hover:text-white transition-colors">
                                            <span className="material-symbols-outlined text-[18px]">content_copy</span>
                                        </button>
                                    </div>
                                </div>

                                <div className="p-4 bg-slate-900/50 rounded-xl border border-white/5">
                                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Application Secret</label>
                                    <div className="flex gap-2">
                                        <div className="relative flex-1">
                                            <input 
                                                type={showSecret ? "text" : "password"} 
                                                readOnly 
                                                value={selectedApp.secret || 'Not available'} 
                                                className="w-full bg-slate-950/50 border border-white/5 rounded-lg px-3 py-2 text-xs font-mono text-accent outline-none" 
                                            />
                                            <button onClick={() => setShowSecret(!showSecret)} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors">
                                                <span className="material-symbols-outlined text-[18px]">
                                                    {showSecret ? 'visibility_off' : 'visibility'}
                                                </span>
                                            </button>
                                        </div>
                                        <button onClick={() => { navigator.clipboard.writeText(selectedApp.secret); window.showToast && window.showToast('App secret copied', 'success'); }} className="p-2 hover:bg-white/5 rounded-lg text-slate-400 transition-colors">
                                            <span className="material-symbols-outlined text-[18px]">content_copy</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
            <ConfirmModal 
                isOpen={confirmModal.isOpen} 
                title={confirmModal.title} 
                message={confirmModal.message} 
                type={confirmModal.type} 
                onConfirm={confirmModal.onConfirm} 
                onCancel={() => setConfirmModal({ ...confirmModal, isOpen: false })} 
            />
        </div>
    );
};

export default Apps;
