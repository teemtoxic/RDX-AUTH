import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const Orders = () => {
    const [requests, setRequests] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedRequest, setSelectedRequest] = useState(null);
    const [adminNote, setAdminNote] = useState('');
    const [actionLoading, setActionLoading] = useState(false);

    useEffect(() => {
        fetchRequests();
    }, []);

    const fetchRequests = async () => {
        try {
            setLoading(true);
            const token = localStorage.getItem('rdx_token');
            const res = await fetch('/rdx/api/admin/plan-requests', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                setRequests(data.data);
            }
        } catch (error) {
            console.error('Failed to fetch plan requests', error);
        } finally {
            setLoading(false);
        }
    };

    const handleAction = async (id, status) => {
        try {
            setActionLoading(true);
            const token = localStorage.getItem('rdx_token');
            const res = await fetch(`/rdx/api/admin/plan-requests/${id}/action`, {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ status, admin_note: adminNote })
            });
            const data = await res.json();
            if (data.success) {
                window.showToast && window.showToast(`Request ${status} successfully`, 'success');
                setRequests(requests.filter(r => r.id !== id));
                setSelectedRequest(null);
                setAdminNote('');
            } else {
                window.showToast && window.showToast(data.message || 'Error processing request', 'error');
            }
        } catch (error) {
            console.error('Action failed', error);
        } finally {
            setActionLoading(false);
        }
    };

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
            {/* Header Area */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-3xl font-black text-white mb-2 uppercase tracking-tighter text-shadow-glow flex items-center gap-3">
                        <span className="material-symbols-outlined text-4xl text-accent">shopping_cart</span>
                        Pending Plan Requests
                    </h2>
                    <p className="text-slate-400">Review and approve subscription upgrades from users.</p>
                </div>
                <div className="flex gap-3">
                    <button 
                        onClick={fetchRequests}
                        className="bg-white/5 hover:bg-white/10 border border-white/10 text-white p-2.5 rounded-xl transition-all flex items-center gap-2"
                        title="Refresh"
                    >
                        <span className="material-symbols-outlined text-[20px]">refresh</span>
                    </button>
                </div>
            </div>

            {/* Requests Table */}
            <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-slate-900/40 relative overflow-hidden shadow-2xl">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-accent/50 to-transparent opacity-30"></div>
                
                {loading ? (
                    <div className="flex flex-col items-center justify-center py-20 text-accent gap-4">
                        <span className="material-symbols-outlined animate-spin text-4xl">sync</span>
                        <span className="font-mono text-xs uppercase tracking-[0.3em]">Downloading Queue...</span>
                    </div>
                ) : requests.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-24 opacity-50 grayscale transition-all hover:grayscale-0">
                        <span className="material-symbols-outlined text-6xl mb-4 text-slate-500">inventory_2</span>
                        <p className="text-lg font-bold text-white uppercase tracking-widest text-shadow-glow">No Pending Orders</p>
                        <p className="text-sm text-slate-500 mt-1 uppercase tracking-tighter">Your queue is fully processed and optimized</p>
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse min-w-[900px]">
                            <thead>
                                <tr className="border-b border-white/10 uppercase tracking-widest text-[10px] text-slate-500">
                                    <th className="py-5 pl-4 font-black">User Intel</th>
                                    <th className="py-5 px-4 font-black">Plan Delta</th>
                                    <th className="py-5 px-4 font-black">Payment Reference</th>
                                    <th className="py-5 px-4 font-black">Timestamp</th>
                                    <th className="py-5 px-4 font-black text-right pr-4">Execution</th>
                                </tr>
                            </thead>
                            <tbody>
                                {requests.map((request, idx) => (
                                    <motion.tr 
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: idx * 0.05 }}
                                        key={request.id} 
                                        className="border-b border-white/5 hover:bg-white/5 transition-colors group relative"
                                    >
                                        <td className="py-5 pl-4">
                                            <div className="flex items-center gap-3">
                                                <div className="w-10 h-10 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center text-xs font-black text-white overflow-hidden relative group-hover:border-accent/50 transition-colors">
                                                    {request.username ? request.username.substring(0, 2).toUpperCase() : '??'}
                                                    <div className="absolute inset-0 bg-accent/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                                </div>
                                                <div>
                                                    <div className="font-black text-white group-hover:text-accent transition-colors tracking-tight text-sm uppercase">{request.username}</div>
                                                    <div className="text-[10px] text-slate-500 font-mono mt-0.5">{request.email}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="py-5 px-4">
                                            <div className="inline-flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-lg border border-white/5 group-hover:border-accent/20 transition-all">
                                                <span className="text-[10px] font-black text-slate-500 uppercase tracking-tighter">{request.current_plan || 'EXPIRED'}</span>
                                                <span className="material-symbols-outlined text-[14px] text-primary">arrow_forward</span>
                                                <span className="text-[11px] font-black text-white uppercase tracking-widest">{request.plan}</span>
                                            </div>
                                        </td>
                                        <td className="py-5 px-4">
                                            <div className="space-y-1">
                                                <div className="flex items-center gap-2">
                                                    <span className="text-xs font-mono text-accent font-bold select-all tracking-wider">{request.transaction_id}</span>
                                                    <button onClick={() => navigator.clipboard.writeText(request.transaction_id)} className="text-slate-600 hover:text-white transition-colors">
                                                        <span className="material-symbols-outlined text-[14px]">content_copy</span>
                                                    </button>
                                                </div>
                                                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest italic flex items-center gap-1">
                                                     <span className="material-symbols-outlined text-[12px]">payments</span>
                                                     Amount Verified: ₹{request.amount || '??'}
                                                </div>
                                            </div>
                                        </td>
                                        <td className="py-5 px-4">
                                            <div className="text-[11px] text-slate-400 font-bold uppercase tracking-tighter">
                                                {new Date(request.created_at).toLocaleDateString()}
                                                <span className="block text-[9px] text-slate-600 font-mono mt-0.5">{new Date(request.created_at).toLocaleTimeString()}</span>
                                            </div>
                                        </td>
                                        <td className="py-5 px-4 text-right pr-4">
                                            <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0">
                                                <button 
                                                    onClick={() => setSelectedRequest(request)}
                                                    className="px-4 py-2 bg-accent/20 hover:bg-accent border border-accent/20 hover:border-accent text-accent hover:text-slate-900 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all"
                                                >
                                                    Process
                                                </button>
                                            </div>
                                        </td>
                                    </motion.tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {/* Bottom Insight Area */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-12">
                <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-slate-900/40 relative overflow-hidden group hover:border-primary/30 transition-all">
                    <div className="flex items-start justify-between">
                        <div>
                            <h4 className="text-[11px] font-black text-slate-500 uppercase tracking-[0.3em] mb-4">Security Protocol Info</h4>
                            <p className="text-sm text-slate-400 leading-relaxed">
                                All plan requests require <span className="text-white font-bold">Manual UTR Verification</span>. 
                                Approving a request will automatically activate the license and notify the user via Telegram/Email.
                            </p>
                        </div>
                        <span className="material-symbols-outlined text-4xl text-primary/20 group-hover:text-primary transition-colors">verified_user</span>
                    </div>
                </div>
                <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-slate-900/40 relative overflow-hidden group hover:border-accent/30 transition-all">
                    <div className="flex items-start justify-between">
                        <div>
                            <h4 className="text-[11px] font-black text-slate-500 uppercase tracking-[0.3em] mb-4">Automated Enforcement</h4>
                            <p className="text-sm text-slate-400 leading-relaxed">
                                The AI Shield monitors for <span className="text-white font-bold">Duplicate Transaction IDs</span>. 
                                Suspicious requests are highlighted for immediate blacklisting of the HWID involved.
                            </p>
                        </div>
                        <span className="material-symbols-outlined text-4xl text-accent/20 group-hover:text-accent transition-colors">shield</span>
                    </div>
                </div>
            </div>

            {/* Process Modal */}
            <AnimatePresence>
                {selectedRequest && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
                        <motion.div 
                            initial={{ scale: 0.9, opacity: 0, y: 20 }}
                            animate={{ scale: 1, opacity: 1, y: 0 }}
                            exit={{ scale: 0.9, opacity: 0, y: 20 }}
                            className="glass-panel p-8 rounded-3xl max-w-lg w-full border border-white/10 shadow-[0_0_50px_rgba(0,245,212,0.1)] relative overflow-hidden"
                        >
                            <div className="absolute top-0 right-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
                            
                            <div className="flex justify-between items-center mb-8 relative z-10">
                                <div>
                                    <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Request Management</h3>
                                    <p className="text-slate-500 text-[10px] font-bold tracking-widest uppercase mt-1">Reviewing ID: {selectedRequest.id}</p>
                                </div>
                                <button onClick={() => setSelectedRequest(null)} className="text-slate-500 hover:text-white p-2">
                                    <span className="material-symbols-outlined">close</span>
                                </button>
                            </div>

                            <div className="space-y-6 relative z-10">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-black/20 p-4 rounded-2xl border border-white/5">
                                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Target Plan</p>
                                        <p className="text-lg font-black text-accent uppercase tracking-tighter">{selectedRequest.plan}</p>
                                    </div>
                                    <div className="bg-black/20 p-4 rounded-2xl border border-white/5">
                                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Reference ID</p>
                                        <p className="text-sm font-bold text-white font-mono break-all">{selectedRequest.transaction_id}</p>
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 px-1">Internal Admin Note (Optional)</label>
                                    <textarea 
                                        value={adminNote}
                                        onChange={(e) => setAdminNote(e.target.value)}
                                        placeholder="Add private note about this transaction..."
                                        className="w-full h-24 bg-[#0a0a0f] border border-white/5 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-accent/50 transition-all resize-none font-medium placeholder:text-slate-700"
                                    ></textarea>
                                </div>

                                <div className="flex gap-4 pt-2">
                                    <button 
                                        disabled={actionLoading}
                                        onClick={() => handleAction(selectedRequest.id, 'approved')}
                                        className="flex-1 bg-accent hover:bg-accent-glow text-slate-900 font-black py-4 rounded-xl shadow-neon-sm transition-all uppercase tracking-widest text-xs flex items-center justify-center gap-2"
                                    >
                                        {actionLoading ? <span className="material-symbols-outlined animate-spin">sync</span> : <span className="material-symbols-outlined">check_circle</span>}
                                        Approve
                                    </button>
                                    <button 
                                        disabled={actionLoading}
                                        onClick={() => handleAction(selectedRequest.id, 'rejected')}
                                        className="px-8 bg-red-500/10 hover:bg-red-500 border border-red-500/20 hover:border-red-500 text-red-500 hover:text-white font-black rounded-xl transition-all uppercase tracking-widest text-xs flex items-center justify-center"
                                    >
                                        Reject
                                    </button>
                                </div>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default Orders;
