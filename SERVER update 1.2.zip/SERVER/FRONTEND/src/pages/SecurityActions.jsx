import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const SecurityActions = () => {
    const [hwidRequests, setHwidRequests] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [apps, setApps] = useState([]);
    const [selectedAppId, setSelectedAppId] = useState('');
    const [isSaving, setIsSaving] = useState(false);
    const [settings, setSettings] = useState({
        vpn_detection: false,
        debugger_detection: false,
        integrity_check: false
    });

    useEffect(() => {
        loadData();
    }, []);

    useEffect(() => {
        if (selectedAppId) {
            loadAppSettings();
            loadHwidRequests();
        }
    }, [selectedAppId]);

    const loadData = async () => {
        try {
            const token = localStorage.getItem('rdx_token');
            const res = await fetch('/rdx/api/apps', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) setApps(data.apps);
            setIsLoading(false);
        } catch (e) {
            console.error('Core Data Load Failed:', e);
            setIsLoading(false);
        }
    };

    const loadAppSettings = async () => {
        try {
            const token = localStorage.getItem('rdx_token');
            const res = await fetch(`/rdx/api/apps/${selectedAppId}/settings`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                setSettings({
                    vpn_detection: data.settings.vpn_detection === 1,
                    debugger_detection: data.settings.debugger_detection === 1,
                    integrity_check: data.settings.integrity_check === 1
                });
            }
        } catch (e) { console.error('Settings Load Failed:', e); }
    };

    const loadHwidRequests = async () => {
        try {
            const token = localStorage.getItem('rdx_token');
            const res = await fetch(`/rdx/api/hwid/requests?app_id=${selectedAppId}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) setHwidRequests(data.requests);
        } catch (e) { console.error('HWID Requests Load Failed:', e); }
    };

    const saveSettings = async () => {
        if (!selectedAppId) return;
        setIsSaving(true);
        try {
            const token = localStorage.getItem('rdx_token');
            const res = await fetch(`/rdx/api/apps/${selectedAppId}/settings`, {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(settings)
            });
            const data = await res.json();
            if (data.success) {
                window.showToast && window.showToast('Mainframe Security Protocols Updated', 'success');
            }
        } catch (e) { console.error('Save Failed:', e); }
        setIsSaving(false);
    };

    const handleHwidAction = async (requestId, action) => {
        try {
            const token = localStorage.getItem('rdx_token');
            const res = await fetch(`/rdx/api/hwid/requests/${requestId}`, {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ action })
            });
            const data = await res.json();
            if (data.success) {
                window.showToast && window.showToast(`Identity Clearance ${action}`, 'success');
                loadHwidRequests();
            } else {
                window.showToast && window.showToast(`Error: ${data.message}`, 'error');
            }
        } catch (e) { console.error('Action Failed:', e); }
    };

    if (isLoading) {
        return (
            <div className="p-8 text-white font-black uppercase tracking-widest animate-pulse flex items-center gap-3">
                <span className="material-symbols-outlined animate-spin text-primary">admin_panel_settings</span>
                Initializing Security Actions...
            </div>
        );
    }

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
            {/* Header */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="space-y-1">
                    <h2 className="text-3xl font-black text-white uppercase tracking-tighter flex items-center gap-3 text-shadow-glow">
                        <span className="material-symbols-outlined text-4xl text-primary drop-shadow-[0_0_10px_rgba(140,37,244,0.5)]">admin_panel_settings</span>
                        Security Actions
                    </h2>
                    <p className="text-slate-400 font-medium tracking-tight">Manage mainframe defense protocols and identity clearances.</p>
                </div>
                <div className="flex items-center gap-4">
                    <div className="relative group">
                        <select 
                            value={selectedAppId} 
                            onChange={(e) => setSelectedAppId(e.target.value)}
                            className="bg-slate-900 border border-white/10 rounded-xl px-5 py-3 text-xs text-white font-black uppercase tracking-widest hover:border-primary transition-all focus:outline-none focus:ring-2 focus:ring-primary/20 appearance-none pr-10 min-w-[200px]"
                        >
                            <option value="">Select Target App</option>
                            {apps.map(app => (
                                <option key={app.id} value={app.id}>{app.name}</option>
                            ))}
                        </select>
                        <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none text-[18px]">expand_more</span>
                    </div>
                    <button 
                        onClick={loadHwidRequests}
                        className="p-3 bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white rounded-xl border border-white/5 transition-all group shadow-inner hover:shadow-white/5"
                    >
                        <span className={`material-symbols-outlined ${isLoading ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-500'}`}>refresh</span>
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Defensive Toggles */}
                <div className="space-y-6">
                    <div className="glass-panel p-8 rounded-3xl border border-white/5 bg-slate-900/40 relative overflow-hidden h-full hover:border-primary/30 shadow-neon-sm transition-all duration-500">
                        <div className="flex items-center gap-3 mb-8">
                            <span className="material-symbols-outlined text-primary text-shadow-glow">security</span>
                            <h3 className="text-[10px] text-slate-400 uppercase font-black tracking-[0.3em] text-shadow-glow">Guard Settings</h3>
                        </div>
                        
                        <div className="space-y-4">
                            {[
                                { id: 'vpn', label: 'VPN Defence', sub: 'Anti-Proxy Protocols', key: 'vpn_detection' },
                                { id: 'debug', label: 'Debugger Guard', sub: 'Reverse-Engine Prevention', key: 'debugger_detection' },
                                { id: 'integrity', label: 'Integrity Scan', sub: 'File Modification Guard', key: 'integrity_check' }
                            ].map(toggle => (
                                <div key={toggle.id} className="flex items-center justify-between p-4 rounded-2xl bg-black/40 border border-white/5 group hover:border-primary/30 hover:bg-white/[0.02] transition-all">
                                    <div className="space-y-0.5">
                                        <p className="text-xs font-black text-white uppercase tracking-tight group-hover:text-primary transition-colors">{toggle.label}</p>
                                        <p className="text-[8px] text-slate-500 uppercase font-black tracking-widest">{toggle.sub}</p>
                                    </div>
                                    <div 
                                        onClick={() => setSettings(s => ({...s, [toggle.key]: !s[toggle.key]}))}
                                        className={`w-10 h-5 rounded-full relative cursor-pointer transition-all duration-300 ${settings[toggle.key] ? 'bg-primary shadow-[0_0_10px_rgba(140,37,244,0.5)]' : 'bg-slate-800'}`}
                                    >
                                        <div className={`absolute top-1 size-3 rounded-full bg-white transition-all duration-300 ${settings[toggle.key] ? 'left-6' : 'left-1'}`}></div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <button 
                            onClick={saveSettings}
                            disabled={isSaving || !selectedAppId}
                            className="w-full mt-10 py-4 bg-primary hover:bg-primary-glow disabled:opacity-50 disabled:cursor-not-allowed text-white text-[10px] font-black rounded-xl uppercase tracking-[0.3em] transition-all shadow-neon flex items-center justify-center gap-2 group"
                        >
                            {isSaving ? <span className="material-symbols-outlined animate-spin">sync</span> : <span className="material-symbols-outlined text-sm group-hover:rotate-180 transition-transform duration-500">settings_suggest</span>}
                            Deploy Protocols
                        </button>
                        
                        {!selectedAppId && <p className="mt-4 text-[9px] text-center text-red-400/60 uppercase font-black tracking-widest animate-pulse">Select target app first</p>}
                    </div>
                </div>

                {/* HWID Clearance */}
                <div className="space-y-8">
                    <div className="glass-panel rounded-3xl border border-white/5 overflow-hidden bg-slate-900/40 shadow-neon-sm hover:border-blue-500/30 transition-all duration-500 h-full">
                        <div className="p-6 border-b border-white/5 bg-white/5 flex items-center justify-between backdrop-blur-md">
                            <div className="flex items-center gap-3">
                                <span className="material-symbols-outlined text-blue-400 text-shadow-glow">fingerprint</span>
                                <h3 className="text-xs font-black text-white uppercase tracking-[0.3em] text-shadow-glow">Identity Clearances</h3>
                            </div>
                            <div className="flex gap-2">
                                <span className="px-3 py-1 bg-primary/10 text-primary text-[9px] font-black rounded-lg uppercase tracking-widest border border-primary/20">HWID LOCK</span>
                                <span className="px-3 py-1 bg-white/5 text-slate-500 text-[9px] font-mono font-black rounded-lg uppercase tracking-widest border border-white/10">{hwidRequests.length} QUEUED</span>
                            </div>
                        </div>
                        <div className="overflow-x-auto h-[400px] custom-scrollbar bg-black/20">
                            <table className="w-full text-left">
                                <thead className="bg-slate-900/50 text-[9px] text-slate-500 font-black uppercase tracking-[0.3em] border-b border-white/5">
                                    <tr>
                                        <th className="px-6 py-5">User Manifest</th>
                                        <th className="px-6 py-5">Assigned App</th>
                                        <th className="px-6 py-5 text-right">Clearance</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-white/5 font-mono text-xs">
                                    {hwidRequests.length === 0 ? (
                                        <tr><td colSpan="3" className="px-6 py-16 text-center text-slate-600 italic opacity-50 text-[10px] uppercase font-black tracking-widest">No pending identity resets.</td></tr>
                                    ) : (
                                        hwidRequests.map(req => (
                                            <tr key={req.id} className="hover:bg-white/[0.05] transition-colors group">
                                                <td className="px-6 py-5">
                                                    <div className="text-white font-black uppercase text-[11px] tracking-tight">{req.username}</div>
                                                    <div className="text-[10px] text-slate-500 font-medium line-clamp-1 max-w-[200px] mt-2" title={req.reason}>"{req.reason}"</div>
                                                </td>
                                                <td className="px-6 py-5 text-slate-400 font-bold italic">{req.app_name}</td>
                                                <td className="px-6 py-5 text-right">
                                                    <div className="flex justify-end gap-2 text-shadow-glow">
                                                        <button onClick={() => handleHwidAction(req.id, 'approved')} className="size-10 bg-green-500/10 hover:bg-green-500 text-green-500 hover:text-white rounded-xl border border-green-500/20 transition-all flex items-center justify-center shadow-lg group-hover:scale-105 hover:shadow-[0_0_15px_rgba(34,197,94,0.4)]">
                                                            <span className="material-symbols-outlined text-[20px]">check</span>
                                                        </button>
                                                        <button onClick={() => handleHwidAction(req.id, 'rejected')} className="size-10 bg-red-500/10 hover:bg-red-600 text-red-500 hover:text-white rounded-xl border border-red-500/20 transition-all flex items-center justify-center shadow-lg group-hover:scale-105 hover:shadow-[0_0_15px_rgba(239,68,68,0.4)]">
                                                            <span className="material-symbols-outlined text-[20px]">close</span>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SecurityActions;
