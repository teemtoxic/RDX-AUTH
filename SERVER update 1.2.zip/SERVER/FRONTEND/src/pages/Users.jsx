import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ConfirmModal from '../components/shared/ConfirmModal';

const Users = () => {
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [newUser, setNewUser] = useState({ username: '', password: '', appId: '', subscriptionId: '', expiry_date: '', expiry_preset: 'lifetime', hwid_lock: false });
    
    // Edit User state
    const [editUser, setEditUser] = useState({ id: '', username: '', password: '', expiry_date: '', hwid_lock: false });

    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [apps, setApps] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedAppFilter, setSelectedAppFilter] = useState('');
    const [confirmModal, setConfirmModal] = useState({ isOpen: false, title: '', message: '', type: 'danger', onConfirm: () => {} });

    // Subscriptions for Select
    const [subscriptions, setSubscriptions] = useState([]);

    useEffect(() => {
        fetchData();
    }, [selectedAppFilter]);

    const fetchData = async () => {
        try {
            const token = localStorage.getItem('rdx_token');
            if (!token) return;

            setLoading(true);

            // Fetch Apps for the dropdown
            const appsRes = await fetch('/rdx/api/apps', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const appsData = await appsRes.json();
            if (appsData.success) {
                setApps(appsData.apps);
            }

            // Fetch Subscriptions for Select
            const subsRes = await fetch('/rdx/api/subscriptions', {
                 headers: { 'Authorization': `Bearer ${token}` }
            });
            const subsData = await subsRes.json();
            if (subsData.success) {
                setSubscriptions(subsData.subscriptions || []);
            }

            // Fetch Users with optional app filter
            let url = '/rdx/api/users';
            if (selectedAppFilter) url += `?app_id=${selectedAppFilter}`;

            const usersRes = await fetch(url, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const usersData = await usersRes.json();
            if (usersData.success) {
                setUsers(usersData.users);
            }
        } catch (error) {
            console.error('Failed to fetch data', error);
        } finally {
            setLoading(false);
        }
    };

    const handleCreateUser = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('rdx_token');
            const payload = {
                app_id: newUser.appId,
                username: newUser.username,
                password: newUser.password
            };
            if (newUser.subscriptionId) payload.subscription_id = newUser.subscriptionId;
            if (newUser.expiry_date) payload.expiry_date = newUser.expiry_date;
            payload.hwid_lock = newUser.hwid_lock;

            const res = await fetch('/rdx/api/users', {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });
            const data = await res.json();
            if (data.success) {
                setIsAddModalOpen(false);
                setNewUser({ username: '', password: '', appId: '', subscriptionId: '', expiry_date: '', expiry_preset: 'lifetime', hwid_lock: false });
                fetchData();
            } else {
                alert(data.message || 'Failed to create user');
            }
        } catch (error) {
            console.error(error);
            alert('An error occurred');
        }
    };

    const handleEditUserSubmit = async (e) => {
        e.preventDefault();
        try {
            const token = localStorage.getItem('rdx_token');
            const res = await fetch(`/rdx/api/users/${editUser.id}`, {
                method: 'PUT',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    password: editUser.password,
                    expiry_date: editUser.expiry_date,
                    hwid_lock: editUser.hwid_lock
                })
            });
            const data = await res.json();
            if (data.success) {
                setIsEditModalOpen(false);
                fetchData();
            } else {
                alert(data.message || 'Failed to update user');
            }
        } catch (error) {
            console.error(error);
            alert('An error occurred');
        }
    };

    const openEditModal = (user) => {
        setEditUser({
            id: user.id,
            username: user.username,
            password: '',
            expiry_date: user.expiry_date ? new Date(new Date(user.expiry_date).getTime() - (new Date().getTimezoneOffset() * 60000)).toISOString().slice(0, 16) : '',
            hwid_lock: user.hwid_lock ? true : false
        });
        setIsEditModalOpen(true);
    };

    const handleDeleteUser = (id) => {
        setConfirmModal({
            isOpen: true,
            title: 'Delete User',
            message: 'Are you sure you want to delete this user account? This action cannot be undone.',
            type: 'danger',
            onConfirm: async () => {
                try {
                    const token = localStorage.getItem('rdx_token');
                    const res = await fetch(`/rdx/api/users/${id}`, {
                        method: 'DELETE',
                        headers: { 'Authorization': `Bearer ${token}` }
                    });
                    const data = await res.json();
                    if (data.success) {
                        fetchData();
                    } else {
                        alert(data.message || 'Failed to delete user');
                    }
                } catch (err) { console.error(err); }
            }
        });
    };

    const handleResetHwid = (id) => {
        setConfirmModal({
            isOpen: true,
            title: 'Reset User HWID',
            message: 'Are you sure you want to reset HWID for this user? This allows them to bind a new device.',
            type: 'danger',
            onConfirm: async () => {
                try {
                    const token = localStorage.getItem('rdx_token');
                    const res = await fetch(`/rdx/api/users/${id}/reset`, {
                        method: 'POST',
                        headers: { 'Authorization': `Bearer ${token}` }
                    });
                    const data = await res.json();
                    if (data.success) fetchData();
                    else alert(data.message || 'Failed to reset HWID');
                } catch (err) { console.error(err); }
            }
        });
    };

    const toggleUserStatus = (id, currentStatus, type) => {
        let newStatus = 'active';
        let confirmMsg = '';

        if (type === 'pause') {
            newStatus = currentStatus === 'paused' ? 'active' : 'paused';
            confirmMsg = `Are you sure you want to ${newStatus === 'paused' ? 'pause' : 'resume'} this user?`;
        } else if (type === 'ban') {
            newStatus = currentStatus === 'banned' ? 'active' : 'banned';
            confirmMsg = `Are you sure you want to ${newStatus === 'banned' ? 'ban' : 'unban'} this user?`;
        }

        setConfirmModal({
            isOpen: true,
            title: 'Change User Status',
            message: confirmMsg,
            type: 'warning',
            onConfirm: async () => {
                try {
                    const token = localStorage.getItem('rdx_token');
                    const res = await fetch(`/rdx/api/users/${id}/status`, {
                        method: 'POST',
                        headers: { 
                            'Authorization': `Bearer ${token}`,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ status: newStatus })
                    });
                    const data = await res.json();
                    if (data.success) fetchData();
                    else alert(data.message || 'Failed to update user status');
                } catch (err) { console.error(err); }
            }
        });
    };

    const filteredUsers = users.filter(u => 
        u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (u.hwid && u.hwid.toLowerCase().includes(searchQuery.toLowerCase()))
    );

    return (
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-3xl font-bold text-white mb-2 uppercase tracking-tighter">
                        User Management
                    </h2>
                    <p className="text-slate-400">Manage application users and their access levels.</p>
                </div>
                <div className="flex flex-wrap gap-3 w-full md:w-auto">
                    {/* Search Bar */}
                    <div className="relative group">
                        <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-[18px] group-focus-within:text-primary transition-colors">search</span>
                        <input 
                            type="text" 
                            placeholder="Search user or HWID..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="bg-slate-900 border border-white/10 rounded-lg pl-10 pr-4 py-2 text-sm text-white focus:border-primary/50 outline-none w-64 transition-all placeholder:text-slate-600 focus:ring-1 focus:ring-primary/50"
                        />
                    </div>

                    <div className="relative">
                        <select value={selectedAppFilter} onChange={e => setSelectedAppFilter(e.target.value)} className="bg-slate-900 border border-white/10 rounded-lg px-4 py-2 text-sm text-white hover:border-primary/50 transition-all min-w-[180px] uppercase tracking-wider font-bold appearance-none focus:outline-none focus:ring-1 focus:ring-primary/50 h-full">
                            <option value="">ALL APPLICATIONS</option>
                            {apps.map(app => <option key={app.id} value={app.id}>{app.name}</option>)}
                        </select>
                        <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-[18px] opacity-50 pointer-events-none">expand_more</span>
                    </div>

                    <button id="btn-refresh-users" onClick={fetchData} className="glass-panel px-4 py-2 text-white text-sm rounded-lg hover:bg-white/5 transition-colors flex items-center gap-2 border border-white/10">
                        <span className="material-symbols-outlined text-[20px]">refresh</span>
                        Refresh
                    </button>
                    
                    <button
                        id="btn-open-create-user-modal"
                        onClick={() => setIsAddModalOpen(true)}
                        className="bg-primary hover:bg-primary/90 text-white text-sm font-medium px-6 py-2.5 rounded-lg shadow-neon-sm transition-all flex items-center gap-2"
                    >
                        <span className="material-symbols-outlined text-[20px]">person_add</span>
                        Create User
                    </button>
                </div>
            </div>

            <div className="glass-panel overflow-hidden rounded-xl border border-white/5 shadow-2xl">
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-slate-900/50 border-b border-white/10">
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">User</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Application</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Subscription</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">HWID / UID</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Created</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Status</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Expiry</th>
                                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5 font-mono text-xs">
                            {loading ? (
                                <tr>
                                    <td colSpan="7" className="px-6 py-12 text-center text-slate-500 animate-pulse font-mono tracking-widest text-xs uppercase">
                                        Loading mainframe records...
                                    </td>
                                </tr>
                            ) : filteredUsers.length === 0 ? (
                                <tr>
                                    <td colSpan="7" className="px-6 py-12 text-center text-slate-500 font-mono tracking-widest text-xs uppercase">
                                        No users found
                                    </td>
                                </tr>
                            ) : (
                                filteredUsers.map(user => (
                                    <tr key={user.id} className="hover:bg-white/5 transition-colors group">
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-xs uppercase">
                                                    {user.username.substring(0,2)}
                                                </div>
                                                <div>
                                                    <div className="text-sm font-bold text-white flex gap-2 items-center">
                                                        {user.username}
                                                        <button onClick={() => { navigator.clipboard.writeText(user.username); window.showToast && window.showToast('Username copied', 'success'); }} className="text-slate-600 hover:text-white transition-colors opacity-0 group-hover:opacity-100">
                                                            <span className="material-symbols-outlined text-[12px]">content_copy</span>
                                                        </button>
                                                    </div>
                                                    <div className="text-[10px] text-slate-500 uppercase tracking-widest flex items-center gap-1">
                                                        ID: {user.id}
                                                        <button onClick={() => { navigator.clipboard.writeText(user.id); window.showToast && window.showToast('ID copied', 'success'); }} className="text-slate-600 hover:text-white transition-colors opacity-0 group-hover:opacity-100">
                                                            <span className="material-symbols-outlined text-[10px]">content_copy</span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-300">
                                            {user.app_name || 'N/A'}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-xs text-slate-400 font-bold uppercase tracking-wider">
                                            {user.subscription_name || 'Free Tier'}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center gap-2 group/copy">
                                                <code className="text-xs text-slate-400 font-mono px-2 py-1 bg-white/5 rounded border border-white/10" title={user.hwid}>
                                                    {Number(user.hwid_lock) === 0 ? 'Public User' : (user.hwid ? user.hwid.substring(0,25)+'...' : 'Unbound')}
                                                </code>
                                                {user.hwid && (
                                                    <button onClick={() => { navigator.clipboard.writeText(user.hwid); window.showToast && window.showToast('HWID copied', 'success'); }} className="text-slate-500 hover:text-white transition-colors opacity-0 group-hover/copy:opacity-100">
                                                        <span className="material-symbols-outlined text-[14px]">content_copy</span>
                                                    </button>
                                                )}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">
                                            {new Date(user.created_at).toLocaleDateString()}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            {user.status === 'active' && <span className="px-2 py-1 inline-flex text-[10px] leading-4 font-bold rounded bg-green-500/10 text-green-400 uppercase tracking-wider border border-green-500/20">Active</span>}
                                            {user.status === 'paused' && <span className="px-2 py-1 inline-flex text-[10px] leading-4 font-bold rounded bg-yellow-500/10 text-yellow-400 uppercase tracking-wider border border-yellow-500/20">Paused</span>}
                                            {user.status === 'banned' && <span className="px-2 py-1 inline-flex text-[10px] leading-4 font-bold rounded bg-red-500/10 text-red-400 uppercase tracking-wider border border-red-500/20">Banned</span>}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">
                                            {user.expiry_date ? new Date(user.expiry_date).toLocaleDateString() : 'Lifetime'}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button onClick={() => openEditModal(user)} className="text-slate-500 hover:text-blue-400 transition-colors tooltip" title="Edit User">
                                                    <span className="material-symbols-outlined text-[18px]">edit</span>
                                                </button>
                                                <button onClick={() => handleResetHwid(user.id)} className="text-slate-500 hover:text-yellow-400 transition-colors tooltip" title="Reset HWID">
                                                    <span className="material-symbols-outlined text-[18px]">restart_alt</span>
                                                </button>
                                                <button onClick={() => toggleUserStatus(user.id, user.status, 'pause')} className="text-slate-500 hover:text-orange-400 transition-colors tooltip" title={user.status === 'paused' ? 'Resume User' : 'Pause User'}>
                                                    <span className="material-symbols-outlined text-[18px]">{user.status === 'paused' ? 'play_circle' : 'pause_circle'}</span>
                                                </button>
                                                <button onClick={() => toggleUserStatus(user.id, user.status, 'ban')} className="text-slate-500 hover:text-red-500 transition-colors tooltip" title={user.status === 'banned' ? 'Unban User' : 'Ban User'}>
                                                    <span className="material-symbols-outlined text-[18px]">{user.status === 'banned' ? 'gavel' : 'block'}</span>
                                                </button>
                                                <button onClick={() => handleDeleteUser(user.id)} className="text-slate-500 hover:text-red-400 transition-colors tooltip" title="Delete Account">
                                                    <span className="material-symbols-outlined text-[18px]">delete</span>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Create User Modal - Premium Redesign */}
            <AnimatePresence>
                {isAddModalOpen && (
                    <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-background-dark/80 backdrop-blur-md"
                    >
                        <motion.div 
                            initial={{ scale: 0.95, opacity: 0, y: 20 }}
                            animate={{ scale: 1, opacity: 1, y: 0 }}
                            exit={{ scale: 0.95, opacity: 0, y: 20 }}
                            className="glass-panel w-full max-w-md rounded-2xl p-8 border border-primary/20 relative overflow-hidden bg-slate-950/95 shadow-[0_0_50px_rgba(140,37,244,0.15)]"
                        >
                            {/* Visual Accents */}
                            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
                            
                            <div className="flex justify-between items-center mb-8 relative z-10">
                                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                                    <span className="material-symbols-outlined text-primary">person_add</span>
                                    Initialize Secure User
                                </h3>
                                <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white transition-colors">
                                    <span className="material-symbols-outlined">close</span>
                                </button>
                            </div>

                            <form onSubmit={handleCreateUser} className="space-y-5 relative z-10">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Username</label>
                                        <input
                                            required
                                            type="text"
                                            value={newUser.username}
                                            onChange={e => setNewUser({ ...newUser, username: e.target.value })}
                                            placeholder="e.g. shadow_stalker"
                                            className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary transition-all font-mono"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Password</label>
                                        <input
                                            required
                                            type="password"
                                            value={newUser.password}
                                            onChange={e => setNewUser({ ...newUser, password: e.target.value })}
                                            placeholder="••••••••"
                                            className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary transition-all font-mono"
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Target Application</label>
                                    <select 
                                        required 
                                        value={newUser.appId} 
                                        onChange={e => setNewUser({ ...newUser, appId: e.target.value })}
                                        className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary transition-all font-mono appearance-none cursor-pointer"
                                    >
                                        <option value="" disabled>--- Select Application ---</option>
                                        {apps.map(app => <option key={app.id} value={app.id}>{app.name}</option>)}
                                    </select>
                                </div>

                                <div>
                                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Subscription Plan</label>
                                    <select 
                                        value={newUser.subscriptionId} 
                                        onChange={e => setNewUser({ ...newUser, subscriptionId: e.target.value })}
                                        className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-accent transition-all font-mono appearance-none cursor-pointer"
                                    >
                                        <option value="">--- No Subscription ---</option>
                                        {subscriptions
                                            .filter(s => newUser.appId ? s.app_id === parseInt(newUser.appId) : true)
                                            .map(sub => (
                                                <option key={sub.id} value={sub.id}>
                                                    {sub.name} (Level {sub.level})
                                                </option>
                                            ))
                                        }
                                    </select>
                                </div>

                                <div>
                                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Access Expiry Date & Time</label>
                                    <input
                                        type="datetime-local"
                                        value={newUser.expiry_date}
                                        onChange={e => setNewUser({ ...newUser, expiry_date: e.target.value })}
                                        className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-primary transition-all appearance-none"
                                    />
                                </div>

                                <div className="flex items-center gap-3 p-4 bg-slate-900/50 rounded-xl border border-white/5 transition-all hover:border-primary/20">
                                    <div className="flex-1">
                                        <h5 className="text-[11px] font-bold text-white uppercase tracking-wider">Hardware Identity Lock</h5>
                                        <p className="text-[9px] text-slate-500 mt-0.5">Restrict this account to a single device (HWID Lock)</p>
                                    </div>
                                    <div className="relative">
                                        <input 
                                            type="checkbox" 
                                            checked={newUser.hwid_lock} 
                                            onChange={e => setNewUser({ ...newUser, hwid_lock: e.target.checked })}
                                            className="accent-primary size-5 rounded border-white/10 bg-slate-900 cursor-pointer"
                                        />
                                    </div>
                                </div>

                                <div className="pt-4">
                                    <button
                                        type="submit"
                                        className="w-full bg-primary hover:bg-primary-glow text-white font-black py-4 rounded-xl transition-all shadow-neon flex items-center justify-center gap-2 group uppercase tracking-widest text-[11px] border border-primary/30"
                                    >
                                        <span>Initialize Secure User</span>
                                        <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">verified_user</span>
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Edit User Modal */}
            <AnimatePresence>
                {isEditModalOpen && (
                    <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-background-dark/80 backdrop-blur-sm"
                    >
                        <motion.div 
                            initial={{ scale: 0.9, y: 20 }}
                            animate={{ scale: 1, y: 0 }}
                            exit={{ scale: 0.9, y: 20 }}
                            className="glass-panel w-full max-w-md rounded-3xl p-8 border border-white/10 shadow-[0_0_50px_rgba(59,130,246,0.1)] bg-slate-950/95 relative overflow-hidden"
                        >
                            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>

                            <div className="flex justify-between items-center mb-8 relative z-10">
                                <div>
                                    <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Modify Credentials</h3>
                                    <p className="text-slate-500 text-[10px] font-bold tracking-widest uppercase mt-1">Authorized entity reconfiguration</p>
                                </div>
                                <button onClick={() => setIsEditModalOpen(false)} className="text-slate-500 hover:text-white transition-colors p-2">
                                    <span className="material-symbols-outlined">close</span>
                                </button>
                            </div>
                            <form onSubmit={handleEditUserSubmit} className="space-y-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Username</label>
                                    <input className="w-full bg-slate-800/50 border border-white/5 rounded-lg px-4 py-3 text-slate-400 cursor-not-allowed" disabled type="text" value={editUser.username} />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">New Password (Optional)</label>
                                    <input className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary/50 transition-all" placeholder="Leave empty to keep current" type="password" value={editUser.password} onChange={e => setEditUser({...editUser, password: e.target.value})} />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Expiry Date & Time</label>
                                    <input className="w-full bg-slate-900 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary transition-all appearance-none" type="datetime-local" value={editUser.expiry_date} onChange={e => setEditUser({...editUser, expiry_date: e.target.value})} />
                                </div>
                                <div className="flex items-center gap-3 p-4 bg-slate-900/50 rounded-xl border border-white/5 transition-all hover:border-primary/20">
                                    <div className="flex-1">
                                        <h5 className="text-xs font-bold text-white uppercase tracking-wider">HWID Lock</h5>
                                        <p className="text-[10px] text-slate-500 mt-0.5">Restrict access to specific hardware</p>
                                    </div>
                                    <input className="accent-primary size-5 rounded border-white/10 bg-slate-900" type="checkbox" checked={editUser.hwid_lock} onChange={e => setEditUser({...editUser, hwid_lock: e.target.checked})} />
                                </div>
                                <div className="pt-6">
                                    <button type="submit" className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black py-4 rounded-xl transition-all shadow-[0_0_20px_rgba(37,99,235,0.3)] flex items-center justify-center gap-2 group uppercase tracking-widest text-xs border border-blue-500/30">
                                        <span>Commit Changes</span>
                                        <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">save</span>
                                    </button>
                                </div>
                            </form>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>

            <ConfirmModal 
                isOpen={confirmModal.isOpen} 
                title={confirmModal.title} 
                message={confirmModal.message} 
                type={confirmModal.type} 
                onConfirm={confirmModal.onConfirm} 
                onCancel={() => setConfirmModal({ ...confirmModal, isOpen: false })} 
            />
        </div>
    );
};

export default Users;
