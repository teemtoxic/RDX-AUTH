import os
import glob

def fix_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Replace literal \` with `
    content = content.replace('\\`', '`')
    # Replace literal \$ with $
    content = content.replace('\\$', '$')
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"Fixed {filepath}")

for filepath in glob.glob("c:/Users/Administrator/Desktop/SERVER/FRONTEND/src/**/*.jsx", recursive=True):
    fix_file(filepath)
