# RDX Public API Documentation

This document explains the public APIs available on your server. Since you are hosting on a domain, the endpoints remain the same but do not require port numbers in the URL.

## 1. SDK Integration APIs (KeyAuth Compatible)
These endpoints are designed for the C# and C++ SDKs to interact with the server.

| Purpose | Endpoint | Method | Key Parameters |
|---------|----------|--------|----------------|
| **Init** | `/api/1.3/` | POST | `type=init`, `appid`, `name`, `secret` |
| **Login** | `/api/1.3/` | POST | `type=login`, `username`, `pass`, `hwid` |
| **Register** | `/api/1.3/` | POST | `type=register`, `username`, `pass`, `key` |

---

## 2. RDX Native Dashboard APIs
Used by the web interface and for extended functionality.

### Variable Management
- **URL**: `/rdx/api/variables`
- **Description**: Fetches dynamic variables (like offsets, settings) for your applications.
- **Security**: Protected by JWT and Integrity headers.

### License Validation (Direct)
- **URL**: `/rdx/api/licenses/validate`
- **Description**: Lightweight endpoint to check if a key is still active without full user login.

---

## 3. HWID Reset Request System
### Submit Request
- **URL**: `/rdx/api/hwid-reset/request`
- **Method**: `POST`
- **Body**: `{ "app_id": "1", "reason": "Hardware upgrade" }`
- **Description**: Submits a request to the server owner to clear the HWID lock for a specific app.

### List Requests (Admin/Owner)
- **URL**: `/rdx/api/hwid-reset/list`
- **Method**: `GET`
- **Description**: Returns pending requests for the owner's applications.

---

> [!TIP]
> **Domain Usage**: Since you are using a domain, your API calls will look like `https://yourdomain.com/api/1.3/`. No port (e.g., `:5000`) is needed as standard HTTPS uses port 443.
