const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const dbPath = process.env.DB_FILE ? path.resolve(process.env.DB_FILE) : path.join(__dirname, '../database/rdx_auth.db');
console.log(`[RDX] Database Path: ${dbPath}`);

let dbInstance = null;

async function getDb() {
    if (dbInstance) return dbInstance;

    dbInstance = await open({
        filename: dbPath,
        driver: sqlite3.Database
    });

    // Optimize SQLite for better concurrency and multi-AI access
    await dbInstance.exec('PRAGMA journal_mode = WAL');
    await dbInstance.exec('PRAGMA synchronous = NORMAL');
    await dbInstance.exec('PRAGMA cache_size = -10000'); // ~10MB cache
    await dbInstance.exec('PRAGMA busy_timeout = 5000'); // 5s timeout to handle locking

    return dbInstance;
}

async function initDb() {
    const db = await getDb();

    // Create Apps Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS apps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            owner_id INTEGER,
            owner_key TEXT UNIQUE NOT NULL,
            secret TEXT NOT NULL,
            version TEXT DEFAULT '1.0.0',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Create unique index for app name scoped to owner (allows different owners to have same app names)
    try {
        await db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_apps_name_owner ON apps(name, owner_id)');
    } catch (e) {
        console.error('[RDX DB Migration] Failed to create scoped app index:', e.message);
    }

    // Create Users Table
    await db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        email TEXT UNIQUE,
        google_id TEXT UNIQUE,
        password_hash TEXT,
        status TEXT DEFAULT 'active',
        role TEXT DEFAULT 'user',
        plan TEXT DEFAULT 'starter',
        expiry_date TIMESTAMP,
        email_verified INTEGER DEFAULT 0,
        verify_token TEXT,
        reset_token TEXT,
        reset_expires BIGINT,
        failed_logins INTEGER DEFAULT 0,
        locked_until BIGINT,
        two_factor_secret TEXT,
        two_factor_enabled INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);

    // Active Sessions Table
    await db.run(`CREATE TABLE IF NOT EXISTS active_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        jti TEXT UNIQUE,
        hwid TEXT,
        ip_address TEXT,
        user_agent TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        expires_at BIGINT,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`);

    // Schema Migrations
    // Helper function to check if a column exists
    async function columnExists(tableName, columnName) {
        const columns = await db.all(`PRAGMA table_info(${tableName})`);
        return columns.some(col => col.name === columnName);
    }

    // Users Table Migrations
    if (!(await columnExists('users', 'google_id'))) { try { await db.exec('ALTER TABLE users ADD COLUMN google_id TEXT UNIQUE'); } catch (e) { } }
    if (!(await columnExists('users', 'email'))) { try { await db.exec('ALTER TABLE users ADD COLUMN email TEXT UNIQUE'); } catch (e) { } }
    if (!(await columnExists('users', 'status'))) { try { await db.exec('ALTER TABLE users ADD COLUMN status TEXT DEFAULT "active"'); } catch (e) { } }
    if (!(await columnExists('users', 'plan'))) { try { await db.exec('ALTER TABLE users ADD COLUMN plan TEXT DEFAULT "starter"'); } catch (e) { } }
    if (!(await columnExists('users', 'app_id'))) { try { await db.exec('ALTER TABLE users ADD COLUMN app_id INTEGER'); } catch (e) { } }
    if (!(await columnExists('users', 'expiry_date'))) { try { await db.exec('ALTER TABLE users ADD COLUMN expiry_date TIMESTAMP'); } catch (e) { } }
    if (!(await columnExists('users', 'hwid'))) { try { await db.exec('ALTER TABLE users ADD COLUMN hwid TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'hwid_lock'))) { try { await db.exec('ALTER TABLE users ADD COLUMN hwid_lock INTEGER DEFAULT 0'); } catch (e) { } }
    if (!(await columnExists('users', 'last_active'))) { try { await db.exec('ALTER TABLE users ADD COLUMN last_active TIMESTAMP'); } catch (e) { } }
    if (!(await columnExists('users', 'ai_token'))) { try { await db.exec('ALTER TABLE users ADD COLUMN ai_token TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'ai_alignment_prompt'))) { try { await db.exec('ALTER TABLE users ADD COLUMN ai_alignment_prompt TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'ai_rule_base'))) { try { await db.exec('ALTER TABLE users ADD COLUMN ai_rule_base TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'ai_mode'))) { try { await db.exec('ALTER TABLE users ADD COLUMN ai_mode TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'discord_id'))) { try { await db.exec('ALTER TABLE users ADD COLUMN discord_id TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'discord_log_channel_id'))) { try { await db.exec('ALTER TABLE users ADD COLUMN discord_log_channel_id TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'email_verified'))) { try { await db.exec('ALTER TABLE users ADD COLUMN email_verified INTEGER DEFAULT 0'); } catch (e) { } }
    if (!(await columnExists('users', 'verify_token'))) { try { await db.exec('ALTER TABLE users ADD COLUMN verify_token TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'reset_token'))) { try { await db.exec('ALTER TABLE users ADD COLUMN reset_token TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'reset_expires'))) { try { await db.exec('ALTER TABLE users ADD COLUMN reset_expires BIGINT'); } catch (e) { } }
    if (!(await columnExists('users', 'failed_logins'))) { try { await db.exec('ALTER TABLE users ADD COLUMN failed_logins INTEGER DEFAULT 0'); } catch (e) { } }
    if (!(await columnExists('users', 'locked_until'))) { try { await db.exec('ALTER TABLE users ADD COLUMN locked_until BIGINT'); } catch (e) { } }
    if (!(await columnExists('users', 'two_factor_secret'))) { try { await db.exec('ALTER TABLE users ADD COLUMN two_factor_secret TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'two_factor_enabled'))) { try { await db.exec('ALTER TABLE users ADD COLUMN two_factor_enabled INTEGER DEFAULT 0'); } catch (e) { } }
    if (!(await columnExists('users', 'two_factor_type'))) { try { await db.exec('ALTER TABLE users ADD COLUMN two_factor_type TEXT DEFAULT "totp"'); } catch (e) { } }
    if (!(await columnExists('users', 'telegram_chat_id'))) { try { await db.exec('ALTER TABLE users ADD COLUMN telegram_chat_id TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'two_factor_backup_codes'))) { try { await db.exec('ALTER TABLE users ADD COLUMN two_factor_backup_codes TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'recovery_otp'))) { try { await db.exec('ALTER TABLE users ADD COLUMN recovery_otp TEXT'); } catch (e) { } }
    if (!(await columnExists('users', 'recovery_otp_expires'))) { try { await db.exec('ALTER TABLE users ADD COLUMN recovery_otp_expires BIGINT'); } catch (e) { } }
    if (!(await columnExists('users', 'recovery_token'))) { try { await db.exec('ALTER TABLE users ADD COLUMN recovery_token TEXT'); } catch (e) { } }

    // Indexes for users table
    try { await db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_google_id ON users(google_id)'); } catch (e) { }
    try { await db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email)'); } catch (e) { }

    // Plan Requests Table Migrations
    if (!(await columnExists('plan_requests', 'amount'))) { try { await db.exec('ALTER TABLE plan_requests ADD COLUMN amount INTEGER DEFAULT 0'); } catch (e) { } }

    // Create Licenses Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS licenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            license_key TEXT UNIQUE NOT NULL,
            app_id INTEGER,
            user_id INTEGER,
            hwid TEXT,
            hwid_baseboard TEXT,
            hwid_cpu TEXT,
            hwid_mac TEXT,
            hwid_lock INTEGER DEFAULT 1,
            expiry_date TIMESTAMP,
            duration INTEGER,
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (app_id) REFERENCES apps(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    `);

    // Create Logs Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            app_id INTEGER,
            action TEXT NOT NULL,
            ip TEXT,
            hwid TEXT,
            user_agent TEXT,
            location TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (app_id) REFERENCES apps(id)
        )
    `);

    // Migrations for logs table
    if (!(await columnExists('logs', 'user_agent'))) { try { await db.exec('ALTER TABLE logs ADD COLUMN user_agent TEXT'); } catch (e) { } }
    if (!(await columnExists('logs', 'location'))) { try { await db.exec('ALTER TABLE logs ADD COLUMN location TEXT'); } catch (e) { } }

    // Create Variables Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS variables (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            app_id INTEGER,
            name TEXT NOT NULL,
            value TEXT NOT NULL,
            FOREIGN KEY (app_id) REFERENCES apps(id)
        )
    `);

    // Create App Resellers Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS app_resellers (
            app_id INTEGER,
            user_id INTEGER,
            PRIMARY KEY (app_id, user_id),
            FOREIGN KEY (app_id) REFERENCES apps(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    `);

    // Create App Subscriptions Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS app_subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            app_id INTEGER,
            name TEXT NOT NULL,
            level INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (app_id) REFERENCES apps(id) ON DELETE CASCADE
        )
    `);

    // Schema Migrations for subscription_id
    try { await db.exec('ALTER TABLE users ADD COLUMN subscription_id INTEGER'); } catch (e) { }
    try { await db.exec('ALTER TABLE licenses ADD COLUMN subscription_id INTEGER'); } catch (e) { }

    // Create Blacklist Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS blacklist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL, -- 'ip' or 'hwid'
            value TEXT NOT NULL UNIQUE,
            reason TEXT,
            app_id INTEGER, -- Optional: NULL for global
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (app_id) REFERENCES apps(id)
        )
    `);

    // Create Plan Requests Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS plan_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            plan TEXT NOT NULL,
            transaction_id TEXT NOT NULL,
            amount INTEGER DEFAULT 0,
            status TEXT DEFAULT 'pending', -- pending, approved, rejected
            admin_note TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    `);

    // Schema Migrations for Licenses
    try { await db.exec('ALTER TABLE licenses ADD COLUMN duration INTEGER'); } catch (e) { }
    try { await db.exec('ALTER TABLE licenses ADD COLUMN expiry_date TIMESTAMP'); } catch (e) { }
    try { await db.exec('ALTER TABLE licenses ADD COLUMN hwid_baseboard TEXT'); } catch (e) { }
    try { await db.exec('ALTER TABLE licenses ADD COLUMN hwid_cpu TEXT'); } catch (e) { }
    try { await db.exec('ALTER TABLE licenses ADD COLUMN hwid_mac TEXT'); } catch (e) { }

    // Security Schema Migrations for Apps
    try { await db.exec('ALTER TABLE apps ADD COLUMN vpn_detection INTEGER DEFAULT 0'); } catch (e) { }
    try { await db.exec('ALTER TABLE apps ADD COLUMN debugger_detection INTEGER DEFAULT 0'); } catch (e) { }
    try { await db.exec('ALTER TABLE apps ADD COLUMN integrity_check INTEGER DEFAULT 0'); } catch (e) { }
    try { await db.exec('ALTER TABLE apps ADD COLUMN force_update INTEGER DEFAULT 0'); } catch (e) { }
    try { await db.exec('ALTER TABLE apps ADD COLUMN anti_vm INTEGER DEFAULT 0'); } catch (e) { }
    try { await db.exec('ALTER TABLE apps ADD COLUMN anti_debug INTEGER DEFAULT 0'); } catch (e) { }

    // Create System Settings Table (if not exists)
    await db.exec(`
        CREATE TABLE IF NOT EXISTS system_settings (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Initialize Maintenance Settings
    await db.run("INSERT OR IGNORE INTO system_settings (key, value) VALUES ('maintenance_mode', '0')");
    await db.run("INSERT OR IGNORE INTO system_settings (key, value) VALUES ('maintenance_until', '')");
    await db.run("INSERT OR IGNORE INTO system_settings (key, value) VALUES ('auto_delete_expired_licenses', '0')");

    // Performance Indexes
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_licenses_user_id ON licenses(user_id)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_licenses_app_id ON licenses(app_id)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_apps_owner_id ON apps(owner_id)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_logs_user_id ON logs(user_id)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_logs_app_id ON logs(app_id)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON logs(timestamp)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_users_app_id ON users(app_id)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_users_expiry ON users(expiry_date)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_variables_app_id ON variables(app_id)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_blacklist_value ON blacklist(value)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_blacklist_app_id ON blacklist(app_id)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_plan_requests_user_id ON plan_requests(user_id)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_plan_requests_status ON plan_requests(status)'); } catch (e) { }
    try { await db.exec('CREATE INDEX IF NOT EXISTS idx_logs_action ON logs(action)'); } catch (e) { }

    // Enable Foreign Keys
    try { await db.exec('PRAGMA foreign_keys = ON'); } catch (e) { }

    // AI Conversation Memory
    await db.run(`CREATE TABLE IF NOT EXISTS ai_conversations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        discord_id TEXT NOT NULL,
        role TEXT NOT NULL, -- 'user' or 'assistant'
        content TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Key Distribution System (Unified from RESOURCES)
    await db.exec(`
        CREATE TABLE IF NOT EXISTS chains (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_id INTEGER,
            name TEXT NOT NULL,
            isActive INTEGER DEFAULT 0,
            FOREIGN KEY (owner_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS shorteners (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chainId INTEGER,
            name TEXT NOT NULL,
            baseUrl TEXT NOT NULL,
            apiToken TEXT NOT NULL,
            orderIndex INTEGER DEFAULT 0,
            FOREIGN KEY (chainId) REFERENCES chains(id)
        );

        CREATE TABLE IF NOT EXISTS distribution_sessions (
            sessionId TEXT PRIMARY KEY,
            owner_id INTEGER,
            hwid TEXT,
            ipAddress TEXT,
            key TEXT,
            status TEXT DEFAULT 'pending',
            apiType TEXT,
            currentStep INTEGER DEFAULT 0,
            totalSteps INTEGER DEFAULT 0,
            timestamp INTEGER,
            expiresAt INTEGER,
            FOREIGN KEY (owner_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS redistribution_settings (
            owner_id INTEGER PRIMARY KEY,
            key_prefix TEXT DEFAULT 'RDX_V3_',
            expiration_hours INTEGER DEFAULT 12,
            FOREIGN KEY (owner_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS shortened_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_id INTEGER,
            alias TEXT UNIQUE NOT NULL,
            target_url TEXT NOT NULL,
            views INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (owner_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS discord_moderation_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_id INTEGER,
            discord_user_id TEXT NOT NULL,
            discord_username TEXT NOT NULL,
            action_type TEXT NOT NULL,
            reason TEXT,
            action_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            resolved INTEGER DEFAULT 0,
            FOREIGN KEY (owner_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS hwid_reset_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            app_id INTEGER NOT NULL,
            reason TEXT,
            status TEXT DEFAULT 'pending', -- pending, approved, rejected
            admin_note TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (app_id) REFERENCES apps(id) ON DELETE CASCADE
        );
    `);

    // Migrations for existing tables
    try { await db.exec('ALTER TABLE chains ADD COLUMN owner_id INTEGER'); } catch (e) { }
    try { await db.exec('ALTER TABLE distribution_sessions ADD COLUMN owner_id INTEGER'); } catch (e) { }
    try { await db.exec('ALTER TABLE distribution_sessions ADD COLUMN currentStep INTEGER DEFAULT 0'); } catch (e) { }
    try { await db.exec('ALTER TABLE distribution_sessions ADD COLUMN totalSteps INTEGER DEFAULT 0'); } catch (e) { }
    try { await db.exec('ALTER TABLE distribution_sessions ADD COLUMN last_step_time INTEGER'); } catch (e) { }
    try { await db.exec('ALTER TABLE active_sessions ADD COLUMN hwid TEXT'); } catch (e) { }

    // Create Scheduled Tasks Table
    await db.exec(`
        CREATE TABLE IF NOT EXISTS scheduled_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_id INTEGER,
            action TEXT NOT NULL,
            payload TEXT,
            cron_expression TEXT NOT NULL,
            is_active INTEGER DEFAULT 1,
            last_run TIMESTAMP,
            next_run TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
        )
    `);

    console.log('[RDX] Database initialized successfully.');
    return db;
}

module.exports = { getDb, initDb };