# RDX Website Hosting Setup (Cloudflare Tunnel)

Aapki website ko public karne ke liye niche diye gaye steps follow karein:

### Step 1: Login to Cloudflare
Terminal (CMD/PowerShell) mein niche wala command run karein. Ye ek browser window kholega jahan aapko apna Cloudflare account login karna hai.
```powershell
.\cloudflared.exe login
```

### Step 2: Tunnel Create Karna
Login karne ke baad mujhe batayein, main aapke liye ye commands run karunga:
1. `.\cloudflared.exe tunnel create rdx-server`
2. `.\cloudflared.exe tunnel route dns rdx-server rdxcommunity.qzz.io`
3. `.\cloudflared.exe tunnel route dns rdx-server admin.rdxcommunity.qzz.io`
4. `.\cloudflared.exe tunnel run rdx-server --url http://localhost:5000`

### Step 3: Website Live!
Iske baad aapki website **HTTPS** ke saath puri duniya ke liye live ho jayegi.

> [!NOTE]
> Server (node index.js) background mein chalu rehna chahiye.
