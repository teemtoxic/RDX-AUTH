const express = require('express');
const router = express.Router();
const taskController = require('../controllers/taskController');
const authMiddleware = require('../middleware/authMiddleware');
const isAdmin = require('../middleware/adminMiddleware');
const decryptPayload = require('../middleware/encryptionMiddleware');

router.use(authMiddleware);
router.use(isAdmin);

router.get('/', taskController.getTasks);
router.post('/create', decryptPayload, taskController.createTask);
router.delete('/:id', taskController.deleteTask);
router.post('/:id/toggle', taskController.toggleTaskStatus);

module.exports = router;
