const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');

router.use((req, res, next) => {
    console.log('[AUTH ROUTER] Method:', req.method, 'URL:', req.url, 'Path:', req.path);
    next();
});

router.get('/me', authMiddleware, authController.getMe);
router.post('/update-profile', authMiddleware, authController.updateProfile);
router.get('/billing-history', authMiddleware, authController.getBillingHistory);
router.get('/config/discord', authController.getDiscordConfig);
router.post('/config/discord', authMiddleware, authController.saveDiscordConfig);
router.get('/discord/moderation-logs', authMiddleware, authController.getDiscordModerationLogs);
router.post('/discord/unban', authMiddleware, authController.unbanDiscordUser);
router.post('/delete-account', authMiddleware, authController.deleteAccount);
router.post('/logout-all', authMiddleware, authController.logoutAll);
router.post('/resend-verification', authMiddleware, authController.resendVerification);
router.get('/logs', authMiddleware, authController.getLogs);

// 2FA Routes
router.get('/2fa/setup', authMiddleware, authController.setup2FA);
router.post('/2fa/enable', authMiddleware, authController.enable2FA);
router.post('/2fa/disable', authMiddleware, authController.disable2FA);
router.post('/2fa/verify-login', authController.verify2FALogin);

router.post('/register', authController.register);
router.post('/register-key', authController.registerWithKey);
router.post('/login', authController.login);
router.post('/forgot-password', authController.forgotPassword);
router.post('/reset-password', authController.resetPassword);

// OTP-based recovery (Preferred)
router.post('/recovery/send-otp', authController.sendRecoveryOTP);
router.post('/recovery/verify-otp', authController.verifyRecoveryOTP);
router.post('/recovery/reset-password', authController.resetPasswordWithOTP);

router.get('/verify-email', authController.verifyEmail);

console.log('[RDX] Auth Routes Loaded');
// Google uses POST for redirect mode
router.post('/google/callback', authController.googleCallback);
router.post('/google', authController.googleLogin);

module.exports = router;
