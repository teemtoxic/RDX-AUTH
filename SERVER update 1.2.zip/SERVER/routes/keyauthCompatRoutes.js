const express = require('express');
const router = express.Router();
const keyauthCompatController = require('../controllers/keyauthCompatController');

// All KeyAuth requests from C# hit this single endpoint via POST
router.post('/1.3/', keyauthCompatController.handleRequest);

module.exports = router;
