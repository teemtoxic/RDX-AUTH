const express = require('express');
const router = express.Router();
const aiController = require('../controllers/aiController');

// Public verify (limited data)
router.get('/verify/:accountId', aiController.verifyAIStatus);

// Secure execute (requires Pro plan check inside)
router.post('/execute', aiController.executeAIAction);

console.log('[RDX] AI Routes Loaded');

module.exports = router;
