const express = require('express');
const router = express.Router();
const path = require('path');
const { getDb } = require('../config/db');
const authenticate = require('../middleware/authMiddleware');

// Apply authentication to all routes in this router
router.use(authenticate);

// GET /rdx/api/key-dist/stats
router.get('/stats', async (req, res) => {
    try {
        const db = await getDb();
        const ownerId = req.user.id;

        const totalEver = await db.get('SELECT COUNT(*) as count FROM distribution_sessions WHERE owner_id = ?', [ownerId]);
        const complete = await db.get('SELECT COUNT(*) as count FROM distribution_sessions WHERE status = "verified" AND hwid IS NULL AND owner_id = ?', [ownerId]);
        const activate = await db.get('SELECT COUNT(*) as count FROM distribution_sessions WHERE status = "verified" AND hwid IS NOT NULL AND owner_id = ?', [ownerId]);
        const pending = await db.get('SELECT COUNT(*) as count FROM distribution_sessions WHERE status = "pending" AND owner_id = ?', [ownerId]);
        const totalViewsData = await db.get('SELECT SUM(views) as total FROM shortened_links WHERE owner_id = ?', [ownerId]);
        const totalViews = totalViewsData && totalViewsData.total ? totalViewsData.total : 0;

        res.json({
            success: true,
            stats: {
                total: totalEver ? totalEver.count : 0,
                complete: complete ? complete.count : 0,
                activate: activate ? activate.count : 0,
                pending: pending ? pending.count : 0,
                totalViews: totalViews
            }
        });
    } catch (error) {
        console.error('[RDX KeyDist API] Error:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error', error: error.message });
    }
});

// --- CAMPAIGN (CHAINS) ROUTES ---

// GET /rdx/api/key-dist/chains
router.get('/chains', async (req, res) => {
    try {
        const db = await getDb();
        const chains = await db.all('SELECT * FROM chains WHERE owner_id = ? ORDER BY id DESC', [req.user.id]);
        res.json({ success: true, chains });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// POST /rdx/api/key-dist/chains
router.post('/chains', async (req, res) => {
    const { name } = req.body || {};
    try {
        const db = await getDb();
        await db.run('INSERT INTO chains (name, owner_id, isActive) VALUES (?, ?, 0)', [name, req.user.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// PUT /rdx/api/key-dist/chains/:id/activate
router.put('/chains/:id/activate', async (req, res) => {
    const { id } = req.params;
    try {
        const db = await getDb();
        const ownerId = req.user.id;

        // Verify ownership before activating
        const chain = await db.get('SELECT id FROM chains WHERE id = ? AND owner_id = ?', [id, ownerId]);
        if (!chain) return res.status(403).json({ success: false, message: 'Unauthorized' });

        await db.run('UPDATE chains SET isActive = 0 WHERE owner_id = ?', [ownerId]);
        await db.run('UPDATE chains SET isActive = 1 WHERE id = ? AND owner_id = ?', [id, ownerId]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// DELETE /rdx/api/key-dist/chains/:id
router.delete('/chains/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const db = await getDb();
        const ownerId = req.user.id;

        // Verify ownership
        const chain = await db.get('SELECT id FROM chains WHERE id = ? AND owner_id = ?', [id, ownerId]);
        if (!chain) return res.status(403).json({ success: false, message: 'Unauthorized' });

        await db.run('DELETE FROM shorteners WHERE chainId = ?', [id]);
        await db.run('DELETE FROM chains WHERE id = ? AND owner_id = ?', [id, ownerId]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// --- SHORTENER (STEPS) ROUTES ---

// GET /rdx/api/key-dist/chains/:chainId/shorteners
router.get('/chains/:chainId/shorteners', async (req, res) => {
    const { chainId } = req.params;
    try {
        const db = await getDb();
        const ownerId = req.user.id;

        // Verify chain ownership
        const chain = await db.get('SELECT id FROM chains WHERE id = ? AND owner_id = ?', [chainId, ownerId]);
        if (!chain) return res.status(403).json({ success: false, message: 'Unauthorized' });

        const shorteners = await db.all('SELECT * FROM shorteners WHERE chainId = ? ORDER BY orderIndex ASC, id ASC', [chainId]);
        res.json({ success: true, shorteners });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// POST /rdx/api/key-dist/shorteners
router.post('/shorteners', async (req, res) => {
    const { name, baseUrl, apiToken, chainId } = req.body || {};
    try {
        const db = await getDb();
        const ownerId = req.user.id;

        // Verify chain ownership
        const chain = await db.get('SELECT id FROM chains WHERE id = ? AND owner_id = ?', [chainId, ownerId]);
        if (!chain) return res.status(403).json({ success: false, message: 'Unauthorized' });

        // Get current max index for this chain
        const max = await db.get('SELECT MAX(orderIndex) as maxInd FROM shorteners WHERE chainId = ?', [chainId]);
        const nextIndex = (max && max.maxInd !== null) ? max.maxInd + 1 : 0;

        await db.run(
            'INSERT INTO shorteners (name, baseUrl, apiToken, orderIndex, chainId) VALUES (?, ?, ?, ?, ?)',
            [name, baseUrl, apiToken, nextIndex, chainId]
        );
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// PUT /rdx/api/key-dist/shorteners/reorder
router.put('/shorteners/reorder', async (req, res) => {
    const { id, direction, chainId } = req.body || {};
    try {
        const db = await getDb();
        const ownerId = req.user.id;

        // Verify chain/shortener ownership
        const current = await db.get('SELECT s.* FROM shorteners s JOIN chains c ON s.chainId = c.id WHERE s.id = ? AND c.owner_id = ?', [id, ownerId]);
        if (!current) return res.status(403).json({ success: false, message: 'Unauthorized or Node not found' });

        let other;
        if (direction === 'up') {
            other = await db.get('SELECT * FROM shorteners WHERE chainId = ? AND orderIndex < ? ORDER BY orderIndex DESC LIMIT 1', [chainId || current.chainId, current.orderIndex]);
        } else {
            other = await db.get('SELECT * FROM shorteners WHERE chainId = ? AND orderIndex > ? ORDER BY orderIndex ASC LIMIT 1', [chainId || current.chainId, current.orderIndex]);
        }

        if (other) {
            await db.run('UPDATE shorteners SET orderIndex = ? WHERE id = ?', [other.orderIndex, current.id]);
            await db.run('UPDATE shorteners SET orderIndex = ? WHERE id = ?', [current.orderIndex, other.id]);
            res.json({ success: true });
        } else {
            res.json({ success: false, message: 'Nowhere to move' });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// DELETE /rdx/api/key-dist/shorteners/:id
router.delete('/shorteners/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const db = await getDb();
        const ownerId = req.user.id;

        // Verify ownership
        const current = await db.get('SELECT s.id FROM shorteners s JOIN chains c ON s.chainId = c.id WHERE s.id = ? AND c.owner_id = ?', [id, ownerId]);
        if (!current) return res.status(403).json({ success: false, message: 'Unauthorized' });

        await db.run('DELETE FROM shorteners WHERE id = ?', [id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// --- SHORTENED LINKS ROUTES ---

// GET /rdx/api/key-dist/shorten
router.get('/shorten', async (req, res) => {
    try {
        const db = await getDb();
        const links = await db.all('SELECT * FROM shortened_links WHERE owner_id = ? ORDER BY created_at DESC', [req.user.id]);
        res.json({ success: true, links });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// POST /rdx/api/key-dist/shorten
router.post('/shorten', async (req, res) => {
    const { target_url, alias } = req.body || {};
    try {
        if (!target_url) return res.status(400).json({ success: false, message: 'Missing target URL' });
        const db = await getDb();
        const ownerId = req.user.id;

        let linkAlias = alias;
        if (!linkAlias) {
            const crypto = require('crypto');
            linkAlias = crypto.randomBytes(4).toString('hex');
        }

        const existing = await db.get('SELECT id FROM shortened_links WHERE alias = ?', [linkAlias]);
        if (existing) {
            return res.status(400).json({ success: false, message: 'Alias already in use. Please choose another.' });
        }

        await db.run('INSERT INTO shortened_links (owner_id, alias, target_url) VALUES (?, ?, ?)', [ownerId, linkAlias, target_url]);

        const protocol = req.headers['x-forwarded-proto'] || req.protocol;
        const host = req.get('host');
        const shortenedUrl = `${protocol}://${host}/s/${linkAlias}`;

        res.json({ success: true, url: shortenedUrl });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// DELETE /rdx/api/key-dist/shorten/:id
router.delete('/shorten/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const db = await getDb();
        await db.run('DELETE FROM shortened_links WHERE id = ? AND owner_id = ?', [id, req.user.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// --- KEY MANAGEMENT ROUTES ---

// GET /rdx/api/key-dist/keys
router.get('/keys', async (req, res) => {
    try {
        const db = await getDb();
        const ownerId = req.user.id;

        // Fetch last 500 keys for management, filtered by owner
        const keys = await db.all('SELECT * FROM distribution_sessions WHERE owner_id = ? ORDER BY timestamp DESC LIMIT 500', [ownerId]);
        res.json({ success: true, keys });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// DELETE /rdx/api/key-dist/keys/:sessionId
router.delete('/keys/:sessionId', async (req, res) => {
    const { sessionId } = req.params;
    try {
        const db = await getDb();
        const ownerId = req.user.id;

        await db.run('DELETE FROM distribution_sessions WHERE sessionId = ? AND owner_id = ?', [sessionId, ownerId]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// PUT /rdx/api/key-dist/keys/:sessionId/status
router.put('/keys/:sessionId/status', async (req, res) => {
    const { sessionId } = req.params;
    const { status } = req.body || {};
    try {
        const db = await getDb();
        const ownerId = req.user.id;

        await db.run('UPDATE distribution_sessions SET status = ? WHERE sessionId = ? AND owner_id = ?', [status, sessionId, ownerId]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// --- SETTINGS ROUTES ---

// GET /rdx/api/key-dist/settings
router.get('/settings', async (req, res) => {
    try {
        const db = await getDb();
        const ownerId = req.user.id;

        let settings = await db.get('SELECT * FROM redistribution_settings WHERE owner_id = ?', [ownerId]);
        if (!settings) {
            // Default settings if not exist
            settings = { key_prefix: 'RDX_V3_', expiration_hours: 12 };
        }
        res.json({ success: true, settings });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// POST /rdx/api/key-dist/settings
router.post('/settings', async (req, res) => {
    const { key_prefix, expiration_hours } = req.body || {};
    try {
        const db = await getDb();
        const ownerId = req.user.id;

        await db.run(
            `INSERT INTO redistribution_settings (owner_id, key_prefix, expiration_hours) 
             VALUES (?, ?, ?) 
             ON CONFLICT(owner_id) DO UPDATE SET key_prefix = excluded.key_prefix, expiration_hours = excluded.expiration_hours`,
            [ownerId, key_prefix || 'RDX_V3_', parseInt(expiration_hours) || 12]
        );
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

module.exports = router;
