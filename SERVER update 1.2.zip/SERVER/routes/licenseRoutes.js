const express = require('express');
const router = express.Router();
const licenseController = require('../controllers/licenseController');
const authMiddleware = require('../middleware/authMiddleware');

// Public validation endpoint (used by the software/injector)
router.post('/validate', licenseController.validateLicense);

// Protected generation endpoint (used by Admin/Reseller)
router.post('/generate', authMiddleware, licenseController.generateLicense);

module.exports = router;
