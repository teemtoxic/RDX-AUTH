const express = require('express');
const router = express.Router();
const resellerController = require('../controllers/resellerController');
const authMiddleware = require('../middleware/authMiddleware');

router.get('/my-apps', authMiddleware, resellerController.getMyApps);
router.post('/add', authMiddleware, resellerController.addReseller);

module.exports = router;
