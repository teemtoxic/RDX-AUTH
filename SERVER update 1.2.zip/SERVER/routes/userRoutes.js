const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const authenticate = require('../middleware/authMiddleware');

// /rdx/api/apps
router.get('/apps', authenticate, userController.getUserApps);
router.post('/apps', authenticate, userController.createApp);
router.delete('/apps/:id', authenticate, userController.deleteApp);

// /rdx/api/subscriptions
router.get('/subscriptions', authenticate, userController.getSubscriptions);
router.post('/subscriptions', authenticate, userController.createSubscription);
router.delete('/subscriptions/:id', authenticate, userController.deleteSubscription);

// /rdx/api/licenses
router.get('/licenses', authenticate, userController.getUserLicenses);
router.post('/licenses/create', authenticate, userController.createLicense);
router.delete('/licenses/:id', authenticate, userController.deleteLicense);
router.post('/licenses/:id/reset', authenticate, userController.resetLicenseHwid);
router.post('/licenses/:id/status', authenticate, userController.updateLicenseStatus);

// /rdx/api/stats
router.get('/stats', authenticate, userController.getUserStats);

// /rdx/api/analytics
router.get('/analytics', authenticate, userController.getUserAnalytics);

// /rdx/api/logs
router.get('/logs', authenticate, userController.getUserLogs);

// /rdx/api/users
router.get('/users', authenticate, userController.getUserList);
router.post('/users', authenticate, userController.createUser);
router.put('/users/:id', authenticate, userController.updateUser);
router.delete('/users/:id', authenticate, userController.deleteUser);
router.post('/users/:id/reset', authenticate, userController.resetUserHwid);
router.post('/users/:id/status', authenticate, userController.updateUserStatus);

// /rdx/api/plan-request
router.post('/plan-request', authenticate, userController.requestPlan);

// /rdx/api/messages
router.get('/messages', authenticate, userController.getMessages);
router.post('/messages/:messageId/read', authenticate, userController.markMessageRead);

// /rdx/api/hwid-reset
router.post('/hwid-reset/request', authenticate, userController.requestHwidReset);
router.get('/hwid-reset/list', authenticate, userController.getHwidRequests);
router.post('/hwid-reset/approve', authenticate, userController.approveHwidReset);
router.post('/hwid-reset/reject', authenticate, userController.rejectHwidReset);

module.exports = router;
