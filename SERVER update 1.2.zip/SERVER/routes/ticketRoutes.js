const express = require('express');
const router = express.Router();
const ticketController = require('../controllers/ticketController');
const authMiddleware = require('../middleware/authMiddleware');
const adminMiddleware = require('../middleware/adminMiddleware');

const upload = require('../utils/uploadService');

// User Routes
router.post('/upload-attachment', authMiddleware, upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });
    res.json({ success: true, url: `/uploads/tickets/${req.file.filename}` });
});

router.post('/create', authMiddleware, ticketController.createTicket);
router.get('/my-tickets', authMiddleware, ticketController.getMyTickets);
router.get('/:ticketId/messages', authMiddleware, ticketController.getTicketMessages);
router.post('/:ticketId/reply', authMiddleware, ticketController.addMessage);

// Admin Routes
router.get('/admin/all', authMiddleware, adminMiddleware, ticketController.getAllTickets);
router.put('/admin/:ticketId/status', authMiddleware, adminMiddleware, ticketController.updateTicketStatus);
router.post('/admin/bulk-delete', authMiddleware, adminMiddleware, ticketController.bulkDeleteTickets);

module.exports = router;
