const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const authMiddleware = require('../middleware/authMiddleware');

// Middleware to strictly enforce admin role
const isAdmin = (req, res, next) => {
    if (req.user && req.user.role === 'admin') {
        next();
    } else {
        res.status(403).json({ success: false, message: 'Access denied. Admin privileges required.' });
    }
};

// Apply auth + admin check to all routes below
router.use(authMiddleware);
router.use(isAdmin);

// System Stats & Logs
router.get('/test', (req, res) => res.json({ success: true, message: 'Admin API is online' }));
router.get('/logs', adminController.getLogs);
router.get('/stats', adminController.getStats);
router.get('/system-stats', adminController.getStats); // Alias for compatibility with coordination roadmap
router.get('/analytics', adminController.getAnalytics);
router.get('/realtime-traffic', adminController.getRealtimeTraffic);

// App Management
router.get('/apps', adminController.getApps);
router.post('/apps', adminController.createApp);

// User Management
router.get('/users', adminController.getUsers);
router.get('/export/users', adminController.exportUsers);
router.get('/clients/:id/stats', adminController.getClientDetailedStats);
router.post('/users', adminController.createUser);
router.put('/users/:id', adminController.updateUser);
router.delete('/users/:id', adminController.deleteUser);
router.post('/users/:id/status', adminController.updateUserStatus);
router.post('/users/:id/reset', adminController.resetHwid);

// License Management
router.get('/licenses', adminController.getLicenses);
router.post('/licenses/create', adminController.createLicense);
router.delete('/licenses/:id', adminController.deleteLicense);
router.post('/licenses/:id/reset', adminController.resetLicenseHwid);
router.post('/licenses/:id/status', adminController.updateLicenseStatus);

// Message Management
router.post('/messages', adminController.sendMessage);

// Plan Request Management
router.get('/plan-requests', adminController.getPlanRequests);
router.post('/plan-requests/:id/action', adminController.updatePlanRequestStatus);

// Settings Management
router.get('/settings', adminController.getSettings);
router.post('/settings', adminController.updateSettings);

// Administrative Resets
router.post('/reset/users', adminController.resetUsers);
router.post('/reset/licenses', adminController.resetLicenses);
router.post('/reset/clients', adminController.resetClients);
router.post('/reset/apps', adminController.resetApps);
router.post('/reset/dashboard', adminController.resetDashboard);

module.exports = router;
