const express = require('express');
const router = express.Router();
const securityController = require('../controllers/securityController');
const authMiddleware = require('../middleware/authMiddleware');

const isAdmin = (req, res, next) => {
    if (req.user && req.user.role === 'admin') {
        next();
    } else {
        res.status(403).json({ success: false, message: 'Access denied. Admin privileges required.' });
    }
};

router.get('/blacklist', authMiddleware, securityController.getBlacklist);
router.post('/blacklist/add', authMiddleware, securityController.addBlacklist);
router.post('/blacklist/remove', authMiddleware, securityController.removeBlacklist);

router.get('/settings', authMiddleware, securityController.getAppSecurity);
router.post('/settings/update', authMiddleware, securityController.updateAppSecurity);

router.get('/intel', authMiddleware, isAdmin, securityController.getIntel);
router.post('/intel/clear', authMiddleware, isAdmin, securityController.clearIntel);
router.get('/system-settings', authMiddleware, isAdmin, securityController.getSystemSecurity);
router.post('/system-settings/update', authMiddleware, isAdmin, securityController.updateSystemSecurity);

router.get('/app-logins', authMiddleware, securityController.getAppLogins);
router.get('/realtime-traffic', authMiddleware, isAdmin, securityController.getRealtimeTraffic);

module.exports = router;
