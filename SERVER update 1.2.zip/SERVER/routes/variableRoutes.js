const express = require('express');
const router = express.Router();
const variableController = require('../controllers/variableController');
const authMiddleware = require('../middleware/authMiddleware');

router.get('/', variableController.getVariables);
router.post('/update', authMiddleware, variableController.updateVariable);
router.post('/delete', authMiddleware, variableController.deleteVariable);

module.exports = router;
