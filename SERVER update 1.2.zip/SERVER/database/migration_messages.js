const { getDb } = require('../config/db');

async function migrate() {
    try {
        const db = await getDb();
        console.log('Creating messages table...');
        await db.run(`
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender_id INTEGER NOT NULL,
                receiver_id INTEGER NOT NULL,
                content TEXT NOT NULL,
                is_read INTEGER DEFAULT 0,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (sender_id) REFERENCES users(id),
                FOREIGN KEY (receiver_id) REFERENCES users(id)
            )
        `);
        console.log('Migration successful.');
    } catch (error) {
        console.error('Migration failed:', error);
    }
}

migrate();
