const crypto = require('crypto');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const ENCRYPTION_KEY = process.env.PAYLOAD_SECRET || process.env.JWT_SECRET || 'RDX_DEFAULT_SECRET_BASE_123456789';
const IV_LENGTH = 16; // For AES, this is always 16

/**
 * Middleware to decrypt AES-256-CBC encrypted payloads.
 * Expected body: { payload: "iv:encryptedData" }
 */
const decryptPayload = (req, res, next) => {
    if (!req.body.payload || typeof req.body.payload !== 'string') {
        return next(); // Not encrypted or using standard format
    }

    try {
        const textParts = req.body.payload.split(':');
        if (textParts.length !== 2) return next(); // Not encrypted format

        const iv = Buffer.from(textParts.shift(), 'hex');
        const encryptedText = Buffer.from(textParts.join(':'), 'hex');
        
        // Key must be 32 bytes for aes-256-cbc
        const key = crypto.createHash('sha256').update(ENCRYPTION_KEY).digest();
        
        const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
        let decrypted = decipher.update(encryptedText);
        decrypted = Buffer.concat([decrypted, decipher.final()]);

        req.body.payload = JSON.parse(decrypted.toString());
        console.log('[RDX-ENCRYPTION] Payload decrypted successfully.');
        next();
    } catch (err) {
        console.error('[RDX-ENCRYPTION] Decryption failed:', err.message);
        return res.status(400).json({ success: false, message: 'Invalid encrypted payload structure.' });
    }
};

module.exports = decryptPayload;