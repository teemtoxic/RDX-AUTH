const { getDb } = require('../config/db');
const jwt = require('jsonwebtoken');

module.exports = async (req, res, next) => {
    // 1. Skip check for admin routes
    if (req.path.startsWith('/rdx/api/admin')) {
        return next();
    }

    try {
        const db = await getDb();
        const maintenanceMode = await db.get("SELECT value FROM system_settings WHERE key = 'maintenance_mode'");

        if (maintenanceMode && maintenanceMode.value === '1') {
            const maintenanceUntil = await db.get("SELECT value FROM system_settings WHERE key = 'maintenance_until'");
            const now = new Date();
            const until = maintenanceUntil && maintenanceUntil.value ? new Date(maintenanceUntil.value) : null;

            // If "until" is not set, or we are before the "until" time
            if (!until || now < until) {

                // check if user is admin to bypass
                let isAdmin = false;

                // Case A: req.user already populated by previous middleware
                if (req.user && req.user.role === 'admin') {
                    isAdmin = true;
                }
                // Case B: req.user not populated, try to check token manually
                else {
                    const authHeader = req.headers['authorization'];
                    const token = authHeader && authHeader.split(' ')[1];
                    if (token) {
                        try {
                            const decoded = jwt.verify(token, process.env.JWT_SECRET);
                            if (decoded && decoded.role === 'admin') {
                                isAdmin = true;
                                req.user = decoded; // Performance win: populate it for later
                            }
                        } catch (e) { /* ignore invalid token for maintenance check */ }
                    }
                }

                if (!isAdmin) {
                    return res.status(503).json({
                        success: false,
                        maintenance: true,
                        message: 'Server is currently under maintenance.',
                        until: until ? until.toISOString() : null
                    });
                }
            }
        }
        next();
    } catch (error) {
        console.error('[Maintenance Middleware Error]', error);
        next();
    }
};
