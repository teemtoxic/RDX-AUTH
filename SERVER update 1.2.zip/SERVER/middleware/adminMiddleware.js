module.exports = (req, res, next) => {
    const AUTHORIZED_ADMIN = 'noobgameryt12630@gmail.com';

    if (req.user && req.user.role === 'admin' && req.user.email === AUTHORIZED_ADMIN) {
        next();
    } else {
        console.warn(`[RDX SECURITY] Admin access denied for user: ${req.user ? req.user.username : 'Unknown'} (${req.user ? req.user.email : 'No Email'})`);
        res.status(403).json({ success: false, message: 'Access denied. Unauthorized Admin.' });
    }
};
