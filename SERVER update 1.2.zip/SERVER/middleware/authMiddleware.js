const jwt = require('jsonwebtoken');
const { getDb } = require('../config/db');
const fs = require('fs');
const path = require('path');

const LOG_FILE = path.join(__dirname, '../../server.log');

const logToDebug = (msg) => {
    console.error(msg);
    try { fs.appendFileSync(LOG_FILE, `[RDX Auth] ${msg}\n`); } catch(e) {}
};

module.exports = async (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        logToDebug(`Access denied. No token provided for path ${req.originalUrl}`);
        return res.status(401).json({ success: false, message: 'Access denied. No token provided.' });
    }

    try {
        if (!process.env.JWT_SECRET) {
            logToDebug('JWT_SECRET is not defined in process.env');
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        const db = await getDb();
        const user = await db.get('SELECT id FROM users WHERE id = ?', [decoded.id]);

        if (!user) {
            logToDebug(`User ID ${decoded.id} not found in database. Force logging out.`);
            return res.status(401).json({ success: false, message: 'Invalid token. User not found.' });
        }

        if (decoded.jti) {
            const session = await db.get('SELECT id, hwid FROM active_sessions WHERE jti = ? AND user_id = ? AND expires_at > ?', [decoded.jti, decoded.id, Date.now()]);
            if (!session) {
                logToDebug(`Session JTI ${decoded.jti} is invalid or expired. Executing forced logout.`);
                return res.status(401).json({ success: false, message: 'Session expired or revoked.' });
            }

            const clientFp = req.headers['x-rdx-fp'] || req.headers['x-rdx-hwid'] || (req.body && req.body.hwid) || 'WEB_SESSION';
            
            if (session.hwid && session.hwid !== 'WEB_SESSION' && session.hwid !== 'Unknown' && session.hwid !== 'UNKNOWN' && session.hwid !== clientFp) {
                const isWebSessionAuto = session.hwid.startsWith('WEB-') && clientFp === 'WEB_SESSION';
                
                if (!isWebSessionAuto) {
                    logToDebug(`Fingerprint Mismatch for User ${decoded.id}. DB Session HWID: '${session.hwid}', Client FP: '${clientFp}'. Revoking session.`);
                
                    const logService = require('../utils/logService');
                    await logService.recordLog(decoded.id, null, 'SESSION_FINGERPRINT_MISMATCH', req.ip, clientFp, req.headers['user-agent']);
                    
                    await db.run('DELETE FROM active_sessions WHERE jti = ?', [decoded.jti]);
                    return res.status(401).json({ success: false, message: 'Security alert: Hardware identity changed. Session revoked.' });
                }
            }
        }

        req.user = decoded;
        next();
    } catch (error) {
        logToDebug(`Token Verification Failed for token: ${token.substring(0, 10)}... Error: ${error.message}`);
        res.status(401).json({ success: false, message: 'Invalid token or session expired.' });
    }
};
