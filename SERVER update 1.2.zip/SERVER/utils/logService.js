const { getDb } = require('../config/db');

/**
 * Records an activity log in the database.
 */
exports.recordLog = async (user_id, app_id, action, ip = null, hwid = null, user_agent = null, location = null) => {
    try {
        const db = await getDb();
        
        // If location is not provided, we could potentially look it up here if needed, 
        // but for now we expect it from the controller to keep it fast.
        
        await db.run(
            `INSERT INTO logs (user_id, app_id, action, ip, hwid, user_agent, location) VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [user_id, app_id, action, ip, hwid, user_agent, location]
        );
        console.log(`[RDX Log] ${action} (User: ${user_id || 'System'}, App: ${app_id || 'N/A'})`);

        // Discord Broadcast Logic
        let ownerId = null;
        if (app_id) {
            const app = await db.get('SELECT owner_id FROM apps WHERE id = ?', [app_id]);
            if (app) ownerId = app.owner_id;
        } else if (user_id) {
            // If global action (like profile update), use user_id as owner
            ownerId = user_id;
        }

        if (ownerId) {
            const discordService = require('./discordService');
            let msg = `**Action:** ${action}\n**User ID:** ${user_id || 'N/A'}\n**IP:** ${ip || 'Internal'}`;
            if (location) msg += `\n**Location:** ${location}`;
            if (user_agent) msg += `\n**Device:** ${user_agent.substring(0, 50)}...`;
            
            discordService.sendLogToDiscord(ownerId, action, msg);

            // Real-time Dashboard Alert via Socket.io
            if (global.io) {
                global.io.to(`user_${ownerId}`).emit('security_alert', {
                    action,
                    ip,
                    hwid,
                    timestamp: new Date().toISOString(),
                    type: action.includes('FAIL') || action.includes('MISMATCH') ? 'danger' : 'info'
                });
            }
        }

    } catch (error) {
        console.error('[RDX Log Error]', error);
    }
};
