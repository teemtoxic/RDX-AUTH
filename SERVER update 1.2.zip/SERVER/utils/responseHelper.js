const sendResponse = (res, status, success, data = null, message = null) => {
    const payload = { success, message };
    
    // Legacy support: If data is an object, flatten it into the root
    if (data && typeof data === 'object' && !Array.isArray(data)) {
        Object.assign(payload, data);
        // Also keep it under 'data' key just in case
        payload.data = data;
    } else if (data !== null) {
        // If it's an array or primitive, just put it in 'data'
        payload.data = data;
        
        // Dynamic pluralization fallback for common routes
        // This fixes pages like Apps, Users, Licenses without modifying 50 controllers
        const url = res.req ? res.req.originalUrl : '';
        if (Array.isArray(data)) {
            if (url.includes('/apps') && !payload.apps) payload.apps = data;
            if (url.includes('/users') && !payload.users) payload.users = data;
            if (url.includes('/licenses') && !payload.licenses) payload.licenses = data;
            if (url.includes('/subscriptions') && !payload.subscriptions) payload.subscriptions = data;
            if (url.includes('/logs') && !payload.logs) payload.logs = data;
            if (url.includes('/variables') && !payload.variables) payload.variables = data;
        }
    }

    return res.status(status).json(payload);
};

module.exports = sendResponse;
