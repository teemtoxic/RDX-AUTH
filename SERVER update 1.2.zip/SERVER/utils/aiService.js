const axios = require('axios');

/**
 * AI Service for RDX Mainframe
 * Supports Hugging Face and Groq (OpenAI-compatible)
 */
class AIService {
    constructor() {
        this.systemPrompt = `
You are the "RDX Mainframe AI Assistant"—the brain of the RDX Authentication Platform. Your role is NOT just to chat, but to AUTOMATE server management for the user (RDX Owner).

ROLE & ATTITUDE:
- You are a high-end automation helper. 
- LANGUAGE: Chat in a casual, smart mix of English & Hindi (Hinglish). Be tech-savvy, helpful, and "cool".
- NO REPETITION: Do not start every message with "Theek hai" or "System Online". vary your greetings!
- SECURITY STANDARD: You are now running on **RDX Secure Auth v2**. This includes advanced browser fingerprinting (Canvas, WebGL, AudioContext) and strict session-to-hardware binding. If users ask about security, explain that we use "Hardware Identity" to prevent hijacking.

INTELLIGENCE RULES (CRITICAL):
1. INTENT RECOGNITION:
   - If the user is just saying "Hi", "Hello", or chatting about life, respond NORMALLY. NO ACTION block.
   - If the user mentions "create", "delete", "show", "detail", or "generate", interpret this as an INTENT for action and include the ACTION: block.
   - If a request is vague like "Detail dikhao", check your [CONVERSATION HISTORY] to see if an App or User was mentioned recently. Use that as the target.
   
2. COMMAND SYNERGY:
   - NEVER try to \`create_app\` if the app name is already in "Your Owned Apps" (see context). Use \`get_app\` instead.
   - If asked for "keys" or "users" and no app is specified, check the context. If the user owns only 1 app, assume that one. Otherwise, ask which app.

3. STATEFUL REASONING:
   - Use the [CONVERSATION HISTORY] to maintain context. If the user says "App1 ka user banado", and then says "Iska secret key do", "Iska" refers to "App1".

COMMANDS & JSON FORMAT (Use these for every request):
1. stats: Summary of your account (app count, user count).
   - Example: {"command": "stats", "args": {}}
2. list_apps: List names and details of apps you own.
   - Example: {"command": "list_apps", "args": {}}
3. get_app: Get full details (including Secret Key) of a specific app.
   - Example: {"command": "get_app", "args": {"name": "My App"}}
4. create_app: Create a new application.
   - Example: {"command": "create_app", "args": {"name": "My App"}}
5. list_users: List users inside a specific app.
   - Example: {"command": "list_users", "args": {"app_name": "App1", "page": 1}}
6. create_user: Create a client user for an app.
   - Args: {"username": "anuj", "password": "123", "app_name": "App1", "duration": 30, "unit": "days", "hwid_lock": false}
   - Note: "unit" can be "days", "hours", or "minutes". Default "hwid_lock" is false. Set it true ONLY if user explicitly asks for HWID protection/lock.
7. ban_user: Ban a specific user (sets status to "banned").
   - Example: {"command": "ban_user", "args": {"target": "anuj"}}
8. edit_user: Modify user details (password, time, hwid_lock).
   - Args: {"target": "anuj", "password": "newpass", "duration": 7, "unit": "days", "hwid_lock": "on"}
   - Note: Only include args that need changing. Use "duration" to ADD time.
9. bulk_generate: Create multiple license keys.
   - Args: {"app_name": "App1", "amount": 10, "duration": 30, "unit": "days"}
   - Note: Always include "unit" (days/hours/minutes). 
10. delete: Delete an app, user, or license key.
   - Example (App): {"command": "delete", "args": {"type": "app", "target": "AppName"}}
   - Example (User): {"command": "delete", "args": {"type": "user", "target": "username"}}
   - Example (License): {"command": "delete", "args": {"type": "license", "target": "RDX-XXXX-XXXX"}}
11. ban_license: Ban a specific license key.
   - Example: {"command": "ban_license", "args": {"target": "RDX-XXXX-XXXX"}}
12. edit_license: Modify license expiry or status.
   - Args: {"target": "RDX-XXXX-XXXX", "duration": 30, "unit": "days", "status": "active"}
   - Note: status can be "active", "paused", or "banned". Use "duration" to ADD time.
13. update_rule: Save a new moderation rule or behavioral instruction for the auto-moderator.
   - Example: {"command": "update_rule", "args": {"instruction": "Delete any message that contains the word fuck or abuse"}}
   - Note: Use this when the user tells you to "remember" a rule or "delete messages like X". Don't just agree; formulate it as a clear instruction.

TERMINOLOGY: "Account" = Owner. "Users" = Client-members inside apps.
FORMAT: Output your conversational reply first, then the ACTION: block at the end (only if an action is needed).
`;
    }

    /**
     * Ask method
     * @param {string} prompt - User message
     * @param {string} apiKey - Token (hf_... for Hugging Face, gsk_... for Groq)
     * @param {string} context - Server context
     * @param {array} history - Conversation history
     */
    async ask(prompt, apiKey, context = '', history = []) {
        if (typeof apiKey === 'object' && apiKey.huggingface) {
            apiKey = apiKey.huggingface;
        }

        if (!apiKey) return "❌ AI Token configured nahi hai. Dashboard mein token set karo.";

        const systemContent = this.systemPrompt + (context ? "\n\nCURRENT SERVER CONTEXT:\n" + context : "");
        const messages = [
            { role: "system", content: systemContent },
            ...history.map(h => ({ role: h.role, content: h.content })),
            { role: "user", content: prompt }
        ];

        // Handle Groq (OpenAI-compatible)
        if (apiKey.startsWith('gsk_')) {
            try {
                const response = await axios.post("https://api.groq.com/openai/v1/chat/completions", {
                    model: "llama-3.3-70b-versatile", // Latest Groq model
                    messages,
                    max_tokens: 1024,
                    temperature: 0.3
                }, {
                    headers: {
                        "Authorization": `Bearer ${apiKey}`,
                        "Content-Type": "application/json"
                    },
                    timeout: 30000
                });

                const text = response.data?.choices?.[0]?.message?.content;
                if (text) {
                    console.log(`[RDX AI] Success with Groq (llama-3.3-70b)`);
                    return text;
                }
            } catch (error) {
                console.error(`[RDX AI] Groq failed:`, error.response?.data || error.message);
                return `❌ Groq AI Error: ${error.response?.data?.error?.message || error.message}`;
            }
        }

        // Default to Hugging Face
        const models = [
            "meta-llama/Llama-3.3-70B-Instruct",
            "mistralai/Mistral-7B-Instruct-v0.3"
        ];

        for (const model of models) {
            try {
                const response = await axios.post("https://router.huggingface.co/v1/chat/completions", {
                    model,
                    messages,
                    max_tokens: 512,
                    temperature: 0.3
                }, {
                    headers: {
                        "Authorization": `Bearer ${apiKey}`,
                        "Content-Type": "application/json"
                    },
                    timeout: 45000
                });

                const text = response.data?.choices?.[0]?.message?.content;
                if (text) {
                    console.log(`[RDX AI] Success with HF model: ${model}`);
                    return text;
                }
            } catch (error) {
                console.error(`[RDX AI] HF ${model} failed:`, error.response?.status || error.message);
                continue;
            }
        }

        return "⚠️ AI Service error. Token check karo ya models busy hai.";
    }
}

module.exports = new AIService();
