const nodemailer = require('nodemailer');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT),
    secure: process.env.SMTP_PORT == 465,
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
    },
});

const DEFAULT_THEME = {
    bg: '#0f172a',
    card: '#1e293b',
    primary: '#8b5cf6',
    text: '#f8fafc',
    muted: '#94a3b8',
    border: '#334155'
};

const BASE_URL = process.env.BASE_URL || 'https://rdxofficial.com';

const getEmailTemplate = (content) => `
    <div style="background-color: ${DEFAULT_THEME.bg}; padding: 40px 20px; font-family: 'Inter', system-ui, -apple-system, sans-serif;">
        <div style="max-width: 600px; margin: 0 auto; background-color: ${DEFAULT_THEME.card}; borderRadius: 16px; overflow: hidden; border: 1px solid ${DEFAULT_THEME.border}; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.3);">
            <div style="padding: 30px; border-bottom: 4px solid ${DEFAULT_THEME.primary}; text-align: center;">
                <h1 style="color: ${DEFAULT_THEME.text}; margin: 0; font-size: 28px; letter-spacing: -0.025em;">RDX <span style="color: ${DEFAULT_THEME.primary}">OFFICIAL</span></h1>
            </div>
            <div style="padding: 40px 30px; color: ${DEFAULT_THEME.text}; line-height: 1.6;">
                ${content}
            </div>
            <div style="padding: 20px 30px; background-color: rgba(0,0,0,0.1); border-top: 1px solid ${DEFAULT_THEME.border}; text-align: center;">
                <p style="margin: 0; font-size: 14px; color: ${DEFAULT_THEME.muted};">
                    &copy; ${new Date().getFullYear()} RDX Systems. All rights reserved.
                </p>
                <div style="margin-top: 10px;">
                    <a href="${BASE_URL}" style="color: ${DEFAULT_THEME.primary}; text-decoration: none; font-size: 12px; margin: 0 10px;">Website</a>
                    <a href="${BASE_URL}/support" style="color: ${DEFAULT_THEME.primary}; text-decoration: none; font-size: 12px; margin: 0 10px;">Support</a>
                </div>
            </div>
        </div>
    </div>
`;

const sendEmail = async (to, subject, content) => {
    try {
        await transporter.sendMail({
            from: process.env.SMTP_USER,
            to,
            subject,
            html: getEmailTemplate(content),
        });
        console.log(`[EmailService] Email sent to ${to}: ${subject}`);
        return true;
    } catch (error) {
        console.error(`[EmailService] Error sending to ${to}:`, error);
        return false;
    }
};

/**
 * Send a welcome email to a new user.
 */
exports.sendWelcomeEmail = async (email, username) => {
    const content = `
        <h2 style="color: ${DEFAULT_THEME.primary};">Welcome to the Elite, ${username}!</h2>
        <p>Your account has been successfully created. We're excited to have you on board with RDX Official.</p>
        <p>Access your dashboard to manage your applications, security tools, and licenses with ease.</p>
        <div style="margin: 30px 0; text-align: center;">
            <a href="${BASE_URL}/login" style="background-color: ${DEFAULT_THEME.primary}; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Get Started</a>
        </div>
        <p style="font-size: 14px; color: ${DEFAULT_THEME.muted};">If you didn't create this account, please ignore this email or contact support.</p>
    `;
    return sendEmail(email, 'Welcome to RDX Official', content);
};

/**
 * Send a ticket creation thank you email.
 */
exports.sendTicketCreatedEmail = async (email, username, ticket) => {
    const content = `
        <h2 style="color: ${DEFAULT_THEME.primary};">Support Ticket Received</h2>
        <p>Hi ${username},</p>
        <p>Thank you for reaching out to RDX Support. We've received your ticket:</p>
        <div style="background: rgba(0,0,0,0.2); padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid ${DEFAULT_THEME.primary};">
            <strong style="display: block; color: ${DEFAULT_THEME.primary};">#${ticket.id} - ${ticket.subject}</strong>
            <span style="font-size: 14px; color: ${DEFAULT_THEME.muted};">Category: ${ticket.category}</span>
        </div>
        <p>Our team usually responds within <strong>4 hours</strong>. We will notify you via email as soon as there is an update.</p>
        <div style="margin: 30px 0; text-align: center;">
            <a href="${BASE_URL}/dashboard/support" style="background-color: ${DEFAULT_THEME.primary}; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 600;">View Ticket</a>
        </div>
    `;
    return sendEmail(email, `Support Ticket Received: #${ticket.id}`, content);
};

/**
 * Send a ticket resolved email.
 */
exports.sendTicketResolvedEmail = async (email, username, ticketId, subject) => {
    const content = `
        <h2 style="color: #10b981;">Support Ticket Resolved</h2>
        <p>Hi ${username},</p>
        <p>Your support ticket <strong>#${ticketId} - ${subject}</strong> has been marked as <strong>Resolved</strong> by our team.</p>
        <p>We hope we was able to assist you effectively. If you still have questions or the issue persists, feel free to reply to the ticket to reopen it.</p>
        <div style="margin: 30px 0; text-align: center;">
            <a href="${BASE_URL}/dashboard/support/${ticketId}" style="background-color: ${DEFAULT_THEME.primary}; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 600;">Check Resolution</a>
        </div>
    `;
    return sendEmail(email, `Ticket Resolved: #${ticketId}`, content);
};

/**
 * Send a payment verification thank you email.
 */
exports.sendPaymentReceivedEmail = async (email, username, plan) => {
    const content = `
        <h2 style="color: ${DEFAULT_THEME.primary};">Payment Under Verification</h2>
        <p>Hi ${username},</p>
        <p>Thank you for choosing the <strong>${plan.toUpperCase()}</strong> plan! We've received your verification request.</p>
        <p>Our billing department is currently verifying your transaction. This process usually takes <strong>15-60 minutes</strong>.</p>
        <p>You will receive an automated email with full details once your subscription is active.</p>
        <div style="padding: 15px; background: rgba(139, 92, 246, 0.1); border-radius: 8px; border: 1px dashed ${DEFAULT_THEME.primary}; margin: 20px 0; font-size: 14px;">
            <p style="margin: 0;"><strong>Next Step:</strong> Stay tuned! Your dashboard will automatically update once approved.</p>
        </div>
    `;
    return sendEmail(email, 'Payment Verification in Progress', content);
};

/**
 * Send a detailed plan activation email.
 */
exports.sendPlanActivatedEmail = async (email, username, details) => {
    const { plan, txId, amount, expiry, features } = details;
    const content = `
        <div style="text-align: center; margin-bottom: 30px;">
            <div style="width: 60px; height: 60px; background: #10b981; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 15px;">
                <span style="color: white; font-size: 30px;">✓</span>
            </div>
            <h2 style="color: #10b981; margin: 0;">Subscription Activated!</h2>
        </div>
        <p>Hi ${username},</p>
        <p>Great news! Your <strong>${plan.toUpperCase()}</strong> subscription is now active. Here is your receipt and plan details:</p>
        
        <div style="background: rgba(0,0,0,0.2); padding: 20px; border-radius: 12px; margin: 25px 0;">
            <table style="width: 100%; font-size: 14px; border-collapse: collapse;">
                <tr><td style="padding: 8px 0; color: ${DEFAULT_THEME.muted};">Plan Name:</td><td style="padding: 8px 0; text-align: right; font-weight: bold; color: ${DEFAULT_THEME.primary};">${plan.toUpperCase()}</td></tr>
                <tr><td style="padding: 8px 0; color: ${DEFAULT_THEME.muted};">Transaction ID:</td><td style="padding: 8px 0; text-align: right; font-family: monospace;">${txId}</td></tr>
                <tr><td style="padding: 8px 0; color: ${DEFAULT_THEME.muted};">Amount Paid:</td><td style="padding: 8px 0; text-align: right; font-weight: bold;">$${amount}</td></tr>
                <tr><td style="padding: 8px 0; color: ${DEFAULT_THEME.muted};">Valid Until:</td><td style="padding: 8px 0; text-align: right;">${new Date(expiry).toLocaleDateString()}</td></tr>
            </table>
        </div>

        <h3 style="color: ${DEFAULT_THEME.primary}; font-size: 16px; border-bottom: 1px solid ${DEFAULT_THEME.border}; padding-bottom: 8px;">Included Features</h3>
        <ul style="padding-left: 20px; font-size: 14px;">
            ${features.map(f => `<li style="margin-bottom: 5px;">${f}</li>`).join('')}
        </ul>

        <div style="margin: 30px 0; text-align: center;">
            <a href="${BASE_URL}/dashboard" style="background-color: ${DEFAULT_THEME.primary}; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Launch Dashboard</a>
        </div>
    `;
    return sendEmail(email, `Subscription Active: ${plan.toUpperCase()} Plan`, content);
};

/**
 * Send an expiry alert email.
 */
exports.sendExpiryAlertEmail = async (email, username, plan, daysRemaining) => {
    const isExpired = daysRemaining <= 0;
    const content = `
        <h2 style="color: ${isExpired ? '#ef4444' : '#f59e0b'};">${isExpired ? 'Subscription Expired' : 'Action Required: Expiry Alert'}</h2>
        <p>Hi ${username},</p>
        <p>${isExpired
            ? `Your <strong>${plan.toUpperCase()}</strong> subscription has expired. Your account features have been restricted to the Starter plan.`
            : `Your <strong>${plan.toUpperCase()}</strong> subscription will expire in <strong>${daysRemaining}</strong> days.`}</p>
        <p>Renew now to maintain uninterrupted access to your exclusive RDX premium features.</p>
        <div style="margin: 30px 0; text-align: center;">
            <a href="${BASE_URL}/dashboard/billing" style="background-color: ${DEFAULT_THEME.primary}; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 600;">Renew Subscription</a>
        </div>
    `;
    return sendEmail(email, isExpired ? 'Subscription Expired' : 'Renewal Alert', content);
};

/**
 * Send an email verification link.
 */
exports.sendVerificationEmail = async (email, username, token) => {
    const verifyUrl = `${BASE_URL}/rdx/api/auth/verify-email?token=${token}`;
    const content = `
        <h2 style="color: ${DEFAULT_THEME.primary};">Verify Your Email Address</h2>
        <p>Hi ${username},</p>
        <p>Thank you for joining RDX Official! To activate your account and access all features, please verify your email address by clicking the button below:</p>
        <div style="margin: 30px 0; text-align: center;">
            <a href="${verifyUrl}" style="background-color: ${DEFAULT_THEME.primary}; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Verify Email</a>
        </div>
        <p style="font-size: 14px; color: ${DEFAULT_THEME.muted};">If the button doesn't work, copy and paste this link into your browser:</p>
        <p style="font-size: 12px; color: ${DEFAULT_THEME.primary}; word-break: break-all;">${verifyUrl}</p>
        <p style="font-size: 14px; color: ${DEFAULT_THEME.muted};">This link will expire in 24 hours.</p>
    `;
    return sendEmail(email, 'Verify your email - RDX Official', content);
};

/**
 * Send a password reset email.
 */
exports.sendResetPasswordEmail = async (email, username, token) => {
    const resetUrl = `${BASE_URL}/reset-password?token=${token}`;
    const content = `
        <h2 style="color: #ef4444;">Password Reset Request</h2>
        <p>Hi ${username},</p>
        <p>We received a request to reset the password for your RDX account. You can reset your password by clicking the button below:</p>
        <div style="margin: 30px 0; text-align: center;">
            <a href="${resetUrl}" style="background-color: #ef4444; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Reset Password</a>
        </div>
        <p style="font-size: 14px; color: ${DEFAULT_THEME.muted};">If you didn't request a password reset, you can safely ignore this email. Your password will remain unchanged.</p>
        <p style="font-size: 14px; color: ${DEFAULT_THEME.muted};">This link is valid for **1 hour** only.</p>
        <p style="font-size: 12px; color: #ef4444; word-break: break-all;">${resetUrl}</p>
    `;
    return sendEmail(email, 'Password Reset - RDX Official', content);
};

/**
 * Send a recovery OTP email.
 */
exports.sendRecoveryOTPEmail = async (email, username, otp) => {
    const content = `
        <div style="text-align: center; margin-bottom: 30px;">
            <div style="width: 60px; height: 60px; background: rgba(99, 102, 241, 0.1); border: 2px solid ${DEFAULT_THEME.primary}; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 15px;">
                <span style="color: ${DEFAULT_THEME.primary}; font-size: 24px;">🔒</span>
            </div>
            <h2 style="color: ${DEFAULT_THEME.text}; margin: 0; letter-spacing: -0.025em;">Identity Verification</h2>
            <p style="color: ${DEFAULT_THEME.muted}; font-size: 14px; margin-top: 5px;">Secure Account Recovery Protocol</p>
        </div>
        
        <p>Hi ${username},</p>
        <p>We received a request to recover access to your RDX account. Use the following high-stakes verification code to authorize the identity reset:</p>
        
        <div style="background: rgba(0,0,0,0.2); padding: 30px; border-radius: 16px; margin: 30px 0; border: 1px solid ${DEFAULT_THEME.border}; text-align: center;">
            <div style="font-size: 42px; font-weight: 800; letter-spacing: 0.2em; color: ${DEFAULT_THEME.primary}; font-family: 'JetBrains Mono', monospace;">
                ${otp}
            </div>
            <p style="font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; color: ${DEFAULT_THEME.muted}; margin-top: 15px; font-weight: bold;">
                VALID FOR 10 MINUTES
            </p>
        </div>
        
        <p style="font-size: 14px; color: ${DEFAULT_THEME.muted};"><strong>Security Warning:</strong> Never share this code with anyone. Our support team will never ask for this code. If you did not initiate this request, please secure your account immediately.</p>
    `;
    return sendEmail(email, 'Identity Verification Code - RDX Official', content);
};