const cron = require('node-cron');
const { getDb } = require('../config/db');
const discordService = require('./discordService');
const { v4: uuidv4 } = require('uuid');

let activeTasks = {};

/**
 * Initialize all active tasks from the database
 */
const initScheduler = async () => {
    try {
        const db = await getDb();
        const tasks = await db.all('SELECT * FROM scheduled_tasks WHERE is_active = 1');
        
        console.log(`[SCHEDULER] Initializing ${tasks.length} active tasks...`);
        
        // Clear existing memory tasks if any
        Object.values(activeTasks).forEach(t => t.stop());
        activeTasks = {};

        for (const task of tasks) {
            scheduleTask(task);
        }

        // Initialize Internal Security Tasks
        initInternalSecurityTasks();
    } catch (error) {
        console.error('[SCHEDULER] Initialization Error:', error);
    }
};

/**
 * Tasks that run automatically for system security
 */
const initInternalSecurityTasks = () => {
    const securityUtils = require('./securityUtils');
    
    // AI Forensics Scan: Every 10 minutes
    cron.schedule('*/10 * * * *', async () => {
        console.log('[SCHEDULER] Running Internal Security Task: AI Forensics Scan');
        await securityUtils.runAiForensicsScan();
    });
};

/**
 * Schedule a single task in memory
 */
const scheduleTask = (task) => {
    if (activeTasks[task.id]) {
        activeTasks[task.id].stop();
    }

    const job = cron.schedule(task.cron_expression, async () => {
        console.log(`[SCHEDULER] Executing Task ID: ${task.id} | Action: ${task.action}`);
        await executeTaskAction(task);
    });

    activeTasks[task.id] = job;
};

/**
 * Stop and remove a scheduled task from memory
 */
const stopTask = (taskId) => {
    if (activeTasks[taskId]) {
        activeTasks[taskId].stop();
        delete activeTasks[taskId];
        console.log(`[SCHEDULER] Stopped Task ID: ${taskId}`);
    }
};

/**
 * Core execution logic for different task types
 */
const executeTaskAction = async (task) => {
    const db = await getDb();
    const payload = JSON.parse(task.payload || '{}');
    
    try {
        switch (task.action) {
            case 'CREATE_FREE_KEY':
                await handleCreateFreeKey(db, task, payload);
                break;
            
            case 'DISCORD_POST':
                await handleDiscordPost(task, payload);
                break;

            default:
                console.warn(`[SCHEDULER] Unknown action type: ${task.action}`);
        }

        // Update last run time
        await db.run('UPDATE scheduled_tasks SET last_run = CURRENT_TIMESTAMP WHERE id = ?', [task.id]);

    } catch (error) {
        console.error(`[SCHEDULER] Execution Error (Task ${task.id}):`, error);
    }
};

/**
 * Handle: Create a user/key and post to Discord
 */
const handleCreateFreeKey = async (db, task, payload) => {
    const username = `FREE_${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    const password = Math.random().toString(36).substring(2, 10);
    const expiryDate = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(); // 24 Hours

    // 1. Create User
    const bcrypt = require('bcryptjs');
    const hashedPassword = await bcrypt.hash(password, 10);

    await db.run(
        'INSERT INTO users (username, password_hash, role, plan, expiry_date, status) VALUES (?, ?, "user", "free", ?, "active")',
        [username, hashedPassword, expiryDate]
    );

    const message = payload.custom_message || `🎁 **FREE KEY GENERATED** 🎁\n\n**User:** \`${username}\`\n**Pass:** \`${password}\`\n**Expiry:** 24 Hours\n\n@everyone @here`;

    // 2. Post to Discord if channel is provided
    if (payload.channel_id) {
        await discordService.sendToChannel(payload.channel_id, message);
    }
    
    console.log(`[SCHEDULER] Created free key: ${username}`);
};

/**
 * Handle: Standard Discord Message
 */
const handleDiscordPost = async (task, payload) => {
    if (!payload.channel_id || !payload.message) return;
    await discordService.sendToChannel(payload.channel_id, payload.message);
};

module.exports = {
    initScheduler,
    scheduleTask,
    stopTask
};
