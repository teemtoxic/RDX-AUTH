const cron = require('node-cron');
const { getDb } = require('../config/db');
const emailService = require('./emailService');

/**
 * Subscription Cron Job
 * Runs every day at midnight (00:00)
 */
const startSubscriptionCron = () => {
    // 0 0 * * * = Every day at midnight
    // For testing/demo, you could use * * * * * for every minute
    cron.schedule('0 0 * * *', async () => {
        console.log('[SubscriptionCron] Starting daily subscription check...');
        try {
            const db = await getDb();
            const now = new Date();
            now.setHours(0, 0, 0, 0);
            const nowStr = now.toISOString();

            // 1. Find users who have expired (expiry_date < now AND plan != 'starter')
            const expiredUsers = await db.all(
                "SELECT id, username, email, plan FROM users WHERE expiry_date IS NOT NULL AND expiry_date < ? AND plan != 'starter' AND status = 'active'",
                [nowStr]
            );

            for (const user of expiredUsers) {
                console.log(`[SubscriptionCron] Downgrading expired user: ${user.username}`);

                await db.run('BEGIN TRANSACTION');
                try {
                    // Downgrade user plan
                    await db.run("UPDATE users SET plan = 'starter', expiry_date = NULL WHERE id = ?", [user.id]);

                    // Update associated license
                    await db.run("UPDATE licenses SET status = 'expired' WHERE user_id = ?", [user.id]);

                    // Send Expiry Email
                    if (user.email) {
                        await emailService.sendExpiryAlertEmail(user.email, user.username, user.plan, 0);
                    }

                    await db.run('COMMIT');
                } catch (err) {
                    await db.run('ROLLBACK');
                    console.error(`[SubscriptionCron] Failed to downgrade user ${user.username}:`, err);
                }
            }

            // 2. Alert intervals (7, 3, 1 day left)
            const alertIntervals = [7, 3, 1];
            for (const days of alertIntervals) {
                const alertDate = new Date();
                alertDate.setDate(alertDate.getDate() + days);
                const start = new Date(alertDate.setHours(0, 0, 0, 0)).toISOString();
                const end = new Date(alertDate.setHours(23, 59, 59, 999)).toISOString();

                const expiringSoon = await db.all(
                    "SELECT id, username, email, plan FROM users WHERE expiry_date BETWEEN ? AND ? AND plan != 'starter' AND status = 'active'",
                    [start, end]
                );

                for (const user of expiringSoon) {
                    if (user.email) {
                        console.log(`[SubscriptionCron] Sending ${days}-day expiry alert to ${user.username}`);
                        await emailService.sendExpiryAlertEmail(user.email, user.username, user.plan, days);
                    }
                }
            }

            console.log('[SubscriptionCron] Daily check completed.');
        } catch (error) {
            console.error('[SubscriptionCron] Critical Error:', error);
        }
    });
};

module.exports = { startSubscriptionCron };
