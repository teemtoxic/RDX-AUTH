const axios = require('axios');

/**
 * Security Utilities for RDX Auth
 * Handles VPN/Proxy detection and IP intelligence.
 */

// Simple cache to avoid redundant API calls for the same IP (1 hour TTL)
const ipCache = new Map();
const CACHE_TTL = 3600000;

exports.checkIpSecurity = async (ip) => {
    try {
        // Skip check for localhost/internal IPs
        if (ip === '::1' || ip === '127.0.0.1' || ip.startsWith('192.168.') || ip.startsWith('10.')) {
            return { isProxy: false, details: 'Local/Internal IP' };
        }

        // Check cache
        const cached = ipCache.get(ip);
        if (cached && (Date.now() - cached.timestamp < CACHE_TTL)) {
            return cached.data;
        }

        // Use a reputable IP intelligence API (e.g., ip-api.com or similar)
        // Note: For production, a paid API with a secret key is recommended.
        // This implementation uses a public endpoint as a baseline.
        const response = await axios.get(`http://ip-api.com/json/${ip}?fields=status,message,proxy,hosting,query`, {
            timeout: 1500 // 1.5 second max to prevent login stalling
        });

        if (response.data && response.data.status === 'success') {
            const result = {
                isProxy: response.data.proxy === true || response.data.hosting === true,
                details: response.data.proxy ? 'VPN/Proxy Detected' : (response.data.hosting ? 'Hosting Provider/Data Center' : 'Residential/Mobile IP')
            };

            // Update cache
            ipCache.set(ip, {
                timestamp: Date.now(),
                data: result
            });

            return result;
        }

        return { isProxy: false, details: 'Detection Unavailable' };
    } catch (error) {
        console.error(`[RDX Security] IP check failed for ${ip}:`, error.message);
        return { isProxy: false, details: 'Check Error' };
    }
};

/**
 * Standardizes Hardware ID components
 */
exports.parseHardwareInfo = (hwid, hardware_info) => {
    let components = {
        hwid: hwid || null,
        baseboard: null,
        cpu: null,
        mac: null
    };

    if (hardware_info) {
        try {
            const info = typeof hardware_info === 'string' ? JSON.parse(hardware_info) : hardware_info;
            components.baseboard = info.baseboard || info.Baseboard || null;
            components.cpu = info.cpu || info.CPU || null;
            components.mac = info.mac || info.MAC || null;
            if (!components.hwid) components.hwid = info.id || info.ID || null;
        } catch (e) {
            // If it's a raw string and we have no hwid, use the string
            if (!components.hwid && typeof hardware_info === 'string') {
                components.hwid = hardware_info;
            }
        }
    }

    return components;
};
/**
 * AI Forensics: Scans logs for brute-force patterns across multiple applications.
 * Automatically blacklists offenders.
 */
exports.runAiForensicsScan = async () => {
    const { getDb } = require('../config/db');
    try {
        const db = await getDb();
        const tenMinsAgo = new Date(Date.now() - 10 * 60 * 1000).toISOString();

        console.log(`[AI-FORENSICS] Scanning logs since ${tenMinsAgo}...`);

        // 1. Check for IP based attacks (10+ fails across any apps)
        const ipAttacks = await db.all(`
            SELECT ip, COUNT(*) as fail_count, COUNT(DISTINCT app_id) as app_count
            FROM logs 
            WHERE timestamp > ? AND action LIKE '%FAIL%' 
            GROUP BY ip 
            HAVING fail_count >= 10
        `, [tenMinsAgo]);

        for (const attack of ipAttacks) {
            console.log(`[AI-FORENSICS] Threat Detected: IP ${attack.ip} has ${attack.fail_count} fails across ${attack.app_count} apps.`);
            await db.run(`
                INSERT OR IGNORE INTO blacklist (type, value, reason) 
                VALUES ('ip', ?, ?)
            `, [attack.ip, `AI_FORENSICS_AUTO_BAN: ${attack.fail_count} failed attempts in 10 mins across ${attack.app_count} apps`]);
            
            // Notify via socket if global.io exists
            if (global.io) {
                global.io.emit('security_alert', {
                    type: 'AUTO_BAN',
                    target: attack.ip,
                    reason: 'Cross-app brute force detected'
                });
            }
        }

        // 2. Check for HWID based attacks
        const hwidAttacks = await db.all(`
            SELECT hwid, COUNT(*) as fail_count, COUNT(DISTINCT app_id) as app_count
            FROM logs 
            WHERE timestamp > ? AND action LIKE '%FAIL%' AND hwid IS NOT NULL AND hwid != '' AND hwid != 'WEB_SESSION'
            GROUP BY hwid 
            HAVING fail_count >= 10
        `, [tenMinsAgo]);

        for (const attack of hwidAttacks) {
            console.log(`[AI-FORENSICS] Threat Detected: HWID ${attack.hwid} has ${attack.fail_count} fails across ${attack.app_count} apps.`);
            await db.run(`
                INSERT OR IGNORE INTO blacklist (type, value, reason) 
                VALUES ('hwid', ?, ?)
            `, [attack.hwid, `AI_FORENSICS_AUTO_BAN: HWID brute-force detected (${attack.fail_count} fails)`]);

            if (global.io) {
                global.io.emit('security_alert', {
                    type: 'AUTO_BAN',
                    target: attack.hwid,
                    reason: 'HWID brute-force detected'
                });
            }
        }

    } catch (error) {
        console.error('[AI-FORENSICS] Scan Error:', error);
    }
};
