const { Client, GatewayIntentBits, Partials, EmbedBuilder, REST, Routes, SlashCommandBuilder } = require('discord.js');
const { getDb } = require('../config/db');

// Global client instance
let client = null;

/**
 * Initializes the Discord Bot using the token stored in system settings.
 */
async function initDiscordBot() {
    try {
        if (client) {
            console.log('[RDX Discord] Destroying existing client for re-initialization...');
            client.destroy();
            client = null;
        }
        const db = await getDb();
        const setting = await db.get('SELECT value FROM system_settings WHERE key = "discord_bot_token"');

        if (!setting || !setting.value) {
            console.warn('[RDX Discord] Bot skipped: No "discord_bot_token" found in system_settings.');
            return;
        }

        const token = setting.value;

        client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.MessageContent
            ],
            partials: [Partials.Channel]
        });

        client.on('ready', () => {
            console.log(`[RDX Discord] Mainframe Connection Established: ${client.user.tag}`);
            registerCommands(token, client.user.id);
        });

        client.on('messageCreate', async (message) => {
            if (message.author.bot) return;
            if (message.mentions.has(client.user)) {
                return handleAIMessage(message);
            }
            if (message.guild) {
                handleModeration(message);
            }
        });

        client.on('interactionCreate', async (interaction) => {
            if (!interaction.isChatInputCommand()) return;
            handleCommand(interaction);
        });

        await client.login(token);

    } catch (error) {
        console.error('[RDX Discord] Initialization Failure:', error);
    }
}

/**
 * Automates Discord Moderation using configured Rule Base and AI
 */
async function handleModeration(message) {
    try {
        const db = await getDb();
        // 1. Find the owner of this Discord Server
        const clientUser = await db.get('SELECT * FROM users WHERE discord_server_id = ? AND status = "active"', [message.guild.id]);
        if (!clientUser) return; // Not an RDX managed server or owner is disabled

        let aiMode = { level: 'enforcer', learning: false };
        let rules = {};
        let aiPrompt = clientUser.ai_alignment_prompt || '';

        try { if (clientUser.ai_mode) aiMode = JSON.parse(clientUser.ai_mode); } catch (e) { }
        try { if (clientUser.ai_rule_base) rules = JSON.parse(clientUser.ai_rule_base); } catch (e) { }

        // Local Rule: Link Filtering
        if (rules.links && rules.links.enabled) {
            const hasLink = /(https?:\/\/[^\s]+)/g.test(message.content);
            if (hasLink) {
                const safelist = (rules.links.safelist || "").split(',').map(s => s.trim().toLowerCase());
                const links = message.content.match(/(https?:\/\/[^\s]+)/g);
                let isMalicious = false;
                for (let link of links) {
                    try {
                        let domain = new URL(link).hostname.toLowerCase();
                        if (!safelist.some(safe => domain.includes(safe))) {
                            isMalicious = true;
                            break;
                        }
                    } catch (e) { }
                }

                if (isMalicious) {
                    await message.delete().catch(() => null);
                    await message.channel.send(`⚠️ ${message.author}, unauthorized link removed.`);
                    await db.run('INSERT INTO discord_moderation_logs (discord_user_id, discord_username, action_type, reason) VALUES (?, ?, ?, ?)', [message.author.id, message.author.tag, 'WARNING', 'Unauthorized Link']);
                    return; // Stop AI processing to save tokens
                }
            }
        }

        // Validate text length before AI processing
        if (!message.content || message.content.length < 3) return;
        if (aiMode.level === 'observer' && !(rules.spam?.enabled || rules.toxicity?.enabled)) return;

        const systemAIToken = await db.get('SELECT value FROM system_settings WHERE key = "huggingface_token"');
        const token = clientUser.ai_token ? clientUser.ai_token : (systemAIToken ? systemAIToken.value : null);
        if (!token) return;

        const aiService = require('./aiService');

        // Build Moderation Prompt
        let context = `[RDX GUARDIAN MODERATION CORE]\n`;
        context += `You are a strict Discord Moderator AI. Analyze the user's message and determine if it violates the community rules.\n`;
        if (aiPrompt) context += `\n[COMMUNITY ALIGNMENT DIRECTIVES]:\n${aiPrompt}\n`;

        context += `\n[RULE BASE CONFIG]:\n`;
        if (rules.spam?.enabled) {
            context += `- SPAM: Strictness is ${rules.spam.strictness}. Punish with: ${rules.spam.action}\n`;
        }
        if (rules.toxicity?.enabled) {
            context += `- TOXICITY/ABUSE: Tolerance is ${rules.toxicity.tolerance}. Punish with: ${rules.toxicity.action}\n`;
        }

        context += `\nINSTRUCTIONS: If there is no violation, reply exactly with: {"violation": false}\n`;
        context += `If there IS a violation, reply ONLY with a JSON payload: {"violation": true, "reason": "Reason for violation", "action": "warn|timeout_10m|timeout_1h|timeout_24h|kick|ban"}\n`;

        const response = await aiService.ask(message.content, token, context, []);

        try {
            const cleanJson = response.replace(/```json\s*/g, '').replace(/```\s*/g, '').trim();
            const result = JSON.parse(cleanJson);

            if (result.violation && result.action) {
                if (aiMode.level === 'observer') {
                    // Observer doesn't take action automatically, just logs
                    await db.run('INSERT INTO discord_moderation_logs (discord_user_id, discord_username, action_type, reason) VALUES (?, ?, ?, ?)', [message.author.id, message.author.tag, 'WARNING', '[OBSERVER FLAG] ' + result.reason]);
                    return;
                }

                await message.delete().catch(() => null);

                let actionType = 'WARNING';

                if (result.action === 'warn') {
                    await message.channel.send(`⚠️ ${message.author}, ${result.reason}`);
                }
                else if (result.action.startsWith('timeout')) {
                    actionType = 'TIMEOUT';
                    const member = await message.guild.members.fetch(message.author.id);
                    let ms = 10 * 60 * 1000;
                    if (result.action === 'timeout_1h') ms = 60 * 60 * 1000;
                    if (result.action === 'timeout_24h') ms = 24 * 60 * 60 * 1000;
                    if (member) await member.timeout(ms, result.reason).catch(() => null);
                }
                else if (result.action === 'kick') {
                    actionType = 'KICK';
                    const member = await message.guild.members.fetch(message.author.id);
                    if (member) await member.kick(result.reason).catch(() => null);
                }
                else if (result.action === 'ban') {
                    actionType = 'BAN';
                    const member = await message.guild.members.fetch(message.author.id);
                    if (member) await member.ban({ reason: result.reason }).catch(() => null);
                }

                // Log it
                await db.run('INSERT INTO discord_moderation_logs (discord_user_id, discord_username, action_type, reason) VALUES (?, ?, ?, ?)', [message.author.id, message.author.tag, actionType, result.reason]);

            }
        } catch (e) {
            // Not a valid JSON or no violation
        }

    } catch (error) {
        console.error('[Discord Moderation] Error:', error);
    }
}

/**
 * Handles natural language messages using Gemini AI.
 */
async function handleAIMessage(message) {
    try {
        const db = await getDb();
        const authorId = message.author.id;

        // Determine the Context (Which RDX Client's Bot is this?)
        let contextOwner = null;
        let isAuthorized = false;

        // 1. Is the user the Global Admin? (from system_settings)
        const globalSettings = await db.get('SELECT value FROM system_settings WHERE key = "discord_allowed_ids"');
        const globalAdmins = globalSettings && globalSettings.value ? globalSettings.value.split(',').map(id => id.trim()) : [];
        if (globalAdmins.includes(authorId)) {
            contextOwner = await db.get('SELECT * FROM users WHERE role = "admin" LIMIT 1');
            isAuthorized = true;
        }

        // 2. Are we in a Guild? If so, the context owner is the Guild Owner.
        if (!contextOwner && message.guild) {
            contextOwner = await db.get('SELECT * FROM users WHERE discord_server_id = ? AND status = "active"', [message.guild.id]);
        }

        // 3. If still no context (e.g. DMs, and not global admin), see if they are a direct client
        if (!contextOwner) {
            contextOwner = await db.get('SELECT * FROM users WHERE discord_id = ? AND status = "active"', [authorId]);
            if (contextOwner) isAuthorized = true;
        }

        if (!contextOwner) {
            return message.reply("🚫 **System Error**: I am not linked to any active RDX Client for this server.");
        }

        // 4. Verify Authorization for the Context Owner
        if (!isAuthorized) {
            if (contextOwner.discord_id === authorId) {
                isAuthorized = true;
            } else if (contextOwner.allowed_admin_ids && contextOwner.allowed_admin_ids.split(',').map(i => i.trim()).includes(authorId)) {
                isAuthorized = true;
            } else if (message.guild) {
                const member = await message.guild.members.fetch(authorId).catch(() => null);
                if (member && contextOwner.discord_role_id && member.roles.cache.has(contextOwner.discord_role_id)) {
                    isAuthorized = true;
                }
            }
        }

        // Fetch AI Token
        const systemAIToken = await db.get('SELECT value FROM system_settings WHERE key = "huggingface_token"');
        const token = contextOwner.ai_token ? contextOwner.ai_token : (systemAIToken ? systemAIToken.value : null);

        if (!token) {
            if (isAuthorized) return message.reply("⚠️ AI is not configured. Ask the Client Admin to set `AI TOKEN` in their RDX Dashboard.");
            return; // Fail silently for normal members if AI is off
        }

        // Build context
        let context = `[RDX MAINFRAME IDENTITY]\n`;
        context += `Discord Account: ${message.author.tag} (ID: ${message.author.id})\n`;

        if (!isAuthorized) {
            context += `\n[SECURITY ALERT]: THIS USER IS A NORMAL MEMBER, NOT AN ADMINISTRATOR. YOU MUST ABSOLUTELY REFUSE ANY REQUESTS TO EXECUTE ACTIONS (LIKE CREATE, DELETE, BAN). ONLY CHAT CASUALLY AND ANSWER QUESTIONS ABOUT THE COMMUNITY. DO NOT OUTPUT ANY JSON ACTION BLOCK.\n`;
            if (contextOwner.ai_alignment_prompt) {
                context += `\n[COMMUNITY CHAT RULES]:\n${contextOwner.ai_alignment_prompt}\n`;
            }
        } else {
            context += `Authorization: ADMINISTRATOR (Owner/Admin)\n`;
            const userPlan = (contextOwner.plan || 'free').toLowerCase();
            const isAdminRole = contextOwner.role === 'admin';

            if (userPlan !== 'pro' && !isAdminRole) {
                return message.reply(`🚫 **Subscription Required**: This RDX Client account requires a **PRO** plan to use AI Console.`);
            }

            context += `Linked RDX Client: ${contextOwner.username} (ID: ${contextOwner.id})\n`;
            context += `Role: ${contextOwner.role} | Plan: ${contextOwner.plan}\n`;

            if (contextOwner.ai_alignment_prompt) {
                context += `\n[COMMUNITY ALIGNMENT DIRECTIVES]:\n${contextOwner.ai_alignment_prompt}\n`;
            }

            const apps = await db.all('SELECT id, name FROM apps WHERE owner_id = ?', [contextOwner.id]);
            context += `Owned Apps: ${apps.length > 0 ? apps.map(a => `${a.name} (ID: ${a.id})`).join(', ') : 'None'}\n`;

            const maint = await db.get('SELECT value FROM system_settings WHERE key = "maintenance_mode"');
            context += `Global Maintenance: ${maint?.value === '1' ? 'ON (Locked)' : 'OFF (Live)'}\n`;

            if (isAdminRole) {
                const stats = await db.get('SELECT (SELECT count(*) FROM users) as u, (SELECT count(*) FROM apps) as a');
                context += `\n[SYSTEM-WIDE STATS]\nTotal Accounts: ${stats.u} | Total Apps: ${stats.a}\n`;
            }
        }

        // 4. History
        const history = await db.all(
            'SELECT role, content FROM ai_conversations WHERE discord_id = ? ORDER BY created_at ASC LIMIT 10',
            [message.author.id]
        );

        const aiService = require('./aiService');
        await message.channel.sendTyping();

        const response = await aiService.ask(message.content, token, context, history);

        // 6. Action extraction
        const actionBlocks = response.split(/ACTION:\s*/).slice(1);
        let finalReply = response.split(/ACTION:\s*/)[0].trim();
        let action = null;

        if (actionBlocks.length > 0 && isAuthorized) {
            try {
                for (let block of actionBlocks) {
                    let cleanBlock = block.replace(/```json\s*/g, '').replace(/```\s*/g, '');
                    const jsonMatch = cleanBlock.match(/({[\s\S]*?})(?:\s*ACTION:|\s*$)/) || cleanBlock.match(/({[\s\S]*})/);
                    if (jsonMatch) {
                        try {
                            action = JSON.parse(jsonMatch[1]);
                            if (action && action.command) break;
                        } catch (e) { continue; }
                    }
                }

                if (finalReply) await message.reply(`🤖 **AI Console**: ${finalReply}`);
                if (action) await executeInternalAction(message, action.command, action.args, contextOwner.id);
            } catch (jsonErr) {
                console.error('[AI JSON Error]', jsonErr);
                message.reply("❌ AI Console format error.");
            }
        } else {
            message.reply(response);
            if (actionBlocks.length > 0 && !isAuthorized) {
                console.log(`[SECURITY] AI attempted action for unauthorized user ${message.author.tag}`);
            }
        }

        // Save History
        await db.run('INSERT INTO ai_conversations (discord_id, role, content) VALUES (?, "user", ?)', [message.author.id, message.content]);
        await db.run('INSERT INTO ai_conversations (discord_id, role, content) VALUES (?, "assistant", ?)', [message.author.id, finalReply || response]);
        await db.run('DELETE FROM ai_conversations WHERE id IN (SELECT id FROM ai_conversations WHERE discord_id = ? ORDER BY created_at DESC LIMIT -1 OFFSET 20)', [message.author.id]);

    } catch (err) {
        console.error('[AI Handler Error]', err);
        message.reply("❌ AI Console error: " + err.message);
    }
}

/**
 * Shared execution logic for all Bot Commands with Security Isolation.
 */
async function executeInternalAction(trigger, command, args, preAuthOwnerId = null) {
    const db = await getDb();
    const isInteraction = trigger.isChatInputCommand?.() || false;

    const reply = async (content, ephemeral = true) => {
        if (isInteraction) {
            if (trigger.replied || trigger.deferred) return trigger.editReply({ content });
            return trigger.reply({ content, ephemeral });
        }
        return trigger.channel.send(content);
    };

    const replyEmbed = async (embed, ephemeral = true) => {
        if (isInteraction) {
            if (trigger.replied || trigger.deferred) return trigger.editReply({ embeds: [embed] });
            return trigger.reply({ embeds: [embed], ephemeral });
        }
        return trigger.channel.send({ embeds: [embed] });
    };

    try {
        const authorId = trigger.author?.id || trigger.user?.id;

        // SECURITY: Identify which Client (User) this Discord user belongs to.
        let owner = null;

        if (preAuthOwnerId) {
            owner = await db.get('SELECT * FROM users WHERE id = ?', [preAuthOwnerId]);
        } else {
            // 1. Is the user the Global Admin?
            const globalSettings = await db.get('SELECT value FROM system_settings WHERE key = "discord_allowed_ids"');
            const globalAdmins = globalSettings && globalSettings.value ? globalSettings.value.split(',').map(id => id.trim()) : [];
            if (globalAdmins.includes(authorId)) {
                owner = await db.get('SELECT * FROM users WHERE role = "admin" LIMIT 1');
            }

            // 2. Are they a direct owner?
            if (!owner) {
                owner = await db.get('SELECT * FROM users WHERE discord_id = ?', [authorId]);
            }

            // 3. Are they allowed via allowed_admin_ids?
            if (!owner) {
                const potentialClients = await db.all('SELECT * FROM users WHERE allowed_admin_ids IS NOT NULL AND allowed_admin_ids != ""');
                owner = potentialClients.find(u => u.allowed_admin_ids.split(',').map(p => p.trim()).includes(authorId));
            }

            // 4. Role check in guild
            if (!owner && trigger.guild) {
                const member = await trigger.guild.members.fetch(authorId).catch(() => null);
                if (member) {
                    const roles = member.roles.cache.map(r => r.id);
                    if (roles.length > 0) {
                        const placeholders = roles.map(() => '?').join(',');
                        owner = await db.get(`SELECT * FROM users WHERE discord_role_id IN (${placeholders})`, roles);
                    }
                }
            }
        }

        if (!owner) return reply("❌ **Identity Error**: You are not authorized to execute RDX actions. Please link your account or ask the Client Boss to add you.");

        switch (command) {
            case 'stats': {
                let userCount, appCount, keyCount;
                if (owner.role === 'admin') {
                    userCount = await db.get('SELECT count(*) as count FROM users WHERE role != "admin"');
                    appCount = await db.get('SELECT count(*) as count FROM apps');
                    keyCount = await db.get('SELECT count(*) as count FROM licenses');
                } else {
                    userCount = await db.get('SELECT count(*) as count FROM users WHERE app_id IN (SELECT id FROM apps WHERE owner_id = ?)', [owner.id]);
                    appCount = await db.get('SELECT count(*) as count FROM apps WHERE owner_id = ?', [owner.id]);
                    keyCount = await db.get('SELECT count(*) as count FROM licenses WHERE app_id IN (SELECT id FROM apps WHERE owner_id = ?)', [owner.id]);
                }

                const embed = new EmbedBuilder()
                    .setColor('#8C25F4')
                    .setTitle(owner.role === 'admin' ? '📊 Mainframe Global Stats' : '📊 My Mainframe Stats')
                    .addFields(
                        { name: 'My Users', value: (userCount?.count || 0).toString(), inline: true },
                        { name: 'My Apps', value: (appCount?.count || 0).toString(), inline: true },
                        { name: 'My Keys', value: (keyCount?.count || 0).toString(), inline: true }
                    )
                    .setTimestamp();
                return replyEmbed(embed);
            }

            case 'create_user': {
                const { username, password = '1', app_name, duration, unit = 'days', hwid_lock = true } = args;
                const app = await db.get('SELECT id FROM apps WHERE name = ?' + (owner.role === 'admin' ? '' : ' AND owner_id = ?'),
                    owner.role === 'admin' ? [app_name] : [app_name, owner.id]);
                if (!app) return reply(`❌ App **${app_name}** not found or unauthorized.`);

                const bcrypt = require('bcryptjs');
                const hashedPassword = await bcrypt.hash(password, 10);
                const expiryDate = new Date();
                const d = parseInt(duration);
                if (unit === 'days') expiryDate.setDate(expiryDate.getDate() + d);
                else if (unit === 'hours') expiryDate.setHours(expiryDate.getHours() + d);
                else if (unit === 'minutes') expiryDate.setMinutes(expiryDate.getMinutes() + d);

                const parseBool = (val) => {
                    if (val === true || val === 1 || val === 'true' || val === 'on' || val === '1') return 1;
                    return 0;
                };

                await db.run(
                    'INSERT INTO users (username, password_hash, app_id, expiry_date, status, hwid_lock, email) VALUES (?, ?, ?, ?, "active", ?, ?)',
                    [username, hashedPassword, app.id, expiryDate.toISOString(), parseBool(hwid_lock), `${username}@rdx.local`]
                );

                await sendLogToDiscord(owner.id, 'USER CREATED', `Bot created user **${username}** (App: ${app_name})`);
                return reply(`✅ **User Created**: \`${username}\` (Expires: <t:${Math.floor(expiryDate.getTime() / 1000)}:R>)`);
            }

            case 'create_app': {
                const { name } = args;
                if (!name) return reply("❌ **Error**: Application name is required. Usage: `create_app name = My Awesome App` or just `create_app My App`.");

                const exists = await db.get('SELECT id FROM apps WHERE name = ? AND owner_id = ?', [name, owner.id]);
                if (exists) return reply(`❌ **Error**: App **${name}** already exists.`);

                const appCount = await db.get('SELECT COUNT(*) as count FROM apps WHERE owner_id = ?', [owner.id]);
                const plan = (owner.plan || 'starter').toLowerCase();
                let limit = 5;
                if (plan === 'basic') limit = 10;
                else if (plan === 'pro' || owner.role === 'admin') limit = Infinity;

                if (appCount.count >= limit) return reply(`❌ **Plan Limit Reached** (${limit} apps).`);

                const crypto = require('crypto');
                const owner_key = crypto.randomBytes(8).toString('hex').toUpperCase();
                const secret = crypto.randomBytes(16).toString('hex').toUpperCase();

                await db.run('INSERT INTO apps (name, owner_id, owner_key, secret, version) VALUES (?, ?, ?, ?, "1.0.0")', [name, owner.id, owner_key, secret]);
                return reply(`✅ **App Created**: \`${name}\` (API Key: \`${owner_key}\`)`);
            }

            case 'list_apps': {
                const apps = await db.all('SELECT name, version, owner_key FROM apps WHERE owner_id = ?', [owner.id]);
                if (apps.length === 0) return reply("⚠️ You don't have any apps yet. Create one with `create_app name = MyNewApp`.");

                const embed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('📱 Your Owned Applications')
                    .setDescription(apps.map(a => `**${a.name}** | API Key: \`${a.owner_key}\` | v${a.version}`).join('\n') + "\n\n*Use `get_app name = AppName` for full details.*")
                    .setTimestamp();

                return replyEmbed(embed);
            }

            case 'get_app': {
                const { name } = args;
                if (!name) return reply("❌ **Error**: Application name required. Usage: `get_app name = My App`.");

                const app = await db.get('SELECT * FROM apps WHERE name = ?' + (owner.role === 'admin' ? '' : ' AND owner_id = ?'),
                    owner.role === 'admin' ? [name] : [name, owner.id]);

                if (!app) return reply(`❌ App **${name}** not found or unauthorized.`);

                const embed = new EmbedBuilder()
                    .setColor('#8C25F4')
                    .setTitle(`📱 App Details: ${app.name}`)
                    .addFields(
                        { name: 'App ID', value: app.id.toString(), inline: true },
                        { name: 'Version', value: app.version, inline: true },
                        { name: 'Status', value: app.status || 'Active', inline: true },
                        { name: 'Owner Key (API)', value: `\`${app.owner_key}\``, inline: false },
                        { name: 'Secret Key', value: `||${app.secret}||`, inline: false },
                        { name: 'Created At', value: `<t:${Math.floor(new Date(app.created_at).getTime() / 1000)}:R>`, inline: true }
                    )
                    .setFooter({ text: 'Sensitive data is spoiler-masked. Click to reveal.' });

                return replyEmbed(embed);
            }

            case 'bulk_generate': {
                const { app_name, amount = 1, duration = 30, unit = 'days' } = args;
                const app = await db.get('SELECT id FROM apps WHERE name = ?' + (owner.role === 'admin' ? '' : ' AND owner_id = ?'),
                    owner.role === 'admin' ? [app_name] : [app_name, owner.id]);
                if (!app) return reply(`❌ App **${app_name}** not found or unauthorized.`);

                const crypto = require('crypto');
                const keys = [];
                const expiryDate = new Date();
                const d = parseInt(duration);
                if (unit === 'days') expiryDate.setDate(expiryDate.getDate() + d);
                else if (unit === 'hours') expiryDate.setHours(expiryDate.getHours() + d);
                else if (unit === 'minutes') expiryDate.setMinutes(expiryDate.getMinutes() + d);

                for (let i = 0; i < Math.min(amount, 500); i++) {
                    const key = 'RDX-' + crypto.randomBytes(4).toString('hex').toUpperCase() + '-' + crypto.randomBytes(4).toString('hex').toUpperCase();
                    await db.run('INSERT INTO licenses (license_key, app_id, duration, expiry_date, status) VALUES (?, ?, ?, ?, "active")',
                        [key, app.id, duration, expiryDate.toISOString()]);
                    keys.push(key);
                }

                // Return keys in a code block if small amount, otherwise mention count
                let keyList = keys.length <= 10 ? `\n\`\`\`\n${keys.join('\n')}\n\`\`\`` : '';
                return reply(`✅ Generated **${keys.length}** keys for ${app_name} (Expires: <t:${Math.floor(expiryDate.getTime() / 1000)}:R>).${keyList}`);
            }

            case 'list_users': {
                const { app_name, page = 1 } = args;
                const limit = 10;
                const offset = (page - 1) * limit;

                let query = 'SELECT username, status, expiry_date, hwid_lock FROM users';
                let params = [];
                let conditions = [];

                if (app_name) {
                    const app = await db.get('SELECT id FROM apps WHERE name = ?' + (owner.role === 'admin' ? '' : ' AND owner_id = ?'),
                        owner.role === 'admin' ? [app_name] : [app_name, owner.id]);
                    if (!app) return reply(`❌ App **${app_name}** not found or unauthorized.`);
                    conditions.push('app_id = ?');
                    params.push(app.id);
                } else if (owner.role !== 'admin') {
                    conditions.push('app_id IN (SELECT id FROM apps WHERE owner_id = ?)');
                    params.push(owner.id);
                }

                if (conditions.length > 0) query += ' WHERE ' + conditions.join(' AND ');
                query += ` ORDER BY created_at DESC LIMIT ${limit} OFFSET ${offset}`;
                const users = await db.all(query, params);

                if (users.length === 0) return reply(`⚠️ No users found.`);

                const embed = new EmbedBuilder()
                    .setColor('#00ff41')
                    .setTitle(`👥 Users List (${app_name || 'All My Apps'})`)
                    .setDescription(users.map(u =>
                        `**${u.username}** | ${u.status} | ${u.hwid_lock ? '🔒' : '🔓'} | Exp: ${new Date(u.expiry_date).toLocaleDateString()}`
                    ).join('\n'));

                return replyEmbed(embed);
            }

            case 'delete': {
                const { type, target } = args;
                if (type === 'user') {
                    const userFilter = owner.role === 'admin' ? '' : ' AND app_id IN (SELECT id FROM apps WHERE owner_id = ?)';
                    const targetUser = await db.get(`SELECT id FROM users WHERE (username = ? OR id = ?)${userFilter}`,
                        owner.role === 'admin' ? [target, target] : [target, target, owner.id]);
                    if (!targetUser) return reply(`❌ User **${target}** not found or unauthorized.`);

                    await db.run('DELETE FROM users WHERE id = ?', [targetUser.id]);
                    await db.run('UPDATE licenses SET user_id = NULL WHERE user_id = ?', [targetUser.id]);
                    return reply(`🗑️ User **${target}** deleted.`);
                } else if (type === 'app') {
                    const app = await db.get('SELECT id FROM apps WHERE (name = ? OR id = ?)' + (owner.role === 'admin' ? '' : ' AND owner_id = ?'),
                        owner.role === 'admin' ? [target, target] : [target, target, owner.id]);
                    if (!app) return reply(`❌ App **${target}** not found or unauthorized.`);

                    await db.run('DELETE FROM apps WHERE id = ?', [app.id]);
                    await db.run('DELETE FROM licenses WHERE app_id = ?', [app.id]);
                    return reply(`🗑️ App **${target}** deleted.`);
                } else if (type === 'license' || type === 'key') {
                    const licFilter = owner.role === 'admin' ? '' : ' AND app_id IN (SELECT id FROM apps WHERE owner_id = ?)';
                    const lic = await db.get(`SELECT id FROM licenses WHERE (license_key = ? OR id = ?)${licFilter}`,
                        owner.role === 'admin' ? [target, target] : [target, target, owner.id]);
                    if (!lic) return reply(`❌ License **${target}** not found or unauthorized.`);

                    await db.run('DELETE FROM licenses WHERE id = ?', [lic.id]);
                    return reply(`🗑️ License **${target}** deleted (revoked).`);
                }
                return reply("❌ Delete type must be 'user', 'app', or 'license'.");
            }

            case 'ban_license': {
                const { target } = args;
                const licFilter = owner.role === 'admin' ? '' : ' AND app_id IN (SELECT id FROM apps WHERE owner_id = ?)';
                const lic = await db.get(`SELECT id FROM licenses WHERE (license_key = ? OR id = ?)${licFilter}`,
                    owner.role === 'admin' ? [target, target] : [target, target, owner.id]);

                if (!lic) return reply(`❌ License **${target}** not found or unauthorized.`);

                await db.run('UPDATE licenses SET status = "banned" WHERE id = ?', [lic.id]);
                await sendLogToDiscord(owner.id, 'LICENSE BANNED', `Bot banned license **${target}**`);
                return reply(`🚫 License **${target}** has been **BANNED**.`);
            }

            case 'edit_license': {
                const { target, duration, unit, status } = args;
                const licFilter = owner.role === 'admin' ? '' : ' AND app_id IN (SELECT id FROM apps WHERE owner_id = ?)';
                const lic = await db.get(`SELECT id, expiry_date FROM licenses WHERE (license_key = ? OR id = ?)${licFilter}`,
                    owner.role === 'admin' ? [target, target] : [target, target, owner.id]);

                if (!lic) return reply(`❌ License **${target}** not found or unauthorized.`);

                let updates = [];
                let params = [];

                if (duration) {
                    const newExpiry = new Date(lic.expiry_date || Date.now());
                    const d = parseInt(duration);
                    if (unit === 'days') newExpiry.setDate(newExpiry.getDate() + d);
                    else if (unit === 'hours') newExpiry.setHours(newExpiry.getHours() + d);
                    else if (unit === 'minutes') newExpiry.setMinutes(newExpiry.getMinutes() + d);
                    updates.push('expiry_date = ?');
                    params.push(newExpiry.toISOString());
                }

                if (status) {
                    updates.push('status = ?');
                    params.push(status.toLowerCase());
                }

                if (updates.length === 0) return reply("⚠️ No changes specified for license edit.");

                params.push(lic.id);
                await db.run(`UPDATE licenses SET ${updates.join(', ')} WHERE id = ?`, params);
                await sendLogToDiscord(owner.id, 'LICENSE EDITED', `Bot edited license **${target}** (${updates.length} fields modified)`);
                return reply(`✅ License **${target}** updated successfully.`);
            }

            case 'ban_user': {
                const { target } = args;
                const userFilter = owner.role === 'admin' ? '' : ' AND app_id IN (SELECT id FROM apps WHERE owner_id = ?)';
                const targetUser = await db.get(`SELECT id FROM users WHERE (username = ? OR id = ?)${userFilter}`,
                    owner.role === 'admin' ? [target, target] : [target, target, owner.id]);

                if (!targetUser) return reply(`❌ User **${target}** not found or unauthorized.`);

                await db.run('UPDATE users SET status = "banned" WHERE id = ?', [targetUser.id]);
                await sendLogToDiscord(owner.id, 'USER BANNED', `Bot banned user **${target}**`);
                return reply(`🚫 User **${target}** has been **BANNED**.`);
            }

            case 'edit_user': {
                const { target, password, duration, unit, hwid_lock } = args;
                const userFilter = owner.role === 'admin' ? '' : ' AND app_id IN (SELECT id FROM apps WHERE owner_id = ?)';
                const targetUser = await db.get(`SELECT id, expiry_date FROM users WHERE (username = ? OR id = ?)${userFilter}`,
                    owner.role === 'admin' ? [target, target] : [target, target, owner.id]);

                if (!targetUser) return reply(`❌ User **${target}** not found or unauthorized.`);

                let updates = [];
                let params = [];

                if (password) {
                    const bcrypt = require('bcryptjs');
                    const hashedPassword = await bcrypt.hash(password, 10);
                    updates.push('password_hash = ?');
                    params.push(hashedPassword);
                }

                if (duration) {
                    const newExpiry = new Date(targetUser.expiry_date || Date.now());
                    const d = parseInt(duration);
                    if (unit === 'days') newExpiry.setDate(newExpiry.getDate() + d);
                    else if (unit === 'hours') newExpiry.setHours(newExpiry.getHours() + d);
                    else if (unit === 'minutes') newExpiry.setMinutes(newExpiry.getMinutes() + d);
                    updates.push('expiry_date = ?');
                    params.push(newExpiry.toISOString());
                }

                if (hwid_lock !== undefined) {
                    const parseBool = (val) => {
                        if (val === true || val === 1 || val === 'true' || val === 'on' || val === '1') return 1;
                        return 0;
                    };
                    updates.push('hwid_lock = ?');
                    params.push(parseBool(hwid_lock));
                }

                if (updates.length === 0) return reply("⚠️ No changes specified for edit.");

                params.push(targetUser.id);
                await db.run(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, params);
                await sendLogToDiscord(owner.id, 'USER EDITED', `Bot edited user **${target}** (${updates.length} fields modified)`);
                return reply(`✅ User **${target}** updated successfully.`);
            }

            case 'maintenance': {
                if (owner.role !== 'admin') return reply("❌ **Admin Only**.");
                const val = (args.status === 'on') ? 'true' : 'false';
                await db.run("INSERT OR REPLACE INTO system_settings (key, value) VALUES ('maintenance_mode', ?)", [val]);
                return reply(val === 'true' ? '🔴 **MAINTENANCE ENABLED**' : '🟢 **MAINTENANCE DISABLED**');
            }

            case 'discord_ban': {
                const { target, reason } = args;
                if (!trigger.guild) return reply("❌ **Error**: Action must be used inside a Guild.");
                const member = await trigger.guild.members.fetch(target).catch(() => null);
                if (!member) return reply(`❌ User **${target}** not found in this server.`);

                await member.ban({ reason: reason || 'Banned by RDX AI' });
                await logModerationAction(owner.id, member.user.id, member.user.username, 'BAN', reason || 'Banned by RDX AI');
                return reply(`🚫 **Discord Banned**: <@${target}>. Reason: ${reason || 'N/A'}`);
            }

            case 'discord_kick': {
                const { target, reason } = args;
                if (!trigger.guild) return reply("❌ **Error**: Action must be used inside a Guild.");
                const member = await trigger.guild.members.fetch(target).catch(() => null);
                if (!member) return reply(`❌ User **${target}** not found in this server.`);

                await member.kick(reason || 'Kicked by RDX AI');
                await logModerationAction(owner.id, member.user.id, member.user.username, 'KICK', reason || 'Kicked by RDX AI');
                return reply(`👢 **Discord Kicked**: <@${target}>. Reason: ${reason || 'N/A'}`);
            }

            case 'discord_timeout': {
                const { target, reason, minutes } = args;
                if (!trigger.guild) return reply("❌ **Error**: Action must be used inside a Guild.");
                const member = await trigger.guild.members.fetch(target).catch(() => null);
                if (!member) return reply(`❌ User **${target}** not found in this server.`);

                const ms = (parseInt(minutes) || 10) * 60 * 1000;
                await member.timeout(ms, reason || 'Timeout by RDX AI');
                await logModerationAction(owner.id, member.user.id, member.user.username, 'TIMEOUT', reason || 'Timeout by RDX AI');
                return reply(`⏱️ **Discord Timeout**: <@${target}> for ${minutes} mins. Reason: ${reason || 'N/A'}`);
            }

            case 'discord_warn': {
                const { target, reason } = args;
                if (!trigger.guild) return reply("❌ **Error**: Action must be used inside a Guild.");
                const member = await trigger.guild.members.fetch(target).catch(() => null);
                if (!member) return reply(`❌ User **${target}** not found in this server.`);

                await logModerationAction(owner.id, member.user.id, member.user.username, 'WARNING', reason || 'Warned by RDX AI');
                await member.send(`⚠️ You received a warning in **${trigger.guild.name}**: ${reason}`).catch(() => { });
                return reply(`⚠️ **Discord Warned**: <@${target}>. Reason: ${reason || 'N/A'}`);
            }

            case 'update_rule': {
                const { instruction } = args;
                if (!instruction) return reply("❌ No instruction provided.");

                const currentPrompt = owner.ai_alignment_prompt || "";
                // Append the new instruction gracefully
                const newPrompt = currentPrompt
                    ? currentPrompt + "\n- " + instruction
                    : "- " + instruction;

                await db.run('UPDATE users SET ai_alignment_prompt = ? WHERE id = ?', [newPrompt, owner.id]);
                return reply(`✅ **Rule Saved** to Auto-Moderator Memory: \`${instruction}\``);
            }

            default: return reply("❓ Unknown command: " + command);
        }
    } catch (e) {
        console.error('[Action Error]', e);
        return reply("❌ Action failed: " + e.message);
    }
}

async function handleCommand(interaction) {
    const db = await getDb();
    const commandName = interaction.commandName;
    const args = {};
    interaction.options.data.forEach(opt => args[opt.name] = opt.value);
    await executeInternalAction(interaction, commandName, args);
}

async function sendLogToDiscord(ownerId, action, message) {
    try {
        const db = await getDb();
        const settings = await db.get('SELECT discord_log_channel_id FROM users WHERE id = ?', [ownerId]);
        if (!settings || !settings.discord_log_channel_id) return;

        const channel = await client.channels.fetch(settings.discord_log_channel_id).catch(() => null);
        if (!channel) return;

        const embed = new EmbedBuilder()
            .setColor('#2F3136')
            .setTitle(`📜 Log: ${action}`)
            .setDescription(message)
            .setTimestamp();

        channel.send({ embeds: [embed] });
    } catch (err) { console.error('[Log Error]', err); }
}

async function logModerationAction(ownerId, discordUserId, discordUsername, actionType, reason) {
    try {
        const db = await getDb();
        await db.run(
            'INSERT INTO discord_moderation_logs (owner_id, discord_user_id, discord_username, action_type, reason) VALUES (?, ?, ?, ?, ?)',
            [ownerId, discordUserId, discordUsername, actionType, reason]
        );
    } catch (err) {
        console.error('[Discord Log Moderation] Error:', err);
    }
}

async function unbanUser(guildId, userId) {
    if (!client) return false;
    try {
        const guild = await client.guilds.fetch(guildId).catch(() => null);
        if (!guild) return false;

        await guild.members.unban(userId);
        return true;
    } catch (err) {
        console.error(`[Discord Unban] Error unbanning ${userId} in ${guildId}:`, err);
        return false;
    }
}

async function registerCommands(token, clientId) {
    const commands = [
        new SlashCommandBuilder().setName('status').setDescription('Check system status'),
        new SlashCommandBuilder().setName('stats').setDescription('View account stats'),
        new SlashCommandBuilder().setName('list_apps').setDescription('List your owned applications'),
        new SlashCommandBuilder().setName('get_app').setDescription('Get full details of a specific app')
            .addStringOption(o => o.setName('name').setDescription('App name').setRequired(true)),
        new SlashCommandBuilder().setName('create_user').setDescription('Register user')
            .addStringOption(o => o.setName('username').setDescription('Username to create').setRequired(true))
            .addStringOption(o => o.setName('app_name').setDescription('Target Application').setRequired(true))
            .addIntegerOption(o => o.setName('duration').setDescription('Keys duration (days)').setRequired(true)),
        new SlashCommandBuilder().setName('create_app').setDescription('Create app')
            .addStringOption(o => o.setName('name').setDescription('Name for the new app').setRequired(true)),
        new SlashCommandBuilder().setName('delete').setDescription('Delete entity')
            .addStringOption(o => o.setName('type').setDescription('Target type (user/app)').setRequired(true))
            .addStringOption(o => o.setName('target').setDescription('Identifier of target').setRequired(true)),
        new SlashCommandBuilder().setName('ban_user').setDescription('Ban a user')
            .addStringOption(o => o.setName('target').setDescription('Username or ID').setRequired(true)),
        new SlashCommandBuilder().setName('edit_user').setDescription('Edit user details')
            .addStringOption(o => o.setName('target').setDescription('Username or ID').setRequired(true))
            .addStringOption(o => o.setName('password').setDescription('New password'))
            .addIntegerOption(o => o.setName('duration').setDescription('Add time'))
            .addStringOption(o => o.setName('unit').setDescription('Unit (days/hours/minutes)').addChoices({ name: 'Days', value: 'days' }, { name: 'Hours', value: 'hours' }, { name: 'Minutes', value: 'minutes' }))
            .addStringOption(o => o.setName('hwid_lock').setDescription('HWID Lock (on/off)').addChoices({ name: 'On', value: 'on' }, { name: 'Off', value: 'off' }))
    ].map(c => c.toJSON());

    const rest = new REST({ version: '10' }).setToken(token);
    try {
        await rest.put(Routes.applicationCommands(clientId), { body: commands });
        console.log('[RDX Discord] Slash Commands Synchronized.');
    } catch (e) { console.error('[Discord Sync Error]', e); }
}

module.exports = { initDiscordBot, executeInternalAction, sendLogToDiscord, unbanUser };
