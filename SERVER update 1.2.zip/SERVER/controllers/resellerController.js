const { getDb } = require('../config/db');

exports.getMyApps = async (req, res) => {
    const user_id = req.user.id;

    try {
        const db = await getDb();
        const apps = await db.all(`
            SELECT a.* FROM apps a
            JOIN app_resellers ar ON a.id = ar.app_id
            WHERE ar.user_id = ?
        `, [user_id]);

        res.json({ success: true, apps });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

exports.addReseller = async (req, res) => {
    const { app_id, reseller_id } = req.body;

    // Only app owner or admin should be able to do this
    try {
        const db = await getDb();
        const app = await db.get('SELECT owner_id FROM apps WHERE id = ?', [app_id]);

        if (!app || (app.owner_id !== req.user.id && req.user.role !== 'admin')) {
            return res.status(403).json({ success: false, message: 'Unauthorized' });
        }

        await db.run('INSERT OR IGNORE INTO app_resellers (app_id, user_id) VALUES (?, ?)', [app_id, reseller_id]);
        res.json({ success: true, message: 'Reseller added successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
