const { getDb } = require('../config/db');
const crypto = require('crypto');
const securityUtils = require('../utils/securityUtils'); // Re-use VPN checks if possible
const logService = require('../utils/logService');

// Helper to encrypt response strings (simple translation since C# expects specific responses)
// In a real KeyAuth setup, this would use HMAC/AES. We'll send plaintext if ED25519 is disabled, 
// or match whatever encryption the client expects. For now, since sigCheck is disabled, 
// we return raw JSON.
exports.handleRequest = async (req, res) => {
    try {
        const db = await getDb();
        const { type, ownerid, name, sessionid, hwid, username, pass, key, varid } = req.body;

        // Automatically append ownerid to all JSON responses to satisfy KeyAuth C# SDK
        const originalJson = res.json;
        res.json = function(body) {
            if (body && typeof body === 'object' && ownerid) {
                body.ownerid = ownerid;
            }
            return originalJson.call(this, body);
        };

        // Log the incoming KeyAuth request for debugging
        console.log(`[KeyAuth Compat] Request Type: ${type} | App: ${name} | Owner: ${ownerid}`);

        // Security Validation (Ensure the app exists and belongs to the owner)
        const appInfo = await db.get('SELECT * FROM apps WHERE owner_key = ? AND name = ?', [ownerid, name]);

        if (!appInfo && type !== 'log') {
            return res.status(200).json({ success: false, message: 'Application not found.' });
        }

        // Basic Session Validation (if required by SDK after init)
        if (type !== 'init' && type !== 'log') {
            // Verify sessionid exists in active_sessions (we'll create this on init)
            const session = await db.get('SELECT * FROM active_sessions WHERE jti = ?', [sessionid]);
            if (!session) {
                return res.status(200).json({ success: false, message: 'Session expired or invalid.' });
            }
        }

        // --- Handle specific KeyAuth operations ---
        switch (type) {
            case 'init':
                return await handleInit(req, res, appInfo, db);
            case 'login':
                return await handleLogin(req, res, appInfo, db);
            case 'register':
                return await handleRegister(req, res, appInfo, db);
            case 'license':
                return await handleLicense(req, res, appInfo, db);
            case 'check':
                return await handleCheck(req, res, appInfo, db);
            case 'var': // global var
                return await handleGlobalVar(req, res, appInfo, db);
            case 'log':
                return await handleLog(req, res, db);
            default:
                return res.status(200).json({ success: false, message: 'Unsupported KeyAuth operation.' });
        }
    } catch (error) {
        console.error('[KeyAuth Compat] Error:', error);
        res.status(500).json({ success: false, message: 'Internal server error' });
    }
};

async function handleInit(req, res, appInfo, db) {
    // Generate a new Session ID
    const sessionId = crypto.randomUUID().replace(/-/g, '');

    await db.run(
        'INSERT INTO active_sessions (user_id, jti, ip_address, user_agent, expires_at) VALUES (?, ?, ?, ?, ?)',
        [appInfo.owner_id, sessionId, req.ip, req.get('User-Agent'), Date.now() + 3600000] // 1 hour 
    );

    res.status(200).json({
        success: true,
        message: 'Initialized successfully',
        sessionid: sessionId,
        appinfo: {
            numUsers: "100", // Fake stats or query real ones
            numOnlineUsers: "10",
            numKeys: "500",
            version: appInfo.version,
            customerPanelLink: "",
            downloadLink: ""
        }
    });
}

async function handleLogin(req, res, appInfo, db) {
    const { username, pass, hwid } = req.body;

    // Check Global Settings for Auto-Deletion
    const autoDeleteSetting = await db.get("SELECT value FROM system_settings WHERE key = 'auto_delete_expired_licenses'");
    const autoDelete = autoDeleteSetting ? autoDeleteSetting.value === '1' : false;

    let user = await db.get('SELECT * FROM users WHERE app_id = ? AND username = ?', [appInfo.id, username]);
    let license = null;
    let isLicenseLogin = false;

    if (!user) {
        // Try to find a standalone license key acting as a username
        license = await db.get('SELECT * FROM licenses WHERE app_id = ? AND license_key = ? AND user_id IS NULL', [appInfo.id, username]);
        if (license) {
            isLicenseLogin = true;
        } else {
            return res.status(200).json({ success: false, message: 'User or License not found.' });
        }
    }

    if (isLicenseLogin) {
        // Handle standalone License Key login
        if (license.status !== 'active') {
            return res.status(200).json({ success: false, message: `License status: ${license.status}` });
        }

        // Expiry Check
        if (license.expiry_date && new Date(license.expiry_date) < new Date()) {
            if (autoDelete) {
                await db.run('DELETE FROM licenses WHERE id = ?', [license.id]);
                await logService.recordLog(null, appInfo.id, `AUTO_DELETE_EXPIRED: ${license.license_key}`, req.ip, hwid);
                return res.status(200).json({ success: false, message: 'License expired and purged.' });
            }
            return res.status(200).json({ success: false, message: 'License key expired.' });
        }

        // HWID Check on License
        if (license.hwid_lock == 1) {
            if (license.hwid && license.hwid !== hwid) {
                await logService.recordLog(null, appInfo.id, 'LOGIN_FAILED_HWID_HWID_SDK', req.ip, hwid);
                return res.status(200).json({ success: false, message: 'HWID mismatch.' });
            } else if (!license.hwid && hwid) {
                await db.run('UPDATE licenses SET hwid = ? WHERE id = ?', [hwid, license.id]);
            }
        } else {
            if (!license.hwid && hwid) {
                await db.run('UPDATE licenses SET hwid = ? WHERE id = ?', [hwid, license.id]);
            }
        }

        await logService.recordLog(null, appInfo.id, 'LICENSE_LOGIN_SUCCESS_SDK', req.ip, hwid);

        res.status(200).json({
            success: true,
            message: 'Logged in successfully via Key',
            info: {
                username: license.license_key,
                ip: req.ip,
                hwid: hwid,
                createdate: Math.floor(new Date(license.created_at).getTime() / 1000).toString(),
                lastlogin: Math.floor(Date.now() / 1000).toString(),
                subscriptions: [{
                    subscription: 'default',
                    expiry: license.expiry_date ? Math.floor(new Date(license.expiry_date).getTime() / 1000).toString() : '0',
                    timeleft: license.expiry_date ? Math.floor((new Date(license.expiry_date).getTime() - Date.now()) / 1000).toString() : '0'
                }]
            }
        });
        return;
    }

    // Standard User Password check handling
    let isMatch = false;
    if (user.password_hash && (user.password_hash.startsWith('$2a$') || user.password_hash.startsWith('$2b$') || user.password_hash.startsWith('$2y$'))) {
        const bcrypt = require('bcryptjs');
        isMatch = await bcrypt.compare(pass, user.password_hash);
    } else {
        isMatch = (user.password_hash === crypto.createHash('md5').update(pass).digest('hex'));
    }

    if (!isMatch) {
        await logService.recordLog(user.id, appInfo.id, 'LOGIN_FAILED_PASSWORD_SDK', req.ip, hwid);
        return res.status(200).json({ success: false, message: 'Invalid password.' });
    }

    // User Expiry Check
    if (user.expiry_date && new Date(user.expiry_date) < new Date()) {
        return res.status(200).json({ success: false, message: 'Your account has expired.' });
    }

    // HWID Check
    if (user.hwid_lock == 1) {
        if (user.hwid && user.hwid !== hwid) {
            await logService.recordLog(user.id, appInfo.id, 'LOGIN_FAILED_HWID_SDK', req.ip, hwid);
            return res.status(200).json({ success: false, message: 'HWID mismatch.' });
        } else if (!user.hwid) {
            await db.run('UPDATE users SET hwid = ? WHERE id = ?', [hwid, user.id]);
        }
    } else {
        // Optionially track HWID even if not locked
        if (!user.hwid && hwid) {
            await db.run('UPDATE users SET hwid = ? WHERE id = ?', [hwid, user.id]);
        }
    }

    const subscriptions = [];
    if (user.subscription_id) {
        const directSub = await db.get('SELECT name, level FROM app_subscriptions WHERE id = ?', [user.subscription_id]);
        if (directSub) {
            subscriptions.push({
                subscription: directSub.name,
                expiry: user.expiry_date ? Math.floor(new Date(user.expiry_date).getTime() / 1000).toString() : '0',
                timeleft: user.expiry_date ? Math.floor((new Date(user.expiry_date).getTime() - Date.now()) / 1000).toString() : '0'
            });
        }
    }

    const linkedLicenses = await db.all(`
        SELECT l.*, s.name as sub_name, s.level 
        FROM licenses l 
        LEFT JOIN app_subscriptions s ON l.subscription_id = s.id
        WHERE (l.user_id = ? OR l.app_user_id = ?) AND l.app_id = ? AND l.status = 'active'
    `, [user.id, user.id, appInfo.id]);

    linkedLicenses.forEach(l => {
        subscriptions.push({
            subscription: l.sub_name || 'default',
            expiry: l.expiry_date ? Math.floor(new Date(l.expiry_date).getTime() / 1000).toString() : '0',
            timeleft: l.expiry_date ? Math.floor((new Date(l.expiry_date).getTime() - Date.now()) / 1000).toString() : '0'
        });
    });

    if (subscriptions.length === 0 && !user.expiry_date) {
        return res.status(200).json({ success: false, message: 'No active subscriptions found.' });
    }

    await logService.recordLog(user.id, appInfo.id, 'LOGIN_SUCCESS_SDK', req.ip, hwid);

    res.status(200).json({
        success: true,
        message: 'Logged in successfully',
        info: {
            username: user.username,
            ip: req.ip,
            hwid: hwid,
            createdate: Math.floor(new Date(user.created_at).getTime() / 1000).toString(),
            lastlogin: Math.floor(Date.now() / 1000).toString(),
            subscriptions: subscriptions
        }
    });
}

// Additional handlers like register, license, etc...
// (Will map closely to handleLogin logic)
async function handleRegister(req, res, appInfo, db) {
    return res.status(200).json({ success: false, message: 'Registration under development.' });
}

async function handleLicense(req, res, appInfo, db) {
    const { key, hwid } = req.body;

    // Check Global Settings for Auto-Deletion
    const autoDeleteSetting = await db.get("SELECT value FROM system_settings WHERE key = 'auto_delete_expired_licenses'");
    const autoDelete = autoDeleteSetting ? autoDeleteSetting.value === '1' : false;

    const license = await db.get(`
        SELECT l.*, s.name as sub_name, s.level 
        FROM licenses l 
        LEFT JOIN app_subscriptions s ON l.subscription_id = s.id
        WHERE l.license_key = ? AND l.app_id = ?
    `, [key, appInfo.id]);

    if (!license) {
        return res.status(200).json({ success: false, message: 'Invalid license key.' });
    }

    if (license.status !== 'active') {
        return res.status(200).json({ success: false, message: `License status: ${license.status}` });
    }

    // Expiry Check
    if (license.expiry_date && new Date(license.expiry_date) < new Date()) {
        if (autoDelete) {
            await db.run('DELETE FROM licenses WHERE id = ?', [license.id]);
            await logService.recordLog(null, appInfo.id, `AUTO_DELETE_EXPIRED: ${license.license_key}`, req.ip, hwid);
            return res.status(200).json({ success: false, message: 'License expired and purged.' });
        }
        return res.status(200).json({ success: false, message: 'License key expired.' });
    }

    // HWID Check on License
    if (license.hwid_lock == 1) {
        if (license.hwid && license.hwid !== hwid) {
            await logService.recordLog(null, appInfo.id, 'LICENSE_FAILED_HWID_SDK', req.ip, hwid);
            return res.status(200).json({ success: false, message: 'HWID mismatch.' });
        } else if (!license.hwid && hwid) {
            // Lock HWID on first login
            await db.run('UPDATE licenses SET hwid = ? WHERE id = ?', [hwid, license.id]);
        }
    } else {
        // Track HWID even if not locked
        if (!license.hwid && hwid) {
            await db.run('UPDATE licenses SET hwid = ? WHERE id = ?', [hwid, license.id]);
        }
    }

    const subscriptions = [{
        subscription: license.sub_name || 'default',
        expiry: license.expiry_date ? Math.floor(new Date(license.expiry_date).getTime() / 1000).toString() : '0',
        timeleft: license.expiry_date ? Math.floor((new Date(license.expiry_date).getTime() - Date.now()) / 1000).toString() : '0'
    }];

    await logService.recordLog(null, appInfo.id, 'LICENSE_SUCCESS_SDK', req.ip, hwid);

    // Build format expected by C# JSON deserializer
    res.status(200).json({
        success: true,
        message: 'Logged in successfully',
        info: {
            username: key, 
            ip: req.ip,
            hwid: hwid,
            createdate: Math.floor(new Date(license.created_at).getTime() / 1000).toString(), 
            lastlogin: Math.floor(Date.now() / 1000).toString(),
            subscriptions: subscriptions
        }
    });
}

async function handleCheck(req, res, appInfo, db) {
    return res.status(200).json({ success: true, message: 'Session active' });
}

async function handleGlobalVar(req, res, appInfo, db) {
    const { varid, sessionid } = req.body;

    if (!varid) {
        return res.status(200).json({ success: false, message: 'Variable ID (varid) is required.' });
    }

    try {
        const variable = await db.get('SELECT value FROM variables WHERE app_id = ? AND name = ?', [appInfo.id, varid]);

        if (!variable) {
            return res.status(200).json({ success: false, message: 'Variable not found.' });
        }

        res.status(200).json({
            success: true,
            message: 'Variable fetched successfully',
            response: variable.value
        });
    } catch (err) {
        console.error('[KeyAuth Compat] Var Error:', err);
        res.status(200).json({ success: false, message: 'Error fetching variable.' });
    }
}

async function handleLog(req, res, db) {
    return res.status(200).json({ success: true });
}
