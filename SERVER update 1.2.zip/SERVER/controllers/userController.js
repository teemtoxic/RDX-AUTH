const { getDb } = require('../config/db');
const crypto = require('crypto');
const logService = require('../utils/logService');
const emailService = require('../utils/emailService');
const discordService = require('../utils/discordService');
const sendResponse = require('../utils/responseHelper');

exports.getUserApps = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        console.log(`[RDX Debug] Loading apps for user ID: ${userId}`);

        // If user is admin, they might want to see ALL apps? 
        // For now, let's keep "My Apps" strictly as "Apps I own". 
        // Admins can use the Admin Dashboard for global view if needed, 
        // but this dashboard seems to be the main interface.
        // If I am an Admin, I am also a User. So I see my apps.
        // If the Admin dashboard (index.html) is separate, that's fine. 
        // This is for dashboard.html which seems to be the "Client Area".

        const apps = await db.all('SELECT * FROM apps WHERE owner_id = ?', [userId]);
        return sendResponse(res, 200, true, apps, 'Apps fetched successfully');
    } catch (error) {
        console.error('[RDX User Apps] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error loading apps');
    }
};

exports.createApp = async (req, res) => {
    const { name, version } = req.body;
    const owner_id = req.user.id;

    console.log('[RDX Debug] Create App Request:', { body: req.body, user: req.user });

    if (!name) {
        console.log('[RDX Debug] Create App Failed: Name is required');
        return sendResponse(res, 400, false, null, 'App name is required');
    }

    try {
        const db = await getDb();

        // 1. Check Plan Limits
        // We need to fetch the user's current plan and app count
        const user = await db.get('SELECT plan FROM users WHERE id = ?', [owner_id]);
        const appCount = await db.get('SELECT COUNT(*) as count FROM apps WHERE owner_id = ?', [owner_id]);

        const plan = user ? user.plan : 'starter';
        const currentCount = appCount.count;
        let limit = 5; // Default Starter

        if (plan === 'basic') limit = 10;
        else if (plan === 'pro') limit = Infinity;

        console.log(`[RDX Plan Check] User: ${req.user.username}, Plan: ${plan}, Apps: ${currentCount}/${limit}`);

        if (currentCount >= limit) {
            return sendResponse(res, 403, false, null, `Plan limit reached (${currentCount}/${limit}). Upgrade to create more apps.`);
        }

        // Auto-generate unique identifiers
        const owner_key = crypto.randomBytes(8).toString('hex').toUpperCase();
        const secret = crypto.randomBytes(16).toString('hex').toUpperCase();

        const result = await db.run(
            'INSERT INTO apps (name, owner_id, owner_key, secret, version) VALUES (?, ?, ?, ?, ?)',
            [name, owner_id, owner_key, secret, version || '1.0.0']
        );

        await logService.recordLog(owner_id, result.lastID, `APP CREATED: ${name}`, req.ip, null, req.headers['user-agent']);

        return sendResponse(res, 201, true, {
            id: result.lastID,
            name,
            owner_key,
            secret,
            version: version || '1.0.0'
        }, 'Application created successfully');
    } catch (error) {
        if (error.message.includes('UNIQUE constraint failed')) {
            console.log(`[RDX Debug] Create App Failed: Name "${name}" already exists`);
            return sendResponse(res, 400, false, null, 'App name already exists');
        }
        console.error('[RDX Create App] Error:', error);
        return sendResponse(res, 500, false, null, `Server error creating app: ${error.message}`);
    }
};

exports.getUserLicenses = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;

        // Fetch licenses for apps owned by this user (or all if admin)
        // We join with apps to ensure ownership
        let baseQuery = `
            FROM licenses l
            LEFT JOIN apps a ON l.app_id = a.id
            LEFT JOIN users u ON l.user_id = u.id
        `;
        const params = [];

        if (req.user.role !== 'admin') {
            baseQuery += ' WHERE a.owner_id = ?';
            params.push(userId);
        }

        // Get total count for pagination
        const query = `
            SELECT l.*, a.name as app_name, u.username
            ${baseQuery}
            ORDER BY l.created_at DESC
            LIMIT ? OFFSET ?
        `;

        const countResult = await db.get(`SELECT COUNT(*) as total ${baseQuery}`, params);
        const licenses = await db.all(query, [...params, limit, offset]);

        const total = countResult ? countResult.total : 0;

        return sendResponse(res, 200, true, { licenses, total, limit, offset }, 'Licenses fetched');
    } catch (error) {
        console.error('[RDX User Licenses] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error loading licenses');
    }
};

exports.getUserStats = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        console.log(`[RDX Analytics Debug] Loading stats for User ID: ${userId} (${req.user.username})`);

        // Execute all heavy queries in parallel to significantly improve load time
        // 1. Core Counts
        let coreQuery = `
            SELECT 
                (SELECT COUNT(*) FROM apps WHERE owner_id = ?) as totalApps,
                (SELECT COUNT(*) FROM licenses l JOIN apps a ON l.app_id = a.id WHERE a.owner_id = ?) as totalLicenses,
                (SELECT COUNT(DISTINCT u.id) FROM users u 
                 LEFT JOIN licenses l ON u.id = l.user_id 
                 LEFT JOIN apps a_lic ON l.app_id = a_lic.id 
                 LEFT JOIN apps a_usr ON u.app_id = a_usr.id 
                 WHERE a_lic.owner_id = ? OR a_usr.owner_id = ?) as totalUsers
        `;
        let coreParams = [userId, userId, userId, userId];

        if (req.user.role === 'admin') {
            coreQuery = `
                SELECT 
                    (SELECT COUNT(*) FROM apps) as totalApps,
                    (SELECT COUNT(*) FROM licenses) as totalLicenses,
                    (SELECT COUNT(*) FROM users) as totalUsers
            `;
            coreParams = [];
        }
        const coreStats = await db.get(coreQuery, coreParams);

        // 2. License Status
        let licQuery = `
            SELECT 
                COUNT(CASE WHEN l.user_id IS NOT NULL AND l.status = 'active' THEN 1 END) as used,
                COUNT(CASE WHEN l.user_id IS NULL AND l.status = 'active' THEN 1 END) as unused,
                COUNT(CASE WHEN l.status = 'banned' THEN 1 END) as banned,
                COUNT(CASE WHEN l.status = 'paused' THEN 1 END) as paused
            FROM licenses l
            JOIN apps a ON l.app_id = a.id
            WHERE a.owner_id = ?
        `;
        let licParams = [userId];

        if (req.user.role === 'admin') {
            licQuery = `
                SELECT 
                    COUNT(CASE WHEN user_id IS NOT NULL AND status = 'active' THEN 1 END) as used,
                    COUNT(CASE WHEN user_id IS NULL AND status = 'active' THEN 1 END) as unused,
                    COUNT(CASE WHEN status = 'banned' THEN 1 END) as banned,
                    COUNT(CASE WHEN status = 'paused' THEN 1 END) as paused
                FROM licenses
            `;
            licParams = [];
        }
        const licStatus = await db.get(licQuery, licParams);

        // 3. User Status
        let usrQuery = `
            SELECT 
                COUNT(DISTINCT CASE WHEN u.status = 'active' AND u.hwid IS NOT NULL THEN u.id END) as active,
                COUNT(DISTINCT CASE WHEN u.status = 'active' AND u.hwid IS NULL THEN u.id END) as unused,
                COUNT(DISTINCT CASE WHEN u.status = 'paused' THEN u.id END) as paused,
                COUNT(DISTINCT CASE WHEN u.status = 'banned' THEN u.id END) as banned
            FROM users u 
            LEFT JOIN licenses l ON u.id = l.user_id 
            LEFT JOIN apps a_lic ON l.app_id = a_lic.id 
            LEFT JOIN apps a_usr ON u.app_id = a_usr.id 
            WHERE a_lic.owner_id = ? OR a_usr.owner_id = ?
        `;
        let usrParams = [userId, userId];

        if (req.user.role === 'admin') {
            usrQuery = `
                SELECT 
                    COUNT(CASE WHEN status = 'active' AND hwid IS NOT NULL THEN id END) as active,
                    COUNT(CASE WHEN status = 'active' AND hwid IS NULL THEN id END) as unused,
                    COUNT(CASE WHEN status = 'paused' THEN id END) as paused,
                    COUNT(CASE WHEN status = 'banned' THEN id END) as banned
                FROM users
            `;
            usrParams = [];
        }
        const usrStatus = await db.get(usrQuery, usrParams);

        // 4. Hit Stats (Total, Failed) from LOGS
        let hitQuery = `
            SELECT 
                COUNT(*) as totalHits24h,
                COUNT(CASE WHEN (l.action LIKE '%FAILED%' OR l.action LIKE '%REJECTED%') THEN 1 END) as failedHits24h
            FROM logs l 
            JOIN apps a ON l.app_id = a.id 
            WHERE a.owner_id = ? 
            AND (l.action LIKE 'LOGIN%' OR l.action LIKE 'AUTH%' OR l.action LIKE 'VALIDATE%' OR l.action LIKE 'USER_LOGIN%' OR l.action LIKE 'APP_LOGIN%' OR l.action LIKE '%SDK%') 
            AND l.timestamp >= datetime('now', '-24 hours')
        `;
        let hitParams = [userId];

        if (req.user.role === 'admin') {
            hitQuery = `
                SELECT 
                    COUNT(*) as totalHits24h,
                    COUNT(CASE WHEN (action LIKE '%FAILED%' OR action LIKE '%REJECTED%') THEN 1 END) as failedHits24h
                FROM logs 
                WHERE (action LIKE 'LOGIN%' OR action LIKE 'AUTH%' OR action LIKE 'VALIDATE%' OR action LIKE 'USER_LOGIN%' OR action LIKE 'APP_LOGIN%' OR action LIKE '%SDK%') 
                AND timestamp >= datetime('now', '-24 hours')
            `;
            hitParams = [];
        }
        const hitStats = await db.get(hitQuery, hitParams);

        // 5. Authentication Traffic (last 24h chart data)
        let authTrafficQuery = `
            SELECT strftime('%H:00', datetime(l.timestamp, 'localtime')) as hour, COUNT(*) as count 
            FROM logs l
            JOIN apps a ON l.app_id = a.id
            WHERE a.owner_id = ?
            AND (l.action LIKE 'LOGIN%' OR l.action LIKE 'AUTH%' OR l.action LIKE 'VALIDATE%' OR l.action LIKE 'USER_LOGIN%' OR l.action LIKE 'APP_LOGIN%' OR l.action LIKE '%SDK%')
            AND l.timestamp >= datetime('now', '-24 hours')
            GROUP BY hour
        `;
        let authTrafficParams = [userId];

        if (req.user.role === 'admin') {
            authTrafficQuery = `
                SELECT strftime('%H:00', datetime(timestamp, 'localtime')) as hour, COUNT(*) as count 
                FROM logs 
                WHERE (action LIKE 'LOGIN%' OR action LIKE 'AUTH%' OR action LIKE 'VALIDATE%' OR action LIKE 'USER_LOGIN%' OR action LIKE 'APP_LOGIN%' OR action LIKE '%SDK%')
                AND timestamp >= datetime('now', '-24 hours')
                GROUP BY hour
            `;
            authTrafficParams = [];
        }
        const authTrafficStats = await db.all(authTrafficQuery, authTrafficParams);

        // 6. Registration Traffic (last 24h)
        let regTrafficQuery = `
            SELECT strftime('%H:00', datetime(l.timestamp, 'localtime')) as hour, COUNT(*) as count 
            FROM logs l
            JOIN apps a ON l.app_id = a.id
            WHERE a.owner_id = ?
            AND (l.action LIKE 'REGISTER%' OR l.action LIKE 'REDEEM%' OR l.action LIKE 'KEY_GEN%')
            AND l.timestamp >= datetime('now', '-24 hours')
            GROUP BY hour
        `;
        let regTrafficParams = [userId];

        if (req.user.role === 'admin') {
            regTrafficQuery = `
                SELECT strftime('%H:00', datetime(timestamp, 'localtime')) as hour, COUNT(*) as count 
                FROM logs 
                WHERE (action LIKE 'REGISTER%' OR action LIKE 'REDEEM%' OR action LIKE 'KEY_GEN%')
                AND timestamp >= datetime('now', '-24 hours')
                GROUP BY hour
            `;
            regTrafficParams = [];
        }
        const regTrafficStats = await db.all(regTrafficQuery, regTrafficParams);

        const hitRate = hitStats.totalHits24h > 0 ? Math.round(((hitStats.totalHits24h - hitStats.failedHits24h) / hitStats.totalHits24h) * 100) : 0;

        // 7. Data Formatting for Charts
        const authData = new Array(24).fill(0);
        const regData = new Array(24).fill(0);
        const trafficLabels = [];

        // UTC to Local sync and fill (SQLite logs in UTC)
        authTrafficStats.forEach(r => {
            const h = parseInt(r.hour.split(':')[0]);
            if (!isNaN(h)) authData[h] = r.count;
        });
        regTrafficStats.forEach(r => {
            const h = parseInt(r.hour.split(':')[0]);
            if (!isNaN(h)) regData[h] = r.count;
        });

        const authTrafficData = [];
        const regTrafficData = [];
        for (let i = 23; i >= 0; i--) {
            const d = new Date(); d.setHours(d.getHours() - i);
            const h = d.getHours();
            authTrafficData.push(authData[h]);
            regTrafficData.push(regData[h]);
            trafficLabels.push(h.toString().padStart(2, '0') + ':00');
        }

        const stats = {
            users: coreStats.totalUsers,
            licenses: coreStats.totalLicenses,
            totalApps: coreStats.totalApps,
            licenseRequests: regTrafficStats.reduce((sum, r) => sum + r.count, 0),
            hits24h: hitStats.totalHits24h,
            blockedHits: hitStats.failedHits24h,
            totalHits: hitStats.totalHits24h, // Backwards compat
            hitRate,
            keys: licStatus,
            users_status: usrStatus,
            authTrafficData,
            regTrafficData,
            trafficLabels
        };

        return sendResponse(res, 200, true, { stats }, 'User stats fetched');
    } catch (error) {
        console.error('[RDX User Stats] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error loading stats');
    }
};

exports.createUser = async (req, res) => {
    const { username, password, app_id, subscription_id, expiry_days, expiry_date, hwid_lock, generate_license } = req.body;
    const userId = req.user.id;

    try {
        const db = await getDb();

        // Verify app ownership
        const app = await db.get('SELECT * FROM apps WHERE id = ? AND owner_id = ?', [app_id, userId]);
        if (!app) return res.status(404).json({ success: false, message: 'Application not found or access denied' });

        // Ensure subscription belongs to this app if provided
        if (subscription_id) {
            const sub = await db.get('SELECT * FROM app_subscriptions WHERE id = ? AND app_id = ?', [subscription_id, app_id]);
            if (!sub) return res.status(400).json({ success: false, message: 'Invalid subscription plan for this application' });
        }

        const userExists = await db.get('SELECT id FROM users WHERE username = ?', [username]);
        if (userExists) {
            return sendResponse(res, 400, false, null, 'Username already exists');
        }

        const hashedPassword = await require('bcryptjs').hash(password, 10);

        // Calculate Expiry Date for the User record
        let user_expiry_date = null;
        if (expiry_date) {
            user_expiry_date = new Date(expiry_date);
            if (isNaN(user_expiry_date.getTime())) user_expiry_date = null;
        } else if (expiry_days) {
            user_expiry_date = new Date();
            user_expiry_date.setDate(user_expiry_date.getDate() + parseInt(expiry_days));
        }

        // We assume subscription_id is added to the users table; using dynamic insert to avoid crash if not.
        const userResult = await db.run(
            'INSERT INTO users (username, password_hash, role, status, app_id, expiry_date, hwid_lock) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [username, hashedPassword, 'user', 'active', app_id, user_expiry_date ? user_expiry_date.toISOString() : null, hwid_lock ? 1 : 0]
        );
        const target_user_id = userResult.lastID;

        // Try binding subscription_id (graceful fallback if column doesn't exist yet)
        if (subscription_id) {
            try {
                await db.run('UPDATE users SET subscription_id = ? WHERE id = ?', [subscription_id, target_user_id]);
            } catch (e) {
                console.log('[RDX Warning] Could not update subscription_id on users table. Might need schema update:', e.message);
            }
        }


        await logService.recordLog(userId, app_id, `USER CREATED BY OWNER: ${username}`, req.ip, null, req.headers['user-agent']);

        // Discord Notification to Client (Owner)
        discordService.sendLogToDiscord(userId, 'MEMBER CREATED', `New member **${username}** has been created for app **${app.name}**.`);

        return sendResponse(res, 201, true, null, 'User created successfully');
    } catch (error) {
        console.error('[RDX Create User] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.createLicense = async (req, res) => {
    const { app_id, subscription_id, duration_days, expiry_date, hwid_lock } = req.body;
    const userId = req.user.id;

    if (!app_id) return sendResponse(res, 400, false, null, 'App is required');

    try {
        const db = await getDb();

        // Verify app ownership
        const app = await db.get('SELECT * FROM apps WHERE id = ? AND owner_id = ?', [app_id, userId]);
        if (!app) return res.status(404).json({ success: false, message: 'Application not found or access denied' });

        // Ensure subscription belongs to this app if provided
        if (subscription_id) {
            const sub = await db.get('SELECT * FROM app_subscriptions WHERE id = ? AND app_id = ?', [subscription_id, app_id]);
            if (!sub) return res.status(400).json({ success: false, message: 'Invalid subscription plan for this application' });
        }

        const license_key = crypto.randomBytes(12).toString('hex').toUpperCase();

        let finalExpiry = expiry_date || null;
        let finalDuration = duration_days || null;

        // If expiry is provided but not duration, calculate duration
        if (finalExpiry && !finalDuration) {
            finalDuration = Math.ceil((new Date(finalExpiry) - new Date()) / 86400000);
        }
        // If duration is provided but not expiry, calculate expiry
        else if (!finalExpiry && finalDuration) {
            const d = new Date();
            d.setDate(d.getDate() + parseInt(finalDuration));
            finalExpiry = d.toISOString();
        }

        await db.run(
            'INSERT INTO licenses (license_key, app_id, subscription_id, duration, expiry_date, status, hwid_lock) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [license_key, app_id, subscription_id || null, finalDuration, finalExpiry, 'active', hwid_lock !== undefined ? (hwid_lock ? 1 : 0) : 1]
        );

        await logService.recordLog(userId, app_id, `LICENSE GENERATED BY OWNER: ${license_key}`, req.ip, null, req.headers['user-agent']);

        // Discord Notification to Client (Owner)
        discordService.sendLogToDiscord(userId, 'LICENSE GENERATED', `New license key generated for app **${app.name}**: \`${license_key}\` (Duration: ${finalDuration} days)`);

        return sendResponse(res, 201, true, license_key, 'License generated successfully');
    } catch (error) {
        console.error('[RDX Create License] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.getUserLogs = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;

        const baseQuery = `
            FROM logs l
            LEFT JOIN users u ON l.user_id = u.id
            LEFT JOIN apps a ON l.app_id = a.id
            WHERE a.owner_id = ? OR (l.user_id = ? AND l.app_id IS NULL)
        `;

        const countResult = await db.get(`SELECT COUNT(*) as total ${baseQuery}`, [userId, userId]);
        const total = countResult ? countResult.total : 0;

        const query = `
            SELECT l.*, u.username, a.name as app_name 
            ${baseQuery}
            ORDER BY l.timestamp DESC 
            LIMIT ? OFFSET ?
        `;

        const logs = await db.all(query, [userId, userId, limit, offset]);
        return sendResponse(res, 200, true, { logs, total, limit, offset }, 'Logs fetched successfully');
    } catch (error) {
        console.error('[RDX User Logs] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error loading logs');
    }
};

exports.getUserList = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        const { appId, page = 1, limit = 10 } = req.query;
        const offset = (page - 1) * limit;

        let baseQuery = `
            FROM users u
            LEFT JOIN licenses l ON u.id = l.user_id
            LEFT JOIN apps a ON (u.app_id = a.id OR l.app_id = a.id)
            WHERE a.owner_id = ?
        `;
        const params = [userId];

        if (appId) {
            baseQuery += ' AND a.id = ?';
            params.push(appId);
        }

        const query = `
            SELECT DISTINCT u.id, u.username, u.email, u.status, u.created_at, 
            COALESCE(u.expiry_date, l.expiry_date) as expiry_date, 
            COALESCE(u.app_id, l.app_id) as app_id,
            COALESCE(u.hwid, l.hwid) as hwid, 
            COALESCE(u.hwid_lock, l.hwid_lock) as hwid_lock,
            a.name as app_name,
            sub.name as subscription_name,
            (SELECT timestamp FROM logs WHERE user_id = u.id AND action LIKE '%LOGIN%' ORDER BY timestamp DESC LIMIT 1) as last_login,
            (SELECT ip FROM logs WHERE user_id = u.id AND action LIKE '%LOGIN%' ORDER BY timestamp DESC LIMIT 1) as last_ip,
            (SELECT COUNT(*) FROM logs WHERE user_id = u.id AND (action LIKE '%LOGIN%' OR action LIKE '%SDK%')) as total_hits
            FROM users u
            LEFT JOIN licenses l ON u.id = l.user_id
            LEFT JOIN apps a ON (u.app_id = a.id OR l.app_id = a.id)
            LEFT JOIN app_subscriptions sub ON (u.subscription_id = sub.id OR l.subscription_id = sub.id)
            WHERE a.owner_id = ?
            ${appId ? ' AND a.id = ?' : ''}
            ORDER BY u.created_at DESC
            LIMIT ? OFFSET ?
        `;

        const countResult = await db.get(`SELECT COUNT(DISTINCT u.id) as total ${baseQuery}`, params);
        const users = await db.all(query, [...params, parseInt(limit), parseInt(offset)]);

        const total = countResult ? countResult.total : 0;
        return sendResponse(res, 200, true, {
            users,
            pagination: {
                total,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: Math.ceil(total / limit)
            }
        }, 'User list fetched');
    } catch (error) {
        console.error('[RDX User List] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error loading users');
    }
};

exports.updateUser = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        const targetId = req.params.id;
        const { password, expiry_date, hwid_lock, discord_id, app_id } = req.body;

        // Verify ownership
        // A user is "owned" if they are assigned to an app owned by this user
        const user = await db.get(`
            SELECT u.* FROM users u 
            LEFT JOIN apps a ON (u.app_id = a.id)
            LEFT JOIN licenses l ON (u.id = l.user_id)
            LEFT JOIN apps al ON (l.app_id = al.id)
            WHERE u.id = ? AND (a.owner_id = ? OR al.owner_id = ?)
        `, [targetId, userId, userId]);

        if (!user) return res.status(404).json({ success: false, message: 'User not found or access denied' });

        if (password) {
            const hashedPassword = await require('bcryptjs').hash(password, 10);
            await db.run('UPDATE users SET password_hash = ? WHERE id = ?', [hashedPassword, targetId]);
        }

        // Update user record directly
        await db.run('UPDATE users SET expiry_date = ?, hwid_lock = ?, app_id = ?, discord_id = ? WHERE id = ?',
            [expiry_date || user.expiry_date, hwid_lock !== undefined ? (hwid_lock ? 1 : 0) : user.hwid_lock, app_id || user.app_id, discord_id || user.discord_id, targetId]);

        // Sync with licenses table
        if (hwid_lock !== undefined) {
            await db.run('UPDATE licenses SET hwid_lock = ? WHERE user_id = ?', [hwid_lock ? 1 : 0, targetId]);
        }

        // For now, let's keep it simple and prioritize user table.

        return sendResponse(res, 200, true, null, 'User updated successfully');
    } catch (error) {
        console.error('[RDX User Update] Error:', error);
        return sendResponse(res, 500, false, null, 'Update failed');
    }
};

exports.deleteUser = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        const targetId = req.params.id;

        // Verify ownership (Standalone via app_id OR License-based)
        const user = await db.get(`
            SELECT u.* FROM users u 
            LEFT JOIN apps a ON (u.app_id = a.id)
            LEFT JOIN licenses l ON (u.id = l.user_id)
            LEFT JOIN apps al ON (l.app_id = al.id)
            WHERE u.id = ? AND (a.owner_id = ? OR al.owner_id = ?)
        `, [targetId, userId, userId]);

        if (!user) return res.status(404).json({ success: false, message: 'User not found or access denied' });

        await db.run('BEGIN TRANSACTION');
        try {
            // 1. Dissociate from licenses
            await db.run('UPDATE licenses SET user_id = NULL WHERE user_id = ?', [targetId]);
            
            // 2. Clear sessions
            await db.run('DELETE FROM active_sessions WHERE user_id = ?', [targetId]);
            
            // 3. Remove hardware reset requests
            await db.run('DELETE FROM hwid_reset_requests WHERE user_id = ?', [targetId]);
            
            // 4. Remove support tickets and messages
            await db.run('DELETE FROM ticket_messages WHERE sender_id = ?', [targetId]);
            await db.run('DELETE FROM tickets WHERE user_id = ?', [targetId]);
            
            // 5. Remove account messages
            await db.run('DELETE FROM messages WHERE sender_id = ? OR receiver_id = ?', [targetId, targetId]);

            // 6. Remove distribution chains and sessions
            await db.run('DELETE FROM distribution_sessions WHERE owner_id = ?', [targetId]);
            await db.run('DELETE FROM redistribution_settings WHERE owner_id = ?', [targetId]);
            await db.run('DELETE FROM shortened_links WHERE owner_id = ?', [targetId]);
            await db.run('DELETE FROM chains WHERE owner_id = ?', [targetId]);

            // 7. Remove discord moderation logs
            await db.run('DELETE FROM discord_moderation_logs WHERE owner_id = ?', [targetId]);

            // 8. Remove plan requests
            await db.run('DELETE FROM plan_requests WHERE user_id = ?', [targetId]);

            // 9. Remove reseller permissions
            await db.run('DELETE FROM app_resellers WHERE user_id = ?', [targetId]);

            // 10. Remove scheduled tasks
            await db.run('DELETE FROM scheduled_tasks WHERE owner_id = ?', [targetId]);

            // 11. Remove user logs
            await db.run('DELETE FROM logs WHERE user_id = ?', [targetId]);

            // 12. Purge app_users (if table is used)
            try {
                await db.run('DELETE FROM app_users WHERE app_id IN (SELECT id FROM apps WHERE owner_id = ?) AND username = (SELECT username FROM users WHERE id = ?)', [userId, targetId]);
            } catch (e) {
                console.log('[RDX Warning] Could not purge app_users:', e.message);
            }

            // 13. Finally remove the user record
            await db.run('DELETE FROM users WHERE id = ?', [targetId]);
            await db.run('COMMIT');
            return sendResponse(res, 200, true, null, 'User deleted');
        } catch (e) {
            await db.run('ROLLBACK');
            throw e;
        }
    } catch (error) {
        console.error('[RDX User Delete] Error:', error);
        return sendResponse(res, 500, false, null, 'Deletion failed');
    }
};

exports.resetUserHwid = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        const targetId = req.params.id;

        // Verify ownership (Standalone via app_id OR License-based)
        const user = await db.get(`
            SELECT u.* FROM users u 
            LEFT JOIN apps a ON (u.app_id = a.id)
            LEFT JOIN licenses l ON (u.id = l.user_id)
            LEFT JOIN apps al ON (l.app_id = al.id)
            WHERE u.id = ? AND (a.owner_id = ? OR al.owner_id = ?)
        `, [targetId, userId, userId]);

        if (!user) return res.status(404).json({ success: false, message: 'User not found or access denied' });

        // Update HWID in users table directly (Standalone)
        await db.run('UPDATE users SET hwid = NULL WHERE id = ?', [targetId]);

        // Also reset in licenses if it exists (Legacy/License sync)
        await db.run('UPDATE licenses SET hwid = NULL WHERE user_id = ?', [targetId]);

        return sendResponse(res, 200, true, null, 'HWID reset successfully');
    } catch (error) {
        console.error('[RDX Reset User HWID] Error:', error);
        return sendResponse(res, 500, false, null, 'Reset failed');
    }
};

exports.updateUserStatus = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        const targetId = req.params.id;
        const { status } = req.body;

        // Verify ownership (Standalone via app_id OR License-based)
        const user = await db.get(`
            SELECT u.* FROM users u 
            LEFT JOIN apps a ON (u.app_id = a.id)
            LEFT JOIN licenses l ON (u.id = l.user_id)
            LEFT JOIN apps al ON (l.app_id = al.id)
            WHERE u.id = ? AND (a.owner_id = ? OR al.owner_id = ?)
        `, [targetId, userId, userId]);

        if (!user) return res.status(404).json({ success: false, message: 'User not found or access denied' });

        // Update Status in users table directly (Standalone)
        await db.run('UPDATE users SET status = ? WHERE id = ?', [status, targetId]);

        // Also update in licenses if it exists (Legacy/License sync)
        await db.run('UPDATE licenses SET status = ? WHERE user_id = ?', [status, targetId]);

        return sendResponse(res, 200, true, null, 'Status updated');
    } catch (error) {
        console.error('[RDX Update User Status] Error:', error);
        return sendResponse(res, 500, false, null, 'Update failed');
    }
};

// ============ HWID RESET REQUESTS ============

exports.requestHwidReset = async (req, res) => {
    try {
        const { app_id, reason } = req.body;
        const userId = req.user.id;
        const db = await getDb();

        if (!app_id) return res.status(400).json({ success: false, message: 'App ID is required' });

        // Check if user has an active license for this app
        const license = await db.get('SELECT id FROM licenses WHERE user_id = ? AND app_id = ? AND status = "active"', [userId, app_id]);
        if (!license) {
            return sendResponse(res, 403, false, null, 'No active license found for this application.');
        }

        // Check for existing pending request
        const existing = await db.get('SELECT id FROM hwid_reset_requests WHERE user_id = ? AND app_id = ? AND status = "pending"', [userId, app_id]);
        if (existing) {
            return sendResponse(res, 400, false, null, 'You already have a pending HWID reset request for this app.');
        }

        await db.run(
            'INSERT INTO hwid_reset_requests (user_id, app_id, reason) VALUES (?, ?, ?)',
            [userId, app_id, reason || 'No reason provided']
        );

        return sendResponse(res, 200, true, null, 'HWID reset request submitted successfully.');
    } catch (e) {
        return sendResponse(res, 500, false, null, e.message);
    }
};

exports.getHwidRequests = async (req, res) => {
    try {
        const userId = req.user.id;
        const db = await getDb();

        // Owners see requests for THEIR apps
        let query = `
            SELECT r.*, u.username, a.name as app_name 
            FROM hwid_reset_requests r
            JOIN users u ON r.user_id = u.id
            JOIN apps a ON r.app_id = a.id
        `;
        let params = [];

        if (req.user.role !== 'admin') {
            if (req.originalUrl.includes('/my-requests')) {
                query += ' WHERE r.user_id = ?';
            } else {
                query += ' WHERE a.owner_id = ?';
            }
            params.push(userId);
        }

        query += ' ORDER BY r.created_at DESC';

        const requests = await db.all(query, params);
        return sendResponse(res, 200, true, requests, 'HWID requests fetched');
    } catch (e) {
        return sendResponse(res, 500, false, null, e.message);
    }
};

exports.approveHwidReset = async (req, res) => {
    const { getDb } = require('../config/db');
    try {
        const { requestId, adminNote } = req.body;
        const userId = req.user.id;
        const db = await getDb();

        const request = await db.get(`
            SELECT r.*, a.owner_id 
            FROM hwid_reset_requests r 
            JOIN apps a ON r.app_id = a.id 
            WHERE r.id = ?
        `, [requestId]);

        if (!request) return res.status(404).json({ success: false, message: 'Request not found' });

        if (req.user.role !== 'admin' && request.owner_id !== userId) {
            return res.status(403).json({ success: false, message: 'Unauthorized' });
        }

        await db.run('BEGIN TRANSACTION');
        
        // 1. Mark request as approved
        await db.run(
            'UPDATE hwid_reset_requests SET status = "approved", admin_note = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
            [adminNote || 'Approved by owner', requestId]
        );

        // 2. Clear HWID for the user in the licenses table (for that app)
        await db.run(
            'UPDATE licenses SET hwid = NULL, hwid_baseboard = NULL, hwid_cpu = NULL, hwid_mac = NULL WHERE user_id = ? AND app_id = ?',
            [request.user_id, request.app_id]
        );

        // 3. Clear hardware lock status if it exists in users table (legacy)
        await db.run('UPDATE users SET hwid = NULL WHERE id = ?', [request.user_id]);

        await db.run('COMMIT');

        return sendResponse(res, 200, true, null, 'HWID reset approved and hardware lock cleared.');
    } catch (e) {
        const db = await getDb();
        if (db) await db.run('ROLLBACK');
        return sendResponse(res, 500, false, null, e.message);
    }
};

exports.rejectHwidReset = async (req, res) => {
    try {
        const { requestId, adminNote } = req.body;
        const userId = req.user.id;
        const db = await getDb();

        const request = await db.get(`
            SELECT r.*, a.owner_id 
            FROM hwid_reset_requests r 
            JOIN apps a ON r.app_id = a.id 
            WHERE r.id = ?
        `, [requestId]);

        if (!request) return res.status(404).json({ success: false, message: 'Request not found' });

        if (req.user.role !== 'admin' && request.owner_id !== userId) {
            return res.status(403).json({ success: false, message: 'Unauthorized' });
        }

        await db.run(
            'UPDATE hwid_reset_requests SET status = "rejected", admin_note = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
            [adminNote || 'Rejected by owner', requestId]
        );

        return sendResponse(res, 200, true, null, 'HWID reset request rejected.');
    } catch (e) {
        return sendResponse(res, 500, false, null, e.message);
    }
};

exports.deleteLicense = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        const licenseId = req.params.id;

        // Verify ownership
        const license = await db.get(`
            SELECT l.* FROM licenses l 
            JOIN apps a ON l.app_id = a.id 
            WHERE l.id = ? AND a.owner_id = ?
        `, [licenseId, userId]);

        if (!license) return res.status(404).json({ success: false, message: 'License not found or access denied' });

        await db.run('DELETE FROM licenses WHERE id = ?', [licenseId]);
        return sendResponse(res, 200, true, null, 'License deleted successfully');
    } catch (error) {
        console.error('[RDX Delete License] Error:', error);
        return sendResponse(res, 500, false, null, 'Deletion failed');
    }
};

exports.resetLicenseHwid = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        const licenseId = req.params.id;

        // Verify ownership
        const license = await db.get(`
            SELECT l.* FROM licenses l 
            JOIN apps a ON l.app_id = a.id 
            WHERE l.id = ? AND a.owner_id = ?
        `, [licenseId, userId]);

        if (!license) return res.status(404).json({ success: false, message: 'License not found or access denied' });

        await db.run('UPDATE licenses SET hwid = NULL WHERE id = ?', [licenseId]);
        return sendResponse(res, 200, true, null, 'HWID reset successfully');
    } catch (error) {
        console.error('[RDX Reset License HWID] Error:', error);
        return sendResponse(res, 500, false, null, 'Reset failed');
    }
};

exports.updateLicenseStatus = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        const licenseId = req.params.id;
        const { status } = req.body;

        // Verify ownership
        const license = await db.get(`
            SELECT l.* FROM licenses l 
            JOIN apps a ON l.app_id = a.id 
            WHERE l.id = ? AND a.owner_id = ?
        `, [licenseId, userId]);

        if (!license) return res.status(404).json({ success: false, message: 'License not found or access denied' });

        await db.run('UPDATE licenses SET status = ? WHERE id = ?', [status, licenseId]);
        return sendResponse(res, 200, true, null, 'Status updated');
    } catch (error) {
        console.error('[RDX Update License Status] Error:', error);
        return sendResponse(res, 500, false, null, 'Update failed');
    }
};


exports.requestPlan = async (req, res) => {
    const { plan, transaction_id } = req.body;
    const userId = req.user.id;

    if (!plan || !transaction_id) {
        return sendResponse(res, 400, false, null, 'Plan and Transaction ID are required');
    }

    if (plan.toLowerCase() === 'starter') {
        return sendResponse(res, 400, false, null, 'Starter plan is free and does not require verification.');
    }

    try {
        const db = await getDb();

        // 1. Define Plan Prices
        const planPrices = {
            'basic': 50,
            'pro': 80,
            'starter': 0
        };
        const amount = planPrices[plan.toLowerCase()] || 0;

        // 2. Check if there is already a pending request for this user
        const existing = await db.get('SELECT id FROM plan_requests WHERE user_id = ? AND status = "pending"', [userId]);
        if (existing) {
            return sendResponse(res, 400, false, null, 'You already have a pending request. Please wait for admin approval.');
        }

        await db.run(
            'INSERT INTO plan_requests (user_id, plan, transaction_id, amount, status) VALUES (?, ?, ?, ?, ?)',
            [userId, plan, transaction_id, amount, 'pending']
        );

        const user = await db.get('SELECT email, username FROM users WHERE id = ?', [userId]);
        if (user && user.email) {
            console.log(`[RDX Email Trigger] Sending Payment Received email to: ${user.email}`);
            await emailService.sendPaymentReceivedEmail(user.email, user.username, plan);
        } else {
            console.log(`[RDX Email Trigger] Skipping Payment Received email: ${user ? 'No email for ' + user.username : 'User not found'}`);
        }

        await logService.recordLog(userId, null, `PLAN_REQUEST: ${plan.toUpperCase()} by ${user.username} (TxID: ${transaction_id})`, req.ip, null, req.headers['user-agent']);

        return sendResponse(res, 200, true, null, 'Request submitted successfully. Admin will verify and approve shortly.');
    } catch (error) {
        console.error('[RDX Plan Request] Error:', error);
        return sendResponse(res, 500, false, null, 'Failed to submit request');
    }
};

exports.getMessages = async (req, res) => {
    const userId = req.user.id;
    try {
        const db = await getDb();
        const messages = await db.all(
            'SELECT * FROM messages WHERE receiver_id = ? ORDER BY timestamp DESC',
            [userId]
        );
        return sendResponse(res, 200, true, messages, 'Messages fetched');
    } catch (error) {
        console.error('[RDX Get Messages] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error loading messages');
    }
};

exports.markMessageRead = async (req, res) => {
    const userId = req.user.id;
    const { messageId } = req.params;
    try {
        const db = await getDb();
        await db.run(
            'UPDATE messages SET is_read = 1 WHERE id = ? AND receiver_id = ?',
            [messageId, userId]
        );
        return sendResponse(res, 200, true, null, 'Message marked as read');
    } catch (error) {
        console.error('[RDX Mark Message Read] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.deleteApp = async (req, res) => {
    const { id } = req.params;
    const userId = req.user.id;

    try {
        const db = await getDb();

        // Verify ownership
        const app = await db.get('SELECT * FROM apps WHERE id = ? AND owner_id = ?', [id, userId]);
        if (!app) {
            return sendResponse(res, 404, false, null, 'Application not found or unauthorized');
        }

        // Transactional deletion for consistency
        await db.run('BEGIN TRANSACTION');
        try {
            // 1. Delete associated licenses
            await db.run('DELETE FROM licenses WHERE app_id = ?', [id]);

            // 2. Delete associated standalone users
            await db.run('DELETE FROM users WHERE app_id = ?', [id]);

            // 3. Delete associated app variables
            await db.run('DELETE FROM variables WHERE app_id = ?', [id]);

            // 4. Delete app-specific logs
            await db.run('DELETE FROM logs WHERE app_id = ?', [id]);

            // 5. Delete app-specific blacklist entries
            await db.run('DELETE FROM blacklist WHERE app_id = ?', [id]);

            // 6. Delete reseller permissions
            await db.run('DELETE FROM app_resellers WHERE app_id = ?', [id]);

            // 7. Finally, delete the app itself
            await db.run('DELETE FROM apps WHERE id = ?', [id]);

            await logService.recordLog(userId, id, `APP DELETED: ${app.name}`, req.ip, null, req.headers['user-agent']);
            await db.run('COMMIT');

            return sendResponse(res, 200, true, null, 'Application and all associated data purged successfully');
        } catch (txError) {
            await db.run('ROLLBACK');
            throw txError;
        }
    } catch (error) {
        console.error('[RDX Delete App] Error:', error);
        return sendResponse(res, 500, false, null, `Server error during app deletion: ${error.message}`);
    }
};

exports.getUserAnalytics = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;

        // Analytics for Apps owned by this user
        const actionFilter = '(l.action LIKE "LOGIN%" OR l.action LIKE "AUTH%" OR l.action LIKE "VALIDATE%" OR l.action LIKE "USER_LOGIN%" OR l.action LIKE "%SDK%")';

        const wHits = await db.get(`SELECT COUNT(*) as count FROM logs l JOIN apps a ON l.app_id = a.id WHERE a.owner_id = ? AND ${actionFilter} AND l.timestamp >= datetime("now", "-7 days")`, [userId]);
        const mHits = await db.get(`SELECT COUNT(*) as count FROM logs l JOIN apps a ON l.app_id = a.id WHERE a.owner_id = ? AND ${actionFilter} AND l.timestamp >= datetime("now", "-30 days")`, [userId]);
        const dHits = await db.all(`SELECT strftime("%Y-%m-%d", l.timestamp) as date, COUNT(*) as count FROM logs l JOIN apps a ON l.app_id = a.id WHERE a.owner_id = ? AND ${actionFilter} AND l.timestamp >= datetime("now", "-30 days") GROUP BY date ORDER BY date ASC`, [userId]);
        const dActive = await db.all(`SELECT strftime("%Y-%m-%d", l.timestamp) as date, COUNT(DISTINCT l.user_id) as count FROM logs l JOIN apps a ON l.app_id = a.id WHERE a.owner_id = ? AND l.timestamp >= datetime("now", "-30 days") GROUP BY date ORDER BY date ASC`, [userId]);

        return sendResponse(res, 200, true, {
            weeklyHits: wHits ? wHits.count : 0,
            monthlyHits: mHits ? mHits.count : 0,
            dailyHits: dHits || [],
            dailyActive: dActive || [],
            deletedAccounts: 0,
            planDist: []
        }, 'Analytics fetched');
    } catch (error) {
        console.error('[RDX User Analytics] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error loading analytics');
    }
};

exports.getSubscriptions = async (req, res) => {
    try {
        const db = await getDb();
        const userId = req.user.id;
        const isAdmin = req.user.role === 'admin';
        const appIdFilter = req.query.appId;

        let query = `
            SELECT s.*, a.name as app_name,
            ((SELECT COUNT(*) FROM licenses l WHERE l.subscription_id = s.id AND l.status = 'active') + 
             (SELECT COUNT(*) FROM users u WHERE u.subscription_id = s.id AND u.status = 'active')) as usersCnt
            FROM app_subscriptions s
            JOIN apps a ON s.app_id = a.id
        `;
        let params = [];
        
        if (!isAdmin) {
            query += ' WHERE a.owner_id = ?';
            params.push(userId);
        } else {
            query += ' WHERE 1=1';
        }

        if (appIdFilter) {
            query += ' AND s.app_id = ?';
            params.push(appIdFilter);
        }

        query += ' ORDER BY s.created_at DESC';

        const subscriptions = await db.all(query, params);
        return sendResponse(res, 200, true, subscriptions, 'Subscriptions fetched');
    } catch (error) {
        console.error('[RDX Get Subscriptions] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error loading subscriptions');
    }
};

exports.createSubscription = async (req, res) => {
    const { app_id, name, level } = req.body;
    const userId = req.user.id;

    if (!app_id || !name || !level) {
        return sendResponse(res, 400, false, null, 'App, Plan Name, and Level are required');
    }

    try {
        const db = await getDb();

        // Verify app ownership
        let app;
        if (req.user.role === 'admin') {
            app = await db.get('SELECT * FROM apps WHERE id = ?', [app_id]);
        } else {
            app = await db.get('SELECT * FROM apps WHERE id = ? AND owner_id = ?', [app_id, userId]);
        }
        
        if (!app) return res.status(404).json({ success: false, message: 'Application not found or access denied' });

        const result = await db.run(
            'INSERT INTO app_subscriptions (app_id, name, level) VALUES (?, ?, ?)',
            [app_id, name, level]
        );

        await logService.recordLog(userId, app_id, `SUBSCRIPTION CREATED: ${name} (Level: ${level})`, req.ip, null, req.headers['user-agent']);

        return sendResponse(res, 201, true, {
            id: result.lastID,
            app_id,
            name,
            level,
            usersCnt: 0
        }, 'Subscription created successfully');
    } catch (error) {
        console.error('[RDX Create Subscription] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error creating subscription');
    }
};

exports.deleteSubscription = async (req, res) => {
    const subId = req.params.id;
    const userId = req.user.id;

    try {
        const db = await getDb();

        // Verify ownership
        let sub;
        if (req.user.role === 'admin') {
            sub = await db.get(`
                SELECT s.* FROM app_subscriptions s
                JOIN apps a ON s.app_id = a.id
                WHERE s.id = ?
            `, [subId]);
        } else {
            sub = await db.get(`
                SELECT s.* FROM app_subscriptions s
                JOIN apps a ON s.app_id = a.id
                WHERE s.id = ? AND a.owner_id = ?
            `, [subId, userId]);
        }

        if (!sub) return res.status(404).json({ success: false, message: 'Subscription not found or access denied' });

        await db.run('BEGIN TRANSACTION');
        try {
            // Nullify subscription_id for any linked licenses
            await db.run('UPDATE licenses SET subscription_id = NULL WHERE subscription_id = ?', [subId]);
            // Attempt to nullify on users (if column exists)
            try {
                await db.run('UPDATE users SET subscription_id = NULL WHERE subscription_id = ?', [subId]);
            } catch (e) {
                // Ignore if column doesn't exist
            }

            await db.run('DELETE FROM app_subscriptions WHERE id = ?', [subId]);
            await db.run('COMMIT');

            await logService.recordLog(userId, sub.app_id, `SUBSCRIPTION DELETED: ${sub.name}`, req.ip, null, req.headers['user-agent']);
            return sendResponse(res, 200, true, null, 'Subscription deleted successfully');
        } catch (txErr) {
            await db.run('ROLLBACK');
            throw txErr;
        }
    } catch (error) {
        console.error('[RDX Delete Subscription] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error deleting subscription');
    }
};
