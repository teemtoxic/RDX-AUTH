const { getDb } = require('../config/db');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const logService = require('../utils/logService');
const emailService = require('../utils/emailService');
const discordService = require('../utils/discordService');
const sendResponse = require('../utils/responseHelper');

// --- LOGS ---
exports.getLogs = async (req, res) => {
    if (req.user.role !== 'admin') return sendResponse(res, 403, false, null, 'Forbidden: Admins only');
    const { app_id, user_id, limit = 100, page = 1 } = req.query;
    const offset = (page - 1) * limit;
    try {
        const db = await getDb();
        let baseQuery = `
            FROM logs l
            LEFT JOIN users u ON l.user_id = u.id
            LEFT JOIN apps a ON l.app_id = a.id
        `;
        const params = [];
        const conditions = [];

        if (app_id) { conditions.push('l.app_id = ?'); params.push(app_id); }
        if (user_id) { conditions.push('l.user_id = ?'); params.push(user_id); }

        if (conditions.length > 0) {
            baseQuery += ' WHERE ' + conditions.join(' AND ');
        }

        const countResult = await db.get(`SELECT COUNT(*) as total ${baseQuery}`, params);
        const total = countResult ? countResult.total : 0;

        let query = `SELECT l.*, u.username, a.name as app_name ${baseQuery} ORDER BY l.timestamp DESC LIMIT ? OFFSET ?`;
        params.push(parseInt(limit), parseInt(offset));

        const logs = await db.all(query, params);
        return sendResponse(res, 200, true, {
            logs,
            pagination: {
                total,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: Math.ceil(total / limit)
            }
        }, 'Admin logs fetched');
    } catch (error) {
        console.error('[RDX Admin Logs] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error loading logs');
    }
};

// --- STATS ---
exports.getStats = async (req, res) => {
    if (req.user.role !== 'admin') return sendResponse(res, 403, false, null, 'Forbidden: Admins only');
    try {
        const db = await getDb();
        const userId = req.user.id;
        const isAdmin = true; // Hardcoded to true since non-admins are blocked

        // 1. Consolidated Core Counts
        let coreCountsQuery;
        if (isAdmin) {
            coreCountsQuery = db.get(`
                SELECT 
                    (SELECT COUNT(*) FROM apps) as appsCount,
                    (SELECT COUNT(*) FROM licenses) as licensesCount,
                    (SELECT COUNT(*) FROM users WHERE role != 'admin') as usersCount
            `);
        } else {
            coreCountsQuery = db.get(`
                SELECT 
                    (SELECT COUNT(*) FROM apps WHERE owner_id = ?) as appsCount,
                    (SELECT COUNT(*) FROM licenses l JOIN apps a ON l.app_id = a.id WHERE a.owner_id = ?) as licensesCount,
                    (SELECT COUNT(DISTINCT u.id) 
                     FROM users u 
                     LEFT JOIN licenses l ON u.id = l.user_id 
                     LEFT JOIN apps a_lic ON l.app_id = a_lic.id 
                     LEFT JOIN apps a_usr ON u.app_id = a_usr.id 
                     WHERE a_lic.owner_id = ? OR a_usr.owner_id = ?) as usersCount
            `, [userId, userId, userId, userId]);
        }

        // 2. Consolidated License Status
        let licenseStatusQuery;
        if (isAdmin) {
            licenseStatusQuery = db.get(`
                SELECT 
                    COUNT(CASE WHEN user_id IS NOT NULL AND status = 'active' THEN 1 END) as used,
                    COUNT(CASE WHEN user_id IS NULL AND status = 'active' THEN 1 END) as unused,
                    COUNT(CASE WHEN status = 'banned' THEN 1 END) as banned,
                    COUNT(CASE WHEN status = 'paused' THEN 1 END) as paused
                FROM licenses
            `);
        } else {
            licenseStatusQuery = db.get(`
                SELECT 
                    COUNT(CASE WHEN l.user_id IS NOT NULL AND l.status = 'active' THEN 1 END) as used,
                    COUNT(CASE WHEN l.user_id IS NULL AND l.status = 'active' THEN 1 END) as unused,
                    COUNT(CASE WHEN l.status = 'banned' THEN 1 END) as banned,
                    COUNT(CASE WHEN l.status = 'paused' THEN 1 END) as paused
                FROM licenses l 
                JOIN apps a ON l.app_id = a.id 
                WHERE a.owner_id = ?
            `, [userId]);
        }

        // 3. Consolidated User Status
        let userStatusQuery;
        if (isAdmin) {
            userStatusQuery = db.get(`
                SELECT 
                    COUNT(CASE WHEN status = 'active' AND hwid IS NOT NULL THEN 1 END) as active,
                    COUNT(CASE WHEN status = 'active' AND hwid IS NULL THEN 1 END) as unused,
                    COUNT(CASE WHEN status = 'paused' THEN 1 END) as paused,
                    COUNT(CASE WHEN status = 'banned' THEN 1 END) as banned
                FROM users 
                WHERE role != 'admin'
            `);
        } else {
            userStatusQuery = db.get(`
                SELECT 
                    COUNT(DISTINCT CASE WHEN u.status = 'active' AND u.hwid IS NOT NULL THEN u.id END) as active,
                    COUNT(DISTINCT CASE WHEN u.status = 'active' AND u.hwid IS NULL THEN u.id END) as unused,
                    COUNT(DISTINCT CASE WHEN u.status = 'paused' THEN u.id END) as paused,
                    COUNT(DISTINCT CASE WHEN u.status = 'banned' THEN u.id END) as banned
                FROM users u 
                LEFT JOIN licenses l ON u.id = l.user_id 
                LEFT JOIN apps a_lic ON l.app_id = a_lic.id 
                LEFT JOIN apps a_usr ON u.app_id = a_usr.id 
                WHERE a_lic.owner_id = ? OR a_usr.owner_id = ?
            `, [userId, userId]);
        }

        // 4. Hit Stats (Total, Failed, Daily)
        let hitStatsQuery;
        if (isAdmin) {
            hitStatsQuery = db.get(`
                SELECT 
                    COUNT(*) as totalHits24h,
                    COUNT(CASE WHEN (action LIKE '%FAILED%' OR action LIKE '%REJECTED%') THEN 1 END) as failedHits24h
                FROM logs l
                LEFT JOIN users u ON l.user_id = u.id
                WHERE (l.action LIKE 'LOGIN%' OR l.action LIKE 'AUTH%' OR l.action LIKE 'VALIDATE%' OR l.action LIKE 'USER_LOGIN%' OR l.action LIKE 'APP_LOGIN%' OR l.action LIKE '%SDK%') 
                AND l.timestamp >= datetime('now', '-24 hours')
                AND (u.role IS NULL OR u.role != 'admin')
            `);
        } else {
            hitStatsQuery = db.get(`
                SELECT 
                    COUNT(*) as totalHits24h,
                    COUNT(CASE WHEN (l.action LIKE '%FAILED%' OR l.action LIKE '%REJECTED%') THEN 1 END) as failedHits24h
                FROM logs l 
                JOIN apps a ON l.app_id = a.id 
                WHERE a.owner_id = ? 
                AND (l.action LIKE 'LOGIN%' OR l.action LIKE 'AUTH%' OR l.action LIKE 'VALIDATE%' OR l.action LIKE 'USER_LOGIN%' OR l.action LIKE 'APP_LOGIN%' OR l.action LIKE '%SDK%') 
                AND l.timestamp >= datetime('now', '-24 hours')
            `, [userId]);
        }

        const [core, licStatus, usrStatus, hitStats] = await Promise.all([
            coreCountsQuery, licenseStatusQuery, userStatusQuery, hitStatsQuery
        ]);

        // 5. Growth & Revenue (Admin Only)
        let userGrowth = 0, revenueGrowth = 0, totalRevenue = 0;
        if (isAdmin) {
            const growthRow = await db.get(`
        SELECT
            (SELECT COUNT(*) FROM users WHERE role != 'admin' AND created_at >= datetime('now', '-30 days')) as currentUsers,
            (SELECT COUNT(*) FROM users WHERE role != 'admin' AND created_at < datetime('now', '-30 days') AND created_at >= datetime('now', '-60 days')) as previousUsers,
                (SELECT SUM(amount) FROM plan_requests WHERE status = 'approved' AND updated_at >= datetime('now', '-30 days')) as currentRev,
                    (SELECT SUM(amount) FROM plan_requests WHERE status = 'approved' AND updated_at < datetime('now', '-30 days') AND updated_at >= datetime('now', '-60 days')) as previousRev,
                        (SELECT SUM(amount) FROM plan_requests WHERE status = 'approved') as totalRev
                            `);

            totalRevenue = growthRow.totalRev || 0;
            const currentUsers = growthRow.currentUsers || 0;
            const previousUsers = growthRow.previousUsers || 0;
            const currentRev = growthRow.currentRev || 0;
            const previousRev = growthRow.previousRev || 0;

            if (previousUsers > 0) userGrowth = Math.round(((currentUsers - previousUsers) / previousUsers) * 100);
            else if (currentUsers > 0) userGrowth = 100;

            if (previousRev > 0) revenueGrowth = Math.round(((currentRev - previousRev) / previousRev) * 100);
            else if (currentRev > 0) revenueGrowth = 100;
        }

        // 6. Traffic Charts (Last 24h)
        let trafficQuery = `
        SELECT
        strftime('%H:00', l.timestamp, 'localtime') as hour,
            COUNT(CASE WHEN l.action LIKE 'LOGIN%' OR l.action LIKE 'AUTH%' OR l.action LIKE 'VALIDATE%' OR l.action LIKE 'USER_LOGIN%' OR l.action LIKE 'APP_LOGIN%' OR l.action LIKE '%SDK%' THEN 1 END) as authCount,
            COUNT(CASE WHEN l.action LIKE 'REGISTER%' OR l.action LIKE 'REDEEM%' THEN 1 END) as regCount
            FROM logs l
        `;
        if (!isAdmin) {
            trafficQuery += ' JOIN apps a ON l.app_id = a.id WHERE a.owner_id = ?';
        } else {
            trafficQuery += ' LEFT JOIN users u ON l.user_id = u.id WHERE (u.role IS NULL OR u.role != "admin")';
        }
        trafficQuery += ' AND l.timestamp >= datetime("now", "-24 hours") GROUP BY hour';

        const trafficStats = isAdmin ? await db.all(trafficQuery) : await db.all(trafficQuery, [userId]);

        const authData = new Array(24).fill(0);
        const regData = new Array(24).fill(0);
        trafficStats.forEach(r => {
            const h = parseInt(r.hour.split(':')[0]);
            if (!isNaN(h)) {
                authData[h] = r.authCount;
                regData[h] = r.regCount;
            }
        });

        const authTrafficData = [];
        const regTrafficData = [];
        for (let i = 23; i >= 0; i--) {
            const d = new Date(); d.setHours(d.getHours() - i);
            const h = d.getHours();
            authTrafficData.push(authData[h]);
            regTrafficData.push(regData[h]);
        }

        // 7. Additional Info (Notifications & System)
        const [notifications, notificationsCount, systemSettings] = await Promise.all([
            db.all('SELECT l.*, u.username, a.name as app_name FROM logs l LEFT JOIN users u ON l.user_id = u.id LEFT JOIN apps a ON l.app_id = a.id WHERE action LIKE "PLAN_REQUEST%" ORDER BY timestamp DESC LIMIT 10'),
            db.get('SELECT COUNT(*) as count FROM logs WHERE action LIKE "PLAN_REQUEST%"'),
            db.all('SELECT key, value FROM system_settings WHERE key IN ("maintenance_mode", "maintenance_until")')
        ]);

        const mMode = systemSettings.find(s => s.key === 'maintenance_mode');
        const mUntil = systemSettings.find(s => s.key === 'maintenance_until');

        const stats = {
            totalApps: core.appsCount,
            totalLicenses: core.licensesCount,
            totalUsers: core.usersCount,
            licenseRequests: trafficStats.reduce((sum, r) => sum + r.regCount, 0),
            hitRate, userGrowth, revenueGrowth,
            keyStats: licStatus,
            userStats: usrStatus,
            totalRevenue,
            totalHits: hitStats.totalHits24h,
            authTrafficData, regTrafficData,
            notifications,
            unreadNotifications: notificationsCount.count,
            maintenance_mode: mMode ? mMode.value === '1' : false,
            maintenance_until: mUntil ? mUntil.value : null
        };

        return sendResponse(res, 200, true, stats, 'Admin stats fetched');
    } catch (error) {
        console.error('[RDX Admin Stats ERROR]', error);
        return sendResponse(res, 500, false, null, 'Server error loading stats');
    }
};

// --- APPS ---
exports.getApps = async (req, res) => {
    if (req.user.role !== 'admin') return sendResponse(res, 403, false, null, 'Forbidden: Admins only');
    try {
        const db = await getDb();
        const apps = await db.all('SELECT * FROM apps ORDER BY created_at DESC');
        return sendResponse(res, 200, true, apps, 'Apps fetched');
    } catch (error) {
        console.error(error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.createApp = async (req, res) => {
    const { name, version } = req.body;
    const owner_id = req.user.id;
    const owner_key = crypto.randomBytes(8).toString('hex').toUpperCase();
    const secret = crypto.randomBytes(16).toString('hex').toUpperCase();
    try {
        const db = await getDb();
        const result = await db.run('INSERT INTO apps (name, owner_id, owner_key, secret, version) VALUES (?, ?, ?, ?, ?)', [name, owner_id, owner_key, secret, version || '1.0.0']);
        await logService.recordLog(owner_id, result.lastID, `APP CREATED: ${name}`, req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 201, true, { id: result.lastID, name, owner_key, secret, version: version || '1.0.0' }, 'App created');
    } catch (error) {
        if (error && error.message && error.message.includes('UNIQUE constraint failed')) return sendResponse(res, 400, false, null, 'App name exists');
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

// --- USERS ---
exports.getUsers = async (req, res) => {
    const { page = 1, limit = 8, search = '', plan = '' } = req.query;
    const offset = (page - 1) * limit;
    try {
        const db = await getDb();
        let query = `SELECT u.id, u.username, u.email, u.role, u.status, u.plan, u.created_at, (SELECT COUNT(*) FROM apps WHERE owner_id = u.id) as total_apps, (SELECT MAX(timestamp) FROM logs WHERE user_id = u.id) as last_active FROM users u WHERE(u.google_id IS NOT NULL OR(u.email IS NOT NULL AND u.email LIKE '%@%')) AND role = "user"`;
        const params = [];
        if (search) { query += ' AND (username LIKE ? OR email LIKE ?)'; params.push(`% ${search}% `, ` % ${search}% `); }
        if (plan) { query += ' AND plan = ?'; params.push(plan.toLowerCase()); }
        const countRow = await db.get(`SELECT COUNT(*) as count FROM(${query})`, params);
        const count = countRow ? countRow.count : 0;
        query += ' ORDER BY u.created_at DESC LIMIT ? OFFSET ?';
        params.push(parseInt(limit), parseInt(offset));
        const users = await db.all(query, params);
        return sendResponse(res, 200, true, { users, pagination: { total: count, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(count / limit) } }, 'Users fetched');
    } catch (error) {
        console.error('[RDX Admin Get Users] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.createUser = async (req, res) => {
    const { username, password, app_id, expiry_days, hwid_lock } = req.body;
    // Default to false - license creation is strictly manual/opt-in
    try {
        const db = await getDb();
        if (await db.get('SELECT id FROM users WHERE username = ?', [username])) return sendResponse(res, 400, false, null, 'Username exists');
        const hashedPassword = await bcrypt.hash(password, 10);

        let exp = null;
        if (req.body.expiry_date) exp = new Date(req.body.expiry_date);
        else if (expiry_days) { exp = new Date(); exp.setDate(exp.getDate() + parseInt(expiry_days)); }

        const result = await db.run(
            'INSERT INTO users (username, password_hash, role, status, app_id, expiry_date, hwid_lock) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [username, hashedPassword, 'user', 'active', app_id || null, exp ? exp.toISOString() : null, hwid_lock ? 1 : 0]
        );
        const user_id = result.lastID;
        await logService.recordLog(req.user.id, app_id || null, `USER CREATED: ${username}`, req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 201, true, null, 'User created');
    } catch (error) {
        console.error('[RDX Admin Create User] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.updateUserStatus = async (req, res) => {
    const { id } = req.params; const { status } = req.body;
    try {
        const db = await getDb();
        await db.run('UPDATE users SET status = ? WHERE id = ?', [status, id]);
        await db.run('UPDATE licenses SET status = ? WHERE user_id = ?', [status, id]);
        await logService.recordLog(req.user.id, null, `USER STATUS: ID ${id} -> ${status}`, req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 200, true, null, 'Status updated');
    } catch (error) {
        console.error('[RDX Admin Update Status] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.resetHwid = async (req, res) => {
    try {
        const db = await getDb();
        await db.run('UPDATE licenses SET hwid = NULL WHERE user_id = ?', [req.params.id]);
        await logService.recordLog(req.user.id, null, `HWID RESET: ID ${req.params.id}`, req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 200, true, null, 'HWID reset');
    } catch (error) {
        console.error('[RDX Admin Reset HWID] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.deleteUser = async (req, res) => {
    const { id } = req.params;
    try {
        const db = await getDb();
        const apps = await db.all('SELECT id FROM apps WHERE owner_id = ?', [id]);
        const appIds = apps.map(app => app.id);
        await db.run('BEGIN TRANSACTION');
        try {
            if (appIds.length > 0) {
                const placeholders = appIds.map(() => '?').join(',');
                await db.run(`DELETE FROM variables WHERE app_id IN(${placeholders})`, appIds);
                await db.run(`DELETE FROM logs WHERE app_id IN(${placeholders})`, appIds);
                await db.run(`DELETE FROM licenses WHERE app_id IN(${placeholders})`, appIds);
                await db.run(`DELETE FROM apps WHERE owner_id = ? `, [id]);
            }
            await db.run('DELETE FROM logs WHERE user_id = ?', [id]);
            await db.run('DELETE FROM licenses WHERE user_id = ?', [id]);
            await db.run('DELETE FROM messages WHERE sender_id = ? OR receiver_id = ?', [id, id]);
            await db.run('DELETE FROM users WHERE id = ?', [id]);
            await db.run('COMMIT');
            await logService.recordLog(req.user.id, null, `ADMIN DELETED USER: ID ${id}`, req.ip, null, req.headers['user-agent']);
            return sendResponse(res, 200, true, null, 'User deleted');
        } catch (e) { await db.run('ROLLBACK'); throw e; }
    } catch (error) {
        console.error('[RDX Admin Delete User] Error:', error);
        return sendResponse(res, 500, false, null, error.message);
    }
};

exports.updateUser = async (req, res) => {
    const { id } = req.params;
    const { username, email, password, role, status, plan, expiry_date, hwid_lock } = req.body;
    try {
        const db = await getDb();
        if (!await db.get('SELECT id FROM users WHERE id = ?', [id])) return sendResponse(res, 404, false, null, 'Not found');
        let uQ = 'UPDATE users SET '; let uP = [];
        if (username) { uQ += 'username = ?, '; uP.push(username); }
        if (email) { uQ += 'email = ?, '; uP.push(email); }
        if (role) { uQ += 'role = ?, '; uP.push(role); }
        if (status) { uQ += 'status = ?, '; uP.push(status); }
        if (plan) { uQ += 'plan = ?, '; uP.push(plan); }
        if (password && password.trim()) { uQ += 'password_hash = ?, '; uP.push(await bcrypt.hash(password, 10)); }
        if (expiry_date !== undefined) { uQ += 'expiry_date = ?, '; uP.push(expiry_date ? new Date(expiry_date).toISOString() : null); }
        if (hwid_lock !== undefined) { uQ += 'hwid_lock = ?, '; uP.push(hwid_lock ? 1 : 0); }

        if (uP.length > 0) { uQ = uQ.slice(0, -2) + ' WHERE id = ?'; uP.push(id); await db.run(uQ, uP); }
        const lic = await db.get('SELECT * FROM licenses WHERE user_id = ?', [id]);
        if (lic) {
            let lQ = 'UPDATE licenses SET '; let lP = [];
            if (expiry_date !== undefined) { lQ += 'expiry_date = ?, '; lP.push(expiry_date ? new Date(expiry_date).toISOString() : null); }
            if (hwid_lock !== undefined) { lQ += 'hwid_lock = ?, '; lP.push(hwid_lock ? 1 : 0); }
            if (lP.length > 0) { lQ = lQ.slice(0, -2) + ' WHERE user_id = ?'; lP.push(id); await db.run(lQ, lP); }
        }
        await logService.recordLog(req.user.id, null, `USER UPDATED: ID ${id}`, req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 200, true, null, 'User updated');
    } catch (error) {
        console.error('[RDX Admin Update User] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

// --- LICENSES ---
exports.getLicenses = async (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ success: false, message: 'Forbidden: Admins only' });
    try {
        const db = await getDb();
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;

        let baseQuery = `FROM licenses l LEFT JOIN users u ON l.user_id = u.id LEFT JOIN apps a ON l.app_id = a.id LEFT JOIN app_subscriptions sub ON l.subscription_id = sub.id`;
        const params = [];

        // Get total count for pagination
        const countResult = await db.get(`SELECT COUNT(*) as total ${baseQuery} `, params);
        const total = countResult ? countResult.total : 0;

        // Fetch paginated results
        const query = `SELECT l.*, u.username, u.created_at as redemption_date, a.name as app_name, sub.name as subscription_name ${baseQuery} ORDER BY l.created_at DESC LIMIT ? OFFSET ? `;
        const licenses = await db.all(query, [...params, limit, offset]);

        return sendResponse(res, 200, true, { licenses, total, limit, offset }, 'Licenses fetched');
    } catch (error) {
        console.error('[RDX Admin Licenses] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.createLicense = async (req, res) => {
    const { id, app_id, expiry_date, duration_days, duration, is_update, hwid_lock, amount } = req.body;
    if (is_update) {
        try {
            const db = await getDb();
            await db.run('UPDATE licenses SET expiry_date = ? WHERE id = ?', [expiry_date, id]);
            await logService.recordLog(req.user.id, null, `LICENSE UPDATED: ID ${id}`, req.ip, null, req.headers['user-agent']);
            return sendResponse(res, 200, true, null, 'Updated');
        } catch (e) {
            return sendResponse(res, 500, false, null, 'Error');
        }
    }
    if (!app_id) return sendResponse(res, 400, false, null, 'App required');
    try {
        const db = await getDb();
        const numKeys = parseInt(amount) || 1;
        const keys = [];
        const dur = parseInt(duration_days || duration || 0);
        let exp = expiry_date;

        if (!exp && dur > 0) {
            let d = new Date();
            d.setDate(d.getDate() + dur);
            exp = d.toISOString();
        }

        for (let i = 0; i < numKeys; i++) {
            const key = crypto.randomBytes(12).toString('hex').toUpperCase();
            await db.run('INSERT INTO licenses (license_key, app_id, duration, expiry_date, status, hwid_lock) VALUES (?, ?, ?, ?, ?, ?)', 
                [key, app_id, dur, exp, 'active', hwid_lock !== undefined ? (hwid_lock ? 1 : 0) : 1]);
            keys.push(key);
        }

        await logService.recordLog(req.user.id, app_id, `KEYS GEN: ${numKeys} keys generated`, req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 201, true, keys.length === 1 ? keys[0] : keys, 'License keys generated');
    } catch (error) {
        console.error('[RDX Admin Create License] Error:', error);
        return sendResponse(res, 500, false, null, 'Error');
    }
};

exports.deleteLicense = async (req, res) => {
    try {
        const db = await getDb();
        await db.run('DELETE FROM licenses WHERE id = ?', [req.params.id]);
        await logService.recordLog(req.user.id, null, `KEY DEL: ID ${req.params.id}`, req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 200, true, null, 'Deleted');
    } catch (error) {
        return sendResponse(res, 500, false, null, 'Error');
    }
};

exports.resetLicenseHwid = async (req, res) => {
    try {
        const db = await getDb();
        await db.run('UPDATE licenses SET hwid = NULL WHERE id = ?', [req.params.id]);
        await logService.recordLog(req.user.id, null, `KEY HWID RESET: ID ${req.params.id}`, req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 200, true, null, 'Reset');
    } catch (error) {
        return sendResponse(res, 500, false, null, 'Error');
    }
};

exports.updateLicenseStatus = async (req, res) => {
    const { id } = req.params; const { status } = req.body;
    try {
        const db = await getDb();
        await db.run('UPDATE licenses SET status = ? WHERE id = ?', [status, id]);
        await logService.recordLog(req.user.id, null, `KEY STATUS: ID ${id} -> ${status}`, req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 200, true, null, 'Updated');
    } catch (error) {
        return sendResponse(res, 500, false, null, 'Error');
    }
};

// --- CLIENT SPECIFIC ---
exports.getClientDetailedStats = async (req, res) => {
    const { id } = req.params;
    try {
        const db = await getDb();
        const apps = await db.get('SELECT COUNT(*) as count FROM apps WHERE owner_id = ?', [id]);
        const lics = await db.get('SELECT COUNT(*) as count FROM licenses l JOIN apps a ON l.app_id = a.id WHERE a.owner_id = ? AND l.user_id IS NULL', [id]);
        const users = await db.get(`
            SELECT COUNT(DISTINCT u.id) as count 
            FROM users u 
            LEFT JOIN licenses l ON u.id = l.user_id 
            LEFT JOIN apps a_lic ON l.app_id = a_lic.id 
            LEFT JOIN apps a_usr ON u.app_id = a_usr.id 
            WHERE a_lic.owner_id = ? OR a_usr.owner_id = ?
            `, [id, id]);
        const auth = await db.get('SELECT COUNT(*) as count FROM logs l JOIN apps a ON l.app_id = a.id WHERE a.owner_id = ? AND (l.action LIKE "LOGIN%" OR l.action LIKE "AUTH%" OR l.action LIKE "VALIDATE%")', [id]);
        const reg = await db.get('SELECT COUNT(*) as count FROM logs l JOIN apps a ON l.app_id = a.id WHERE a.owner_id = ? AND (l.action LIKE "REGISTER%" OR l.action LIKE "REDEEM%")', [id]);
        return sendResponse(res, 200, true, { totalApps: apps.count, totalLicenses: lics.count, totalUsers: users.count, authHits: auth.count, regHits: reg.count }, 'Detailed stats fetched');
    } catch (error) {
        return sendResponse(res, 500, false, null, 'Error');
    }
};

exports.exportUsers = async (req, res) => {
    try {
        const db = await getDb();
        const users = await db.all('SELECT u.username, u.email, u.role, u.status, u.plan, u.created_at, (SELECT COUNT(*) FROM apps WHERE owner_id = u.id) as total_apps FROM users u WHERE role != "admin" AND (google_id IS NOT NULL OR (email IS NOT NULL AND email LIKE "%@%"))');
        let csv = 'Username,Email,Role,Status,Plan,Created At,Total Apps\n';
        users.forEach(u => { csv += `"${u.username}", "${u.email || ''}", "${u.role}", "${u.status}", "${u.plan}", "${u.created_at}", ${u.total_apps} \n`; });
        res.setHeader('Content-Type', 'text/csv'); res.setHeader('Content-Disposition', 'attachment; filename=clients.csv');
        res.status(200).send(csv);
    } catch (error) { res.status(500).json({ success: false, message: 'Error' }); }
};

exports.getAnalytics = async (req, res) => {
    try {
        const db = await getDb();
        const wHits = await db.get('SELECT COUNT(*) as count FROM logs l JOIN users u ON l.user_id = u.id WHERE (l.action LIKE "LOGIN%" OR l.action LIKE "AUTH%") AND l.timestamp >= datetime("now", "-7 days") AND u.role != "admin"');
        const mHits = await db.get('SELECT COUNT(*) as count FROM logs l JOIN users u ON l.user_id = u.id WHERE (l.action LIKE "LOGIN%" OR l.action LIKE "AUTH%") AND l.timestamp >= datetime("now", "-30 days") AND u.role != "admin"');
        const del = await db.get('SELECT COUNT(*) as count FROM logs WHERE action LIKE "USER DELETED%"');
        const dActive = await db.all('SELECT strftime("%Y-%m-%d", l.timestamp) as date, COUNT(DISTINCT l.user_id) as count FROM logs l JOIN users u ON l.user_id = u.id WHERE u.role != "admin" AND l.timestamp >= datetime("now", "-30 days") GROUP BY date ORDER BY date ASC');
        const dHits = await db.all('SELECT strftime("%Y-%m-%d", l.timestamp) as date, COUNT(*) as count FROM logs l JOIN users u ON l.user_id = u.id WHERE u.role != "admin" AND l.timestamp >= datetime("now", "-30 days") GROUP BY date ORDER BY date ASC');
        const pDist = await db.all('SELECT plan, COUNT(*) as count FROM users WHERE role != "admin" GROUP BY plan');
        return sendResponse(res, 200, true, { weeklyHits: wHits.count, monthlyHits: mHits.count, deletedAccounts: del.count, dailyActive: dActive, dailyHits: dHits, planDist: pDist }, 'Analytics fetched');
    } catch (error) {
        return sendResponse(res, 500, false, null, 'Error');
    }
};

exports.sendMessage = async (req, res) => {
    const { receiver_id, content } = req.body;
    try {
        const db = await getDb();
        await db.run('INSERT INTO messages (sender_id, receiver_id, content) VALUES (?, ?, ?)', [req.user.id, receiver_id, content]);
        await logService.recordLog(req.user.id, null, `MSG TO: ${receiver_id}`, req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 200, true, null, 'Sent');
    } catch (error) {
        return sendResponse(res, 500, false, null, 'Error');
    }
};

// --- PLAN REQUESTS ---
exports.getPlanRequests = async (req, res) => {
    try {
        const db = await getDb();
        const requests = await db.all(`
            SELECT pr.*, u.username, u.email, u.plan as current_plan
            FROM plan_requests pr
            JOIN users u ON pr.user_id = u.id
            WHERE pr.status = 'pending'
            ORDER BY pr.created_at DESC
        `);
        return sendResponse(res, 200, true, requests, 'Plan requests fetched');
    } catch (error) {
        console.error('[RDX Admin Plan Requests] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.updatePlanRequestStatus = async (req, res) => {
    const { id } = req.params;
    const { status, admin_note } = req.body; // status: 'approved' or 'rejected'

    if (!['approved', 'rejected'].includes(status)) {
        return sendResponse(res, 400, false, null, 'Invalid status');
    }

    try {
        const db = await getDb();
        const request = await db.get('SELECT * FROM plan_requests WHERE id = ?', [id]);
        if (!request) return sendResponse(res, 404, false, null, 'Request not found');

        await db.run('BEGIN TRANSACTION');
        try {
            await db.run(
                'UPDATE plan_requests SET status = ?, admin_note = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
                [status, admin_note || null, id]
            );

            if (status === 'approved') {
                // Set expiry date (30 days from now)
                const expiryDate = new Date();
                expiryDate.setDate(expiryDate.getDate() + 30);
                const expiryStr = expiryDate.toISOString();

                // Update user's plan and expiry
                await db.run('UPDATE users SET plan = ?, expiry_date = ? WHERE id = ?', [request.plan, expiryStr, request.user_id]);

                // Update associated license if exists
                await db.run('UPDATE licenses SET expiry_date = ? WHERE user_id = ?', [expiryStr, request.user_id]);

                // Create Notification / Message
                try {
                    await db.run(
                        'INSERT INTO messages (sender_id, receiver_id, content, timestamp) VALUES (?, ?, ?, CURRENT_TIMESTAMP)',
                        [req.user.id, request.user_id, `Congratulations! Your subscription for the ${request.plan.toUpperCase()} plan has been approved and activated.`]
                    );

                    // Send Activation Email
                    const user = await db.get('SELECT email, username FROM users WHERE id = ?', [request.user_id]);
                    if (user && user.email) {
                        console.log(`[RDX Email Trigger] Sending Plan Activated email to: ${user.email} `);
                        await emailService.sendPlanActivatedEmail(user.email, user.username, {
                            plan: request.plan,
                            txId: request.transaction_id,
                            amount: request.amount,
                            expiry: expiryStr,
                            features: request.plan.toLowerCase() === 'pro'
                                ? ['Unlimited Apps', 'Priority Support', 'Custom Branding', 'Advanced Analytics']
                                : ['10 Apps', 'Standard Support', 'Basic Analytics']
                        });
                    } else {
                        console.log(`[RDX Email Trigger] Skipping Plan Activated email: ${user ? 'No email for ' + user.username : 'User not found'} `);
                    }

                    // Discord Notification to Client (Owner) for Plan Activation
                    discordService.sendLogToDiscord(request.user_id, 'PLAN ACTIVATED', `Your subscription for the ** ${request.plan.toUpperCase()} ** plan has been approved and activated!`);
                } catch (msgErr) {
                    console.error('[RDX Admin] Failed to send approval message/email:', msgErr);
                }

                // Log
                await logService.recordLog(req.user.id, null, `PLAN APPROVED: User ID ${request.user_id} -> ${request.plan} `);
            } else {
                await logService.recordLog(req.user.id, null, `PLAN REJECTED: User ID ${request.user_id} `);
            }

            await db.run('COMMIT');
            return sendResponse(res, 200, true, null, `Request ${status}`);
        } catch (e) {
            await db.run('ROLLBACK');
            throw e;
        }
    } catch (error) {
        console.error('[RDX Admin Update Plan Request] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};
exports.getSettings = async (req, res) => {
    try {
        const db = await getDb();
        const settings = await db.all('SELECT * FROM system_settings');
        const config = {};
        settings.forEach(s => config[s.key] = s.value);
        return sendResponse(res, 200, true, config, 'Settings fetched');
    } catch (error) {
        console.error('[RDX Admin Settings] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error loading settings');
    }
};

exports.updateSettings = async (req, res) => {
    const { key, value } = req.body;
    try {
        const db = await getDb();
        await db.run('INSERT INTO system_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = ?, updated_at = CURRENT_TIMESTAMP', [key, value, value]);
        await logService.recordLog(req.user.id, null, `ADMIN SETTING UPDATE: ${key}`);
        if (key === 'discord_bot_token') {
            discordService.initDiscordBot();
        }
        return sendResponse(res, 200, true, null, 'Setting updated');
    } catch (error) {
        console.error('[RDX Admin Settings Update] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error updating settings');
    }
};
// --- ADMINISTRATIVE RESETS ---
exports.resetUsers = async (req, res) => {
    try {
        const db = await getDb();
        await db.run('BEGIN TRANSACTION');
        try {
            await db.run('DELETE FROM ticket_messages WHERE sender_id IN (SELECT id FROM users WHERE role = "user")');
            await db.run('DELETE FROM tickets WHERE user_id IN (SELECT id FROM users WHERE role = "user")');
            await db.run('DELETE FROM logs WHERE user_id IN (SELECT id FROM users WHERE role = "user")');
            await db.run('DELETE FROM messages WHERE sender_id IN (SELECT id FROM users WHERE role = "user") OR receiver_id IN (SELECT id FROM users WHERE role = "user")');
            await db.run('DELETE FROM licenses WHERE user_id IN (SELECT id FROM users WHERE role = "user")');
            await db.run('DELETE FROM plan_requests WHERE user_id IN (SELECT id FROM users WHERE role = "user")');
            await db.run('DELETE FROM users WHERE role = "user"');
            await db.run('COMMIT');
            await logService.recordLog(req.user.id, null, 'ADMIN BULK RESET: ALL CLIENT USERS', req.ip, null, req.headers['user-agent']);
            return sendResponse(res, 200, true, null, 'All client users and their data deleted successfully');
        } catch (e) { await db.run('ROLLBACK'); throw e; }
    } catch (error) {
        console.error('[RDX Admin Reset Users] Error:', error);
        return sendResponse(res, 500, false, null, 'Reset failed: ' + error.message);
    }
};

exports.resetLicenses = async (req, res) => {
    try {
        const db = await getDb();
        await db.run('DELETE FROM licenses');
        await logService.recordLog(req.user.id, null, 'ADMIN BULK RESET: ALL LICENSES', req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 200, true, null, 'All license keys deleted successfully');
    } catch (error) {
        console.error('[RDX Admin Reset Licenses] Error:', error);
        return sendResponse(res, 500, false, null, 'Reset failed');
    }
};

exports.resetClients = async (req, res) => {
    // Clients and Users are essentially the same entity in this context
    return exports.resetUsers(req, res);
};

exports.resetApps = async (req, res) => {
    try {
        const db = await getDb();
        await db.run('BEGIN TRANSACTION');
        try {
            // Delete in order to satisfy FK constraints
            await db.run('DELETE FROM ticket_messages');
            await db.run('DELETE FROM tickets');
            await db.run('DELETE FROM logs');
            await db.run('DELETE FROM messages');
            await db.run('DELETE FROM blacklist');
            await db.run('DELETE FROM plan_requests');
            await db.run('DELETE FROM licenses');
            await db.run('DELETE FROM app_resellers');
            await db.run('DELETE FROM variables');
            await db.run('DELETE FROM users WHERE role = "user"');
            await db.run('DELETE FROM apps');

            await db.run('COMMIT');
            await logService.recordLog(req.user.id, null, 'ADMIN BULK RESET: ALL APPS (FULL DB WIPE)', req.ip, null, req.headers['user-agent']);
            return sendResponse(res, 200, true, null, 'All applications and associated data deleted');
        } catch (e) { await db.run('ROLLBACK'); throw e; }
    } catch (error) {
        console.error('[RDX Admin Reset Apps] Error:', error);
        return sendResponse(res, 500, false, null, 'Reset failed: ' + error.message);
    }
};

exports.resetDashboard = async (req, res) => {
    try {
        const db = await getDb();
        await db.run('BEGIN TRANSACTION');
        try {
            await db.run('DELETE FROM logs');
            await db.run('DELETE FROM plan_requests');
            await db.run('DELETE FROM tickets');
            await db.run('DELETE FROM ticket_messages');
            await db.run('COMMIT');
            await logService.recordLog(req.user.id, null, 'ADMIN BULK RESET: DASHBOARD (TICKETS/LOGS)', req.ip, null, req.headers['user-agent']);
            return sendResponse(res, 200, true, null, 'Dashboard data (tickets, orders, logs) reset');
        } catch (e) { await db.run('ROLLBACK'); throw e; }
    } catch (error) {
        console.error('[RDX Admin Reset Dashboard] Error:', error);
        return sendResponse(res, 500, false, null, 'Reset failed');
    }
};
// --- REAL-TIME TRAFFIC ---
exports.getRealtimeTraffic = async (req, res) => {
    if (req.user.role !== 'admin') return sendResponse(res, 403, false, null, 'Forbidden');
    try {
        const db = await getDb();
        const fiveMinsAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
        
        const traffic = await db.all(`
            SELECT strftime('%H:%M', timestamp, 'localtime') as time, COUNT(*) as hit_count
            FROM logs
            WHERE timestamp > ?
            GROUP BY time
            ORDER BY time ASC
        `, [fiveMinsAgo]);

        return sendResponse(res, 200, true, traffic, 'Real-time traffic fetched');
    } catch (error) {
        console.error('[RDX Real-time Traffic] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};
