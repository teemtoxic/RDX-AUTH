const crypto = require('crypto');
const { getDb } = require('../config/db');

exports.generateLicense = async (req, res) => {
    const { app_id, user_id, expiry_days, hwid_lock } = req.body;

    try {
        const db = await getDb();
        const licenseKey = `RDX-${crypto.randomBytes(4).toString('hex').toUpperCase()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;

        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + (expiry_days || 30));

        await db.run(
            'INSERT INTO licenses (license_key, app_id, user_id, expiry_date, hwid_lock) VALUES (?, ?, ?, ?, ?)',
            [licenseKey, app_id, user_id, expiryDate.toISOString(), hwid_lock !== undefined ? (hwid_lock ? 1 : 0) : 1]
        );

        res.status(201).json({ success: true, licenseKey, expiryDate });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

exports.validateLicense = async (req, res) => {
    // Expected Payload: { license_key, owner_id, app_name, timestamp, hardware_info: { id, baseboard, cpu, mac, is_debug, is_vm } }
    const { license_key, hwid, owner_id, app_name, timestamp, hardware_info } = req.body;
    const signature = req.headers['x-signature'] || req.body.signature;

    // Use legacy hwid string if hardware_info object is not provided
    const clientHwid = hardware_info ? hardware_info.id : hwid;
    const clientBaseboard = hardware_info ? hardware_info.baseboard : null;
    const clientCpu = hardware_info ? hardware_info.cpu : null;
    const clientMac = hardware_info ? hardware_info.mac : null;

    try {
        const db = await getDb();

        const maintenance = await db.get('SELECT value FROM system_settings WHERE key = "maintenance_mode"');
        if (maintenance && maintenance.value === 'true') {
            return res.status(503).json({ success: false, message: 'Server is currently under maintenance.' });
        }

        // Fetch license along with app details AND anti-cheat settings
        const query = `
            SELECT l.*, a.owner_key, a.secret, a.name as app_name,
                   a.anti_vm, a.anti_debug, a.debugger_detection
            FROM licenses l
            LEFT JOIN apps a ON l.app_id = a.id
            WHERE l.license_key = ?
        `;
        const license = await db.get(query, [license_key]);

        if (!license) {
            return res.status(404).json({ success: false, message: 'Invalid license key' });
        }

        // 1. Anti-Tamper / Anti-Cheat Checks
        // If app requires anti_debugger but client reports is_debug = true
        let isDebuggerEnabled = license.anti_debug == 1 || license.debugger_detection == 1;
        if (isDebuggerEnabled && hardware_info && hardware_info.is_debug) {
            console.warn(`[RDX Security] Debugger detected on License: ${license_key}`);
            return res.status(403).json({ success: false, message: 'Security Alert: Debugger attached. Access Denied.' });
        }

        // If app requires anti_vm but client reports is_vm = true
        if (license.anti_vm == 1 && hardware_info && hardware_info.is_vm) {
            console.warn(`[RDX Security] Virtual Machine detected on License: ${license_key}`);
            return res.status(403).json({ success: false, message: 'Security Alert: Virtual Machine detected. Access Denied.' });
        }

        // 2. Verify Request Timestamp (prevent replay attacks > 5 mins old)
        if (timestamp) {
            const reqTime = parseInt(timestamp);
            const now = Date.now();
            if (Math.abs(now - reqTime) > 300000) { // 5 minutes window
                return res.status(403).json({ success: false, message: 'Request expired (Check device time)' });
            }
        }

        // 3. Verify HMAC Signature
        if (signature) {
            const dataToSign = `${license_key}${clientHwid}${owner_id}${timestamp || ''}`;
            const expectedSignature = crypto.createHmac('sha256', license.secret)
                .update(dataToSign)
                .digest('hex');

            if (signature !== expectedSignature) {
                console.warn(`[RDX Security] Signature Mismatch: Expected ${expectedSignature}, Got ${signature}`);
                return res.status(403).json({ success: false, message: 'Invalid Request Signature' });
            }
        }

        // Validate App Credentials if provided (Strict Mode)
        if (owner_id && license.owner_key !== owner_id) {
            return res.status(403).json({ success: false, message: 'License does not belong to this application (Owner ID Mismatch)' });
        }

        if (license.status !== 'active') {
            return res.status(401).json({ success: false, message: `License is ${license.status}` });
        }

        const now = new Date();
        if (license.expiry_date && new Date(license.expiry_date) < now) {
            await db.run('UPDATE licenses SET status = "expired" WHERE id = ?', [license.id]);
            return res.status(401).json({ success: false, message: 'License has expired' });
        }

        // 4. Advanced HWID Locking Logic
        if (license.hwid_lock == 1) {
            if (!license.hwid) {
                // First time use: Bind license to ALL Deep HWID components
                await db.run(
                    'UPDATE licenses SET hwid = ?, hwid_baseboard = ?, hwid_cpu = ?, hwid_mac = ? WHERE id = ?',
                    [clientHwid, clientBaseboard, clientCpu, clientMac, license.id]
                );
            } else {
                // Return User: Verify HWID matching
                let matchConfidence = 0;
                let totalChecks = 0;

                // Check legacy main HWID string
                totalChecks++;
                if (license.hwid === clientHwid) matchConfidence++;

                // Check Baseboard (Motherboard)
                if (license.hwid_baseboard && clientBaseboard) {
                    totalChecks++;
                    if (license.hwid_baseboard === clientBaseboard) matchConfidence++;
                }

                // Check CPU
                if (license.hwid_cpu && clientCpu) {
                    totalChecks++;
                    if (license.hwid_cpu === clientCpu) matchConfidence++;
                }

                // Check MAC Address (Most likely to change/spoof)
                if (license.hwid_mac && clientMac) {
                    totalChecks++;
                    if (license.hwid_mac === clientMac) matchConfidence++;
                }

                // Tolerance Check: If we checked multiple components, require at least 50% match
                // Example: If baseboard and CPU match but MAC changed, it will pass (2 out of 3 = >0.5)
                // If main hwid is the only check (legacy), it must be an exact match
                const requiredRatio = totalChecks > 1 ? 0.51 : 1.0;
                const currentRatio = matchConfidence / totalChecks;

                if (currentRatio < requiredRatio) {
                    console.warn(`[RDX Security] Advanced HWID Mismatch for License: ${license_key} (Ratio: ${currentRatio.toFixed(2)})`);
                    return res.status(401).json({ success: false, message: 'HWID mismatch. License is locked to another device.' });
                }

                // Auto-heal logic: If MAC changed but we passed tolerance, we can optionally update the DB MAC 
                // to allow seamless future logins. (Skipping for now to maintain strict history).
            }
        } else {
            // Optional: Still record HWID for logging/tracking even if not locked
            if (!license.hwid && clientHwid) {
                await db.run(
                    'UPDATE licenses SET hwid = ?, hwid_baseboard = ?, hwid_cpu = ?, hwid_mac = ? WHERE id = ?',
                    [clientHwid, clientBaseboard, clientCpu, clientMac, license.id]
                );
            }
        }

        // Log the successful validation
        await db.run(
            'INSERT INTO logs (user_id, app_id, action, ip, hwid) VALUES (?, ?, ?, ?, ?)',
            [license.user_id, license.app_id, 'LOGIN_SUCCESS', req.ip, clientHwid]
        );

        // Fetch server-side variables for this app
        const variablesRaw = await db.all('SELECT name, value FROM variables WHERE app_id = ?', [license.app_id]);

        const variables = {};
        if (variablesRaw && variablesRaw.length > 0) {
            variablesRaw.forEach(v => variables[v.name] = v.value);
        }

        res.json({
            success: true,
            message: 'Authentication successful',
            info: {
                app: license.app_name,
                expiry: license.expiry_date,
                duration: license.duration
            },
            variables: variables
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error parsing hardware info.' });
    }
};
