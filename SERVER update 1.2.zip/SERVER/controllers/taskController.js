const { getDb } = require('../config/db');
const scheduler = require('../utils/scheduler');
const { v4: uuidv4 } = require('uuid');

exports.getTasks = async (req, res) => {
    try {
        const db = await getDb();
        const tasks = await db.all('SELECT * FROM scheduled_tasks WHERE owner_id = ?', [req.user.id]);
        res.json({ success: true, tasks });
    } catch (err) {
        console.error('[TASK-CONTROLLER] GetTasks Error:', err);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.createTask = async (req, res) => {
    // SECURITY: Only Admins should manage global automation tasks
    if (req.user.role !== 'admin') {
        return res.status(403).json({ success: false, message: 'Forbidden: Admins only' });
    }

    const { action, payload, cron_expression } = req.body;
    
    if (!action || !cron_expression) {
        return res.status(400).json({ success: false, message: 'Action and Cron Expression are required' });
    }

    const ALLOWED_ACTIONS = ['CREATE_FREE_KEY', 'DISCORD_POST'];
    if (!ALLOWED_ACTIONS.includes(action)) {
        return res.status(400).json({ success: false, message: 'Invalid or unauthorized action' });
    }

    try {
        const db = await getDb();
        const result = await db.run(
            'INSERT INTO scheduled_tasks (owner_id, action, payload, cron_expression) VALUES (?, ?, ?, ?)',
            [req.user.id, action, JSON.stringify(payload || {}), cron_expression]
        );

        const newTask = await db.get('SELECT * FROM scheduled_tasks WHERE id = ?', [result.lastID]);
        
        // Register in memory scheduler
        scheduler.scheduleTask(newTask);

        res.json({ success: true, message: 'Task scheduled successfully', task: newTask });
    } catch (err) {
        console.error('[TASK-CONTROLLER] CreateTask Error:', err);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.deleteTask = async (req, res) => {
    const { id } = req.params;
    try {
        const db = await getDb();
        
        // Check ownership
        const task = await db.get('SELECT * FROM scheduled_tasks WHERE id = ? AND owner_id = ?', [id, req.user.id]);
        if (!task) {
            return res.status(404).json({ success: false, message: 'Task not found or access denied' });
        }

        await db.run('DELETE FROM scheduled_tasks WHERE id = ?', [id]);
        
        // Stop in memory scheduler
        scheduler.stopTask(id);

        res.json({ success: true, message: 'Task deleted successfully' });
    } catch (err) {
        console.error('[TASK-CONTROLLER] DeleteTask Error:', err);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.toggleTaskStatus = async (req, res) => {
    const { id } = req.params;
    const { status } = req.body; // 1 for active, 0 for inactive

    try {
        const db = await getDb();
        const task = await db.get('SELECT * FROM scheduled_tasks WHERE id = ? AND owner_id = ?', [id, req.user.id]);
        if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

        await db.run('UPDATE scheduled_tasks SET is_active = ? WHERE id = ?', [status, id]);

        if (status === 1) {
            const updatedTask = await db.get('SELECT * FROM scheduled_tasks WHERE id = ?', [id]);
            scheduler.scheduleTask(updatedTask);
        } else {
            scheduler.stopTask(id);
        }

        res.json({ success: true, message: `Task ${status === 1 ? 'activated' : 'deactivated'}` });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
