const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { OAuth2Client } = require('google-auth-library');
const { getDb } = require('../config/db');
const logService = require('../utils/logService');
const emailService = require('../utils/emailService');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const securityUtils = require('../utils/securityUtils');
const sendResponse = require('../utils/responseHelper');

const googleClient = new OAuth2Client(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET
);

// Helper to write to server log
const logErrorToFile = (error) => {
    const logPath = path.join(__dirname, '../../server.log');
    const timestamp = new Date().toISOString();
    const message = `[RDX ERROR] ${timestamp}: ${error.message}\nStack: ${error.stack}\n`;
    try {
        fs.appendFileSync(logPath, message);
    } catch (e) {
        console.error('Failed to write to log file:', e);
    }
};

exports.googleLogin = async (req, res) => {
    // Check multiple potential payload keys from different frontend implementations
    const idToken = req.body.idToken || req.body.token || req.body.credential;

    if (!idToken) {
        console.error('[RDX Google Login] Missing token in body:', req.body);
        return sendResponse(res, 400, false, null, 'Auth ID token is required');
    }

    try {
        const ticket = await googleClient.verifyIdToken({
            idToken,
            audience: process.env.GOOGLE_CLIENT_ID,
        });

        const payload = ticket.getPayload();
        if (!payload) {
            return sendResponse(res, 401, false, null, 'Invalid Google token payload');
        }

        const { sub: googleId, email, name, picture } = payload;
        const db = await getDb();

        const maintenance = await db.get('SELECT value FROM system_settings WHERE key = "maintenance_mode"');
        if (maintenance && maintenance.value === 'true') {
            return sendResponse(res, 503, false, null, 'Server is under maintenance');
        }

        let user = await db.get('SELECT * FROM users WHERE google_id = ? OR email = ?', [googleId, email]);

        if (!user) {
            // Create new user for google signup
            const username = (name || email.split('@')[0]).replace(/\s+/g, '').toLowerCase() + Math.floor(Math.random() * 1000);

            // Generate verification token for new google user
            const verifyToken = crypto.randomBytes(32).toString('hex');
            const placeholderPassword = crypto.randomBytes(16).toString('hex');
            const hashedPassword = await bcrypt.hash(placeholderPassword, 10);

            await db.run(
                'INSERT INTO users (username, email, google_id, role, password_hash, email_verified, verify_token) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [username, email, googleId, 'user', hashedPassword, 0, verifyToken]
            );
            user = await db.get('SELECT * FROM users WHERE google_id = ?', [googleId]);

            // Send Verification Email
            if (email) {
                await emailService.sendVerificationEmail(email, username, verifyToken);
            }
        } else if (!user.google_id) {
            // Link google account to existing email account
            await db.run('UPDATE users SET google_id = ? WHERE id = ?', [googleId, user.id]);
            user.google_id = googleId;
        }

        // Check 2FA
        if (user.two_factor_enabled === 1) {
            const tempToken = jwt.sign(
                { id: user.id, username: user.username, role: user.role, email: user.email, temp_2fa: true },
                process.env.JWT_SECRET,
                { expiresIn: '5m' }
            );
            return sendResponse(res, 200, true, {
                two_factor_required: true,
                temp_token: tempToken
            }, 'Two-factor authentication required.');
        }

        const jti = crypto.randomBytes(16).toString('hex');
        const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000;
        
        // Standardize Hardware Components for Google Login (RDX-FP-V2 Enforced)
        const hardware = securityUtils.parseHardwareInfo(req.body.hwid, req.body.hardware_info);
        const sessionHwid = req.headers['x-rdx-fp'] || hardware.hwid || req.headers['x-rdx-hwid'] || 'WEB_SESSION';

        await db.run(
            'INSERT INTO active_sessions (user_id, jti, ip_address, user_agent, expires_at, hwid) VALUES (?, ?, ?, ?, ?, ?)',
            [user.id, jti, req.ip, req.headers['user-agent'], expiresAt, sessionHwid]
        );

        const token = jwt.sign(
            { id: user.id, username: user.username, role: user.role, email: user.email, jti },
            process.env.JWT_SECRET,
            { expiresIn: '7d' }
        );

        await logService.recordLog(user.id, null, 'WEB_SESSION_GOOGLE', req.ip, null, req.headers['user-agent']);

        return sendResponse(res, 200, true, {
            token,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role
            }
        }, 'Google login successful');
    } catch (error) {
        console.error('[RDX Google Auth] Verification Error Details:', {
            message: error.message,
            stack: error.stack,
            idToken: idToken ? idToken.substring(0, 20) + '...' : 'MISSING',
            audience: process.env.GOOGLE_CLIENT_ID
        });
        logErrorToFile(error);
        return sendResponse(res, 500, false, null, `Google Auth verification failed: ${error.message}`);
    }
};

exports.resendVerification = async (req, res) => {
    try {
        const db = await getDb();
        const user = await db.get('SELECT id, username, email, email_verified, verify_token FROM users WHERE id = ?', [req.user.id]);

        if (!user) {
            return sendResponse(res, 404, false, null, 'User not found');
        }

        if (user.email_verified) {
            return sendResponse(res, 400, false, null, 'Email is already verified');
        }

        let verifyToken = user.verify_token;
        if (!verifyToken) {
            verifyToken = crypto.randomBytes(32).toString('hex');
            await db.run('UPDATE users SET verify_token = ? WHERE id = ?', [verifyToken, user.id]);
        }

        if (!user.email) {
            return sendResponse(res, 400, false, null, 'No email associated with this account');
        }

        await emailService.sendVerificationEmail(user.email, user.username, verifyToken);

        await logService.recordLog(user.id, null, 'USER_RESEND_VERIFICATION', req.ip, null, req.headers['user-agent']);

        return sendResponse(res, 200, true, null, 'Verification link re-dispatched to your inbox!');
    } catch (error) {
        console.error('[Resend Verification] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.googleCallback = async (req, res) => {
    try {
        const { credential } = req.body;
        if (!credential) {
            console.error('[RDX Google Callback] No credential found in body');
            return res.redirect('/login?error=NoCredential');
        }

        const ticket = await googleClient.verifyIdToken({
            idToken: credential,
            audience: process.env.GOOGLE_CLIENT_ID,
        });

        const payload = ticket.getPayload();
        if (!payload) {
            console.error('[RDX Google Callback] Invalid Token Payload');
            return res.redirect('/login?error=InvalidToken');
        }

        const { sub: googleId, email, name } = payload;
        const db = await getDb();

        let user = await db.get('SELECT * FROM users WHERE google_id = ? OR email = ?', [googleId, email]);

        if (!user) {
            const username = (name || email.split('@')[0]).replace(/\s+/g, '').toLowerCase() + Math.floor(Math.random() * 1000);
            const hashedPassword = "$2a$10$DUMMYPASSWORDHASHFORGOOGLEAUTH123456";
            const verifyToken = crypto.randomBytes(32).toString('hex');

            await db.run(
                'INSERT INTO users (username, email, google_id, role, password_hash, email_verified, verify_token) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [username, email, googleId, 'user', hashedPassword, 0, verifyToken]
            );
            user = await db.get('SELECT * FROM users WHERE google_id = ?', [googleId]);

            if (email) {
                await emailService.sendVerificationEmail(email, username, verifyToken);
            }
        } else if (!user.google_id) {
            await db.run('UPDATE users SET google_id = ? WHERE id = ?', [googleId, user.id]);
            user.google_id = googleId;
        }

        const token = jwt.sign(
            { id: user.id, username: user.username, role: user.role, email: user.email },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        await logService.recordLog(user.id, null, 'WEB_SESSION_GOOGLE_CALLBACK', req.ip, null, req.headers['user-agent']);
        res.redirect(user.role === 'admin' ? `/rdxofficial/unknown=admin/dashboard?auth_token=${token}` : `/dashboard?auth_token=${token}`);
    } catch (error) {
        console.error('[RDX Google Callback] Error:', error);
        logErrorToFile(error);
        res.redirect('/login?error=AuthFailed&message=' + encodeURIComponent(error.message));
    }
};

exports.register = async (req, res) => {
    const { username, password, email, role } = req.body;
    try {
        const db = await getDb();
        const userExists = await db.get('SELECT id FROM users WHERE username = ? OR (email = ? AND email IS NOT NULL AND email != "")', [username, email]);

        if (userExists) {
            return sendResponse(res, 400, false, null, 'Username or Email already exists');
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const verifyToken = crypto.randomBytes(32).toString('hex');

        const userResult = await db.run(
            'INSERT INTO users (username, email, password_hash, role, verify_token) VALUES (?, ?, ?, ?, ?)',
            [username, email || null, hashedPassword, role || 'user', verifyToken]
        );

        await logService.recordLog(userResult.lastID, null, 'USER_REGISTER_SUCCESS', req.ip, null, req.headers['user-agent']);
        if (email) {
            await emailService.sendVerificationEmail(email, username, verifyToken);
        }
        return sendResponse(res, 201, true, null, 'User registered successfully. Please verify your email.');
    } catch (error) {
        console.error(error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.verifyEmail = async (req, res) => {
    const { token } = req.query;
    if (!token) return res.status(400).send('Verification token is required');
    try {
        const db = await getDb();
        const user = await db.get('SELECT id FROM users WHERE verify_token = ?', [token]);
        if (!user) {
            return res.status(400).send('Invalid or expired verification token');
        }
        await db.run('UPDATE users SET email_verified = 1, verify_token = NULL WHERE id = ?', [user.id]);
        res.redirect('/dashboard?verified=true');
    } catch (error) {
        console.error('[Verify Email] Error:', error);
        res.status(500).send('Internal Server Error');
    }
};

exports.forgotPassword = async (req, res) => {
    const { email } = req.body;
    try {
        const db = await getDb();
        const user = await db.get('SELECT id, username FROM users WHERE email = ?', [email]);
        if (!user) {
            return sendResponse(res, 200, true, null, 'If an account exists with that email, a reset link has been sent.');
        }

        const resetToken = crypto.randomBytes(32).toString('hex');
        const resetExpires = Date.now() + 3600000; // 1 hour

        await db.run('UPDATE users SET reset_token = ?, reset_expires = ? WHERE id = ?', [resetToken, resetExpires, user.id]);
        await emailService.sendResetPasswordEmail(email, user.username, resetToken);
        return sendResponse(res, 200, true, null, 'Reset link sent to your email.');
    } catch (error) {
        console.error('[Forgot Password] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.resetPassword = async (req, res) => {
    const { token, newPassword } = req.body;
    try {
        const db = await getDb();
        const user = await db.get('SELECT id FROM users WHERE reset_token = ? AND reset_expires > ?', [token, Date.now()]);
        if (!user) {
            return sendResponse(res, 400, false, null, 'Invalid or expired reset token');
        }
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        await db.run('UPDATE users SET password_hash = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?', [hashedPassword, user.id]);
        return sendResponse(res, 200, true, null, 'Password has been reset successfully');
    } catch (error) {
        console.error('[Reset Password] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.login = async (req, res) => {
    const { username, password, hwid, app_id, app_name, owner_id, hardware_info, twoFactorToken, twoFactorCode } = req.body;
    const clientIp = req.ip;

    try {
        // 1. IP Security Check (VPN/Proxy Detection)
        const ipSecurity = await securityUtils.checkIpSecurity(clientIp);
        if (ipSecurity.isProxy) {
            console.warn(`[RDX Security] Blocked login from VPN/Proxy: ${clientIp} (${ipSecurity.details})`);
            await logService.recordLog(null, app_id || null, 'LOGIN_BLOCKED_VPN', clientIp, hwid || 'Unknown');
            return sendResponse(res, 403, false, null, 'Access denied. Please disable your VPN or Proxy to continue.');
        }

        const db = await getDb();
        const maintenance = await db.get('SELECT value FROM system_settings WHERE key = "maintenance_mode"');
        if (maintenance && maintenance.value === 'true') {
            return sendResponse(res, 503, false, null, 'Server is under maintenance');
        }

        const user = await db.get('SELECT * FROM users WHERE username = ? OR email = ?', [username, username]);
        if (!user) {
            await logService.recordLog(null, app_id || null, 'LOGIN_FAIL_USER_NOT_FOUND', req.ip, hwid || 'Unknown', req.headers['user-agent']);
            return sendResponse(res, 401, false, null, 'Invalid credentials');
        }

        // Standardize Hardware Components
        const hardware = securityUtils.parseHardwareInfo(hwid, hardware_info);
        const clientHwid = hardware.hwid;
        const clientBaseboard = hardware.baseboard;
        const clientCpu = hardware.cpu;
        const clientMac = hardware.mac;

        // Check Lockout Status
        if (user.locked_until && user.locked_until > Date.now()) {
            const minutesLeft = Math.ceil((user.locked_until - Date.now()) / 60000);
            return sendResponse(res, 429, false, null, `Account is temporarily locked due to multiple failed attempts. Try again in ${minutesLeft} minutes.`);
        }

        const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) {
            const newFailedCount = (user.failed_logins || 0) + 1;
            let lockedUntil = null;
            
            // Log the failure for AI Forensics
            await logService.recordLog(user.id, app_id || user.app_id || null, 'LOGIN_FAIL_PASSWORD', req.ip, clientHwid, req.headers['user-agent']);

            if (newFailedCount >= 5) {
                lockedUntil = Date.now() + 15 * 60 * 1000; // 15 minute lockout
                await logService.recordLog(user.id, app_id || user.app_id || null, 'USER_ACCOUNT_LOCKED', req.ip, clientHwid, req.headers['user-agent']);
            }
            await db.run('UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?', [newFailedCount, lockedUntil, user.id]);
            const remaining = 5 - newFailedCount;
            const message = remaining > 0 ? `Invalid credentials. ${remaining} attempts remaining before lockout.` : 'Invalid credentials. Account has been locked for 15 minutes.';
            return sendResponse(res, 401, false, null, message);
        }

        if (user.failed_logins > 0 || user.locked_until) {
            await db.run('UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id = ?', [user.id]);
        }

        // HWID Locking Logic
        if (user.hwid_lock === 1) {
            if (!user.hwid) {
                await db.run('UPDATE users SET hwid = ? WHERE id = ?', [clientHwid, user.id]);
                try {
                    await db.run('UPDATE users SET hwid_baseboard = ?, hwid_cpu = ?, hwid_mac = ? WHERE id = ?',
                        [clientBaseboard, clientCpu, clientMac, user.id]);
                } catch (e) { }
            } else if (user.hwid !== clientHwid) {
                await logService.recordLog(user.id, app_id || user.app_id || null, 'LOGIN_FAILED_HWID', req.ip, clientHwid, req.headers['user-agent']);
                return sendResponse(res, 403, false, null, 'HWID mismatch. Account locked to another device.');
            }
        }

        if (user.status !== 'active') {
            return sendResponse(res, 403, false, null, `Account is ${user.status.toUpperCase()}`);
        }

        if (user.two_factor_enabled === 1) {
            const tempToken = jwt.sign(
                { id: user.id, username: user.username, role: user.role, email: user.email, temp_2fa: true },
                process.env.JWT_SECRET,
                { expiresIn: '5m' }
            );
            return sendResponse(res, 200, true, { two_factor_required: true, temp_token: tempToken }, 'Two-factor authentication required.');
        }

        if (user.expiry_date) {
            const now = new Date();
            const expiry = new Date(user.expiry_date);
            if (expiry < now) {
                await db.run('UPDATE users SET status = "expired" WHERE id = ?', [user.id]);
                return sendResponse(res, 401, false, null, 'Account access has expired');
            }
        }

        const jti = crypto.randomBytes(16).toString('hex');
        const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000;
        const finalHwidForSession = req.headers['x-rdx-fp'] || clientHwid || req.headers['x-rdx-hwid'] || 'UNKNOWN';

        await db.run(
            'INSERT INTO active_sessions (user_id, jti, ip_address, user_agent, expires_at, hwid) VALUES (?, ?, ?, ?, ?, ?)',
            [user.id, jti, req.ip, req.headers['user-agent'], expiresAt, finalHwidForSession]
        );

        const token = jwt.sign(
            { id: user.id, username: user.username, role: user.role, email: user.email, jti },
            process.env.JWT_SECRET,
            { expiresIn: '7d' }
        );

        const logAppId = app_id || user.app_id || null;
        await logService.recordLog(user.id, logAppId, 'LOGIN_SUCCESS_USER', req.ip, clientHwid, req.headers['user-agent']);

        let variables = {};
        if (logAppId) {
            const variablesRaw = await db.all('SELECT name, value FROM variables WHERE app_id = ?', [logAppId]);
            if (variablesRaw && variablesRaw.length > 0) {
                variablesRaw.forEach(v => variables[v.name] = v.value);
            }
        }

        return sendResponse(res, 200, true, {
            token,
            user: { id: user.id, username: user.username, role: user.role, app_id: logAppId },
            variables
        }, 'Login successful');
    } catch (error) {
        console.error('[RDX Member Login Error]', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.logoutAll = async (req, res) => {
    try {
        const db = await getDb();
        await db.run('DELETE FROM active_sessions WHERE user_id = ?', [req.user.id]);
        await logService.recordLog(req.user.id, null, 'USER_LOGOUT_ALL', req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 200, true, null, 'Successfully logged out from all devices');
    } catch (error) {
        console.error('[Logout All] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.registerWithKey = async (req, res) => {
    const { username, password, email, license_key } = req.body;
    if (!username || !password || !license_key) {
        return sendResponse(res, 400, false, null, 'All fields are required');
    }
    try {
        const db = await getDb();
        const userExists = await db.get('SELECT id FROM users WHERE username = ? OR (email = ? AND email IS NOT NULL AND email != "")', [username, email]);
        if (userExists) {
            return sendResponse(res, 400, false, null, 'Username or Email already taken');
        }

        const license = await db.get('SELECT * FROM licenses WHERE license_key = ?', [license_key]);
        if (!license) {
            return sendResponse(res, 404, false, null, 'Invalid license key');
        }
        if (license.user_id) {
            return sendResponse(res, 400, false, null, 'License key already redeemed');
        }
        if (license.status !== 'active') {
            return sendResponse(res, 400, false, null, 'License key is not active');
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const verifyToken = crypto.randomBytes(32).toString('hex');

        const userResult = await db.run(
            'INSERT INTO users (username, password_hash, role, email, verify_token) VALUES (?, ?, ?, ?, ?)',
            [username, hashedPassword, 'user', email || null, verifyToken]
        );
        const user_id = userResult.lastID;

        const expiry_date = new Date();
        expiry_date.setDate(expiry_date.getDate() + (license.duration || 0));

        await db.run('UPDATE licenses SET user_id = ?, expiry_date = ? WHERE id = ?', [user_id, expiry_date.toISOString(), license.id]);
        await logService.recordLog(user_id, license.app_id, 'LICENSE_REDEEM_SUCCESS', req.ip, null, req.headers['user-agent']);
        if (email) {
            await emailService.sendVerificationEmail(email, username, verifyToken);
        }
        return sendResponse(res, 201, true, null, 'Account created and license redeemed. Please verify your email.');
    } catch (error) {
        console.error(error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.getMe = async (req, res) => {
    try {
        const db = await getDb();
        const user = await db.get('SELECT id, username, email, email_verified, role, plan, created_at, expiry_date, discord_id, discord_server_id, discord_log_channel_id, discord_role_id, allowed_admin_ids, groq_api_key, tavily_api_key FROM users WHERE id = ?', [req.user.id]);
        if (!user) {
            return sendResponse(res, 404, false, null, 'User not found');
        }

        const appsCount = await db.get('SELECT COUNT(*) as count FROM apps WHERE owner_id = ?', [user.id]);
        const keysCount = await db.get('SELECT COUNT(*) as count FROM licenses l JOIN apps a ON l.app_id = a.id WHERE a.owner_id = ?', [user.id]);
        const lastLoginRaw = await db.get('SELECT timestamp, ip FROM logs WHERE user_id = ? AND action LIKE "%LOGIN%" ORDER BY timestamp DESC LIMIT 1', [user.id]);
        
        // Better IP Detection for Authorized Source IP
        let currentIp = req.ip;
        if (currentIp === '::1' || currentIp === '127.0.0.1' || currentIp.includes('::ffff:127.0.0.1')) {
            const forwardedFor = req.headers['x-forwarded-for'];
            if (forwardedFor) {
                currentIp = forwardedFor.split(',')[0].trim();
            }
        }

        const lastLogin = {
            timestamp: lastLoginRaw ? lastLoginRaw.timestamp : null,
            ip: (lastLoginRaw && lastLoginRaw.ip && !['::1', '127.0.0.1', '0.0.0.0'].includes(lastLoginRaw.ip)) ? lastLoginRaw.ip : currentIp
        };
        const license = await db.get('SELECT * FROM licenses WHERE user_id = ? AND status = "active"', [user.id]);

        const actionFilter = '(l.action LIKE "LOGIN%" OR l.action LIKE "AUTH%" OR l.action LIKE "VALIDATE%" OR l.action LIKE "USER_LOGIN%" OR l.action LIKE "APP_LOGIN%" OR l.action LIKE "%SDK%")';
        const totalHits = await db.get(`
            SELECT COUNT(*) as count 
            FROM logs l 
            JOIN apps a ON l.app_id = a.id 
            WHERE a.owner_id = ? AND ${actionFilter}
        `, [user.id]);

        return sendResponse(res, 200, true, {
            id: user.id,
            username: user.username,
            email: user.email || 'No email set',
            email_verified: !!user.email_verified,
            role: user.role,
            discord_id: user.discord_id,
            discord_server_id: user.discord_server_id,
            discord_log_channel_id: user.discord_log_channel_id,
            discord_role_id: user.discord_role_id,
            created_at: user.created_at,
            expiry_date: user.expiry_date,
            stats: {
                apps: appsCount.count,
                keys: keysCount.count,
                hits: totalHits.count
            },
            security: {
                last_login: lastLogin ? lastLogin.timestamp : null,
                last_ip: lastLogin ? lastLogin.ip : 'N/A'
            },
            subscription: {
                type: user.plan ? (user.plan.charAt(0).toUpperCase() + user.plan.slice(1)) : 'Starter',
                expiry: license ? license.expiry_date : (user.expiry_date || null),
                key: license ? license.license_key : null
            },
            plan: user.plan || 'starter',
            user_plan: user.plan || 'starter',
            user_role: user.role,
            groq_api_key: user.groq_api_key,
            tavily_api_key: user.tavily_api_key
        }, 'User data fetched');
    } catch (error) {
        console.error(error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.updateProfile = async (req, res) => {
    const { username, email, discord_id, discord_server_id, discord_log_channel_id, discord_role_id, allowed_admin_ids, groq_api_key, tavily_api_key, ai_alignment_prompt, ai_rule_base, ai_mode } = req.body;
    const userId = req.user.id;
    try {
        const db = await getDb();
        if (username) {
            const existingUser = await db.get('SELECT id FROM users WHERE username = ? AND id != ?', [username, userId]);
            if (existingUser) return sendResponse(res, 400, false, null, 'Username already taken');
            await db.run('UPDATE users SET username = ? WHERE id = ?', [username, userId]);
        }
        if (email) {
            const existingEmail = await db.get('SELECT id FROM users WHERE email = ? AND id != ?', [email, userId]);
            if (existingEmail) return sendResponse(res, 400, false, null, 'Email already in use by another account');
            await db.run('UPDATE users SET email = ? WHERE id = ?', [email, userId]);
        }

        const updates = [];
        const params = [];
        const fields = { discord_id, discord_server_id, discord_log_channel_id, discord_role_id, allowed_admin_ids, groq_api_key, tavily_api_key, ai_alignment_prompt, ai_rule_base, ai_mode };
        for (const [key, val] of Object.entries(fields)) {
            if (val !== undefined) {
                updates.push(`${key} = ?`);
                params.push(val);
            }
        }

        if (updates.length > 0) {
            params.push(userId);
            await db.run(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, params);
        }

        await logService.recordLog(userId, null, `PROFILE UPDATED`, req.ip, null, req.headers['user-agent']);
        console.log(`[RDX AUTH] Profile successfully updated for user ID: ${userId}. New data:`, { username, email });
        return sendResponse(res, 200, true, null, 'Profile updated successfully');
    } catch (error) {
        console.error(error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.deleteAccount = async (req, res) => {
    const userId = req.user.id;
    try {
        const db = await getDb();
        const apps = await db.all('SELECT id FROM apps WHERE owner_id = ?', [userId]);
        const appIds = apps.map(app => app.id);

        await db.run('BEGIN TRANSACTION');
        if (appIds.length > 0) {
            const placeholders = appIds.map(() => '?').join(',');
            await db.run(`DELETE FROM variables WHERE app_id IN (${placeholders})`, appIds);
            await db.run(`DELETE FROM licenses WHERE app_id IN (${placeholders})`, appIds);
            await db.run(`DELETE FROM app_resellers WHERE app_id IN (${placeholders})`, appIds);
            await db.run(`DELETE FROM logs WHERE app_id IN (${placeholders})`, appIds);
            await db.run(`DELETE FROM apps WHERE owner_id = ?`, [userId]);
        }
        await db.run('DELETE FROM logs WHERE user_id = ?', [userId]);
        await db.run('DELETE FROM users WHERE id = ?', [userId]);
        await db.run('COMMIT');

        return sendResponse(res, 200, true, null, 'Account and all data deleted successfully.');
    } catch (error) {
        try { const db = await getDb(); await db.run('ROLLBACK'); } catch (e) { }
        console.error('[RDX ERROR] Delete Account failed:', error);
        return sendResponse(res, 500, false, null, 'Failed to delete account');
    }
};

exports.getBillingHistory = async (req, res) => {
    try {
        const db = await getDb();
        const history = await db.all('SELECT * FROM plan_requests WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
        return sendResponse(res, 200, true, history, 'Billing history fetched');
    } catch (error) {
        console.error(error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.getLogs = async (req, res) => {
    try {
        const db = await getDb();
        const logs = await db.all('SELECT timestamp, action, ip, hwid FROM logs WHERE user_id = ? ORDER BY timestamp DESC LIMIT 50', [req.user.id]);
        return sendResponse(res, 200, true, logs, 'Logs fetched successfully');
    } catch (error) {
        console.error('[RDX Auth getLogs] Error:', error);
        return sendResponse(res, 500, false, null, 'Failed to fetch logs');
    }
};

exports.getDiscordConfig = async (req, res) => {
    try {
        const db = await getDb();
        const config = await db.get('SELECT discord_id, discord_server_id, discord_log_channel_id, discord_role_id FROM users WHERE id = ?', [req.user.id]);
        return sendResponse(res, 200, true, config, 'Discord config fetched');
    } catch (error) {
        console.error(error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.getDiscordModerationLogs = async (req, res) => {
    try {
        const db = await getDb();
        const logs = await db.all('SELECT * FROM logs WHERE user_id = ? AND action LIKE "DISCORD_MOD_%" ORDER BY timestamp DESC LIMIT 100', [req.user.id]);
        return sendResponse(res, 200, true, logs, 'Discord moderation logs fetched');
    } catch (error) {
        console.error(error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.unbanDiscordUser = async (req, res) => {
    // Placeholder or logic to unban a user via Discord API
    return sendResponse(res, 200, true, null, 'Unban request sent to Discord');
};

exports.saveDiscordConfig = async (req, res) => {
    const { discord_id, discord_server_id, discord_log_channel_id, discord_role_id } = req.body;
    try {
        const db = await getDb();
        await db.run(
            'UPDATE users SET discord_id = ?, discord_server_id = ?, discord_log_channel_id = ?, discord_role_id = ? WHERE id = ?',
            [discord_id, discord_server_id, discord_log_channel_id, discord_role_id, req.user.id]
        );
        await logService.recordLog(req.user.id, null, 'DISCORD_CONFIG_UPDATED', req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 200, true, null, 'Discord configuration saved');
    } catch (error) {
        console.error(error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.setup2FA = async (req, res) => {
    try {
        const db = await getDb();
        const secret = speakeasy.generateSecret({ name: `RDX Auth (${req.user.username})` });
        const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url);

        await db.run('UPDATE users SET two_factor_secret = ? WHERE id = ?', [secret.base32, req.user.id]);
        return sendResponse(res, 200, true, { qrCodeUrl, secret: secret.base32 }, '2FA Setup initiated');
    } catch (error) {
        console.error(error);
        return sendResponse(res, 500, false, null, 'Failed to setup 2FA');
    }
};

exports.enable2FA = async (req, res) => {
    const { token } = req.body;
    try {
        const db = await getDb();
        const user = await db.get('SELECT two_factor_secret FROM users WHERE id = ?', [req.user.id]);
        if (!user || !user.two_factor_secret) {
            return sendResponse(res, 400, false, null, '2FA setup not initialized');
        }

        const verified = speakeasy.totp.verify({
            secret: user.two_factor_secret,
            encoding: 'base32',
            token: token
        });

        if (verified) {
            await db.run('UPDATE users SET two_factor_enabled = 1 WHERE id = ?', [req.user.id]);
            await logService.recordLog(req.user.id, null, '2FA_ENABLED', req.ip, null, req.headers['user-agent']);
            return sendResponse(res, 200, true, null, '2FA enabled successfully');
        } else {
            return sendResponse(res, 400, false, null, 'Invalid verification code');
        }
    } catch (error) {
        console.error(error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.verify2FALogin = async (req, res) => {
    const { temp_token, code } = req.body;
    try {
        const decoded = jwt.verify(temp_token, process.env.JWT_SECRET);
        if (!decoded.temp_2fa) {
            return sendResponse(res, 401, false, null, 'Invalid session token');
        }

        const db = await getDb();
        const user = await db.get('SELECT * FROM users WHERE id = ?', [decoded.id]);
        if (!user) {
            return sendResponse(res, 404, false, null, 'User not found');
        }

        const verified = speakeasy.totp.verify({
            secret: user.two_factor_secret,
            encoding: 'base32',
            token: code
        });

        if (!verified) {
            return sendResponse(res, 401, false, null, 'Invalid authentication code');
        }

        const jti = crypto.randomBytes(16).toString('hex');
        const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000;
        
        // Standardize Hardware Components for 2FA Verification (RDX-FP-V2 Enforced)
        const hardware = securityUtils.parseHardwareInfo(req.body.hwid, req.body.hardware_info);
        const sessionHwid = req.headers['x-rdx-fp'] || hardware.hwid || req.headers['x-rdx-hwid'] || 'WEB_SESSION';

        await db.run(
            'INSERT INTO active_sessions (user_id, jti, ip_address, user_agent, expires_at, hwid) VALUES (?, ?, ?, ?, ?, ?)',
            [user.id, jti, req.ip, req.headers['user-agent'], expiresAt, sessionHwid]
        );

        const token = jwt.sign(
            { id: user.id, username: user.username, role: user.role, email: user.email, jti },
            process.env.JWT_SECRET,
            { expiresIn: '7d' }
        );

        await logService.recordLog(user.id, null, '2FA_LOGIN_SUCCESS', req.ip, sessionHwid, req.headers['user-agent']);

        return sendResponse(res, 200, true, {
            token,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role
            }
        }, 'Two-factor login successful');
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return sendResponse(res, 401, false, null, 'Session expired. Please login again.');
        }
        console.error('[RDX 2FA Verify] Error:', error);
        return sendResponse(res, 500, false, null, 'Authentication failed');
    }
};

exports.disable2FA = async (req, res) => {
    try {
        const db = await getDb();
        await db.run('UPDATE users SET two_factor_enabled = 0, two_factor_secret = NULL WHERE id = ?', [req.user.id]);
        await logService.recordLog(req.user.id, null, '2FA_DISABLED', req.ip, null, req.headers['user-agent']);
        return sendResponse(res, 200, true, null, 'Two-factor authentication disabled');
    } catch (error) {
        console.error(error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.sendRecoveryOTP = async (req, res) => {
    const { identifier } = req.body;
    try {
        const db = await getDb();
        const user = await db.get('SELECT id, username, email FROM users WHERE email = ? OR username = ?', [identifier, identifier]);
        if (!user || !user.email) {
            return sendResponse(res, 200, true, null, 'If an account exists, a code has been sent.');
        }

        const otp = Math.floor(100000 + Math.random() * 900000).toString();
        const otpExpires = Date.now() + 600000; // 10 minutes

        await db.run('UPDATE users SET recovery_otp = ?, recovery_otp_expires = ? WHERE id = ?', [otp, otpExpires, user.id]);
        await emailService.sendRecoveryOTPEmail(user.email, user.username, otp);
        await logService.recordLog(user.id, null, 'RECOVERY_OTP_SENT', req.ip);

        return sendResponse(res, 200, true, null, 'Verification code sent to your email.');
    } catch (error) {
        console.error('[Send Recovery OTP] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.verifyRecoveryOTP = async (req, res) => {
    const { identifier, otp } = req.body;
    try {
        const db = await getDb();
        const user = await db.get('SELECT id FROM users WHERE (email = ? OR username = ?) AND recovery_otp = ? AND recovery_otp_expires > ?', [identifier, identifier, otp, Date.now()]);
        if (!user) {
            return sendResponse(res, 400, false, null, 'Invalid or expired verification code');
        }

        const recoveryToken = crypto.randomBytes(32).toString('hex');
        await db.run('UPDATE users SET recovery_token = ?, recovery_otp = NULL, recovery_otp_expires = NULL WHERE id = ?', [recoveryToken, user.id]);

        return sendResponse(res, 200, true, { recovery_token: recoveryToken }, 'Code verified successfully');
    } catch (error) {
        console.error('[Verify Recovery OTP] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};

exports.resetPasswordWithOTP = async (req, res) => {
    const { identifier, otp, newPassword } = req.body;
    try {
        const db = await getDb();
        // Fallback to checking the token if it's there via body or ignoring token and checking identifier and otp (since frontend doesn't send token)
        const user = await db.get('SELECT id FROM users WHERE (email = ? OR username = ?) AND (recovery_token IS NOT NULL OR (recovery_otp = ? AND recovery_otp_expires > ?))', [identifier, identifier, otp, Date.now()]);
        
        if (!user) {
            return sendResponse(res, 400, false, null, 'Invalid recovery session');
        }

        const hashedPassword = await bcrypt.hash(newPassword, 10);
        await db.run('UPDATE users SET password_hash = ?, recovery_token = NULL, recovery_otp = NULL, recovery_otp_expires = NULL WHERE id = ?', [hashedPassword, user.id]);
        await logService.recordLog(user.id, null, 'PASSWORD_RESET_OTP_SUCCESS', req.ip);

        return sendResponse(res, 200, true, null, 'Password reset successfully. You can now login.');
    } catch (error) {
        console.error('[Reset Password OTP] Error:', error);
        return sendResponse(res, 500, false, null, 'Server error');
    }
};
