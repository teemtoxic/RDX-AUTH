const { getDb } = require('../config/db');

exports.verifyAIStatus = async (req, res) => {
    const { accountId } = req.params;

    if (!accountId) {
        return res.status(400).json({ success: false, message: 'Account ID is required' });
    }

    try {
        const db = await getDb();
        const user = await db.get('SELECT id, username, plan, groq_api_key, tavily_api_key FROM users WHERE id = ?', [accountId]);

        if (!user) {
            return res.status(404).json({ success: false, message: 'Account not found' });
        }

        // Plan Check: Only PRO users get the full AI experience
        const isPro = (user.plan && user.plan.toUpperCase().includes('PRO'));

        res.json({
            success: true,
            exists: true,
            username: user.username,
            plan: user.plan,
            isPro: isPro,
            config: {
                groq_api_key: isPro ? user.groq_api_key : null,
                tavily_api_key: isPro ? user.tavily_api_key : null
            }
        });
    } catch (error) {
        console.error('[AI Verify Error]', error);
        res.status(500).json({ success: false, message: 'Database error' });
    }
};

exports.executeAIAction = async (req, res) => {
    const { accountId, action, params } = req.body;

    try {
        const db = await getDb();

        // Security Check: Only PRO users (or Professional) can execute actions
        const user = await db.get('SELECT id, plan, username, email FROM users WHERE id = ?', [accountId]);

        if (!user || !user.plan || !user.plan.toUpperCase().includes('PRO')) {
            return res.status(403).json({ success: false, message: 'Pro/Professional Plan Required for AI Actions' });
        }

        console.log(`[AI-ACTION] ${user.username} (ID: ${accountId}) triggered: ${action}`);

        switch (action) {
            case 'GET_EXPIRY':
                // RETURNS ONLY EXPIRY INFO
                const expiryData = await db.get('SELECT expiry_date, plan FROM users WHERE id = ?', [user.id]);
                if (!expiryData || !expiryData.expiry_date) {
                    return res.json({ success: true, message: 'Sir, aapka expiry data account mein nahi mila.' });
                }
                const expDate = new Date(expiryData.expiry_date);
                res.json({
                    success: true,
                    message: `Sir, aapka ${expiryData.plan} plan ${expDate.toLocaleDateString()} ko khatam ho raha hai.`,
                    data: { expiry: expiryData.expiry_date }
                });
                break;

            case 'GET_STATS':
                // RETURNS TOTAL COUNTS AND UNIQUE TARGETS IF THEY EXIST
                const s_apps = await db.all('SELECT id, name FROM apps WHERE owner_id = ?', [user.id]);
                const s_keys = await db.all('SELECT l.license_key FROM licenses l JOIN apps a ON l.app_id = a.id WHERE a.owner_id = ?', [user.id]);
                const s_membersCount = await db.get('SELECT COUNT(*) as count FROM users u JOIN apps a ON u.app_id = a.id WHERE a.owner_id = ?', [user.id]);

                const statsData = {
                    apps: s_apps.length,
                    members: s_membersCount.count,
                    keys: s_keys.length,
                    only_app: s_apps.length === 1 ? s_apps[0] : null,
                    only_key: s_keys.length === 1 ? s_keys[0].license_key : null,
                    only_key_app: s_keys.length === 1 ? (await db.get('SELECT a.name FROM apps a JOIN licenses l ON l.app_id = a.id WHERE l.license_key = ?', [s_keys[0].license_key]))?.name : null
                };

                let statsMsg = `Sir, aapke account mein ${statsData.apps} Apps, ${statsData.members} Members aur ${statsData.keys} Licenses active hain.`;
                if (statsData.only_app) statsMsg += ` (Unique App: ${statsData.only_app.name})`;
                if (statsData.only_key) statsMsg += ` (Unique Key: ${statsData.only_key} for App: ${statsData.only_key_app})`;

                res.json({
                    success: true,
                    message: statsMsg,
                    data: statsData
                });
                break;

            case 'GET_APPS':
                // RETURNS ONLY APP NAMES AND MEMBER COUNTS
                const appsList = await db.all(`
                    SELECT a.id, a.name, COUNT(u.id) as member_count 
                    FROM apps a 
                    LEFT JOIN users u ON u.app_id = a.id 
                    WHERE a.owner_id = ? 
                    GROUP BY a.id`, [user.id]);
                const appStr = appsList.map(a => `${a.name} (ID: ${a.id}) [${a.member_count} members]`).join(', ');
                res.json({
                    success: true,
                    message: `Sir, aapke apps hain: ${appStr || 'none'}.`,
                    data: appsList
                });
                break;

            case 'FETCH_PAYMENTS':
                // Verify if user has pending plan requests
                const payments = await db.all('SELECT plan, transaction_id, status, created_at FROM plan_requests WHERE user_id = ? ORDER BY created_at DESC LIMIT 3', [user.id]);
                let payMsg = `Sir, aapki payment history check kar li gayi hai.`;
                if (payments.length === 0) payMsg = "Sir, aapka koi payment record nahi mila.";

                res.json({ success: true, message: payMsg, data: payments });
                break;

            case 'FETCH_MEMBER':
                let targetUsername = params.username;
                if (!targetUsername) {
                    const ownedMembers = await db.all('SELECT u.username FROM users u JOIN apps a ON u.app_id = a.id WHERE a.owner_id = ?', [user.id]);
                    if (ownedMembers.length === 1) targetUsername = ownedMembers[0].username;
                    else return res.json({ success: false, message: 'Sir, multiple members hain, please username specify karein.' });
                }

                const mDetails = await db.get(`
                    SELECT u.username, u.status, u.expiry_date, u.created_at, a.name as app_name 
                    FROM users u 
                    JOIN apps a ON u.app_id = a.id 
                    WHERE u.username = ? COLLATE NOCASE AND a.owner_id = ?`, [targetUsername, user.id]);

                if (!mDetails) return res.json({ success: false, message: `Sir, member '${targetUsername}' nahi mila.` });

                const mExpStatus = new Date(mDetails.expiry_date) < new Date() ? 'expired' : `expiry: ${new Date(mDetails.expiry_date).toLocaleDateString()}`;
                res.json({
                    success: true,
                    message: `Ji Sir, details: User ${mDetails.username}, App ${mDetails.app_name}, Status ${mDetails.status}, ${mExpStatus}.`,
                    data: mDetails
                });
                break;

            case 'CREATE_USER':
                // User Creation API
                const { username, password, app_id, duration } = params;
                if (!username || !password) return res.json({ success: false, message: 'Username/Password required' });

                let tAppId = app_id;
                if (!tAppId) {
                    const ownedApps = await db.all('SELECT id FROM apps WHERE owner_id = ?', [user.id]);
                    if (ownedApps.length === 1) tAppId = ownedApps[0].id;
                    else return res.json({ success: false, message: 'Sir, multiple apps hain, please app_id specify karein.' });
                }

                const bcrypt = require('bcryptjs');
                const hPass = await bcrypt.hash(password, 10);
                const uExp = new Date();
                uExp.setDate(uExp.getDate() + (parseInt(duration) || 30));

                await db.run('INSERT INTO users (username, password_hash, role, status, app_id, expiry_date) VALUES (?, ?, "user", "active", ?, ?)',
                    [username, hPass, tAppId, uExp.toISOString()]);

                res.json({ success: true, message: `Member ${username} create kar diya gaya hai, Sir.` });
                break;

            case 'DELETE_USER':
            case 'BAN_USER':
            case 'UNBAN_USER':
                // Member management logic
                let targetManageUser = params.username;
                if (!targetManageUser) {
                    const ownedMembers = await db.all('SELECT u.username FROM users u JOIN apps a ON u.app_id = a.id WHERE a.owner_id = ?', [user.id]);
                    if (ownedMembers.length === 1) targetManageUser = ownedMembers[0].username;
                    else return res.json({ success: false, message: 'Sir, multiple members hain, please username specify karein.' });
                }

                const targetU = await db.get('SELECT u.id FROM users u JOIN apps a ON u.app_id = a.id WHERE u.username = ? COLLATE NOCASE AND a.owner_id = ?', [targetManageUser, user.id]);
                if (!targetU) return res.json({ success: false, message: 'Member unauthorized ya missing hai.' });

                if (action === 'DELETE_USER') {
                    await db.run('DELETE FROM users WHERE id = ?', [targetU.id]);
                    res.json({ success: true, message: `Member ${params.username} deleted.` });
                } else {
                    const status = action === 'BAN_USER' ? 'banned' : 'active';
                    await db.run('UPDATE users SET status = ? WHERE id = ?', [status, targetU.id]);
                    res.json({ success: true, message: `Member ${params.username} is now ${status}.` });
                }
                break;

            case 'CREATE_APP':
                if (!params.name) return res.json({ success: false, message: 'App name required' });
                const crypto = require('crypto');
                const ok = crypto.randomBytes(8).toString('hex').toUpperCase();
                const sec = crypto.randomBytes(16).toString('hex').toUpperCase();

                const existingApp = await db.get('SELECT id FROM apps WHERE name = ?', [params.name]);
                if (existingApp) {
                    return res.json({ success: false, message: `Sir, app '${params.name}' already exists. Please choose a different name.` });
                }

                await db.run('INSERT INTO apps (name, owner_id, owner_key, secret) VALUES (?, ?, ?, ?)', [params.name, user.id, ok, sec]);
                res.json({ success: true, message: `App '${params.name}' created, Sir.` });
                break;

            case 'DELETE_APP':
                let targetDelAppId = params.app_id;
                if (!targetDelAppId) {
                    const ownedApps = await db.all('SELECT id FROM apps WHERE owner_id = ?', [user.id]);
                    if (ownedApps.length === 1) targetDelAppId = ownedApps[0].id;
                    else return res.json({ success: false, message: 'Sir, multiple apps hain, please app_id specify karein.' });
                }

                const aDel = await db.get('SELECT id FROM apps WHERE id = ? AND owner_id = ?', [targetDelAppId, user.id]);
                if (!aDel) return res.json({ success: false, message: 'App unauthorized or not found.' });

                try {
                    await db.run('BEGIN TRANSACTION');
                    await db.run('DELETE FROM variables WHERE app_id = ?', [aDel.id]);
                    await db.run('DELETE FROM logs WHERE app_id = ?', [aDel.id]);
                    await db.run('DELETE FROM licenses WHERE app_id = ?', [aDel.id]);
                    await db.run('DELETE FROM users WHERE app_id = ?', [aDel.id]);
                    await db.run('DELETE FROM apps WHERE id = ?', [aDel.id]);
                    await db.run('COMMIT');
                    res.json({ success: true, message: `App #${targetDelAppId} and its associated data have been purged, Sir.` });
                } catch (delError) {
                    await db.run('ROLLBACK');
                    console.error('[AI DELETE_APP Error]', delError);
                    res.json({ success: false, message: 'Error deleting app due to conflict.' });
                }
                break;

            case 'MAINTENANCE_MODE':
                const mStatus = (params.status === 'on' || params.status === 'true') ? 'true' : 'false';
                await db.run('INSERT INTO system_settings (key, value) VALUES ("maintenance_mode", ?) ON CONFLICT(key) DO UPDATE SET value = ?', [mStatus, mStatus]);
                res.json({ success: true, message: `System-wide maintenance turned ${mStatus}, Sir.` });
                break;

            case 'CREATE_TICKET':
                if (!params.subject || !params.message) return res.json({ success: false, message: 'Subject/Message required' });

                // Final Auto-Detection Safeguard: If AI forgot user/app context, check stats
                let finalMsg = params.message;
                const checkA = await db.all('SELECT id, name FROM apps WHERE owner_id = ?', [user.id]);
                if (checkA.length === 1 && !finalMsg.includes(checkA[0].name)) {
                    finalMsg = `[Context: App ${checkA[0].name}] ` + finalMsg;
                }

                // Validation
                if (finalMsg.length < 15) {
                    return res.json({ success: false, message: 'Sir, please ticket ka reason details mein batayein.' });
                }

                try {
                    await db.run('BEGIN TRANSACTION');
                    // Add category if schema allows, otherwise default to context
                    await db.run('INSERT INTO tickets (user_id, subject, status) VALUES (?, ?, "pending")', [user.id, params.subject]);
                    const ticketObj = await db.get('SELECT id FROM tickets WHERE user_id = ? ORDER BY id DESC LIMIT 1', [user.id]);
                    await db.run('INSERT INTO ticket_messages (ticket_id, sender_id, message) VALUES (?, ?, ?)', [ticketObj.id, user.id, finalMsg]);
                    await db.run('COMMIT');
                    res.json({ success: true, message: `Ticket #${ticketObj.id} successfully created, Sir.` });
                } catch (tError) {
                    await db.run('ROLLBACK');
                    throw tError;
                }
                break;

            case 'GENERATE_KEY':
                // Simplified Key Generation
                let targetKeyAppId = params.app_id;
                if (!targetKeyAppId) {
                    const userApps = await db.all('SELECT id FROM apps WHERE owner_id = ?', [user.id]);
                    if (userApps.length === 0) return res.json({ success: false, message: 'Aapke paas koi app nahi hai, Sir.' });
                    if (userApps.length === 1) {
                        targetKeyAppId = userApps[0].id;
                    } else {
                        return res.json({ success: false, message: 'Please specify app_id. Apps: ' + userApps.map(a => `${a.name}(${a.id})`).join(', ') });
                    }
                }

                const knk = 'K-' + Math.random().toString(36).substring(2, 6).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase();
                const kExp = new Date();
                kExp.setDate(kExp.getDate() + (parseInt(params.duration) || 1));
                await db.run('INSERT INTO licenses (license_key, app_id, duration, status, expiry_date) VALUES (?, ?, ?, "active", ?)', [knk, targetKeyAppId, params.duration || '1 day', kExp.toISOString()]);
                res.json({ success: true, message: `Key generated: ${knk}`, data: { key: knk } });
                break;

            case 'SEND_DISCORD_MESSAGE':
                if (!params.channel_id || !params.message) return res.json({ success: false, message: 'Channel ID and Message are required' });
                const discordSvc = require('../utils/discordService');
                await discordSvc.sendToChannel(params.channel_id, params.message);
                res.json({ success: true, message: 'Message sent to Discord successfully.' });
                break;

            case 'SCHEDULE_TASK':
                if (!params.action || !params.cron_expression) return res.json({ success: false, message: 'Action and Cron Expression required for scheduling.' });
                
                const ALLOWED_AI_ACTIONS = ['CREATE_FREE_KEY', 'DISCORD_POST'];
                if (!ALLOWED_AI_ACTIONS.includes(params.action)) {
                    return res.json({ success: false, message: 'Invalid or unauthorized action for scheduling.' });
                }

                const scResult = await db.run(
                    'INSERT INTO scheduled_tasks (owner_id, action, payload, cron_expression) VALUES (?, ?, ?, ?)',
                    [user.id, params.action, JSON.stringify(params.payload || {}), params.cron_expression]
                );
                const sched = require('../utils/scheduler');
                const tInfo = await db.get('SELECT * FROM scheduled_tasks WHERE id = ?', [scResult.lastID]);
                sched.scheduleTask(tInfo);
                res.json({ success: true, message: `Task scheduled: ${params.action} at ${params.cron_expression}`, data: tInfo });
                break;

            default:
                res.status(400).json({ success: false, message: `Unknown action: ${action}` });
        }
    } catch (error) {
        console.error('[AI Action Error]', error);
        res.status(500).json({ success: false, message: 'Execution failed' });
    }
};
