const { getDb } = require('../config/db');
const logService = require('../utils/logService');
const fs = require('fs');
const path = require('path');

exports.getBlacklist = async (req, res) => {
    try {
        const db = await getDb();
        const isAdmin = req.user.role === 'admin';

        let query = 'SELECT * FROM blacklist';
        const params = [];

        if (!isAdmin) {
            // Only show blacklist entries for apps owned by this user
            query = `
                SELECT b.* FROM blacklist b
                JOIN apps a ON b.app_id = a.id
                WHERE a.owner_id = ?
            `;
            params.push(req.user.id);
        }

        query += ' ORDER BY created_at DESC';
        const blacklist = await db.all(query, params);
        res.json({ success: true, blacklist });
    } catch (error) {
        console.error('[RDX Security] GetBlacklist Error:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.addBlacklist = async (req, res) => {
    const { type, value, reason, app_id } = req.body;
    if (!type || !value) return res.status(400).json({ success: false, message: 'Type and Value are required' });

    try {
        const db = await getDb();
        const isAdmin = req.user.role === 'admin';

        // 1. If global (app_id is null/missing), only admin can add
        if (!app_id && !isAdmin) {
             return res.status(403).json({ success: false, message: 'Access denied: Only admins can add global blacklist entries' });
        }

        // 2. If app-specific, verify ownership
        if (app_id && !isAdmin) {
            const app = await db.get('SELECT id FROM apps WHERE id = ? AND owner_id = ?', [app_id, req.user.id]);
            if (!app) return res.status(403).json({ success: false, message: 'Access denied: You do not own this app' });
        }

        await db.run(
            'INSERT INTO blacklist (type, value, reason, app_id) VALUES (?, ?, ?, ?)',
            [type, value, reason, app_id || null]
        );
        await logService.recordLog(req.user.id, app_id || null, `BLACK-LIST ADD: ${type.toUpperCase()} (${value}) Reason: ${reason || 'N/A'}`);
        res.json({ success: true, message: `${type.toUpperCase()} added to blacklist` });
    } catch (error) {
        if (error.code === 'SQLITE_CONSTRAINT') {
            return res.status(400).json({ success: false, message: 'This entry is already blacklisted' });
        }
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.removeBlacklist = async (req, res) => {
    const { id } = req.body;
    if (!id) return res.status(400).json({ success: false, message: 'ID is required' });

    try {
        const db = await getDb();
        const isAdmin = req.user.role === 'admin';

        // Fetch entry to check ownership
        const entry = await db.get('SELECT app_id FROM blacklist WHERE id = ?', [id]);
        if (!entry) return res.status(404).json({ success: false, message: 'Entry not found' });

        if (!isAdmin) {
            if (!entry.app_id) {
                return res.status(403).json({ success: false, message: 'Access denied: Global entries can only be removed by admins' });
            }
            const app = await db.get('SELECT id FROM apps WHERE id = ? AND owner_id = ?', [entry.app_id, req.user.id]);
            if (!app) return res.status(403).json({ success: false, message: 'Access denied: You do not own this app' });
        }

        await db.run('DELETE FROM blacklist WHERE id = ?', [id]);
        await logService.recordLog(req.user.id, null, `BLACK-LIST REMOVE: ID ${id}`);
        res.json({ success: true, message: 'Entry removed from blacklist' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.updateAppSecurity = async (req, res) => {
    const { app_id, vpn_detection, debugger_detection, integrity_check, force_update } = req.body;
    const userId = req.user.id;
    const isAdmin = req.user.role === 'admin';

    if (!app_id) return res.status(400).json({ success: false, message: 'App ID is required' });

    try {
        const db = await getDb();

        // Verify ownership if not admin
        if (!isAdmin) {
            const app = await db.get('SELECT id FROM apps WHERE id = ? AND owner_id = ?', [app_id, userId]);
            if (!app) return res.status(403).json({ success: false, message: 'Access denied' });
        }

        await db.run(
            `UPDATE apps SET 
            vpn_detection = ?, 
            debugger_detection = ?, 
            integrity_check = ?, 
            force_update = ? 
            WHERE id = ?`,
            [vpn_detection ? 1 : 0, debugger_detection ? 1 : 0, integrity_check ? 1 : 0, force_update ? 1 : 0, app_id]
        );
        await logService.recordLog(req.user.id, app_id, `SECURITY SETTINGS UPDATE`);
        res.json({ success: true, message: 'Security settings updated successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.getAppSecurity = async (req, res) => {
    const { app_id } = req.query;
    const userId = req.user.id;
    const isAdmin = req.user.role === 'admin';

    if (!app_id) return res.status(400).json({ success: false, message: 'App ID is required' });

    try {
        const db = await getDb();

        // Verify ownership if not admin
        if (!isAdmin) {
            const app = await db.get('SELECT id FROM apps WHERE id = ? AND owner_id = ?', [app_id, userId]);
            if (!app) return res.status(403).json({ success: false, message: 'Access denied' });
        }

        const settings = await db.get(
            'SELECT vpn_detection, debugger_detection, integrity_check, force_update FROM apps WHERE id = ?',
            [app_id]
        );
        res.json({ success: true, settings });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.getIntel = async (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ success: false, message: 'Admin only' });
    try {
        const logPath = path.join(__dirname, '../../threat_intel.log');
        if (!fs.existsSync(logPath)) {
            return res.json({ success: true, intel: [] });
        }

        const stats = fs.statSync(logPath);
        const fileSize = stats.size;
        const bufferSize = Math.min(fileSize, 16384); // Read last 16KB
        const buffer = Buffer.alloc(bufferSize);
        const fd = fs.openSync(logPath, 'r');
        fs.readSync(fd, buffer, 0, bufferSize, fileSize - bufferSize);
        fs.closeSync(fd);

        const data = buffer.toString('utf8');
        const lines = data.trim().split('\n').reverse().slice(0, 100);

        const intel = lines.map(line => {
            const parts = line.split(' | ');
            if (parts.length < 5) return null;

            // Format: [INTEL] 2026-02-19T08:51:52.596Z | IP: ::ffff:127.0.0.1 | PATH: / | FP: N/A | REF: Direct
            const timestampPart = parts[0].includes('[INTEL] ') ? parts[0].replace('[INTEL] ', '') : parts[0];
            const ip = parts[1].replace('IP: ', '');
            const pathUrl = parts[2].replace('PATH: ', '');
            const fp = parts[3].replace('FP: ', '');
            const ref = parts[4].replace('REF: ', '');

            return { timestamp: timestampPart, ip, path: pathUrl, fp, ref };
        }).filter(item => item !== null);

        res.json({ success: true, intel });
    } catch (error) {
        console.error('[RDX Security] GetIntel Error:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.clearIntel = async (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ success: false, message: 'Admin only' });

    try {
        const logPath = path.join(__dirname, '../../threat_intel.log');
        fs.writeFileSync(logPath, ''); // Truncate file
        await logService.recordLog(req.user.id, null, `SECURITY INTEL CLEAR: Wiped threat_intel.log`);
        res.json({ success: true, message: 'Threat Intelligence logs cleared' });
    } catch (error) {
        console.error('[RDX Security] ClearIntel Error:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.getSystemSecurity = async (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ success: false, message: 'Admin only' });
    try {
        const db = await getDb();
        const settings = await db.all('SELECT key, value FROM system_settings WHERE key LIKE "security_%"');
        const result = {};
        settings.forEach(s => {
            result[s.key] = s.value;
        });

        // Ensure defaults
        if (result['security_anti_bot_enabled'] === undefined) result['security_anti_bot_enabled'] = '1';

        res.json({ success: true, settings: result });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.updateSystemSecurity = async (req, res) => {
    const { anti_bot_enabled } = req.body;
    if (req.user.role !== 'admin') return res.status(403).json({ success: false, message: 'Admin only' });

    try {
        const db = await getDb();
        await db.run(
            'INSERT INTO system_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = ?',
            ['security_anti_bot_enabled', anti_bot_enabled ? '1' : '0', anti_bot_enabled ? '1' : '0']
        );

        await logService.recordLog(req.user.id, null, `SYSTEM SECURITY UPDATE: Anti-Bot ${anti_bot_enabled ? 'ENABLED' : 'DISABLED'}`);
        res.json({ success: true, message: 'System security updated' });
    } catch (error) {
        console.error('[RDX Security] UpdateSystemSecurity Error:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.getAppLogins = async (req, res) => {
    const { app_id } = req.query;
    if (!app_id) return res.status(400).json({ success: false, message: 'App ID is required' });

    try {
        const db = await getDb();
        const isAdmin = req.user.role === 'admin';

        // Verify ownership if not admin
        if (!isAdmin) {
            const app = await db.get('SELECT id FROM apps WHERE id = ? AND owner_id = ?', [app_id, req.user.id]);
            if (!app) return res.status(403).json({ success: false, message: 'Access denied' });
        }

        // Fetch last 50 logins for this app (Success or Failed) to show activity stream
        const logins = await db.all(
            `SELECT l.timestamp, l.ip, l.hwid, l.action, u.username 
             FROM logs l
             LEFT JOIN users u ON l.user_id = u.id
             WHERE l.app_id = ? 
             AND (l.action LIKE 'LOGIN%' OR l.action LIKE 'AUTH%' OR l.action LIKE 'VALIDATE%' OR l.action LIKE 'USER_LOGIN%' OR l.action LIKE 'APP_LOGIN%' OR l.action LIKE '%SDK%')
             ORDER BY l.timestamp DESC LIMIT 50`,
            [app_id]
        );

        res.json({ success: true, logins });
    } catch (error) {
        console.error('[RDX Security] GetAppLogins Error:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

exports.getRealtimeTraffic = async (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ success: false, message: 'Admin only' });
    try {
        const db = await getDb();
        const fiveMinsAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();

        const traffic = await db.all(
            `SELECT strftime('%Y-%m-%dT%H:%M:00', timestamp) as time, COUNT(*) as count 
             FROM logs 
             WHERE timestamp > ? 
             GROUP BY time 
             ORDER BY time ASC`,
            [fiveMinsAgo]
        );

        res.json({ success: true, traffic });
    } catch (error) {
        console.error('[RDX Security] GetRealtimeTraffic Error:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};
