const { getDb } = require('../config/db');
const logService = require('../utils/logService');
const discordService = require('../utils/discordService');
const emailService = require('../utils/emailService');

// --- USER ACTIONS ---

exports.createTicket = async (req, res) => {
    const { subject, message, category, attachment_url } = req.body;
    const userId = req.user.id;

    if (!subject || !message || !category) {
        return res.status(400).json({ success: false, message: 'Subject, message, and category are required' });
    }

    let transactionStarted = false;
    try {
        const db = await getDb();
        await db.run('BEGIN TRANSACTION');
        transactionStarted = true;

        const result = await db.run(
            'INSERT INTO tickets (user_id, subject, category, status, attachment_url) VALUES (?, ?, ?, ?, ?)',
            [userId, subject, category, 'pending', attachment_url || null]
        );
        const ticketId = result.lastID;

        await db.run(
            'INSERT INTO ticket_messages (ticket_id, sender_id, message) VALUES (?, ?, ?)',
            [ticketId, userId, message]
        );

        await db.run('COMMIT');
        transactionStarted = false;

        // Discord Notification to Admin (Removed per user request to avoid cluttering client log channels)
        /*
        const admin = await db.get("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
        if (admin) {
            discordService.sendLogToDiscord(admin.id, 'NEW TICKET', `User **${req.user.username}** opened a [${category}] ticket: *${subject}*`);
        }
        */

        // Email Notification to User
        const user = await db.get('SELECT email, username FROM users WHERE id = ?', [userId]);
        if (user && user.email) {
            console.log(`[RDX Email Trigger] Sending Ticket Created email to: ${user.email}`);
            await emailService.sendTicketCreatedEmail(user.email, user.username, { id: ticketId, subject, category });
        } else {
            console.log(`[RDX Email Trigger] Skipping Ticket Created email: ${user ? 'No email for ' + user.username : 'User not found'}`);
        }

        await logService.recordLog(userId, null, `TICKET CREATED [${category}]: ${subject}`);
        res.json({ success: true, message: 'Ticket created successfully', ticketId });

    } catch (error) {
        console.error('[RDX Ticket Creation Error]:', error);
        if (transactionStarted) {
            try {
                const db = await getDb();
                await db.run('ROLLBACK');
            } catch (rollbackError) {
                console.error('[RDX Rollback Error]:', rollbackError);
            }
        }
        res.status(500).json({ success: false, message: 'Server error: ' + error.message });
    }
};

exports.getMyTickets = async (req, res) => {
    try {
        const db = await getDb();
        const tickets = await db.all(
            'SELECT * FROM tickets WHERE user_id = ? ORDER BY updated_at DESC',
            [req.user.id]
        );
        res.json({ success: true, tickets });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

exports.getTicketMessages = async (req, res) => {
    const { ticketId } = req.params;
    const userId = req.user.id;

    try {
        const db = await getDb();
        // Permission check
        const ticket = await db.get('SELECT * FROM tickets WHERE id = ?', [ticketId]);
        if (!ticket || (ticket.user_id !== userId && req.user.role !== 'admin')) {
            return res.status(403).json({ success: false, message: 'Access denied' });
        }

        const messages = await db.all(
            `SELECT tm.*, u.username as sender_name, u.role as sender_role 
             FROM ticket_messages tm 
             JOIN users u ON tm.sender_id = u.id 
             WHERE tm.ticket_id = ? ORDER BY tm.timestamp ASC`,
            [ticketId]
        );

        res.json({ success: true, ticket, messages });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

exports.addMessage = async (req, res) => {
    const { ticketId } = req.params;
    const { message } = req.body;
    const userId = req.user.id;

    try {
        const db = await getDb();
        const ticket = await db.get('SELECT * FROM tickets WHERE id = ?', [ticketId]);

        if (!ticket || (ticket.user_id !== userId && req.user.role !== 'admin')) {
            return res.status(403).json({ success: false, message: 'Access denied' });
        }

        await db.run(
            'INSERT INTO ticket_messages (ticket_id, sender_id, message) VALUES (?, ?, ?)',
            [ticketId, userId, message]
        );

        // Update ticket timestamp and status if admin replied
        let newStatus = ticket.status;
        if (req.user.role === 'admin') {
            newStatus = 'open'; // Admin replied, mark as open/active
        } else if (ticket.status === 'resolved') {
            newStatus = 'open'; // User replied to a resolved ticket, reopen it
        }

        await db.run(
            'UPDATE tickets SET updated_at = CURRENT_TIMESTAMP, status = ? WHERE id = ?',
            [newStatus, ticketId]
        );

        res.json({ success: true, message: 'Message sent' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// --- ADMIN ACTIONS ---

exports.getAllTickets = async (req, res) => {
    const { status, category, page = 1, limit = 8 } = req.query;
    const offset = (page - 1) * limit;

    try {
        const db = await getDb();
        let query = 'SELECT t.*, u.username as username FROM tickets t JOIN users u ON t.user_id = u.id';
        let countQuery = 'SELECT COUNT(*) as total FROM tickets t';
        const params = [];
        const countParams = [];

        const conditions = [];
        if (status && status !== 'all') {
            conditions.push('t.status = ?');
            params.push(status);
            countParams.push(status);
        }
        if (category && category !== 'all') {
            conditions.push('t.category = ?');
            params.push(category);
            countParams.push(category);
        }

        if (conditions.length > 0) {
            const whereClause = ' WHERE ' + conditions.join(' AND ');
            query += whereClause;
            countQuery += whereClause;
        }

        query += ' ORDER BY t.updated_at DESC LIMIT ? OFFSET ?';
        params.push(parseInt(limit), parseInt(offset));

        const [tickets, countResult] = await Promise.all([
            db.all(query, params),
            db.get(countQuery, countParams)
        ]);

        const total = countResult.total;
        const pages = Math.ceil(total / limit);

        res.json({
            success: true,
            tickets,
            pagination: {
                total,
                page: parseInt(page),
                pages,
                limit: parseInt(limit)
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

exports.bulkDeleteTickets = async (req, res) => {
    const { ids } = req.body; // Expecting an array [1, 2, 3]

    if (!ids || !Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ success: false, message: 'No ticket IDs provided' });
    }

    try {
        const db = await getDb();
        const placeholders = ids.map(() => '?').join(',');
        
        await db.run('BEGIN TRANSACTION');
        try {
            await db.run(`DELETE FROM ticket_messages WHERE ticket_id IN (${placeholders})`, ids);
            await db.run(`DELETE FROM tickets WHERE id IN (${placeholders})`, ids);
            await db.run('COMMIT');
        } catch (dbError) {
            await db.run('ROLLBACK');
            throw dbError;
        }

        await logService.recordLog(req.user.id, null, `BULK TICKETS DELETED: ${ids.join(', ')}`);
        res.json({ success: true, message: `${ids.length} tickets deleted` });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error constraints or transaction fail' });
    }
};

exports.updateTicketStatus = async (req, res) => {
    const { ticketId } = req.params;
    const { status } = req.body;

    try {
        const db = await getDb();
        await db.run(
            'UPDATE tickets SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
            [status, ticketId]
        );

        if (status === 'resolved') {
            // Fetch user info for email and Discord
            const ticket = await db.get(`
                SELECT t.subject, u.email, u.username, u.app_id 
                FROM tickets t 
                JOIN users u ON t.user_id = u.id 
                WHERE t.id = ?
            `, [ticketId]);

            if (ticket) {
                // 1. Email Notification
                if (ticket.email) {
                    console.log(`[RDX Email Trigger] Sending Ticket Resolved email to: ${ticket.email}`);
                    await emailService.sendTicketResolvedEmail(ticket.email, ticket.username, ticketId, ticket.subject);
                }

                // 2. Discord Notification to Owner (Client)
                // If user belongs to an app, notify the app owner
                if (ticket.app_id) {
                    const app = await db.get('SELECT owner_id FROM apps WHERE id = ?', [ticket.app_id]);
                    if (app) {
                        discordService.sendLogToDiscord(app.owner_id, 'TICKET RESOLVED', `Ticket **#${ticketId}** (${ticket.subject}) for user **${ticket.username}** has been marked as **RESOLVED**.`);
                    }
                } else {
                    // If no app_id, the user might be a Client themselves. Notify them directly if they have a log channel.
                    const user = await db.get('SELECT id FROM users WHERE username = ?', [ticket.username]);
                    if (user) {
                        discordService.sendLogToDiscord(user.id, 'TICKET RESOLVED', `Your ticket **#${ticketId}** (${ticket.subject}) has been marked as **RESOLVED**.`);
                    }
                }
            }
        }

        await logService.recordLog(req.user.id, null, `TICKET STATUS UPDATED: ID ${ticketId} -> ${status}`);
        res.json({ success: true, message: `Ticket ${status}` });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
