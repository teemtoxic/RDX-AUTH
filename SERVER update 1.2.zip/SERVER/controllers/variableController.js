const crypto = require('crypto');
const { getDb } = require('../config/db');
const logService = require('../utils/logService');

exports.getVariables = async (req, res) => {
    const { owner_key, app_id, timestamp, signature } = req.query;

    if (!owner_key && !app_id) {
        return res.status(400).json({ success: false, message: 'Owner Key or App ID is required' });
    }

    try {
        const db = await getDb();
        let app;

        if (owner_key) {
            app = await db.get('SELECT id, secret FROM apps WHERE owner_key = ?', [owner_key]);
        } else {
            app = await db.get('SELECT id, secret FROM apps WHERE id = ?', [app_id]);
        }

        if (!app) {
            return res.status(404).json({ success: false, message: 'Application not found' });
        }

        // 2. Verify Signature (Security)
        if (!signature) {
            return res.status(403).json({ success: false, message: 'Request Signature is required' });
        }

        const dataToSign = `${owner_key || app_id}${timestamp || ''}`;
        const expectedSignature = crypto.createHmac('sha256', app.secret)
            .update(dataToSign)
            .digest('hex');

        if (signature !== expectedSignature) {
            return res.status(403).json({ success: false, message: 'Invalid Request Signature' });
        }

        // 3. Fetch Variables
        const variables = await db.all('SELECT name, value FROM variables WHERE app_id = ?', [app.id]);

        const varObj = {};
        variables.forEach(v => {
            varObj[v.name] = v.value;
        });

        res.json({ success: true, variables: varObj });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

exports.updateVariable = async (req, res) => {
    const { app_id, name, value } = req.body;
    const ownerId = req.user.id;

    try {
        const db = await getDb();

        const app = await db.get('SELECT id FROM apps WHERE id = ? AND owner_id = ?', [app_id, ownerId]);
        if (!app) {
            return res.status(403).json({ success: false, message: 'Unauthorized to modify this application' });
        }

        const existing = await db.get('SELECT id FROM variables WHERE app_id = ? AND name = ?', [app_id, name]);

        if (existing) {
            await db.run('UPDATE variables SET value = ? WHERE id = ?', [value, existing.id]);
        } else {
            await db.run('INSERT INTO variables (app_id, name, value) VALUES (?, ?, ?)', [app_id, name, value]);
        }

        await logService.recordLog(req.user?.id || null, app_id, `VARIABLE UPDATED: ${name} = ${value}`);

        res.json({ success: true, message: 'Variable updated' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.deleteVariable = async (req, res) => {
    const { app_id, name } = req.body;
    const ownerId = req.user.id;

    try {
        const db = await getDb();

        const app = await db.get('SELECT id FROM apps WHERE id = ? AND owner_id = ?', [app_id, ownerId]);
        if (!app) {
            return res.status(403).json({ success: false, message: 'Unauthorized to modify this application' });
        }

        await db.run('DELETE FROM variables WHERE app_id = ? AND name = ?', [app_id, name]);
        await logService.recordLog(req.user?.id || null, app_id, `VARIABLE DELETED: ${name}`);
        res.json({ success: true, message: 'Variable deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
