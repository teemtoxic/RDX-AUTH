@echo off
title RDX Mainframe Startup Manager
setlocal enabledelayedexpansion

echo.
echo  ##########################################################
echo  #                                                        #
echo  #          RDX MAINFRAME SYSTEM STARTUP v1.0             #
echo  #                                                        #
echo  ##########################################################
echo.

:: Get the directory of the batch file
set "BASE_DIR=%~dp0"
cd /d "%BASE_DIR%"

echo [!] [SYSTEM] Initializing Backend Server...
start "RDX BACKEND SERVER" cmd /c "node index.js"

echo [!] [SYSTEM] Waiting 5 seconds for server initialization...
timeout /t 5 /nobreak > nul

echo [!] [SYSTEM] Launching Cloudflare Tunnel...
:: We use the local cloudflared.exe and config.yml in the same directory
start "RDX CLOUDFLARE TUNNEL" cmd /c "cloudflared.exe tunnel run"

echo.
echo [v] [SUCCESS] All systems have been signaled to start.
echo [i] [INFO] Please monitor the separate windows for live logs.
echo.
pause
